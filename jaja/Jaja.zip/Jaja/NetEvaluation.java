// $Id: NetEvaluation.java,v 3.2 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class allows to handle a remote Evaluation. */

import java.rmi.registry.*;

public class NetEvaluation extends java.rmi.server.UnicastRemoteObject
  implements EvaluationAble {

  private EvaluationAble evaluation;

  public NetEvaluation (EvaluationAble ev) 
    throws java.rmi.RemoteException {
    evaluation = ev;
  }

  // Delegate the methods of the interface to the private world.

  public WorldAble getWorld () 
    throws java.rmi.RemoteException {
    System.err.println(this + ".getWorld()");  // trace 
    System.err.flush();
    return evaluation.getWorld();
  }
  public DynamicEnvironment getDynamicEnvironment ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getDynamicEnvironment()");  // trace 
    System.err.flush();
    return evaluation.getDynamicEnvironment();
  }
  public int getStatus ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getStatus()");  // trace 
    System.err.flush();
    return evaluation.getStatus();
  }
  public String getStatusName ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getStatusName()");  // trace 
    System.err.flush();
    return evaluation.getStatusName();
  }
  public Value obtain () 
    throws java.rmi.RemoteException {
    System.err.println(this + ".obtain()");  // trace 
    System.err.flush();
    try {
      Value v = evaluation.obtain();
      return v;
    } catch (Exception exc) {
      throw new java.rmi.RemoteException(exc.getMessage());
    }
  }
  public void start ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".start()");  // trace 
    System.err.flush();
    evaluation.start();
  }
  public void stop ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".stop()");  // trace 
    System.err.flush();
    evaluation.stop();
  }
  public void suspend ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".suspend()");  // trace 
    System.err.flush();
    evaluation.suspend();
  }
  public void resume ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".resume()");  // trace 
    System.err.flush();
    evaluation.resume();
  }

}

// end of NetEvaluation.java
