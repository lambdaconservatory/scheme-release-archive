/** @version $Id: GlobalEnvironment.java,v 2.6 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This the class of global environments.  When created, a global
 * environment is completely empty, it must be explicitly enriched by
 * the R4RS bindings as well as some other useful bindings. All these
 * enriching methods are separate to ease the construction of
 * user-tailored environments. A global environment may contain a value
 * or a box holding a value.  */

import java.util.Hashtable;

public class GlobalEnvironment extends Environment {

  private Hashtable table = new Hashtable(128);

  // The default constructor (ie GlobalEnvironment()) is sufficient.

  // Enriching methods

  /** Enrich a global environment with really primitive bindings ie
   * <tt>car</tt>, <tt>cons</tt> but not <tt>append</tt> which may be
   * defined easily in Scheme. */

  public synchronized GlobalEnvironment adjoinPredefinedBindings () {
    this.install("car",  PredefinedValues.car);
    this.install("cdr",  PredefinedValues.cdr);
    this.install("cons", PredefinedValues.cons);
    this.install("eq?", PredefinedValues.eqp);
    this.install("pair?", PredefinedValues.pairp);
    this.install("set-car!", PredefinedValues.set_car);
    this.install("set-cdr!", PredefinedValues.set_cdr);
    this.install("null?", PredefinedValues.nullp);
    this.install("symbol?", PredefinedValues.symbolp);
    this.install("string?", PredefinedValues.stringp);
    this.install("integer?", PredefinedValues.fixnump);
    this.install("number?", PredefinedValues.numberp);
    this.install("procedure?", PredefinedValues.procedurep);
    this.install("eof-object?", PredefinedValues.eofp);
    this.install("+", PredefinedValues.plus);
    // NOTE: - is recognized as 0 by Integer.parse ! This is not the
    // case for +!  That explains that minus is an alternate name.
    this.install("-", PredefinedValues.minus);
    this.install("*", PredefinedValues.times);
    this.install("/", PredefinedValues.divide);
    this.install("quotient", PredefinedValues.quotient);
    this.install("remainder", PredefinedValues.remainder);
    this.install("modulo", PredefinedValues.modulo);
    this.install("<=", PredefinedValues.lep);
    this.install(">=", PredefinedValues.gep);
    this.install("=", PredefinedValues.eqnp);
    this.install("<", PredefinedValues.ltp);
    this.install(">", PredefinedValues.gtp);
    this.install("display", PredefinedValues.display);
    this.install("newline", PredefinedValues.newline);
    this.install("list", PredefinedValues.list);
    this.install("make-vector", PredefinedValues.make_vector);
    this.install("vector-length", PredefinedValues.vector_length);
    this.install("vector-ref", PredefinedValues.vector_ref);
    this.install("vector-set!", PredefinedValues.vector_set);
    this.install("vector?", PredefinedValues.vectorp);
    this.install("string-length", PredefinedValues.string_length);
    this.install("string-ref", PredefinedValues.string_ref);
    this.install("string-set!", PredefinedValues.string_set);
    this.install("make-string", PredefinedValues.make_string);
    this.install("write", PredefinedValues.write);
    this.install("vector", PredefinedValues.vector);
    this.install("string", PredefinedValues.string);
    this.install("boolean?", PredefinedValues.booleanp);
    this.install("symbol->string", PredefinedValues.symbol_to_string);
    this.install("string->symbol", PredefinedValues.string_to_symbol);
    this.install("char?", PredefinedValues.charp);
    this.install("integer->char", PredefinedValues.integer_to_char);
    this.install("char->integer", PredefinedValues.char_to_integer);
    this.install("real?", PredefinedValues.floatnump);
    this.install("read", PredefinedValues.read);
    //[ Evaluation
    this.install("current-input-port", 
                 PredefinedValues.current_input_port);
    this.install("current-output-port", 
                 PredefinedValues.current_output_port);
    //] Evaluation
    this.install("open-input-file", PredefinedValues.open_input_file);
    this.install("open-output-file", PredefinedValues.open_output_file);
    this.install("close-input-port", PredefinedValues.close_input_port);
    this.install("close-output-port", PredefinedValues.close_output_port);
    // Others are still missing.
    return this;
  }

  /** Enrich a global environment with bindings that imply the
   * knowledge of the invocation protocol. These are, for the moment,
   * <tt>apply</tt> and <tt>call/ep</tt>. Other functions in the same
   * case such as <tt>map</tt> are not considered as primitive enough
   * to be there.  */

  public synchronized GlobalEnvironment adjoinSpecialPredefinedBindings () {
    this.install("call/ep", PredefinedValues.callep);
    this.install("apply", PredefinedValues.apply);
    return this;
  }

  /** Enrich a global environment with Jaja-specific bindings.  */

  public synchronized GlobalEnvironment adjoinOtherUsefulBindings () {
    // alphabetic names for arithmetic functions.
    this.install("plus", PredefinedValues.plus);
    this.install("minus", PredefinedValues.minus);
    this.install("times", PredefinedValues.times);
    // Non standard functions
    this.install("exit", PredefinedValues.exit);
    this.install("oblist", PredefinedValues.oblist);
    //[ Evaluation
    this.install("detach", PredefinedValues.detach);
    this.install("diagnose", PredefinedValues.diagnose);
    //] Evaluation
    return this;
  }

  // NOTE: don't forget to install eval, load and expand (@see World).

  // Basic operations for environments.
  
  /** Lookup for a value in a global environment. Dereference the Box if any. 
   * If the variable is not found, follow the 'next' link. */

  public synchronized Value lookup (String n) {
    if ( table.containsKey(n) ) {
      Value v = (Value)table.get(n);
      if ( v instanceof Box ) {
        // May bark if box is uninitialized.
        return ((Box)v).getBoxContent();
      } else {
        return v;
      }
    } else {
      if ( next instanceof Environment ) {
        return next.lookup(n);
      } else {
        throw new RuntimeException("No such binding " + n);
      }
    }
  }

  /** Modify the value a variable. Check if the binding is mutable. If
   * the variable is not found, create a new binding automatically. */

  public synchronized Value update (String n, Value v) {
    if ( table.containsKey(n) ) {
      Value vv = (Value)table.get(n);
      if ( vv instanceof Box ) {
        return ((Box)vv).setBoxContent(v);
      } else {
        throw new RuntimeException("Immutable binding" + n);
      }
    } else {
      table.put(n, new Box(v));
      return v;
    }
  }

  /** This method is used to install new bindings visible from the
   * interpreter as well as new Special operators. */

  private void install (String n, Value v) {
    Symbol.create(n);
    this.update(n, v);
  }

}

// end of GlobalEnvironment.java
