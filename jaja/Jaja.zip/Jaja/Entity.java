/** @version $Id: Entity.java,v 2.3 1997/12/07 18:58:54 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class is the top class for all entities needed by the implementation
 * which are not first-class values.
 */

public abstract class Entity extends Jaja {

  // There must be at least one thing inside this definition for
  // javadoc to process and output something from this class.
  // Is it still true ??????????
  static private int nothing = 0;

}

// end of Entity.java
