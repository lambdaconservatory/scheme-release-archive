// $Id: Eval.java,v 2.8 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class for the eval procedures (one per world).
 * When created such a procedure captures the current world.
 * Therefore this eval procedure is an eval-in-current-module function
 * however it inherits of the dynamic environment of the caller. */

public final class Eval extends Subr1 {

  private WorldAble world;

  // Constructor

  public Eval (World world) {
    super("eval");
    this.world = world;
  }

  // Invokers

  public Value invoke (Value args[]) {
    if ( args.length == 1 ) {
      return this.invoke(args[0]);
    } else {
      return super.invoke(args);
    }
  }

  /** Evaluate an expression specified as a Jaja value. This
   * evaluation inherits from the dynamic environment of the
   * caller. Anomalies that may occur during this evaluation are
   * transmitted to the caller. */

  public Value invoke (Value e) {
    DynamicEnvironment denv = Jaja.currentDynamicEnvironment();
    try {
      EvaluationAble ev = world.createEvaluation(e, denv);
      return ev.obtain();
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

}

// end of Eval.java
