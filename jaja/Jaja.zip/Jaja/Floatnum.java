/** @version $Id: Floatnum.java,v 2.1 1997/11/25 19:37:15 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This will be the class of Floatnums ie the class of inexact numbers
 * represented as floating point numbers.
 */

public class Floatnum extends Number {

  /* package */ final double value;

  // Constructor
  // Don't need to synchronize since a Floatnum is immutable.

  public Floatnum (double d) {
    value = d;
  }

  // Coercing

  public double doubleValue () {
    return value;
  }

  // Printing

  public String toString () {
    return "" + value;
  }

  // Comparing

  public boolean eqnp (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value == ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) == ((Floatnum)other).value );
    } else {
      return false;
    }
  }
  public boolean lep (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value <= ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) <= ((Floatnum)other).value );
    } else {
      return false;
    }
  }
  public boolean ltp (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value < ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) < ((Floatnum)other).value );
    } else {
      return false;
    }
  }

  // Operations

  public Number plus (Number other) {
    return other.floatnum_plus(this);
  }
  public Number fixnum_plus (Fixnum other) {
    double r = this.value + (double)(other.value);
    return new Floatnum(r);
  }
  public Number floatnum_plus (Floatnum other) {
    double r = this.value + other.value;
    return new Floatnum(r);
  }
  public Number minus (Number other) {
    return other.floatnum_minus(this);
  }
  public Number fixnum_minus (Fixnum other) {
    double r = this.value - (double)(other.value);
    return new Floatnum(r);
  }
  public Number floatnum_minus (Floatnum other) {
    double r = this.value - other.value;
    return new Floatnum(r);
  }
  public Number times (Number other) {
    return other.floatnum_times(this);
  }
  public Number fixnum_times (Fixnum other) {
    double r = this.value * (double)(other.value);
    return new Floatnum(r);
  }
  public Number floatnum_times (Floatnum other) {
    double r = this.value * other.value;
    return new Floatnum(r);
  }
    
}

// end of Floatnum.java
