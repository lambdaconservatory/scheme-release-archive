/** @version $Id: PredefinedValues.java,v 2.7 1998/11/27 18:05:42 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class exports many predefined values among which are all the
 * predefined procedures (cons, car, display ...). In a sense, this
 * class represents the global immutable predefined environment of
 * Scheme.
 *
 * <P> History:  These values were previously in Jaja.java but then any
 * Value instance had a 'cons', a 'car' or a 'display' static field
 * which is needless and at least confusing.  
 *
 * <P> Hint: You may use these functions through the Jaja invocation protocol.
 * For instance, you may write <PRE>
 *    PredefinedValues.cons.invoke(aValue, anotherValue) </PRE>
 *
 * <P> Note 1: This class uses internal classes, a feature of Java 1.1.
 *
 * <P> Note 2: These values are not kept in Boxes since these variables are
 * immutable.  The original name in Scheme is also recorded in the
 * value to help debugging. At this point you should distinguish three
 * different meanings for 'car': <UL>
 * <LI> the global variable (<CODE>PredefinedValues.car</CODE>)
 * <LI> the value of this global variable (here an instance of 
 *      <CODE>Subr1</CODE>)
 * <LI> the implementation primitive that follows the left pointer of any
 * given pair (ie the method <CODE>Procedure.car</CODE>). </UL>
 * <p> @see Procedure
 */

public final class PredefinedValues extends Jaja {

  public static Subr1 car =
    new Subr1("car") {
      public Value invoke (Value a) {
        return Procedure.car(a);
      }
  };
  public static Subr1 cdr =
    new Subr1("cdr") {
      public Value invoke (Value a) {
        return Procedure.cdr(a);
      }
  };
  public static Subr2 cons =
    new Subr2("cons") {
      public Value invoke (Value a, Value b) {
        return Procedure.cons(a, b);
      }
  };
  public static Subr2 eqp =
    new Subr2("eq?") {
      public Value invoke (Value a, Value b) {
        return Procedure.eqp(a, b);
      }
  };
  public static Subr1 pairp =
    new Subr1("pair?") {
      public Value invoke (Value a) {
        return Procedure.pairp(a);
      }
  };
  public static Subr2 set_car =
    new Subr2("set-car!") {
      public Value invoke (Value a, Value b) {
        return Procedure.set_car(a, b);
      }
  };
  public static Subr2 set_cdr =
    new Subr2("set-cdr!") {
      public Value invoke (Value a, Value b) {
        return Procedure.set_cdr(a, b);
      }
  };
  public static Subr1 nullp =
    new Subr1("null?") {
      public Value invoke (Value a) {
        return Procedure.nullp(a);
      }
  };
  public static Subr1 symbolp =
    new Subr1("symbol?") {
      public Value invoke (Value a) {
        return Procedure.symbolp(a);
      }
  };
  public static Subr1 stringp =
    new Subr1("string?") {
      public Value invoke (Value a) {
        return Procedure.stringp(a);
      }
  };
  public static Subr1 numberp =
    new Subr1("number?") {
      public Value invoke (Value a) {
        return Procedure.numberp(a);
      }
  };
  public static Subr1 fixnump =
    new Subr1("integer?") {
      public Value invoke (Value a) {
        return Procedure.fixnump(a);
      }
  };
  public static Subr1 floatnump =
    new Subr1("real?") {
      public Value invoke (Value a) {
        return Procedure.floatnump(a);
      }
  };
  public static Subr1 procedurep =
    new Subr1("procedure?") {
      public Value invoke (Value a) {
        return Procedure.procedurep(a);
      }
  };
  public static Subr1 eofp =
    new Subr1("eof-object?") {
      public Value invoke (Value a) {
        return Procedure.eofp(a);
      }
  };
  public static SubrN plus =
    new SubrN("+") {
      public Value invoke (Value a[]) {
        return Procedure.plus(a);
      }
  };
  public static Subr2 minus =
    new Subr2("-") {
      public Value invoke (Value a, Value b) {
        return Procedure.minus(a, b);
      }
  };
  public static SubrN times =
    new SubrN("*") {
      public Value invoke (Value a[]) {
        return Procedure.times(a);
      }
  };
  public static Subr2 divide =
    new Subr2("/") {
      public Value invoke (Value a, Value b) {
        return Procedure.divide(a, b);
      }
  };
  public static Subr2 quotient =
    new Subr2("quotient") {
      public Value invoke (Value a, Value b) {
        return Procedure.quotient(a, b);
      }
  };
  public static Subr2 remainder =
    new Subr2("remainder") {
      public Value invoke (Value a, Value b) {
        return Procedure.remainder(a, b);
      }
  };
  public static Subr2 modulo =
    new Subr2("modulo") {
      public Value invoke (Value a, Value b) {
        return Procedure.modulo(a, b);
      }
  };
  public static Subr2 lep =
    new Subr2("<=") {
      public Value invoke (Value a, Value b) {
        return Procedure.lep(a, b);
      }
  };
  public static Subr2 gep =
    new Subr2(">=") {
      public Value invoke (Value a, Value b) {
        return Procedure.gep(a, b);
      }
  };
  public static Subr2 eqnp =
    new Subr2("=") {
      public Value invoke (Value a, Value b) {
        return Procedure.eqnp(a, b);
      }
  };
  public static Subr2 ltp =
    new Subr2("<") {
      public Value invoke (Value a, Value b) {
        return Procedure.ltp(a, b);
      }
  };
  public static Subr2 gtp =
    new Subr2(">") {
      public Value invoke (Value a, Value b) {
        return Procedure.gtp(a, b);
      }
  };
  public static SubrN display =
    new SubrN("display") {
      public Value invoke (Value a[]) {
        return Procedure.display(a);
      }
  };
  public static SubrN newline =
    new SubrN("newline") {
      public Value invoke (Value a[]) {
        return Procedure.newline(a);
      }
  };
  public static SubrN list =
    new SubrN("list") {
      public Value invoke (Value a[]) {
        return Procedure.list(a);
      }
  };
  public static SubrN apply =
    new SubrN("apply") {
      public Value invoke (Value a[]) {
        return Procedure.apply(a);
      }
  };
  public static Subr1 vectorp =
    new Subr1("vector?") {
      public Value invoke (Value a) {
        return Procedure.vectorp(a);
      }
  };
  public static SubrN make_vector =
    new SubrN("make-vector") {
      public Value invoke (Value a[]) {
        return Procedure.make_vector(a);
      }
  };
  public static SubrN vector =
    new SubrN("vector") {
      public Value invoke (Value a[]) {
        return Procedure.vector(a);
      }
  };
  public static Subr2 vector_ref =
    new Subr2("vector-ref") {
      public Value invoke (Value a, Value b) {
        return Procedure.vector_ref(a, b);
      }
  };
  public static Subr3 vector_set =
    new Subr3("vector-set!") {
      public Value invoke (Value a, Value b, Value c) {
        return Procedure.vector_set(a, b, c);
      }
  };
  public static Subr1 vector_length =
    new Subr1("vector-length") {
      public Value invoke (Value a) {
        return Procedure.vector_length(a);
      }
  };
  public static Subr2 string_ref =
    new Subr2("string-ref") {
      public Value invoke (Value a, Value b) {
        return Procedure.string_ref(a, b);
      }
  };
  public static Subr3 string_set =
    new Subr3("string-set!") {
      public Value invoke (Value a, Value b, Value c) {
        return Procedure.string_set(a, b, c);
      }
  };
  public static Subr1 string_length =
    new Subr1("string-length") {
      public Value invoke (Value a) {
        return Procedure.string_length(a);
      }
  };
  public static SubrN make_string =
    new SubrN("make-string") {
      public Value invoke (Value a[]) {
        return Procedure.make_string(a);
      }
  };
  public static SubrN string =
    new SubrN("string") {
      public Value invoke (Value a[]) {
        return Procedure.string(a);
      }
  };
  public static SubrN write =
    new SubrN("write") {
      public Value invoke (Value a[]) {
        return Procedure.write(a);
      }
  };
  public static Subr1 booleanp =
    new Subr1("boolean?") {
      public Value invoke (Value a) {
        return Procedure.booleanp(a);
      }
  };
  public static Subr1 symbol_to_string =
    new Subr1("symbol->string") {
      public Value invoke (Value a) {
        return Procedure.symbol_to_string(a);
      }
  };
  public static Subr1 string_to_symbol =
    new Subr1("string->symbol") {
      public Value invoke (Value a) {
        return Procedure.string_to_symbol(a);
      }
  };
  public static Subr1 charp =
    new Subr1("char?") {
      public Value invoke (Value a) {
        return Procedure.charp(a);
      }
  };
  public static Subr1 integer_to_char =
    new Subr1("integer->char") {
      public Value invoke (Value a) {
        return Procedure.integer_to_char(a);
      }
  };
  public static Subr1 char_to_integer =
    new Subr1("char->integer") {
      public Value invoke (Value a) {
        return Procedure.char_to_integer(a);
      }
  };
  public static SubrN read =
    new SubrN("read") {
      public Value invoke (Value a[]) {
        return Procedure.read(a);
      }
  };
  //[ Evaluation
  public static Subr0 current_input_port =
    new Subr0("current-input-port" ) {
      public Value invoke () {
        return Procedure.current_input_port();
      }
  };
  public static Subr0 current_output_port =
    new Subr0("current-output-port" ) {
      public Value invoke () {
        return Procedure.current_output_port();
      }
  };
  //] Evaluation
  public static Subr1 open_input_file =
    new Subr1("open-input-file") {
      public Value invoke (Value a) {
        return Procedure.open_input_file(a);
      }
  };
  public static Subr1 open_output_file =
    new Subr1("open-output-file") {
      public Value invoke (Value a) {
        return Procedure.open_output_file(a);
      }
  };
  public static Subr1 close_input_port =
    new Subr1("close-input-port") {
      public Value invoke (Value a) {
        return Procedure.close_port(a);
      }
  };
  public static Subr1 close_output_port =
    new Subr1("close-output-port") {
      public Value invoke (Value a) {
        return Procedure.close_port(a);
      }
  };

  //[ Additional primitives.
  public static Subr1 callep =
    new Subr1("call/ep") {
      public Value invoke (Value a) {
        return Procedure.callep(a);
      }
  };
  public static Subr1 exit =
    new Subr1("exit") {
      public Value invoke (Value a) {
        return Procedure.exit(a);
      }
  };
  public static Subr0 oblist =
    new Subr0("oblist") {
      public Value invoke () {
        return Procedure.oblist();
      }
  };
  public static SubrN detach =
    new SubrN("detach") {
      public Value invoke (Value a[]) {
        return Procedure.detach(a);
      }
  };
  public static Subr2 diagnose =
    new Subr2("diagnose") {
      public Value invoke (Value a, Value b) {
        return Monitor.diagnose(a, b);
      }
  };
  //] Additional primitives.

}

// end of PredefinedValues.java
