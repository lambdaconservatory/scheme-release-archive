// $Id: Escape.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class that represents escaping procedures ie continuations
 * with dynamic extent. They are implemented with Java exceptions. 
 */

public class Escape extends Subr1 {

  /** To differentiate continuations, they contain an index that
   * appears when printed. Since this index is static, it must be
   * synchronized.  */

  private static int counter = 0;

  // Constructor

  public Escape () {
    super("continuation" + Escape.incrementCounter());
  }

  // The existence of this method is a side-effect of the rule of Java
  // that super must be the first instruction of a constructor. I
  // could not access and increment the counter before calling super()
  // so I decided to write a static synchronized method for that.

  public static synchronized int incrementCounter () {
    return counter++;
  }
    
  // Invoker

  public Value invoke (Value arg1) {
    Evaluation cev = currentEvaluation();
    throw new EscapeObject(arg1);
  }

  // Printing

  public String toString () {
    return "#<Continuation" + counter + ">";
  }

}

// end of Escape.java
