// $Id: LocalUninitializedEnvironment.java,v 2.1 1997/12/08 10:59:26 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class allows to introduce uninitialized local variables ie
 * variables that cannot be read before being initialized. The initial
 * Java value used to represent a non initialized Jaja variable is
 * the null value. */

public class LocalUninitializedEnvironment extends Environment {

  public String[] name;
  public Value[]  value;

  // Constructor

  public LocalUninitializedEnvironment (String[] n, Environment r) {
    name  = n;
    value = new Value[n.length];
    next  = r;
  }

  public Value lookup (String n) {
    for ( int i=0 ; i<name.length ; i++ ) {
      if ( name[i].equals(n) ) {
        if ( value[i] != null ) {
          return value[i];
        } else {
          throw new RuntimeException("Uninitialized variable " + n);
        }
      }
    }
    return next.lookup(n);
  }

  public Value update (String n, Value v) {
    for ( int i=0 ; i<name.length ; i++ ) {
      if ( name[i].equals(n) ) {
        Value old = value[i];
        value[i] = v;
        if ( old != null ) {
          return old;
        } else {
          return v;
        }
      }
    }
    return next.update(n, v);
  }

}

// end of LocalUninitializedEnvironment.java
