// $Id: Expand.java,v 2.3 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of the simplistic expand function. */

public class Expand extends Subr1 {
  
  private WorldAble world;

  // Constructor

  public Expand (World world) {
    super("expand");
    this.world = world;
  }

  // Invokers

  public Value invoke (Value args[]) {
    if ( args.length == 1 ) {
      return this.invoke(args[0]);
    } else {
      return super.invoke(args);
    }
  }

  /** Expand an expression specified as a Jaja value. */

  public Value invoke (Value exp) {
    if ( exp instanceof Pair ) {
      Pair pexp = (Pair) exp;
      if ( pexp.car == Symbol.symbol_eval_in_expansion_world ) {
        Value nexp = new Pair(Symbol.beginq, pexp.cdr);
        try {
          EvaluationAble ev = world.createEvaluation(nexp, null);
          return ev.obtain();
        } catch (RuntimeException exc) {
          throw exc;
        } catch (Exception exc) {
          throw new RuntimeException(exc.getMessage());
        }
      } else {
        return exp;
      }
    } else {
      return exp;
    }
  }

}

// end of Expand.java
