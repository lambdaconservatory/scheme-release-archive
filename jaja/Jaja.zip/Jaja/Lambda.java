// $Id: Lambda.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>lambda</CODE> special form.
 */

public class Lambda extends SpecialOperator {

  // Construction

  protected Lambda () {
    super("lambda");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    Value variables;
    Value body;
    if ( parameters instanceof Pair ) {
        variables = ((Pair)parameters).car;
        body = ((Pair)parameters).cdr;
        if ( body instanceof Pair ) {
            return new InterpretedProcedure(variables,
                                            (Pair)body,
                                            r,
                                            world );
        } else {
            throw new RuntimeException("Missing body");
        }
    } else {
        throw new RuntimeException("Missing variables");
    }
  }
  //] Evaluation

}

// end of Lambda.java
