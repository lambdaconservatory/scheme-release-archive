// $Id: Character.java,v 2.3 1997/12/07 18:58:53 queinnec Exp $
/**  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

import java.util.Hashtable;

/** This class defines characters. Since there are so many of them,
 * they are only allocated if needed. An hashtable records the
 * characters that are used. */

public class Character extends Value {

  public char value;

  /** A Hashtable of characters. This saves space since only used
   * characters will be in that table and not all possible (2^16)
   * characters. */

  static Hashtable chartable = new Hashtable(256);

  // Constructors

  protected Character (char c) {
    value = c;
  }
  public static Value create (int i) {
    return Character.create((char)i);
  }
  public static Value create (char c) {
    return Character.adjoin(new Character(c));
  }
  private static Value adjoin (Character c) {
    synchronized (chartable) {
      // What's the cost of using the default hash function ?
      if ( !chartable.containsKey(c) ) {
        chartable.put(c, c);
      }
      return c;
    }
  }
  // Adjoin named characters
  static {
    Character.adjoin(new NamedCharacter('\t', "tab"));
    Character.adjoin(new NamedCharacter('\n', "newline"));
    Character.adjoin(new NamedCharacter('\r', "return"));
    Character.adjoin(new NamedCharacter(' ',  "space"));
  }

  // Printing

  public String toString () {
    return "" + value;
  }
  public String toReadableString () {
    return "#\\" + value;
  }

}

// end of Character.java
