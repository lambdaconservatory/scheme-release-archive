// $Id: DynamicEnvironment.java,v 2.4 1997/12/15 17:29:11 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class is used to represent dynamic environments. It is
 * similar to Environment but yields Objects instead of Values
 * (therefore it does not inherit from Environment). We store Objects
 * instead of Values so we can store any kind of Java objects
 * (streams or URL for instance). 
 *
 * <P> The dynamic environment is represented by a linked list of
 * nodes; the last 'next' field is null. */

public class DynamicEnvironment extends Entity {
  
  private final String name;
  private final Object value;
  private final DynamicEnvironment next;

  // Constructor

  private DynamicEnvironment (String n, Object v, DynamicEnvironment r) {
    name  = n;
    value = v;
    next  = r;
  }
 
  // Real constructors
  /** Extend a dynamic environment with a new binding. */

  public DynamicEnvironment extendDynamic (String s, Object v) {
    return new DynamicEnvironment(s, v, this);
  }

  /** Create a dynamic environment holding a single binding. */

  public static DynamicEnvironment createDynamic (String s, Object v) {
    return new DynamicEnvironment(s, v, null);
  }
 
  /** Search a dynamic environment for the Object associated to a
   * dynamic variable (specified by its name). This method returns
   * null by default. This is an Object instead of a Value since we
   * need to store an URL.  */

  public Object getDynamicValue (String s) {
    if ( name.equals(s) ) {
      return value;
    } else {
      if ( next == null ) {
        return null;
      } else {
        return next.getDynamicValue(s);
      }
    }
  }

}

// end of DynamicEnvironment.java

