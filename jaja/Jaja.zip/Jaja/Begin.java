// $Id: Begin.java,v 2.5 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>begin</CODE> special form.
 */

public final class Begin extends SpecialOperator {

  // Construction

  protected Begin () {
    super("begin");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    return parameters.eprogn(r, world);
  }
  //] Evaluation

}

// end of Begin.java
