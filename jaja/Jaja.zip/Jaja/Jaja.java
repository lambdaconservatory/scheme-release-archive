// $Id: Jaja.java,v 2.5 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the root class of all Jaja related classes.
 *
 * <P> It exports some internal values needed to initialize variables
 * such as <TT>TRUE</TT>, <TT>FALSE</TT> or <TT>NIL</TT>. All these
 * class variables may be accessed as <TT>Jaja.TRUE</TT> or simply as
 * <TT>FALSE</TT> if inheriting from the Jaja class.
 *
 * <P> It does not export the predefined primitives (@see 
 * PredefinedValues for that). 
 * 
 * <P> There are two important classes ie PredefinedValues and Procedure.
 */

import java.io.*;

public abstract class Jaja 
implements Serializable {

  // Predefined internal Scheme constants.

  public static final Boolean TRUE  = Boolean.TRUE;
  public static final Boolean FALSE = Boolean.FALSE;

  /** This value represents the empty list. It has its own class to
   * allow for messages discriminating over Pairs and EmptyList. */

  public static final EmptyList NIL = EmptyList.NIL;

  /** This is the single value used to mark end of files when an input
   *  port is exhausted. */

  public static final Constant EOF = new Constant("#<endOfFile>");

  /** This is what is returned when nothing else seems appropriate.
   * This is used for (begin), (if #f 1) ... */

  public static final Value UNSPECIFIED = FALSE;

  /** Every evaluation is performed within a dynamic environment. This
   * method obtains the object associated with a dynamic variable. */

  public static Object currentDynamicValue (String s) {
    return currentDynamicEnvironment().getDynamicValue(s);
  }

  /** Get current dynamic environment. */

  public static DynamicEnvironment currentDynamicEnvironment () {
    return currentEvaluation().getDynamicEnvironment();
  }

  /** Get current evaluation. */

  public static Evaluation currentEvaluation () {
    return (Evaluation) Thread.currentThread();
  }

  /** The generic way to print Jaja values or entities from Java: */

  public String toString () {
    return "<" + this.getClass().getName() + ":" + this.getName() + ">";
  }
  public String getName () {
    return "";
  }

}

// end of Jaja.java
