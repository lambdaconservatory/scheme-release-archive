// $Id: NullPort.java,v 3.2 1998/11/29 21:53:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class provides a Port that acts as /dev/null in Posix, that is, 
 it swallows any string it is asked to print (but does not print it) and
 if asked to provide a string, it returns an EOF. It is used in Worlds 
 without input/output ports. */ 

public class NullPort extends Port 
implements InputPortAble, OutputPortAble {
  
  public NullPort () {
  }

  // general Port operations:

  public void close () {
  }

  // General InputPort operations:

  public Value read_file () {
    return Jaja.EOF;
  }
  public Value read () {
    return Jaja.EOF;
  }
  public Value read_char () {
    return Jaja.EOF;
  }

  // General OutputPort operations:

  public synchronized void flush () {
  }
  public synchronized void newline () {
  }
  public void print (Value o) {
  }
  public void write (Value o) {
  }
  public synchronized void print (String s) {
  }
  public synchronized void print (char c) {
  }
  public synchronized void print (double d) {
  }
  public synchronized void print (int i) {
  }
  
}

// end of NullPort.java
