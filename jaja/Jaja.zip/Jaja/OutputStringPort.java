// $Id: OutputStringPort.java,v 2.1 1997/12/08 10:59:27 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class refines output port to print onto strings. The result
 * of these printings may be retrieved with <CODE>getText()</CODE>. */

import java.io.*;

public class OutputStringPort extends OutputPort {

  ByteArrayOutputStream internal_stream;
  
  // Constructor

  public OutputStringPort () {
    this.internal_stream = new ByteArrayOutputStream();
    this.name = "aString";
    this.stream = new PrintWriter(internal_stream);
  }

  /** Extract the content of a OutputStringPort into a String.
   * Resets the port as well. Synchronize this effect. */

  public synchronized String getText () {
    String s = internal_stream.toString();
    internal_stream.reset();
    return s;
  }

}

// end of OutputStringPort.java
