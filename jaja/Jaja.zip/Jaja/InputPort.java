/** @version $Id: InputPort.java,v 2.7 1998/11/29 21:53:18 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements Input ports and, chiefly, how to read
 * Sexpressions from them. 
 */

import java.io.*;
import java.applet.*;
import java.net.*;

public class InputPort extends Port 
implements InputPortAble {

  // FUTURE: how to make these two fields final ???

  protected String name;
  protected Reader stream;

  // Constructors
  protected InputPort (String s, Reader is) {
    this.name = s;
    this.stream = is;
  }
  /** This constructor may open a remote file if given an URL. The
   * difficulty is to parse an URL relative to the URL of the applet
   * if the interpreter is run from an applet. */
  public InputPort (String s) {
    try {
      try {
        this.initializeAsFile(s);
      } catch (IOException exc) {
        this.initializeAsURL(s);
      }
    } catch (IOException e) {
      throw new RuntimeException(e.getClass().getName()
                                 + " error: "
                                 + e.getMessage());
    }
  }
  
  public void initializeAsURL (String s) 
  throws IOException {
  //[ Evaluation
    URL url, base_url;
    try {
      base_url = (URL) Jaja.currentDynamicValue("url");
      if ( base_url != null ) {
        url = new URL(base_url, s);
      } else {
        // Means that there is no url since the interpreter
        // was probably not run from an applet.
        url = new URL(s);
      }
    } catch ( IOException exc) {
      // Check if the url may be parsed as an absolute url.
      url = new URL(s);
    }
    InputStream is = url.openStream();
    stream = new InputStreamReader(is);
    name = url.toString();
  //] Evaluation
  }
  
  public void initializeAsFile (String s) 
  throws IOException {
    FileInputStream fis = new FileInputStream(s);
    DataInputStream dis = new DataInputStream(fis);
    stream = new InputStreamReader(dis);
    name = s;
  }

  public void close () {
    try {
      stream.close();
    } catch (IOException exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

  // Printing

  public String toString () {
    return "#<InputPort: " + name + ">";
  }

  // A stream with a peek-char capability.

  private static String string_end_of_stream = "End of Stream";
  private int last_poken = ' ';
  private boolean already_poken = false;
  protected int peekChar () throws IOException {
    if ( !already_poken ) {
      last_poken = stream.read();
      already_poken = true;
    }
    return last_poken;
  }
  private int consumeThenPeekChar () throws IOException {
    consumeChar();
    return peekChar();
  }
  private void consumeChar () {
    already_poken = false;
  }

  // Reading (May also be obtained by compilation).
  /** Get the symbols that are required by the read function.  These
   * are <CODE>quote</CODE> and variants. */

  private static final Value symbol_quote =
    Symbol.create("quote");
  private static final Value symbol_quasiquote =
    Symbol.create("quasiquote");
  private static final Value symbol_unquote =
    Symbol.create("unquote");
  private static final Value symbol_unquote_splicing =
    Symbol.create("unquote_splicing");

  /** Read a single char. */

  public Value read_char () {
    try {
      int c = peekChar();
      consumeChar();
      return Character.create(c);
    } catch (IOException exc) {
      return Jaja.EOF;
    }
  }

  /** Read a whole file and return the list of the Sexpressions it
   * contained. You have to prefix this list with the begin special
   * form operator if you want to evaluate it. */

  public Value read_file () {
    Pair queue = new Pair(Jaja.UNSPECIFIED, Jaja.NIL);
    Pair head  = queue;
    while ( true ) {
      Value e = this.read();
      if ( e != Jaja.EOF ) {
        Pair newqueue = new Pair(e, Jaja.NIL);
        queue.cdr = newqueue;
        queue = newqueue; // ie queue.cdr (without cast)
      } else {
        this.close();
        break;
      }
    }
    return head.cdr;
  }
  
  /** Convert a string into a Sexpression. The string should only
   * contain a single Sexpression (superfluous Sexpressions will be
   * ignored). */
  
  public static Value read (String s) {
    InputStringPort isp = new InputStringPort(s);
    return isp.read();
  }

  /** Read a single Sexpression from an input port. */

  public Value read () {
    try {
      return this.read(peekChar());
    } catch (IOException exc) {
      if ( exc.getMessage().equals(string_end_of_stream) ) {
        return Jaja.EOF;
      } else {
        throw new RuntimeException(exc.getMessage());
      }
    }
  }

  private Value read (int c) throws IOException {
    switch (c) {
    case ' ':
    case '\t':
    case '\n':
    case '\r': {
      return this.read(consumeThenPeekChar());
    }
    case ';': {
      while ( consumeThenPeekChar() != '\n' );
      return this.read(consumeThenPeekChar());
    }
    case '\'': {
      Value e = this.read(consumeThenPeekChar());
      return new Pair(symbol_quote, new Pair(e, NIL));
    }
    case '`': {
      Value e = this.read(consumeThenPeekChar());
      return new Pair(symbol_quasiquote, new Pair(e, NIL));
    }
    case ',': {
      c = consumeThenPeekChar();
      Value symbol = symbol_unquote;
      if ( c == '@' ) {
        consumeChar();
        symbol = symbol_unquote_splicing;
      }
      Value e = this.read(peekChar());
      return new Pair(symbol, new Pair(e, NIL));
    }
    case '(': {
      return this.read_list(consumeThenPeekChar());
    }
    case ')': {
      consumeChar();
      throw new IOException("Superfluous close parenthesis!");
    }
    case '"': {
      return this.read_string("", consumeThenPeekChar());
    }
    case '#': {
      return this.read_sharp_stuff(consumeThenPeekChar());
    }
    case -1: {
      throw new IOException(string_end_of_stream);
    }
    default: {
      return this.read_atom(c);
    }
    }
  }

  private Value read_string (String s, int c) throws IOException {
    switch (c) {
    case '"': {
      consumeChar();
      // Quoted strings are immutable.
      return new ImmutableString(s);
    }
    case '\\': {
      c = consumeThenPeekChar();
      /* fallthrough */
    }
    case -1: {
      throw new IOException(string_end_of_stream);
    }
    default: {
      s += String.valueOf(c);
      return this.read_string(s, consumeThenPeekChar());
    }
    }
  }

  private Value read_sharp_stuff (int c) throws IOException {
    switch (c) {
    case 't':
    case 'T': {
      consumeChar();
      return TRUE;
    }
    case 'f':
    case 'F': {
      consumeChar();
      return FALSE;
    }
    case '\\': {
      c = consumeThenPeekChar();
      String name = this.read_token("", c);
      if ( name.equals("newline") ) {
        return Character.create('\n');
      } else if ( name.equals("return") ) {
        return Character.create('\r');
      } else if ( name.equals("space") ) {
        return Character.create(' ');
      } else {
        if ( name.length() == 1 ) {
          return Character.create(c);
        } else {
          throw new IOException("Unknown character name");
        }
      }
    }
    case '(': {
      Value content = this.read_list(consumeThenPeekChar());
      int leng = content.list_length();
      Vector v = new Vector(leng);
      for ( int i=0 ; i<leng ; i++ ) {
        v.item[i] = ((Pair)content).car;
        content = ((Pair)content).cdr;
      }
      return v;
    }
    case -1: {
      throw new IOException(string_end_of_stream);
    }
    default: {
      consumeChar();
      throw new IOException("Unknown # thing");
    }
    }
  }

  private String read_token (String s, int c) throws IOException {
    switch (c) {
    case ' ':
    case '(':
    case ')':
    case '\t':
    case '\n':
    case '\r': {
      return s;
    }
    // a comment ends a token:
    case ';': {
      return s;
    }
    // an EOF ends a token:
    case -1: {
      return s;
    }
    default: {
      s += String.valueOf((char)c);
      return read_token(s, consumeThenPeekChar());
    }
    }
  }

  /** "+" is not parsed as a legal number but "-" is! */
  private Value read_atom (int c) throws IOException {
    String s = this.read_token("", c);
    if ( s.equals("-") ) {
      return Symbol.create(s);
    }
    try {
      int i = Integer.valueOf(s).intValue();
      return Fixnum.create(i);
    } catch (NumberFormatException exc) {
    }
    try {
      double d = Double.valueOf(s).doubleValue();
      return new Floatnum(d);
    } catch (NumberFormatException exc) {
    }
    return Symbol.create(s);
  }

  private Value read_list (int c) throws IOException {
    switch (c) {
    case ' ':
    case '\t':
    case '\n':
    case '\r': {
      return this.read_list(consumeThenPeekChar());
    }
    case ';': {
      while ( consumeThenPeekChar() != '\n' );
      return this.read_list(consumeThenPeekChar());
    }
    case ')': {
      consumeChar();
      return NIL;
    }
    case '.' : {
      Value end = this.read_list(consumeThenPeekChar());
      if ( end instanceof Pair ) {
        Pair p = (Pair)end;
        if ( p.cdr == NIL ) {
          return p.car;
        } else {
          throw new IOException("Too much terms after dot");
        }
      } else {
        throw new IOException("No term after dot");
      }
    }
    case -1: {
      throw new IOException(string_end_of_stream);
    }
    default: {
      Value term = this.read(c);
      Value terms = this.read_list(peekChar());
      return Procedure.cons(term, terms);
    }
    }
  }

}

// end of InputPort.java
