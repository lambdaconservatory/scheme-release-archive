// $Id: Id.java,v 3.6 1998/11/30 09:24:56 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class stores the identification of the package.
 */

public class Id extends Jaja {

  /** The revision number of the current Java file holds for the whole
   * Jaja package.  */

  public static final String revision = 
    "$Revision: 3.6 $";

  /** The Email of the author. */

  public static final String authorEmail = 
    "Christian.Queinnec@lip6.fr";

  /** The URL leading to the Jaja page.  Might be used to open a
   * browser on the documentation (use Hotjava bean if licensed). */

  public static final String docUrl =
    "http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html";

}

// end of Id.java
