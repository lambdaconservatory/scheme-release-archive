// $Id: Invokation.java,v 2.6 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements a thread that invokes a function and
 * discards its result.
 */

public class Invokation extends Evaluation {

  protected Value f;
  protected Value args[];

  // Constructor

  public Invokation (WorldAble world,
                     DynamicEnvironment denv,
                     Value f, 
                     Value args[] ) {
    super(world, denv, null);
    this.f       = f;
    this.args    = args;
  }

  // Perform the invokation. Use the current dynamic environment for
  // anomaly handlers.

  public void run () {
    setStatus(STARTING);
    try {
      setStatus(EVALUATING);
      result = ((Procedure)f).invoke(args);
      setStatus(EVALUATED);
    } catch (ExitObject eo) {
      // The evaluation performed (exit <code>)
      exception = eo;
      setStatus(EXITED);
    } catch (EscapeObject eo) {
      // The evaluation performed (<continuation> <value>) and
      // <continuation> was no longer active.
      exception = eo;
      setStatus(UNCAUGHT);
    } catch (Exception exc) {
      Anomaly a = new AnomalyFromException(exc);
      Monitor.diagnose(a, Jaja.FALSE);
    }
  }

}

// end of Invokation.java
