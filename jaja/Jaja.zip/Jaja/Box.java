// $Id: Box.java,v 2.4 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements mutable boxes (or references in ML
 * parlance).  A box holds a single value at any time and may be
 * modified to hold another value. Boxes are used to implement mutable
 * variables in Jaja (so they can be shared since the compiler uses
 * flat closures copying the bindings they close.
 *
 * <P> Normally, in Scheme, a Box is not a first-class value and
 * therefore should not inherit from Value. But for ML and for typing
 * reason this is easier.
 *
 * <P> A non initialized box holds a null content.
 */

public class Box extends Value {
    
  /** Only mutated through setBoxContent. Unfortunately this slows
   * down read access which has to pass through a method. */

  protected Value content;

  // Constructors

  public Box () {
    content = null;
  }
  public Box (Value c) {
    content = c;
  }

  /** Modify the content of a Box. Returns the former content. */

  public synchronized Value setBoxContent (Value value) {
    Value old = content;
    content = value;
    if ( old != null ) {
      return old;
    } else {
      return value;
    }
  }

  /** Read the content of a box. this does not need to be a synchronized
      method since the JVM warrants an atomic access to 32 bits pointers. */
  // Useful ??? Change the name to be bean-compatible ???       FUTURE

  public Value getBoxContent () {
    if ( content != null ) {
      return content;
    } else {
      throw new RuntimeException("Uninitialized");
    }
  }

}

// end of Box.java
