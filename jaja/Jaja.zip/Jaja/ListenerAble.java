// $Id: ListenerAble.java,v 3.1 1998/11/28 16:04:33 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

public interface ListenerAble extends java.rmi.Remote {

  /** Bind a Listener to a World. This allows to change the world to
      which the Listener is bound. */
  
  public void setWorld (WorldAble world)
       throws java.rmi.RemoteException;

  /** Initialize the listener. Binds it also to a World but only if
      non-null. */

  public void initialize (String[] argv, WorldAble world)
       throws java.rmi.RemoteException;

}

// end of ListenerAble.java
