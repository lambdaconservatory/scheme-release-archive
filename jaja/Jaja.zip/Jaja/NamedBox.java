// $Id: NamedBox.java,v 2.2 1997/12/08 10:59:26 queinnec Exp $
  /**  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements named boxes, a variety of boxes that know their
 * name and produce a more detailed error when read while uninitialized.
 */

public class NamedBox extends Box {

  public String name;

  //  Constructor

  public NamedBox (String n) {
    super();
    name = n;
  }

  // Accessor

  public Value getBoxContent () {
    if ( content != null ) {
      return content;
    } else {
      throw new RuntimeException(name + " is uninitialized");
    }
  }

}

// end of NamedBox.java
