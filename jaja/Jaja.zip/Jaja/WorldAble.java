// $Id: WorldAble.java,v 2.5 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** The interface describing a World. A world is a place where
 evaluations may take place concurrently. All these evaluations share
 a common global environment. But every evaluation brings its own
 dynamic environment (where the current input and output ports are
 stored). 
 
<p> Every world may have an associated macro world where all
 macro-expansion are performed. A null macro-world means "don't expand".
 The macro world may have itself its own macro world etc.

<P> QUESTION: How to parameterize Jaja wrt RMI or CORBA or DCOM etc...
 */

public interface WorldAble extends java.rmi.Remote {

  /** Get the name of the world. */

  public String getName ()
       throws java.rmi.RemoteException;

  /** Get the current global environment of the world. */

  public Environment getEnvironment ()
       throws java.rmi.RemoteException;

  /** Set the global environment of the world. If env is null then use
      a default environment. This method should be used when
      initializing a world (ie at design-time in beans-parlance). */

  /* design time */ void setEnvironment (Environment env)
       throws java.rmi.RemoteException;

  /** Get the macro world where the current world macro-expand the
      expressions it has to evaluate. */

  public WorldAble getMacroWorld ()
       throws java.rmi.RemoteException;

  /** Set the macro world where the current world macro-expand the
      expressions it has to evaluate. This method should be used when
      initializing a world (ie at design-time in beans-parlance). */

  /* design time */ void setMacroWorld (WorldAble world)
       throws java.rmi.RemoteException;

  /** Create an evaluation (from a string). You will have to start it. */

  public EvaluationAble createEvaluation (String program, 
                                          DynamicEnvironment denv)
       throws java.rmi.RemoteException;

  /** Create an evaluation (from a Value). You will have to start it. */

  public EvaluationAble createEvaluation (Value program, 
                                          DynamicEnvironment denv)
       throws java.rmi.RemoteException;

}

// end of WorldAble.java
