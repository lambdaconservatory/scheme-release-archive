// $Id: Pair.java,v 2.5 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of mutable pairs (dotted pairs in Lisp parlance).
 * Fields are public for direct (and efficient) access. 
 */

public class Pair extends Value {

  public Value car;
  public Value cdr;

  // Constructor

  public Pair (Value a, Value d) {
    car = a;
    cdr = d;
  }

  // Comparing

  public boolean equalp (Value other) {
    if ( other instanceof Pair ) {
      Pair o = (Pair)other;
      if ( this.car.equalp(o.car) && this.cdr.equalp(o.cdr) ) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  // Compute the length of a list.

  public int list_length () {
    return 1 + cdr.list_length();
  }

  // Printing

  public String toString () {
    return "(" + this.toInnerString() + ")";
  }
  public String toInnerString () {
    StringBuffer result = new StringBuffer();
      result.append(car.toString());
    if ( cdr != NIL ) {
      result.append(" ");
      result.append(cdr.toInnerString());
    }
    return new String(result);
  }
  public String toReadableString () {
    return "(" + this.toInnerReadableString() + ")";
  }
  public String toInnerReadableString () {
    StringBuffer result = new StringBuffer();
    result.append(car.toReadableString());
    if ( cdr != NIL ) {
      result.append(" ");
      result.append(cdr.toInnerReadableString());
    }
    return new String(result);
  }

  //[ Evaluation

  /** Evaluating a form or a sequence of forms.
   * Special operators are defined as a subclass of Symbols. Their 
   * behavior is specified as a method of their class. Therefore there
   * as many classes as there are special operators (if, begin, set! ...).
   * Surprisingly, there is no such thing as evlis. Evlis has to return
   * an array of values so the length of the array has to be computed before
   * it can be filled, then it is simple to fill this array.
   */

  public Value eval (Environment r, WorldAble world) {
    Value funparm    = this.car;
    Value parameters = this.cdr;
    if ( funparm instanceof SpecialOperator ) {
      SpecialOperator op = (SpecialOperator) funparm;
      return op.perform(parameters, r, world);
    } else {
      Value function = this.car.eval(r, world);
      int length = parameters.list_length();
      Value[] arguments = new Value[length];
      for ( int i=0 ; i<length ; i++ ) {
        arguments[i] = ((Pair)parameters).car.eval(r, world);
        parameters = ((Pair)parameters).cdr;
      }
      return ((Procedure)function).invoke(arguments);
    }
  }

  public Value eprogn (Environment r, WorldAble world) {
    return cdr.eprognInternal(car, r, world);
  }
  public Value eprognInternal (Value previous, 
                               Environment r, 
                               WorldAble world ) {
    previous.eval(r, world);
    return this.eprogn(r, world);
  }
  //] Evaluation

}

// end of Pair.java
