// $Id: Quote.java,v 1.2 1996/09/26 17:01:07 queinnec Exp 
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>quote</CODE> special form.
 */

public class Quote extends SpecialOperator {

  // Construction

  protected Quote () {
    super("quote");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    Value quotation;
    if ( parameters instanceof Pair ) {
        quotation = ((Pair)parameters).car;
        parameters = ((Pair)parameters).cdr;
        if ( parameters != NIL ) {
            throw new RuntimeException("Bad quotation");
        }
        return quotation;
    } else {
        throw new RuntimeException("Missing quoted value");
    }
  }
  //] Evaluation

}

// end of Quote.java
