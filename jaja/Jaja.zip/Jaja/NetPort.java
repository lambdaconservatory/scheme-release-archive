// @version $Id$
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** Ports cannot migrate since they are bound to a local stream of
    characters. The PortAble interface and NetPort class allow to read
    from or print onto them even if remote. */

public interface PortAble extends java.rmi.Remote {
}

// end of PortAble.java
