// $Id: AnomalyFromException.java,v 2.2 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the subclass of Anomaly that corresponds to
 * RuntimeException raised by the JVM and caught in Evaluation.  */

public class AnomalyFromException extends Anomaly {

  public final Exception exception;

  /** Convert a caught exception into an Anomaly. */

  public AnomalyFromException (Exception e) {
    super(e.getMessage());
    exception = e;
  } 
  
  public String toString () {
    exception.printStackTrace();
    return "#<AnomalyFromException: " + exception.getMessage() + ">";
  }

}

// end of AnomalyFromException.java
