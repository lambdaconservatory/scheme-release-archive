// $Id: InterpretedProcedure.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class representing procedures created on the fly by
 * the interpreter.  */

public class InterpretedProcedure extends ProcedureN {

  Value variables;
  Pair body;
  Environment environment;
  WorldAble world;

  // Constructor

  public InterpretedProcedure (Value variables,
                               Pair body,
                               Environment r,
                               WorldAble world ) {
    this.environment = r;
    this.body = body;
    this.variables = variables;
    this.world = world;
  }

  // Invoker

  public Value invoke (Value args[]) {
    Environment r = environment;
    Value vars = variables;
    int i = 0;
    while ( vars instanceof Pair ) {
      if ( i < args.length ) {
        Pair vv = (Pair)vars;
        Symbol variable = (Symbol)(vv.car);
        vars = vv.cdr;
        r = r.extend(variable.name, args[i++]);
      } else {
        throw new RuntimeException("Too less arguments");
      }
    }
    // Handle dotted variable if any.
    if ( vars instanceof Symbol ) {
      Symbol variable = (Symbol)vars;
      Value arguments = Value.listify(args, i);
      r = r.extend(variable.name, arguments);
    } else if ( vars == Jaja.NIL ) {
      if ( i < args.length ) {
        throw new RuntimeException("Too much arguments");
      } else {
        // all arguments match all variables.
      }
    } else {
      throw new RuntimeException("Incorrect list of variables");
    }
    return body.eprogn(r, world);
  }

}

// end of InterpretedProcedure.java
