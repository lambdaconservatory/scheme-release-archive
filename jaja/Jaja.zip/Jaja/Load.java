// $Id: Load.java,v 2.8 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class for the load procedures (one per interpreter).
 * When created such a procedure captures the current interpreter.
 * Therefore this load procedure is an eval-in-current-module function
 * however it inherits of the dynamic environment of the caller. */

public class Load extends Subr1 {

  private WorldAble world;

  // Constructor

  public Load (World world) {
    super("load");
    this.world = world;
  }

  // Invokers

  public Value invoke (Value args[]) {
    if ( args.length == 1 ) {
      return this.invoke(args[0]);
    } else {
      return super.invoke(args);
    }
  }

  /** Load a file whose name is specified by a Jaja String. This value
   * may represent a filename or an URL leading to a remote file.  The
   * file is entirely read, prefixed with a <tt>begin</tt> symbol and
   * evaluated. This evaluation inherits from the dynamic environment
   * of the caller. Anomalies that may occur during this evaluation
   * are transmitted to the caller. */

  public Value invoke (Value s) {
    String filename = new String(((MutableString)s).content);
    InputPort in = new InputPort(filename);
    Value body = in.read_file();
    Value e = new Pair(Symbol.beginq, body);
    DynamicEnvironment denv = Jaja.currentDynamicEnvironment();
    EvaluationAble ev;
    try {
      ev = world.createEvaluation(e, denv);
      return (Value) ev.obtain();
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

}

// end of Load.java
