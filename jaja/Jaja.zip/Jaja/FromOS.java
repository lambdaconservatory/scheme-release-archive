// $Id: FromOS.java,v 2.9 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.net.*;
import java.lang.*;

/** This class allows to start Jaja from an OS shell. It creates a
 * window to run Jaja as an applet (unless the -textual option is
 * given. This is a separate class since security precludes using
 * setStub. */

public class FromOS {
  
  private static String usage = ""
  + Listener.identification
  + "Command options:\n"
  + "\t-textual     starts the Jaja interpreter in textual mode,\n"
  + "\t             This is equivalent to -listener Jaja.Textual.\n"
  + "\t-listener <className>   specifies the Jaja listener to open,\n"
  + "\t-world <rmiURL>         specifies the World to bind with.\n"
  + "\t<no option>  starts a window-based Jaja listener.\n"
  + "\t             This is equivalent to -listener Jaja.Listener.\n";

  /** This is the default class name of the Listener to use. */

  private static String listenerClassName = "Jaja.Listener";

  /** Starts the applet from an OS shell. If the first command option
   * is -textual, forget about the applet and starts a textual
   * interpreter only. Otherwise, starts a window-based listener whose
   * class may be specified by an option. */

  public static void main (String argv[]) {
    WorldAble world = null;
    String[] nargv  = new String[0];
    int argvIndex = 0;

    while ( argvIndex < argv.length ) {

      // Specify the World to bind with:
      if ( argv[argvIndex].equals("-world") ) {
        System.setSecurityManager(new java.rmi.RMISecurityManager());
        // Next argument specifies the URL of the remote world:
        if ( ++argvIndex < argv.length ) {
          String worldUrl = argv[argvIndex++];
          world = NetWorld.findPublishedWorld(worldUrl);
          continue;
        }

      // Run the interpreter as text only (this is equivalent to the
      // ``-listener Jaja.Textual'' options.
      } else if ( argv[argvIndex].equals("-textual") ) {
        listenerClassName = "Jaja.Textual";
        ++argvIndex;

      // Stops analyzing command options, pass the remaining options to the 
      // Listener so it may achieve its initialization.
      } else if ( argv[argvIndex].equals("--") ) {
        nargv = new String[argv.length - (++argvIndex)];
        for (int j = 0 ; argvIndex < argv.length ; ) {
          nargv[j++] = argv[argvIndex++];
        }

      // Specify the Listener to use:
      } else if ( argv[argvIndex].equals("-listener") ) {
        // Next argument specifies the Listener class to start:
        if ( ++argvIndex < argv.length ) {
          listenerClassName = argv[argvIndex++];
        } else {
          System.err.println(usage + "Missing listenerClassName");
          return;
        }

      // Print a small help:
      } else if ( argv[argvIndex].equals("-help") ) {
        System.err.println(usage);
        return;
      } else {
        System.err.println(usage + "Unknown option: " + argv[argvIndex]);
        return;
      }
    }

    try {
      // Find and load the class of the specified listener:
      ClassLoader cl = FromOS.class.getClassLoader();
      Class listenerClass;
      // When run from FromOS, there is no class loader:
      if ( cl == null ) {
        listenerClass = Class.forName(listenerClassName);
      } else {
        listenerClass = cl.loadClass(listenerClassName);
      }
      if ( listenerClass == null ) {
        System.err.println(usage + "No such listenerClass");
      }
      // Create the default world if not specified:
      if ( world == null ) {
        world = World.createStandardWorld();
      };
      // Create the Listener and initialize it:
      Object oego = listenerClass.newInstance();
      if ( oego instanceof ListenerAble ) {
        ListenerAble ego = (ListenerAble) oego;
        ego.initialize(nargv, world);
      } else {
        throw new Error("Incorrect ListenerAble class " + listenerClassName);
      }
    } catch (Exception exc) {
      System.err.print(usage);
      exc.printStackTrace(System.err);
    }
  }

}

// end of FromOS.java
