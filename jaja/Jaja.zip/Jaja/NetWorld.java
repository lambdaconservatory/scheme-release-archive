// $Id: NetWorld.java,v 3.2 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class represents a remote world. It acts as a proxy and
    relays all methods towards the remote world. It currently uses RMI. 

<P> QUESTION: How to parameterize Jaja wrt RMI or CORBA or DCOM etc...

<p> These worlds may be published in the registry of the current machine
so they may be used from remote sites.  */

import java.rmi.registry.*;
import java.net.URL;

public class NetWorld extends java.rmi.server.UnicastRemoteObject
  implements WorldAble {

  private World world;
  private String worldName;            // cache world.getName()
  protected URL worldURL = null;

  /** Create a NetWorld and publish it in the registry. */

  public NetWorld (String name) 
    throws java.rmi.RemoteException {
    worldName = name;
    world = new World(name);
    this.publish();
  }

  /** Encapsulate an existing world into a remote world. Do not publish it. */

  public NetWorld (World world)
    throws java.rmi.RemoteException {
    this.world = world;
    this.worldName = world.getName();
    this.worldURL = null;
  }

  /** A published world has an URL that looks like:
      rmi://localhost:1099/Jaja/<worldName> */

  public static final String worldsURLname = "rmi:///Jaja/";

  /** Publish a World on the net in the registry. Return the complete
      URL towards the published world. */
  
  public URL publish () {
    try {
      String url = worldsURLname + worldName;
      java.rmi.Naming.rebind(url, this);
      worldURL = new URL(url);
      return worldURL;
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

  public static WorldAble findPublishedWorld (String us) {
    try {
      return (WorldAble) java.rmi.Naming.lookup(us);
    } catch (Exception exc) {
      System.err.println("Cannot find world " + us);
      return null;
    }
  }

  /** Return the URL where the world may be remotely accessed. This
      forces the world to be published. b*/

  public URL getURL () {
    if ( worldURL == null ) {
      return this.publish();
    } else {
      return worldURL;
    }
  }

  /** Start a NetWorld ready to be bound to some Listener. */

  public static void main (String argv[]) {
    String worldName = "JajaNetWorld";
    try {
      System.setSecurityManager(new java.rmi.RMISecurityManager());
      // Create and start the registry instead of using a separate
      // rmiregistry command. The registry is closed when main finishes.
      try {
        LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
      } catch (Exception exc) {
        // The registry is probably already running.
      }
      // A single argument allows to specify the name of the World:
      if ( argv.length == 1 ) {
        worldName = argv[0];
      }
      // Create a world that will register itself in the registry;
      WorldAble world = new NetWorld(worldName);
    } catch (Exception exc) {
      System.err.println("Cannot start NetWorld: " + worldName + "\n" + exc);
    }
  }

  public String toString () {
    return worldName;
  }

  // Delegate the methods of the interface to the private world.

  public String getName ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getName()"); // trace
    System.err.flush();
    return worldName;
  }
  public Environment getEnvironment ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getEnvironment()"); // trace
    System.err.flush();
    return world.getEnvironment();
  }
  public void setEnvironment (Environment env)
    throws java.rmi.RemoteException {
    System.err.println(this + ".setEnvironment(" + env + ")"); // trace
    System.err.flush();
    world.setEnvironment(env);
  }
  public WorldAble getMacroWorld ()
    throws java.rmi.RemoteException {
    System.err.println(this + ".getMacroWorld()"); // trace
    System.err.flush();
    return world.getMacroWorld();
  }
  public void setMacroWorld (WorldAble w)
    throws java.rmi.RemoteException {
    System.err.println(this + ".setMacroWorld(" + world + ")"); // trace
    System.err.flush();
    world.setMacroWorld(w);
  }
  public EvaluationAble createEvaluation (Value program, 
                                          DynamicEnvironment denv)
    throws java.rmi.RemoteException {
    System.err.println(this + ".createEvaluation()"); // trace
    System.err.flush();
    return world.createEvaluation(program, denv);
  }
  public EvaluationAble createEvaluation (String program, 
                                          DynamicEnvironment denv)
    throws java.rmi.RemoteException {
    System.err.println(this + ".createEvaluation()"); // trace
    System.err.flush();
    return world.createEvaluation(program, denv);
  }

}

// end of NetWorld.java
