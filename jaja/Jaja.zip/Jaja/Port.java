// @version $Id: Port.java,v 2.1 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class is the abstract class for Input or Output ports. 
 */

public abstract class Port extends Value {
  
  abstract public void close ();

  // Finalize: Never leave non closed useless Ports.
  protected void finalize () {
    try {
      super.finalize();
      this.close();
    } catch (Throwable t) {
      // Ignore this! We did our best to handle that situation.
    }
  }

}

// end of Port.java
