// $Id: Monitor.java,v 2.7 1998/11/24 21:51:09 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the <tt>(monitor handler forms...)</tt> special form.  A
 * special form that allows to catch exceptions and to handle them
 * with a specified handler (which is run in the dynamic context of
 * the exception if this exception is continuable).
 *
 * <P> The <tt>monitor</tt> special form catches anomalies (aka Jaja
 * exceptions) or Java runtime exceptions. The latter are always non
 * continuable (the stack is unwinded before Jaja gets control again).
 * The former are diagnosed (aka raised in Jaja parlance) in some
 * special circumstances and may be continuable or not. To continue a
 * non continuable anomaly raises another (non continuable) anomaly.
 *
 * <P> Not all erroneous situations lead to anomalies since that
 * detection is expensive (in time and space). The compiler generates
 * code that performs verifications by simple cast expressions instead
 * of generating type checks. Once one has an ClassCastException, one
 * may read the code of Jaja at the accompanying line number and get
 * an idea of the invalid type error. 
 */

public final class Monitor extends SpecialOperator {

  // Construction

  protected Monitor () {
    super("monitor");
  }

  /** This is the name of the dynamic variable that contains the list
   * of all the handlers specified by the active monitor forms. These
   * handlers are kept in the dynamic environment. */

  static String tagName = "monitor_handlers";

  /** Perform the effect of a <tt>monitor</tt> special form. */

  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    if ( parameters instanceof Pair ) {
      Value handlerForm = ((Pair)parameters).car;
      Value handlerValue = handlerForm.eval(r, world);
      // Don't bark immediately if handlerValue is not a Procedure.
      parameters = ((Pair)parameters).cdr;
      Evaluation cev = currentEvaluation();
      DynamicEnvironment denv = Jaja.currentDynamicEnvironment();
      HandlerLink handlers = (HandlerLink) denv.getDynamicValue(tagName);
      DynamicEnvironment newDenv = 
        denv.extendDynamic(tagName, new HandlerLink(handlerValue, handlers));
      cev.setDynamicEnvironment(newDenv);
      try {
        return parameters.eprogn(r, world);
      } catch (EscapeObject eo) {
        throw eo;
      } catch (RuntimeException e) {
        cev.setDynamicEnvironment(denv);
        // Turn the exception into a non continuable anomaly.
        Anomaly a = new AnomalyFromException(e);
        return ((Procedure)handlerValue).invoke(a, FALSE);
      } finally {
        // Reset dynamic environment.
        cev.setDynamicEnvironment(denv);
      }
    } else {
        throw new RuntimeException("Bad monitor form");
    }
  }

  /** Raise an exception associated to a Jaja boolean telling whether
   * the exception may be continued or not. When a continuation is
   * continuable, the handler may return a value that will become the
   * value of the call to diagnose.
   *
   * <P> Exceptions may be raised by the <tt>diagnose</tt>
   * function. If the exception is continuable then the handler is run
   * in the dynamic context of the exception except that it is now
   * monitored by the handler that was previously current. */

  public static Value diagnose (Value exception,
                                Value continuable ) {
    Value result = null;
    Evaluation ev = Jaja.currentEvaluation();
    DynamicEnvironment denv = Jaja.currentDynamicEnvironment();
    HandlerLink handlers = (HandlerLink) denv.getDynamicValue(tagName);
    // Sanity check:
    if ( handlers == null ) {
      throw new RuntimeException("No diagnose handlers");
    }
    HandlerLink otherHandlers;
    // Never pop the last handler.
    if ( handlers.others != null ) {
      otherHandlers = handlers.others;
    } else {
      otherHandlers = handlers;
    }
    try {
      ev.setDynamicEnvironment(denv.extendDynamic(tagName, otherHandlers));
      result = ((Procedure)(handlers.handler)).invoke(exception, continuable);
      if ( continuable == FALSE ) {
        return diagnose(new Anomaly("Non continuable"), FALSE);
      } else {
        return result;
      }
    } catch (EscapeObject eo) {
      throw eo;
    } catch (RuntimeException e) {
      return diagnose(new AnomalyFromException(e), FALSE);
    } finally {
      // reset dynamic environment.
      ev.setDynamicEnvironment(denv);
    }
  }

  /** Create a default initial list of handlers. */
  
  public static HandlerLink createInitialHandler (Value handler) {
    return new HandlerLink(handler, null);
  }

}
 
// A simple class to hold the list of current handlers. 

class HandlerLink extends Jaja {

  // the current Handler and the shadowed HandlerLink.

  Value handler;
  HandlerLink others;

  HandlerLink (Value handler, HandlerLink others) {
    this.handler = handler;
    this.others  = others;
  }

}  

// end of Monitor.java
