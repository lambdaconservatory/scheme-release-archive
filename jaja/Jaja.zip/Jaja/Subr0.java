/** @version $Id: Subr0.java,v 2.1 1997/11/25 19:37:18 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of primitive functions with zero argument. */

public abstract class Subr0 extends Subr {

  // Constructor

  protected Subr0 (String n) {
    super(n);
  }

  // Invokers

  public Value invoke (Value args[]) {
    if ( args.length == 0 ) {
      return this.invoke();
    } else {
      return super.invoke(args);
    }
  }
  abstract public Value invoke ();

}

// end of Subr0.java
