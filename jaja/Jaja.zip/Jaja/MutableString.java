/** @version $Id: MutableString.java,v 2.2 1997/11/25 19:37:16 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of mutable strings. Immutable strings form a subclass.
 * @see ImmutableString 
 */

public class MutableString extends Value {

  // friend classes may access characters of that string directly.

  protected StringBuffer content;

  // Constructors

  public MutableString (String s) {
    content = new StringBuffer(s);
  }
  public MutableString (int size) {
    this(size, '?');
  }
  public MutableString (int size, char c) {
    content = new StringBuffer(size);
    for ( int i=0 ; i<size ; i++) {
      content.append(c);
    }
  }

  // Turn an array of Characters into a MutableString.

  public MutableString (Value arguments[]) {
    content = new StringBuffer(arguments.length);
    for ( int i=0 ; i<arguments.length ; i++ ) {
      content.append(((Character)(arguments[i])).value);
    }
  }

  /** Modify a Jaja string at a position given by index to hold the 
   * new character. Return the character that is overwritten. */

  public Value string_set (int index, char newChar) {
    char oldc = content.charAt(index);
    content.setCharAt(index, newChar);
    return Character.create(oldc);
  }

  // Printing

  public String toString () {
    return new String(content);
  }
  public String toReadableString () {
    StringBuffer result = new StringBuffer();
    result.append("\"");
    for ( int i=0 ; i<content.length() ; i++ ) {
      char c = content.charAt(i);
      switch (c) {
      case '"':
      case '\\': {
        result.append("\\" + c);
        break;
      }
      default: {
        result.append("" + c);
        break;
      }
      }
    }
    result.append("\"");
    return new String(result);
  }

}

// end of MutableString.java
