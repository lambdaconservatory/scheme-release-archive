// $Id: LocalEnvironment.java,v 2.2 1997/12/08 10:59:26 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class for local environments (a kind of Alist).  They
 * are used to implement the interpreter. A local environment directly
 * yields values.  */

public class LocalEnvironment extends Environment {

  private final String name;
  private Value value;

  // Constructor

  public LocalEnvironment (String n, Value v, Environment r) {
    name  = n;
    value = v;
    next  = r;
  }

  public Value lookup (String n) {
    if ( name.equals(n) ) {
      return value;
    } else {
      return next.lookup(n);
    }
  }

  public synchronized Value update (String n, Value v) {
    if ( name.equals(n) ) {
      Value old = value;
      value = v;
      return old;
    } else {
      return next.update(n, v);
    }
  }

}

// end of LocalEnvironment.java
