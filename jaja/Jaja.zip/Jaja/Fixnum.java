/** @version $Id: Fixnum.java,v 2.1 1997/11/25 19:37:14 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of fixnums ie small integers. To increase efficiency
 * very small integers are pre-allocated.
 */

public class Fixnum extends Number {

  /* package */ final long value;

  /** Small integers are preallocated from -127 to +256.  These
  * borders must have type int so they may be legal indexes for
  * arrays. */

  static private int border_max = +256;
  static private int border_min = -127;
  static private Fixnum[] numbers = 
    new Fixnum[border_max - border_min];

  static {
    for ( int i=border_min ; i<border_max ; i++ ) {
      numbers[i-border_min] = new Fixnum(i);
    }
  }

  // Constructor and creator
  // Don't need to synchronize since a Fixnum is immutable.

  private Fixnum (long i) {
    value = i;
  }
  public static Fixnum create (long i) {
    if ( border_min<=i && i<border_max ) {
      return numbers[((int)(i))-border_min];
    } else {
      return new Fixnum(i);
    }
  }

  // Coercing

  public double doubleValue () {
    return (double) value;
  }

  // Comparing

  public boolean eqnp (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value == ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) == ((Floatnum)other).value );
    } else {
      return false;
    }
  }
  public boolean lep (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value <= ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) <= ((Floatnum)other).value );
    } else {
      return false;
    }
  }
  public boolean ltp (Value other) {
    if ( other instanceof Fixnum ) {
      return ( this.value < ((Fixnum)other).value );
    } else if ( other instanceof Floatnum ) {
      return ( (double)(this.value) < ((Floatnum)other).value );
    } else {
      return false;
    }
  }

  // Operations

  public Number plus (Number other) {
    return other.fixnum_plus(this);
  }
  public Number fixnum_plus (Fixnum other) {
    long r = this.value + other.value;
    return Fixnum.create(r);
  }
  public Number floatnum_plus (Floatnum other) {
    double r = (double)(this.value) + other.value;
    return new Floatnum(r);
  }
  public Number minus (Number other) {
    // Attention, arguments are in reverse order!
    return other.fixnum_minus(this);
  }
  public Number fixnum_minus (Fixnum other) {
    long r = other.value - this.value;
    return Fixnum.create(r);
  }
  public Number floatnum_minus (Floatnum other) {
    double r =  other.value - (double)(this.value);
    return new Floatnum(r);
  }
  public Number times (Number other) {
    return other.fixnum_times(this);
  }
  public Number fixnum_times (Fixnum other) {
    long r = this.value * other.value;
    return Fixnum.create(r);
  }
  public Number floatnum_times (Floatnum other) {
    double r = (double)(this.value) * other.value;
    return new Floatnum(r);
  }

  // Printing

  public String toString () {
    return "" + value;
  }

}

// end of Fixnum.java
