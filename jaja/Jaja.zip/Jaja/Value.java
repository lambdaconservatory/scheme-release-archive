// $Id: Value.java,v 2.6 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the top class for all first-class values handled by
 * Jaja.  Default methods exist to compare, compute list-length or
 * print such values. 
 */

public abstract class Value extends Jaja {

  // Comparing

  /** Physical comparison: True if the two objects is the same. */

  public boolean eqp (Value other) {
    return ( this == other );
  }

  /** Structural comparison: True if the two objects have the same
   * class and content.  By default, equal? is similar to eq?. */

  public boolean equalp (Value other) {
    return this.eqp(other);
  }

  /** Computes the length of a Value. This is the base case for Values
   * that are not pairs (ie not part of a list). */

  public int list_length () {
    return 0;
  }

  /** Convert an array of Values into a list. This method is used in
   * the invocation protocol to gather remaining arguments into a
   * list. Only the value of the array with an index greater than i
   * are collected into a list. */

  public static Value listify (Value arguments[], int i) {
    Value result = NIL;
    for ( int j=arguments.length-1 ; j>=i ; j-- ) {
      result = Procedure.cons(arguments[j], result);
    }
    return result;
  }

  // Printing

  /** Convert a Value into a human-readable Java String. toString may
   * also be used by the Java debugger. */

  public String toString () {
    return "#<a " + this.getClass().getName() + ">";
  }

  /** Convert a Value into a computer-readable Java String. */

  public String toReadableString () {
    return this.toString();
  }

  /** Convert the content of a Value into a human-readable Java String. 
   * This is the base case used for Values that are not pairs. */

  public String toInnerString () {
    return ". " + this.toString();
  }

  /** Convert the content of a Value into a computer-readable Java
   * String.  This is the base case used for Values that are not
   * pairs. */

  public String toInnerReadableString () {
    return ". " + this.toReadableString();
  }

  //[ Evaluation 
  // Methods required to implement a Scheme interpreter in Java
  // are surrounded by square brackets in comments. This allows to
  // extract the pure Scheme runtime from this directory.

  /** Evaluation is autoquote by default for all values that is, all
   * Values have themselves as value. */

  public Value eval (Environment r, WorldAble world) {
    return this;
  }

  /** Evaluate a sequence of Values and return the value of the last
   * one. This is the base case for Values that are not pairs. */

  public Value eprogn (Environment r, WorldAble world) {
    throw new RuntimeException("Bad sequence");
  }
  public Value eprognInternal (Value previous, 
                               Environment r, 
                               WorldAble world ) {
    previous.eval(r, world);
    throw new RuntimeException("Bad Sequence");
  }
  
  //] Evaluation

}

// end of Value.java
