// $Id: Set.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>set!</CODE> special form.
 */

public class Set extends SpecialOperator {

  // Construction

  protected Set () {
    super("set!");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    Value variable;
    Value form;
    if ( parameters instanceof Pair ) {
        variable = ((Pair)parameters).car;
        parameters = ((Pair)parameters).cdr;
        if ( parameters instanceof Pair ) {
            form = ((Pair)parameters).car;
            parameters = ((Pair)parameters).cdr;
            if ( parameters != NIL ) {
                throw new RuntimeException("Bad assignment");
            }
            Value v = form.eval(r, world);
            if ( variable instanceof Symbol ) {
                return r.update(((Symbol)variable).name, v);
            } else {
                throw new RuntimeException("Not a variable");
            }
        } else {
            throw new RuntimeException("Missing form");
        }
    } else {
        throw new RuntimeException("Missing variable name");
    }
  }
  //] Evaluation

}

// end of Set.java
