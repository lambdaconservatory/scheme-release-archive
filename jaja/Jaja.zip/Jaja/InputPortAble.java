// $Id: InputPortAble.java,v 3.1 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the interface of objects that may serve as InputPort for Jaja. */

public interface InputPortAble extends java.rmi.Remote {
  public void close();
  
  public Value read_file ();
  public Value read ();
  public Value read_char ();

}

// end of InputPortAble.java
