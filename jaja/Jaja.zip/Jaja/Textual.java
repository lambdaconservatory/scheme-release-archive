// $Id: Textual.java,v 2.11 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

import java.net.*;
import java.io.*;

// import inspector.VISpy;     // @see http://gla.ecoledoc.lip6.fr/~nojean/

/** This class provides a textual access to Jaja. It reads expressions
 * from stdin and outputs results or anomalies on stdout and stderr.
 * Other more visual accesses exists. @see Listener. */

public class Textual extends Jaja 
implements ListenerAble {

  /** A short textual banner for Jaja. */

  protected static final String identification =
      ";;; Jaja: a Scheme interpreter in Java [" + Id.revision + "]\n"
    + ";;; \u00a9 1996-1998 <" + Id.authorEmail + ">. Free software (GPL)!\n"
    + ";;; Documentation: " + Id.docUrl + "\n";

  /** The associated world. */

  private transient WorldAble world;

  public void setWorld (WorldAble world) {
    try {
      this.world = world;
      denv = DynamicEnvironment.createDynamic("world", world);
      // Insert the default handler in the dynamic environment:
      Value defaultHandler = new Subr2("defaultHandler") {
        // The default handler aborts the current evaluation:
        public Value invoke (Value v, Value continuable) {
          Jaja.currentEvaluation().stop();
          // Never reached!
          return Jaja.UNSPECIFIED;
        }
      };
      denv = denv.extendDynamic(Monitor.tagName, 
                                Monitor.createInitialHandler(defaultHandler) );
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

  /** The default dynamic environment for toplevel evaluations. */
  
  private DynamicEnvironment denv;

  /** The base URL for the documentation. */

  protected URL url = null;

  /* The input/output ports if run from a shell. Pay attention to
   * these ports if you are running from an applet. */

  protected InputPort  in;
  protected OutputPort out;
  protected OutputPort err;

  /* Prompts. */

  protected String promptin  = "? ";
  protected String promptout = "= ";

  /** Initialize the textual interpreter when run from a command shell
   * (where input/output are Posix streams). Binds input and output
   * ports in the dynamic environment (so display, read and others may
   * find them).  */

  public Textual initializeAsCommand () {
    try {
      url = new URL(Id.docUrl);
    } catch (MalformedURLException exc) {
      url = null;
    }
    in  = new InputPort("stdin", new InputStreamReader(System.in));
    out = new OutputPort("stdout", new PrintWriter(System.out));
    err = new OutputPort("stderr", new PrintWriter(System.err));
    // Initialize the dynamic environment.
    denv = denv.extendDynamic("input_port", in);
    denv = denv.extendDynamic("output_port", out);
    denv = denv.extendDynamic("error_port", err);
    denv = denv.extendDynamic("url", url);
    return this;
  }
  
  // Constructor

  public Textual () {
  }

  // Read, display result and anomalies.

  /** Reads an Sexpression to evaluate on the input port. Emits a
   * prompt before. */

  public Value getProgram () {
    try {
      out.print(world.getName());
      out.print(promptin);
      out.flush();
      return in.read();
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

  public Value getProgramFromString (String s) {
    return InputPort.read(s);
  }

  /** Prints a result on the output port, prefixed with a prompt. */

  public void displayResult (Value v) {
    try {
      out.print(world.getName());
      out.print(promptout);
      out.print(v);
      out.newline();
      out.flush();
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      throw new RuntimeException(exc.getMessage());
    }
  }

  /** Display information about an anomaly on stderr. */

  public void displayAnomaly (EvaluationAble ev, Exception exception) {
    try {
      // Flush the output stream before reporting an error:
      out.flush();
      err.print("\n;;; Evaluation aborted! ");
      if ( ev != null ) {
        err.print("(status: " + ev.getStatusName() + ")");
      }
      err.print("\n");
      if ( exception != null ) {
        err.print("Exception: " + exception.getMessage() + "\n");
        err.flush();
      }
      exception.printStackTrace();       // Should print on err         FUTURE
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      err.print("Unexploitable details skipped.\n");
    }
  }

  /** Starts a toplevel ie an interactive (read-eval-print) loop. It
   * returns when the input port is exhausted or when the user calls
   * the exit function.  */

  public void toplevel () {
    while ( true ) {
      try {
        Value e = getProgram();
        if ( e == Jaja.EOF ) {
          return;
        } else {
          eval(e);
        }
      } catch (ExitObject exc) {
        out.flush();
        err.flush();
        System.exit(exc.code);
      } catch (Exception exc) {
        displayAnomaly(null, exc);
      }
    }
  }
  
  /** Evaluates one expression, displays its results then stops. */

  public void eval (Value e) {
    EvaluationAble ev = null;
    try {
      ev = world.createEvaluation(e, denv);
      // VISpy spy = new VISpy(ev);               // DEBUG
      Value value = ev.obtain();
      out.flush();
      displayResult(value);
    } catch (ExitObject exc) {
      // Transmit the exception, user evaluated ``(exit <code>)''
      throw exc;
    } catch (Exception exc) {
      displayAnomaly(ev, exc);
    }
  }

  /** Initialize the Listener so it may be used from FromOS. Analyze
      the command options. The -eval option gathers all remaining
      arguments in a string that is evaluated. In this case, the
      toplevel loop is not started. */
  
  public void initialize (String[] argv, WorldAble world) {
    if ( world != null ) {
      this.setWorld(world);
    }
    this.initializeAsCommand();
    if ( argv.length > 0 ) {
      if ( argv[0].equals("-eval") ) {
        // Concatenate the remaining options into a single string to evaluate:
        String programString = "";
        for (int i=1 ; i<argv.length ; i++ ) {
          programString += argv[i] + " ";
        }
        Value program = this.getProgramFromString(programString);
        this.eval(program);
      } 
    } else {
      // Enter an interactive toplevel loop:
      out.print(identification);
      out.flush();
      toplevel();
    }
  }

  /** Starts a stand-alone text-only Scheme interpreter directly from
      a shell with input/output bound to Posix streams. The Scheme
      interpreter may also be run from the FromOS class. @see FromOS */

  public static void main (String argv[]) {
    WorldAble w = World.createStandardWorld();
    Textual interpreter = new Textual();
    interpreter.initialize(argv, w);
  }

}

// end of Textual.java
