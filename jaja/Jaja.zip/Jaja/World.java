// $Id: World.java,v 2.6 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

import java.io.*;

/** This class implements a Jaja World. A World is characterized by a
 * global environment and a macroWorld used for expansion. Multiple
 * evaluations may be performed simultaneously in a World but,
 * alternatively, multiple independent Worlds may coexist.
 *
 * <P> A world is independent of any dynamic environment. */

public class World extends Jaja 
implements WorldAble {

  /** The name of the current world. */

  private String name;
  public String getName () {
    return name;
  }

  /** The global environment. Not everybody may change it. */

  private Environment environment;
  public synchronized void setEnvironment (Environment env) {
    if ( env != null ) {
      environment = env;
    } else {
      // By default, create a non empty global environment:
      GlobalEnvironment r = new GlobalEnvironment();
      r.adjoinPredefinedBindings();
      r.adjoinSpecialPredefinedBindings();
      r.adjoinOtherUsefulBindings();   // This one adds to R4RS.
      this.environment = r; 
      // Add eval, load, expand functions:
      this.enrichWorldWithWorldRelatedPrimitives();
    }
  }
  public synchronized Environment getEnvironment () {
    return environment;
  }

  /** Enrich the global environment with the functions that are
      world-related. These are eval, load and expand.  */

  public void enrichWorldWithWorldRelatedPrimitives () {
    environment.update("eval",   new Eval(this));
    environment.update("load",   new Load(this));
    environment.update("expand", new Expand(this));
  }    

  /** The associated macro world (see Reflection'96, "Macroexpansion
   * Reflective Tower" by C.Queinnec). */

  private WorldAble macro;
  public synchronized WorldAble getMacroWorld () {
    return macro;
  }
  // A null macroWorld means "don't expand":
  public synchronized void setMacroWorld (WorldAble world) {
    macro = world;
  }

  /** Create a world suitable to be a default macro world. This world
   */

  public static WorldAble createMacroWorld (String name) {
    World macroWorld = new World(name);
    macroWorld.setEnvironment(null);
    return macroWorld;
  }
  
  /** Create a World. It comes without macro world. It also comes with
      an empty global environement. Therefore it is just possible to
      evaluate closed forms (aka lambda-calculus).  */

  public World (String name) {
    this.name = name;
    macro = null;                           // No expansion
    environment = new GlobalEnvironment();  // Empty environment
  }

  /** The default name for a world and its macro world: */

  private static String worldName = "Jaja";
  private static String macroWorldName = "JajaMacro";

  /** Utility to create a standard world (with a macro world).
      Pay attention the macro world has no macro world. */

  public static WorldAble createStandardWorld () {
    World world = new World(worldName);
    // Initialize with default global environement:
    world.setEnvironment(null); 
    // Plug in the macro world;
    WorldAble macro = World.createMacroWorld(macroWorldName);
    world.setMacroWorld(macro);
    return world;
  }

  /** Create an Evaluation from a String but don't start it.  */
  
  public EvaluationAble createEvaluation (String program, 
                                          DynamicEnvironment denv) {
    Value v = InputPort.read(program);
    return createEvaluation(v, denv);
  }

  /** Create an Evaluation from a Value but don't start it.  */
  
  public EvaluationAble createEvaluation (Value program,
                                          DynamicEnvironment denv) {
    return new Evaluation(this, denv, program);
  }

  /** Preload files from the JAR file or CLASSPATH or URL.  */
  
  public EvaluationAble createFileEvaluation (String filename, 
                                              DynamicEnvironment denv ) {
    InputStream is = World.class.getResourceAsStream(filename);
    if ( is == null ) {
      throw new RuntimeException("No such file");
    } else {
      InputPort in = new InputPort(filename, new InputStreamReader(is));
      Value content = new Pair(Symbol.beginq, in.read_file());
      return createEvaluation(content, denv);
    }
  }

}

// end of World.java
