/** @version $Id: SubrN.java,v 2.1 1997/11/25 19:37:19 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of primitive procedures that accept an arbitrary
 *  number of arguments. */

public abstract class SubrN extends Subr {

  // Constructor

  protected SubrN (String n) {
    super(n);
  }

  // Invokers

  public Value invoke () {
    Value arguments[] = {};
    return this.invoke(arguments);
  }
  public Value invoke (Value a) {
    Value arguments[] = {a};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b) {
    Value arguments[] = {a, b};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b, Value c) {
    Value arguments[] = {a, b, c};
    return this.invoke(arguments);
  }
  public abstract Value invoke (Value args[]);

}

// end of SubrN.java
