// $Id: UninitializedLet.java,v 2.4 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>uninitialized-let</CODE> special form.
 * This special form does not belong to Scheme but is useful to
 * introduce local uninitialized local variables. For that it uses the
 * LocalUninitializedEnvironment. An uninitialized variable cannot be
 * read without error. 
 */

public final class UninitializedLet extends SpecialOperator {

  // Construction

  protected UninitializedLet () {
    super("uninitialized-let");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    Value variables = ((Pair)parameters).car;
    Value body      = ((Pair)parameters).cdr;
    int len         = variables.list_length();
    String[] names  = new String[len];
    for ( int i=0 ; i<len ; i++ ) {
      Symbol s  = (Symbol)(((Pair)variables).car);
      variables = ((Pair)variables).cdr;
      names[i]  = s.name;
    }
    r = new LocalUninitializedEnvironment(names, r);
    return body.eprogn(r, world);
  }
  //] Evaluation

}

// end of UninitializedLet.java
