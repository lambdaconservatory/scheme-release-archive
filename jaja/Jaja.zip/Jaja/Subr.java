/** @version $Id: Subr.java,v 2.1 1997/11/25 19:37:18 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the top class for all primitive Scheme procedures values.
 * It will be refined into Subr<EM>i</EM> depending on the arity
 * of the procedure or SubrN for variadic functions.
 * @see Subr0
 * @see Subr1
 * @see Subr2
 * @see Subr3
 * @see SubrN
 */

public abstract class Subr extends Procedure {

  /** The name of the primitive. This is used for printing and is also
   * useful when debugging. */

  private String name;

  // Constructor

  protected Subr (String n) {
    name  = n;
  }
  
  // Printing

  public String toString () {
    return "#<" + name + ">";
  }

}

// end of Subr.java
