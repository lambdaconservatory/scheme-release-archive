/** @version $Id: ExitObject.java,v 2.1 1997/11/25 19:37:14 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class helps to implement the (exit <code>) function that
 * allows to exit from an interpreter with a given numeric code (see
 * the exit function in Procedure.java). Normally, to exit
 * aborts the current evaluation and returns back to the run method of
 * Evaluation.java. 
 */

public class ExitObject extends EscapeObject {

  public int code;

  // Constructor
  public ExitObject (Fixnum v) {
    super(v);
    code = (int) v.value;
  }

}

// end of ExitObject.java
