// $Id: Symbol.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

import java.util.*;

/** This is the class of Scheme symbols. It is refined into special
 * symbols to recognize special form operators and give them an
 * appropriate behavior.
 */

public class Symbol extends Value {

  /** The name of the symbol is kept as a Scheme ImmutableString as
   * well as a String.  This avoids confusion and inefficient
   * conversions.  */

  /* package final */ ImmutableString pname;
  /* package final */ String name;

  // A hashtable of all symbols. This is to implement eqness between symbols. 

  private static Hashtable oblist = new Hashtable(32);

  /** Constructor and creators (protected since used by inheriting
   * classes).  Only the creator should be used to create symbols.
   * To use the intern methods of String does not seem useful. */

  protected Symbol (String n) {
    name  = n;
    pname = new ImmutableString(n);
    synchronized (oblist) {
      oblist.put(n, this);
    }
  }
  public static Symbol create (MutableString str) {
    String s = new String(str.content);
    return create(s);
  }
  public static Symbol create (String s) {
    synchronized (oblist) {
      if ( oblist.containsKey(s) ) {
        return (Symbol)(oblist.get(s));
      } else {
        return new Symbol(s);
      }
    }
  }

  // Printing

  public String toString () {
    return name;
  }

  //[ Evaluation

  /** r contains the lexical current environment while interp contains
   * the global environment (and other parameters). 
   */

  public Value eval (Environment r, WorldAble world) {
    return r.lookup(name);
  }

  /** Predefined symbols <CODE>if</CODE>, <CODE>begin</CODE> are
   * reserved keywords in Java, <CODE>set!</CODE> is not a legal
   * identifier: they're all suffixed with <CODE>q</CODE>.  If you add
   * another special form, you should register its name here. It is
   * necessary to create these special symbols now to avoid them being
   * recreated as regular symbols when read. 
   */

  public static final Symbol ifq =
    new If();
  public static final Symbol quote =
    new Quote();
  public static final Symbol beginq =
    new Begin();
  public static final Symbol setq =
    new Set();
  public static final Symbol lambda =
    new Lambda();
  public static final Symbol uninitialized_let =
    new UninitializedLet();
  public static final Symbol monitor =
    new Monitor();

  // These are reserved but not yet implemented. 

  public static final Symbol quasiquote = 
    create("quasiquote");
  public static final Symbol unquote = 
    create("unquote");
  public static final Symbol unquote_splicing = 
    create("unquote-splicing");

  // Other predefined symbols with special meaning.

  public static final Symbol symbol_eval =
    Symbol.create("eval");
  public static final Symbol symbol_load =
    Symbol.create("load");
  public static final Symbol symbol_expand =
    Symbol.create("expand");
  public static final Symbol symbol_eval_in_expansion_world =
    Symbol.create("eval-in-expansion-world");

  //] Evaluation

  /** Debugging: return the list of all interned (ie already seen)
   * symbols. */

  public static Value oblist () {
    Value result = NIL;
    Enumeration symbols;
    synchronized (oblist) {
      symbols = oblist.elements();
    }
    while ( symbols.hasMoreElements() ) {
      try {
        Symbol s = (Symbol)symbols.nextElement();
        result = Procedure.cons(s, result);
      } catch (NoSuchElementException exc) {
        // Should not occur.
      };
    }
    return result;
  }

}

// end of Symbol.java
