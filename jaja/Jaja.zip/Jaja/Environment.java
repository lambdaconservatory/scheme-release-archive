/** @version $Id: Environment.java,v 2.5 1997/12/08 10:59:25 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the abstract class for all kind of environments.
 * Environments should support lookup and update to read/write 
 * variables. They must also support extend to incorporate a
 * new variable but a default extend method is specified here.
 * An environment maps strings to values. 
 */

public abstract class Environment extends Entity {

  /** Environments may be linked through this field. */

  public Environment next;

  /** This method look for the value bound to a given variable. */

  abstract public Value lookup (String name);
  
  /** This method updates in place the value bound to a given variable. */

  abstract public Value update (String name, Value v);

  /** This method extends an environment with a new binding. 
   * For that and in all cases, it uses a LocalEnvironment. */

  public Environment extend (String name, Value v) {
    return new LocalEnvironment(name, v, this);
  }

}

// end of Environment.java
