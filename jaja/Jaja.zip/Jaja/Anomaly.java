// $Id: Anomaly.java,v 2.4 1997/12/15 17:29:11 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class for Anomaly raised or caught by the
 * implementation or raised explicitly by the user (using the diagnose
 * function). This class may be subclassed at will. @See
 * AnomalyFromException */

public class Anomaly extends Value {
  
  public final String message;

  /** Create an Anomaly with a specific reason to be displayed. */

  public Anomaly (String m) {
    message = m;
  }

  public String toString () {
    return "#<Anomaly: " + message + ">";
  }

}

// end of Anomaly.java
