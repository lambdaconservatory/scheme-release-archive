// $Id: SpecialOperator.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of special operator names. These are symbols
 * with a perform method that define how they handle such a special
 * form.  This schema is extendible, you just have to create a
 * subclass with a perform method and to register this symbol in the
 * oblist of symbols.
 */

public abstract class SpecialOperator extends Symbol {

  // Constructor. 
  // It must be present otherwise SpecialOperator() would be the
  // default constructor and Symbol() does not exist for sure!

  protected SpecialOperator (String n) {
    super(n);
  }

  //[ Evaluation

  /** Special operators must support a <CODE>perform</CODE> method.
   * The <CODE>>eval</CODE> method is also refined to provoke an error
   * since a special operator cannot be a legal variable.
   */
  
  public Value eval (Environment r, WorldAble world) {
    throw new RuntimeException("Cannot evaluate SpecialOperator " + name);
  }

  public abstract Value perform (Value parameters, 
                                 Environment r,
                                 WorldAble world );
  //] Evaluation

}

// end of SpecialOperator.java
