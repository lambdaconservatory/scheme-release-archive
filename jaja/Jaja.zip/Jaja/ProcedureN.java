/** @version $Id: ProcedureN.java,v 2.0 1997/11/23 10:27:25 queinnec Exp $
 * @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *         Christian.Queinnec@lip6.fr</A>
 * This file is part of a Scheme->Java compiler and implements a runtime
 * library for Jaja.
 */

package Jaja;

/** This class implements Scheme procedures with a dotted variable ie
 * that may accept a variable number of arguments. Extra arguments
 * are gathered into a freshly generated list before being bound to 
 * the dotted variable.
 */

public class ProcedureN extends Procedure {
    
  // Invokers
  public Value invoke () {
    Value arguments[] = {};
    return this.invoke(arguments);
  }
  public Value invoke (Value a) {
    Value arguments[] = {a};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b) {
    Value arguments[] = {a, b};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b, 
                             Value c ) {
    Value arguments[] = {a, b, c};
    return this.invoke(arguments);
  }

}

// end of ProcedureN.java
