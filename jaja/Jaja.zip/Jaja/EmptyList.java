// $Id: EmptyList.java,v 2.4 1998/11/24 15:47:58 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class containing an unique instance corresponding to
 *  the empty list.
 */

public final class EmptyList extends Constant {

  private EmptyList (String n) {
    super(n);
  }

  static final EmptyList NIL = new EmptyList("()");

  // Evaluation
  
  public Value eprogn (Environment r, WorldAble world) {
    return UNSPECIFIED;
  }
  public Value eprognInternal (Value previous,
                               Environment r, 
                               WorldAble world ) {
    return previous.eval(r, world);
  }

}

// end of EmptyList.java
