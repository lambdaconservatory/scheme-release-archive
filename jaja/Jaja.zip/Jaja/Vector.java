// $Id: Vector.java,v 2.4 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements Scheme mutable vectors. */

public class Vector extends Value {

  /** The content of the Scheme vector is public; it may be modified
   * via <code>v.item[index]</code> as R- or L-value. */

  public Value[] item;

  // Constructors

  public Vector (int size) {
    this(size, UNSPECIFIED);
  }
  public Vector (int size, Value defaultValue) {
    item = new Value[size];
    for ( int i=0 ; i<size ; i++ ) {
      item[i] = defaultValue;
    }
  }
  public Vector (Value arguments[]) {
    item = arguments;
  }

  // Comparing

  public boolean equalp (Value other) {
    if ( other instanceof Vector ) {
      Vector o = (Vector)other;
      if ( this.item.length == o.item.length ) {
        for ( int i=0 ; i<this.item.length ; i++ ) {
          if ( (this.item[i]).equalp(o.item[i]) ) {
            continue;
          } else {
            return false;
          }
        }
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  // Printing

  public String toString () {
    StringBuffer result = new StringBuffer();
    result.append("#(");
    for ( int i=0 ; i<this.item.length-1 ; i++ ) {
      result.append(item[i].toString() + " ");
    }
    if ( this.item.length>0 ) {
      result.append(item[item.length-1].toString());
    }
    result.append(")");
    return new String(result);
  }
  public String toReadableString () {
    StringBuffer result = new StringBuffer();
    result.append("#(");
    for ( int i=0 ; i<this.item.length-1 ; i++ ) {
      result.append(item[i].toReadableString() + " ");
    }
    if ( this.item.length>0 ) {
      result.append(item[item.length-1].toReadableString());
    }
    result.append(")");
    return new String(result);
  }

  //[ Evaluation
  
  /** R4RS does not specify whether vectors may be evaluated. Jaja
   * takes position and forbids it. */

  public Value eval (Environment r, WorldAble world) {
    throw new RuntimeException("Cannot evaluate a vector");
  }
  //] Evaluation

}

// end of Vector.java
