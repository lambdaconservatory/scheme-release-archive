// $Id: NamedCharacter.java,v 2.1 1997/12/07 18:58:54 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of named characters. They are specially
 * displayed.  A bunch of them is already created in the Character
 * class. */

public class NamedCharacter extends Character {
  public String name;

  protected NamedCharacter (char c, String name) {
    super(c);
    this.name = name;
  }

  // Printing

  public String toReadableString () {
    return "#\\" + name;
  }

}

// end of NamedCharacter.java
