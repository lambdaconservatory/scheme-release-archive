// $Id: Evaluation.java,v 2.12 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements the evaluation mechanism. The evaluation is
 * represented by a thread.  An Evaluation is a single-shot entity
 * that can only be used one time since it is no longer alive after
 * the death of the thread). This is a design choice (a hack?) since
 * some data are may be needed everywhere in the computation and it
 * would be dangerous to use global variables for this
 * information. Since it is everywhere possible to get the current
 * Thread and to subclass Thread to offer additional data, I used this
 * technique to provide a dynamic environment that will hold the
 * values of ubiquitous data such as the current input port, the URL
 * of the applet etc. */

public class Evaluation extends Thread 
  implements EvaluationAble {

  /** All evaluations are performed in a given world. */
  
  private /* final */ WorldAble world;

  public WorldAble getWorld () {
    return world;
  }

  /** All evaluations take an expression to evaluate. This is the
      original expression but it becomes the expanded expression after
      state EXPANDED. */

  private /* final */ Value expression;

  /** All evaluation require a dynamic environment: this is required
   * to at least hold the input/output ports. */

  private /* final */ DynamicEnvironment dynamic;
  public synchronized DynamicEnvironment getDynamicEnvironment () {
    return dynamic;
  }
  public synchronized void setDynamicEnvironment (DynamicEnvironment denv) {
    dynamic = denv;
  }

  /** Get the instantaneous status of the result of an Evaluation. */
  
  private int status = UNSTARTED;
  public synchronized int getStatus () {
    return status;
  }
  protected synchronized void setStatus (int status) {
    this.status = status;
  }
  public String getStatusName () {
    return EvaluationAble.statusName[getStatus()];
  }

  /** The computed value or the exception. The status fixes the
      ambiguity which one may be safely read. */

  protected Value result = null;
  protected Exception exception = null;

  /** Synchronous evaluation within a World. Returns the final value
      or throws the obtained exception. 
  @exception Exception errors when running Jaja belong to RuntimeException, 
      Other errors may occur due to remote method invokation.  */

  public Value obtain () throws Exception {
    while ( true ) {
      switch (status) {
      case EVALUATED: {
        return result;
      }
      case UNEVALUATED:
      case UNEXPANDED:
      case EXITED: 
      case UNCAUGHT: {
        throw exception;
      }
      case UNSTARTED: {
        start();
        // fall through
      }
      case STARTING:
      case EVALUATING:
      case EXPANDED: 
      case EXPANDING:
      case EXITING: {
        join();
        continue;
      }
      default: {
        throw new RuntimeException("Weird status " + statusName[status]);
      }
      }
    }
  }
  
  /** Prepare for the evaluation of an expression E in the global
   * environment WORLD and dynamic environment DENV. The evaluation is
   * not immediately started.  */

  public Evaluation (WorldAble w, DynamicEnvironment denv, Value e) {
    world      = w;
    dynamic    = denv;
    expression = e;
    setStatus(UNSTARTED);
  }

  /** Perform an Evaluation.  The expression is macroexpanded before
   * being evaluated.  This method is overriden in the Invokation
   * class. @see Invokation */

  public void run () {
    setStatus(STARTING);
    //System.err.println("Starting with " + expression); // DEBUG
    try {
      try {
        setStatus(EXPANDING);
        // Expand the program:
        WorldAble macro = world.getMacroWorld();
        if ( macro != null ) {
          // Really macroexpand in the macro world: try to evaluate the
          // (expand (quote expression)) Sexpression.
          Value[] e1 = { Symbol.quote, expression };
          Value[] e2 = { Symbol.symbol_expand, Procedure.list(e1) };
          Value e = Procedure.list(e2);
          EvaluationAble ev = macro.createEvaluation(e, null);
          // Replace the original expression with the macro-expanded one:
          expression = ev.obtain();
          setStatus(EXPANDED);
          //System.err.println("Expansion yields " + expression); // DEBUG
        } else {
          setStatus(EXPANDED);
          //System.err.println("Continuing with " + expression); // DEBUG
        }
      } catch (Exception exc) {
        // An error occurred while macro-expanding:
        exception = exc;
        setStatus(UNEXPANDED);
        //System.err.println("Expansion problem " + exception); // DEBUG
        return;
      }
      // The dynamic environment is passed implicitly via the current thread:
      setStatus(EVALUATING);
      result = expression.eval(world.getEnvironment(), world);
      setStatus(EVALUATED);
      //System.err.println("Result is " + result); // DEBUG
    } catch (ExitObject eo) {
      // The evaluation performed (exit <code>)
      exception = eo;
      setStatus(EXITED);
    } catch (EscapeObject eo) {
      // The evaluation performed (<continuation> <value>) and
      // <continuation> was no longer active.
      exception = eo;
      setStatus(UNCAUGHT);
    } catch (Exception exc) {
      exception = exc;
      setStatus(UNEVALUATED);
      //System.err.println("Evaluation problem " + exception); // DEBUG
    }
  }  

}

// end of Evaluation.java
