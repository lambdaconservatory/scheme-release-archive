// $Id: OutputPortAble.java,v 3.1 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the interface of objects that may serve as OutputPort for Jaja. */

public interface OutputPortAble extends java.rmi.Remote {

  public void close ();

  public void flush ();
  public void newline ();
  public void print (Value o);
  public void write (Value o);
  public void print (String s);
  public void print (char c);
  public void print (double d);
  public void print (int i);
  
}

// end of OutputPortAble.java
