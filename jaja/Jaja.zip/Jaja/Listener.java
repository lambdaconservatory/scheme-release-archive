// $Id: Listener.java,v 2.13 1998/11/30 09:22:04 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class provides an Applet to run a Scheme interpreter. */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class Listener extends Applet 
  implements ActionListener, ListenerAble {

  // Meta information

  protected static final String identification =
      ";;; Jaja: a Scheme interpreter in Java [" + Id.revision + "]\n"
    + ";;; (C)  1996-1998 <" + Id.authorEmail + ">. Free software (GPL)!\n"
    + ";;; Documentation: " + Id.docUrl + "\n";

  public String getAppletInfo () {
    return identification;
  }

  public String[][] getParameterInfo () {
    String[][] info = {
      { "expression", "string", "Scheme expression to evaluate"},
      { "lines",      "positive integer", 
        "number of lines of the input window (default " + lines + ")"},
      { "columns",    "positive integer", 
        "number of columns of the input window (default " + columns + ")"}
    };
    return info;
  }

  // The browser may invoke this method on the applet. It should be refined.

  public void print (Graphics g) {
    super.print(g);
  }

  // GUI components

  protected Font logofont = new Font("Helvetica", Font.BOLD, 24);
  protected final Color  logocolor = Color.red;
  protected final String logoname  = "Jaja";
  public int lines   = 8;
  public int columns = 60;
  public int width  = 500;
  public int height = 310;
  private TextArea input;
  private Button send_button;
  private Button stop_button;
  private Button clear_button;
  private TextField statusLine;

  // Interpreter components

  private transient WorldAble          world;
  private transient DynamicEnvironment denv;
  private transient OutputStringPort   out;
  /** There is at most one evaluation directly started by the
   * listener.  This the one which is aborted with the 'stop'
   * button. */
  private transient EvaluationAble evaluation;

  // Constructor

  public Listener () {
  }

  // Read, display result and anomalies.

  public Value getProgram () {
    showStatus("Reading program...");
    try {
      String text = input.getText();
      return InputPort.read(text);
    } catch (Exception exc) {
      showStatus(exc.getMessage());
      try {
        Thread.sleep(1000); // debug
      } catch (InterruptedException ex) {};
      return null;
    }
  }

  public void displayResult (Value v) {
    input.append("\n;;; Result is:\n" + v + "\n");
  }

  public void displayAnomaly (EvaluationAble ev, Exception exception) {
    try {
      input.append("\n;;; Evaluation aborted! (status ");
      if ( ev != null ) {
        input.append(ev.getStatusName());
      } else {
        input.append("?");
      }
      input.append(")\n" );
      input.append("Exception: " + exception.getMessage() + "\n");
    } catch (RuntimeException exc) {
      throw exc;
    } catch (Exception exc) {
      input.append("Skipping unexploitable details.\n" + exc.toString());
    }
  }

  // Actions

  private void actionForSend () {
    Value program = getProgram();
    if ( (program == null) || (program == Jaja.EOF) ) {
      showStatus("Incomplete program.");
    } else {
      if ( evaluation == null ) {
        showStatus("Evaluating ...");
        out.getText(); // Reset OutputStringPort
        try {
          evaluation = world.createEvaluation(program, denv);
          Value v = evaluation.obtain();
          showStatus("End of evaluation.");
          displayResult(v);
        } catch (ExitObject eo) {
          showStatus("Evaluation stopped.");
          this.stop();
        } catch (Exception exc) {
          showStatus("Abandoned evaluation.");
          displayAnomaly(evaluation, exc);
        }
        evaluation = null;
      } else {
        showStatus("Already evaluating ...");
      }
    }
  }

  private void actionForStop () {
    if ( evaluation != null ) {
      showStatus("Stopping evaluation...");
      try {
        evaluation.stop();
      } catch (Exception exc) {}
      showStatus("Evaluation stopped...");
      evaluation = null;
    } else {
      showStatus("No current evaluation.");
    }
  }

  private void actionForClear () {
    input.setText("");
    if ( evaluation == null ) {
      showStatus("Type an expression");
    } else {
      showStatus("Evaluation in progress...");
    }
  }

  public void actionPerformed (ActionEvent event) {
    if ( event.getSource() == send_button ) {
      actionForSend();
      input.requestFocus();
    } else if ( event.getSource() == stop_button ) {
      actionForStop();
      input.requestFocus();
    } else if ( event.getSource() == clear_button ) {
      actionForClear();
      input.requestFocus();
    } else {
      // Action not recognized.
    }
  }

  /** Get a numeric parameter from the html page.  If the applet is
   * run from an OS shell then there is no parameter present then
   * return the second argument. */

  public int getIntParameter (String name, int i) {
    String s = this.getParameter(name);
    if ( s != null ) {
      try {
        i = Integer.parseInt(s);
      } catch (NumberFormatException exc) {
        // nothing
      }
    }
    return i;
  }

  /** Get a string parameter from the html page.  If the applet is run
   * from an OS shell then there is no parameter present then return
   * the second argument. */

  public String getStringParameter (String name, String s) {
    String ns = this.getParameter(name);
    if ( ns != null ) {
      return ns;
    } else {
      return s;
    }
  }

  /** This is the equivalent of the status line provided by html
   * clients (Netscape or Explorer) when Jaja is started as an applet
   * from an OS shell. The next method uses the appropriate status
   * line. */

  public void showStatus (String msg) {
    statusLine.setText(msg);
  }

  /** Initialize the GUI objects. */

  public void initializeGUI () {
    Label label = new Label();
    label.setFont(logofont);
    label.setForeground(logocolor);
    label.setText(logoname + " \u00a9 " + Id.authorEmail);
    this.setLayout(new BorderLayout(1, 1));
    this.add("North", label);
    // Four buttons in a row.
    Panel p = new Panel();
    p.setLayout(new FlowLayout());
    send_button  = new Button("Evaluate");
    stop_button  = new Button("Stop");
    clear_button = new Button("Clear");
    p.add(send_button);
    p.add(stop_button);
    p.add(clear_button);
    this.add("South", p);
    // a status line (in the applet rather than in the bottom of the browser).
    statusLine = new TextField(java.lang.Math.min(30, columns));
    statusLine.setEditable(false);
    p.add(statusLine);
    // Connect applet to its event producers (AWT 1.1)
    send_button.addActionListener(this);
    stop_button.addActionListener(this);
    clear_button.addActionListener(this);
    // Context-dependent parameters.
    lines = getIntParameter("lines", lines);
    columns = getIntParameter("columns", columns);
    input = new TextArea(lines, columns);
    input.setEditable(true);
    String s = this.getStringParameter("expression", "(exit 0)");
    // was input.appendText with AWT 1.0. Unfortunately Communicator
    // 4.03 (still at Java 1.1.2) does not know the input.append method.
    // So I put a single setText method. But then Communicator does not
    // know the addActionListener method...
    input.setText(identification + s);
    this.add("Center", input);
    // Always give focus to the textarea.
    input.requestFocus();
    // FUTURE: Cursor text appears on scrollbars ?
  }

  /** Set the world bound to this Listener. */

  public void setWorld (WorldAble world) {
    this.world = world;
    out = new OutputStringPort();
    denv = DynamicEnvironment.createDynamic("world", world);
    // Insert the default error handler in the dynamic environment:
    Value defaultHandler = new Subr2("defaultHandler") {
      // The default handler aborts the current evaluation:
      public Value invoke (Value v, Value continuable) {
        Jaja.currentEvaluation().stop();
        // Never reached!
        return Jaja.UNSPECIFIED;
      }
    };
    denv = denv.extendDynamic(Monitor.tagName, 
                              Monitor.createInitialHandler(defaultHandler) );
    denv = denv.extendDynamic("output_port", out);
    // error output is merged with regular output:
    denv = denv.extendDynamic("error_port", out);
    // Should implement an input port.                           FUTURE
    denv = denv.extendDynamic("url", getDocumentBase());
  }

  /** Initialize the applet. */

  public void init () {
    super.init();
    if ( world == null ) {
      this.setWorld(World.createStandardWorld());
    }
    initializeGUI();
  }

  /** When called from a shell, there is no surrounding frame. This
      method is used by FromOS to ask the applet to draw its own frame
      (of the correct size) and to draw itself in it. */

  public void createOwnFrame () {
    final Frame frame = new Frame(this.getClass().getName());
    frame.add("Center", this);
    frame.setSize(width, height);
    // Created from here, the applet has no associated stub. This
    // makes getDocumentBase or getParameter errs. This Stub makes
    // the applet feel like being called from the Jaja.html page.
    class VoidAppletStub implements AppletStub {
      public void appletResize (int width, int height) {
        frame.setSize(width, height);
      }
      public AppletContext getAppletContext () { return null; }
      public URL getCodeBase () { 
        try {
          URL jajaUrl = new URL(Id.docUrl);
          return new URL(jajaUrl, "Java");
        } catch (MalformedURLException e) {
          return null;
        }
      }
      public URL getDocumentBase () {
        try {
          return new URL(Id.docUrl);
        } catch (MalformedURLException e) {
          return null;
        }
      }
      public String getParameter (String name) { return null; }
      public boolean isActive () { return true; }
    };
    this.setStub(new VoidAppletStub());
    frame.setVisible(true);
  }

  /** Initialize the Listener so it may be used from FromOS. */
  
  public void initialize (String[] argv, WorldAble world) {
    this.createOwnFrame();
    this.init();
    this.start();
  }

}

// end of Listener.java

