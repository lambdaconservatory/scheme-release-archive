// $Id: InputStringPort.java,v 2.1 1997/12/09 19:47:22 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements an input port that reads from a string. */

import java.io.*;

public class InputStringPort extends InputPort {
  
  // Constructors

  public InputStringPort (String s) {
    super("aString", new StringReader(s));
  }
  public InputStringPort (MutableString s) {
    this(new String(s.content));
  }

}

// end of InputStringPort.java
