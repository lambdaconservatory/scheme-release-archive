/** @version $Id: Number.java,v 2.0 1997/11/23 10:27:24 queinnec Exp $
 * @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *         Christian.Queinnec@lip6.fr</A>
 * This file is part of a Scheme->Java compiler and implements a runtime
 * library for Jaja.
 */

package Jaja;

/** This is the nearly abstract class of the various sorts of numbers.
 * It also exports all the generic operations on numbers. 
 * <P> This class implements default method which are shadowed in 
 * the Fixnum and Floatnum classes. Two different strategies 
 * are used: <UL><LI> arithmetic predicates have a default behavior on 
 * Numbers and discriminate on the type of their second argument.
 * <LI> arithmetic operations use double dispatch with sub-methods
 * fixnum_op and floatnum_op. </UL>
 */

public abstract class Number extends Value {

  // Coercing
  public double doubleValue () {
    throw new RuntimeException("Cannot convert to double");
  }

  // Comparing
  public boolean equal (Value other) {
    return this.eqnp(other);
  }
  public boolean eqnp (Value other) {
    return false;
  }
  public boolean lep (Value other) {
    return false;
  }
  public boolean ltp (Value other) {
    return false;
  }
  public boolean gep (Value other) {
    return ! ( this.ltp(other) );
  }
  public boolean gtp (Value other) {
    return ! ( this.lep(other) );
  }

  // Operations (cannot be abstract unless the whole class is abstract
  // and at that time default behaviors for predicates cannot be defined).
  public Number plus (Number other) {
    throw new RuntimeException("Cannot add these numbers");
  }
  public Number fixnum_plus (Fixnum other) {
    throw new RuntimeException("Cannot add these numbers");
  }
  public Number floatnum_plus (Floatnum other) {
    throw new RuntimeException("Cannot add these numbers");
  }
  public Number minus (Number other) {
    throw new RuntimeException("Cannot subtract these numbers");
  }
  public Number fixnum_minus (Fixnum other) {
    throw new RuntimeException("Cannot subtract these numbers");
  }
  public Number floatnum_minus (Floatnum other) {
    throw new RuntimeException("Cannot subtract these numbers");
  }
  public Number times (Number other) {
    throw new RuntimeException("Cannot multiply these numbers");
  }
  public Number fixnum_times (Fixnum other) {
    throw new RuntimeException("Cannot multiply these numbers");
  }
  public Number floatnum_times (Floatnum other) {
    throw new RuntimeException("Cannot multiply these numbers");
  }
    
}

// end of Number.java
