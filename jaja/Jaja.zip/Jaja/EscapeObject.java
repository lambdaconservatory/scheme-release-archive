// $Id: EscapeObject.java,v 2.1 1997/12/08 10:59:25 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class wraps a Scheme value into a Java Exception to be thrown
 * where the call/ep function was called. Such an entity should never
 * be seen from the Scheme runtime since it only exists while being
 * thrown. To extend RuntimeException spares many ``throws'' clauses
 * for all Scheme classes. This class is used by the <tt>callep</tt>
 * function. */

public class EscapeObject extends RuntimeException {

  protected Value value;

  // Constructor

  public EscapeObject (Value v) {
    value = v;
  }

}

// end of EscapeObject.java
