// $Id: EvaluationAble.java,v 2.6 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This interface characterizes an Evaluation performed by a World on
    behalf of a Listener. The interface looks a little like a Thread:
    one may start an evaluation or stop it. One may also inspect the
    Evaluation to discover in which world it is run. */

public interface EvaluationAble extends java.rmi.Remote {

  /** Discover in which world the evaluation takes place. */

  public WorldAble getWorld () 
    throws java.rmi.RemoteException;

  /** Discover in which dynamic environment the evaluation takes place. */

  public DynamicEnvironment getDynamicEnvironment ()
    throws java.rmi.RemoteException;

  /** An EvaluationAble always maintains an uptodate status which may be
      one of the codes below. The status is initially UNSTARTED and,
      mormally, ends up with DONE. Various intermediary phases exist to
      record the various states of the EvaluationAble: UNEVALUATED means that
      an error occured when evaluating while UNEXPANDED means that an
      error occured when expanding. 
      <p>
      The normal succession of state is as follows:
 UNSTARTED -> STARTING -> EXPANDING -> EXPANDED -> EVALUATING -> EVALUATED
                                    |                         |
                                    +> UNEXPANDED             +> UNEVALUATED
      */

  public int getStatus ()
    throws java.rmi.RemoteException;

  /** This method converts the current status into a
      String. Unfortunately its code must be duplicated in every class
      implementing the current interface. */

  public String getStatusName ()
    throws java.rmi.RemoteException;

  public static final int EVALUATED   = 0; // terminal error-free state
  public static final int UNSTARTED   = 1; // temporary, initial state
  public static final int STARTING    = 2; // temporary state
  public static final int EVALUATING  = 3; // temporary state
  public static final int UNEVALUATED = 4; // terminal state with error
  public static final int EXPANDING   = 5; // temporary state
  public static final int UNEXPANDED  = 6; // terminal state with error
  public static final int EXPANDED    = 7; // terminal state
  public static final int EXITING     = 8; // temporary state
  public static final int EXITED      = 9; // terminal state
  public static final int UNCAUGHT    = 10; // terminal state with error

  public static final String[] statusName = {
    /* 0  */ "evaluated", 
    /* 1  */ "unstarted",
    /* 2  */ "starting",
    /* 3  */ "evaluating",
    /* 4  */ "unevaluated",
    /* 5  */ "expanding",
    /* 6  */ "unexpanded",
    /* 7  */ "expanded",
    /* 8  */ "exiting",
    /* 9  */ "exited",
    /* 10 */ "uncaught",
  };    

  /** The obtain method allows to get the final Value computed by an
      EvalutationAble evaluation or to raise the Exception yielded by
      this EvaluationAble evaluation. If a final state of the
      EvaluationAble is not yet attained, wait until this is
      true. This method is therefore synchronous.
  @exception Exception errors when running Jaja belong to RuntimeException, 
      Other errors may occur due to remote method invokation. */

  public Value obtain ()
    throws Exception, java.rmi.RemoteException;

  // Methods similar to the methods on Thread:

  public void start ()
    throws java.rmi.RemoteException;
  public void stop ()
    throws java.rmi.RemoteException;
  public void suspend ()
    throws java.rmi.RemoteException;
  public void resume ()
    throws java.rmi.RemoteException;
}

// end of EvaluationAble.java
