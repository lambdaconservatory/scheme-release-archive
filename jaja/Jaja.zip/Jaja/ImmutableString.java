/** @version $Id: ImmutableString.java,v 2.1 1997/11/24 17:09:55 queinnec Exp $
 * @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *         Christian.Queinnec@lip6.fr</A>
 * This file is part of a Scheme->Java compiler and implements a runtime
 * library for Jaja.
 */

package Jaja;

/** This is the class of immutable strings. Scheme says that a string
 * that appears quoted in a program (ie surrounded with double quotes)
 * is immutable. This class refines MutableString and redefines
 * string_set to forbid modifications. 
 */

public class ImmutableString extends MutableString {

  public ImmutableString (String s) {
    super(s);
  }

  public Value string_set (int index, char newChar) {
    throw new RuntimeException("Cannot modify an ImmutableString"); 
  }

}

// end of ImmutableString.java
