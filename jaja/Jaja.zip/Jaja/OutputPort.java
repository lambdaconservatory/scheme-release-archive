// $Id: OutputPort.java,v 2.2 1998/11/28 20:14:44 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This class implements output ports for Jaja. */

import java.io.*;

public class OutputPort extends Port 
implements OutputPortAble {

  protected String name;
  protected PrintWriter stream;

  // Constructors

  public OutputPort () {
    // Implicitly used by OutputStringPort.
  }
  public OutputPort (String n, PrintWriter s) {
    this.name   = n;
    this.stream = s;
  }
  public OutputPort (String s) {
    try {
      name = s;
      FileOutputStream fos = new FileOutputStream(s);
      stream   = new PrintWriter(fos);
    } catch (IOException e) {
      throw new RuntimeException(e.getMessage());
    }
  }

  /** Close an output port. */

  public void close () {
    stream.close();
  }

  // Printing

  public String toString () {
    return "#<OutputPort: " + name + ">";
  }

  // Printing machinery

  public synchronized void flush () {
    stream.flush();
  }
  public synchronized void newline () {
    stream.println();
    stream.flush();
  }

  // The two ways of printing a value.

  public void print (Value o) {
    this.print(o.toString());
  }
  public void write (Value o) {
    this.print(o.toReadableString());
  }

  // Basic printing method for Java values.

  public synchronized void print (String s) {
    stream.print(s);
  }
  public synchronized void print (char c) {
    stream.print(c);
  }
  public synchronized void print (double d) {
    stream.print(d);
  }
  public synchronized void print (int i) {
    stream.print(i);
  }

}

// end of OutputPort.java
