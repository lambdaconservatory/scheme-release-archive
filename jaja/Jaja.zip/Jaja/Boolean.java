/** @version $Id: Boolean.java,v 2.2 1997/11/25 19:37:13 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of Boolean values. It statically defines the
 * only two possible Boolean instances.
 * 
 * <P> These are named TRUE and FALSE (in uppercase) not to interfere
 * with the related Java keywords.
 */

public final class Boolean extends Constant {
  
  private Boolean (String n) {
    super(n);
  }

  static final Boolean TRUE  = new Boolean("#t");
  static final Boolean FALSE = new Boolean("#f");

}

// end of Boolean.java
