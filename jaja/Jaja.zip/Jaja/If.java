// $Id: If.java,v 2.3 1998/11/24 13:46:18 queinnec Exp $
/** @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class (with a single instance allocated in Symbol)
 * that implements the <CODE>if</CODE> special form.
 */

public class If extends SpecialOperator {

  // Construction

  protected If () {
    super("if");
  }

  //[ Evaluation
  public Value perform (Value parameters, 
                        Environment r,
                        WorldAble world ) {
    Value condition;
    Value consequent;
    Value alternant = null;
    if ( parameters instanceof Pair ) {
      condition = ((Pair)parameters).car;
      parameters = ((Pair)parameters).cdr;
      if ( parameters instanceof Pair ) {
        consequent = ((Pair)parameters).car;
        parameters = ((Pair)parameters).cdr;
        if ( parameters instanceof Pair ) {
          alternant = ((Pair)parameters).car;
          if ( ((Pair)parameters).cdr != NIL ) {
            throw new RuntimeException("Bad alternative");
          }
        } else if ( parameters != NIL ) {
            throw new RuntimeException("Bad alternative");
        }
        if ( condition.eval(r, world) != FALSE ) {
          return consequent.eval(r, world);
        } else {
          if ( alternant != null ) {
            return alternant.eval(r, world);
          } else {
            return UNSPECIFIED;
          }
        }
      } else {
        throw new RuntimeException("Missing consequent");
      }
    } else {
      throw new RuntimeException("Missing condition");
    }
  }
  //] Evaluation

}

// end of If.java
