/** @version $Id: Procedure.java,v 2.7 1998/11/24 15:47:58 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class defining the behavior of all Scheme predefined
 * procedures. These behaviors do not correspond to Scheme values (see
 * PredefinedValues for that) answering true to
 * <code>procedure?</code> predicate, they rather are the Java methods
 * that implement the Jaja primitives. You may use directly those
 * behaviors that have a fixed arity by saying
 * <TT>Procedure.cons(aValue, anotherValue)</TT> or simply as
 * <TT>car(aValue)</TT> if inheriting from the Procedure class. If the
 * arity is variant, these are n-ary functions, then write
 * <TT>list(anArrayOfValues)</TT> instead.
 *
 * <P> No explicit error checking is done that is, we leave to Java to
 * take care of the validity of cast or message sending. Therefore we
 * do not need a special Exception class nor we have to explicit that
 * these procedures may throw RuntimeExceptions.
 *
 * <P> Most of the implementation lies in the functions here and not
 * in the classes that define the associated data (ie <CODE>car</CODE>
 * is there and not in Pair.java). This is to avoid indirections (as
 * well as name clashes: the static <tt>car</tt> method cannot be
 * defined in Pair that already contains a <tt>car</tt> field). Since
 * Scheme is not statically typed, all these functions take Values and
 * return Values. Arguments are appropriately cast in their definition
 * (these casts are checked by Java).
 *
 * <P> The invocation mechanism is pretty complex. The shape of a call
 * to a procedure <EM>p</EM> depends on the number of arguments. Only
 * invocations up to ten arguments are considered.  Invocations with
 * strictly more than 3 arguments pass through an array of arguments
 * otherwise the procedure is invoked with that number of arguments.
 *
 * <P> Arity checking is done by Java. All methods that follow are
 * default methods and must be refined according to the type of the
 * procedure (@see Subr2 for instance that refines the invoke
 * method for two arguments).
 * */

public abstract class Procedure extends Value {

  // Invokers

  public Value invoke () {
    throw new RuntimeException("Wrong arity");
  }
  public Value invoke (Value a) {
    throw new RuntimeException("Wrong arity");
  }
  public Value invoke (Value a, Value b) {
    throw new RuntimeException("Wrong arity");
  }
  public Value invoke (Value a, Value b, Value c) {
    throw new RuntimeException("Wrong arity");
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d ) {
    Value arguments[] = {a, b, c, d};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e ) {
    Value arguments[] = {a, b, c, d, e};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e, Value f ) {
    Value arguments[] = {a, b, c, d, e, f};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e, Value f,
                             Value g ) {
    Value arguments[] = {a, b, c, d, e, f, g};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e, Value f,
                             Value g, Value h ) {
    Value arguments[] = {a, b, c, d, e, f, g, h};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e, Value f,
                             Value g, Value h,
                             Value i ) {
    Value arguments[] = {a, b, c, d, e, f, g, h, i};
    return this.invoke(arguments);
  }
  public Value invoke (Value a, Value b,
                             Value c, Value d,
                             Value e, Value f,
                             Value g, Value h,
                             Value i, Value j ) {
    Value arguments[] = {a, b, c, d, e, f, g, h, i, j};
    return this.invoke(arguments);
  }
  /** RESTRICTION: The Scheme to Java compiler does not support
   * functions with more than 10 arguments (nor the implementation of
   * apply). */
  public Value invoke (Value args[]) {
    throw new RuntimeException("Wrong arity");
  }

  // Predefined functions

  // Functions on pairs.

  public static Value car (Value a) {
    return ((Pair) a).car;
  }
  public static Value cdr (Value a) {
    return ((Pair) a).cdr;
  }
  public static Value cons (Value a, Value d) {
    return new Pair(a, d);
  }
  public static Value set_car (Value p, Value a) {
    Pair  pair = (Pair)p;
    Value old  = pair.car;
    pair.car = a;
    return old;
  }
  public static Value set_cdr (Value p, Value a) {
    Pair  pair = (Pair)p;
    Value old  = pair.cdr;
    pair.cdr = a;
    return old;
  }
  public static Value list (Value args[]) {
    Value result = NIL;
    for ( int i=args.length ; i>0 ; i--) {
      result = cons(args[i-1], result);
    }
    return result;
  }
  
  // Type predicates.

  public static Value eqp (Value a, Value b) {
    return a.eqp(b) ? TRUE : FALSE ;
  }
  public static Value equalp (Value a, Value b) {
    return a.equalp(b) ? TRUE : FALSE ;
  }
  public static Value pairp (Value a) {
    return (a instanceof Pair) ? TRUE : FALSE;
  }
  public static Value nullp (Value a) {
    return (a == NIL) ? TRUE : FALSE;
  }
  public static Value symbolp (Value a) {
    return (a instanceof Symbol) ? TRUE : FALSE;
  }
  public static Value stringp (Value a) {
    return (a instanceof MutableString) ? TRUE : FALSE;
  }
  public static Value numberp (Value a) {
    return (a instanceof Number) ? TRUE : FALSE;
  }
  public static Value fixnump (Value a) {
    return (a instanceof Fixnum) ? TRUE : FALSE;
  }
  public static Value floatnump (Value a) {
    return (a instanceof Floatnum) ? TRUE : FALSE;
  }
  public static Value procedurep (Value a) {
    return (a instanceof Procedure) ? TRUE : FALSE;
  }
  public static Value booleanp (Value a) {
    return (a == TRUE || a == FALSE) ? TRUE : FALSE;
  }
  public static Value charp (Value a) {
    return (a instanceof Character) ? TRUE : FALSE;
  }
  public static Value eofp (Value a) {
    return (a == Jaja.EOF) ? TRUE : FALSE;
  }
  public static Value symbol_to_string (Value a) {
    return ((Symbol)a).pname;
  }

  // Arithmetic operations.

  public static Value plus (Value args[]) {
    Number r = Fixnum.create(0);
    for ( int i=0 ; i<args.length ; i++ ) {
      r = r.plus((Number)args[i]);
    }
    return r;
  }
  public static Value minus (Value a, Value b) {
    return ((Number)a).minus((Number)b);
  }
  public static Value times (Value args[]) {
    Number r = Fixnum.create(1);
    for ( int i=0 ; i<args.length ; i++ ) {
      r = r.times((Number)args[i]);
    }
    return r;
  }
  public static Value divide (Value a, Value b) {
    double aa = ((Number)a).doubleValue();
    double bb = ((Number)b).doubleValue();
    return new Floatnum (aa/bb);
  }
  public static Value quotient (Value a, Value b) {
    long r = ((Fixnum)a).value / ((Fixnum)b).value;
    return Fixnum.create(r);
  }
  public static Value remainder (Value a, Value b) {
    long aa = ((Fixnum)a).value;
    long bb = ((Fixnum)b).value;
    long r = aa % bb;
    // Java says that r has the sign of aa.
    return Fixnum.create(r);
  }
  public static Value modulo (Value a, Value b) {
    long aa = ((Fixnum)a).value;
    long bb = ((Fixnum)b).value;
    long r = aa % bb;
    return Fixnum.create( (bb>=0) ? r : (-r));
  }

  // Arithmetic predicates.

  public static Value lep (Value a, Value b) {
    return ( ((Number)a).lep(b) ? TRUE : FALSE );
  }
  public static Value gep (Value a, Value b) {
    return ( ((Number)a).gep(b) ? TRUE : FALSE );
  }
  public static Value eqnp (Value a, Value b) {
    return ( ((Number)a).eqnp(b) ? TRUE : FALSE );
  }
  public static Value ltp (Value a, Value b) {
    return ( ((Number)a).ltp(b) ? TRUE : FALSE );
  }
  public static Value gtp (Value a, Value b) {
    return ( ((Number)a).gtp(b) ? TRUE : FALSE );
  }

  // Vector related functions. 

  public static Value vectorp (Value arg1) {
    return (arg1 instanceof Vector) ? TRUE : FALSE;
  }
  public static Value make_vector (Value args[]) {
    switch ( args.length ) {
    case 1: {
      int size = (int) ((Fixnum)args[0]).value;
      return new Vector(size);
    }
    case 2: {
      int size = (int) ((Fixnum)args[0]).value;
      return new Vector(size, args[1]);
    }
    default: {
      throw new RuntimeException("Wrong arity for make-vector");
    }
    }
  }
  public static Value vector_ref (Value v, Value i) {
    int index = (int) ((Fixnum)i).value;
    return ((Vector)v).item[index];
  }
  public static Value vector_set (Value v,
                                        Value i,
                                        Value o ) {
    Vector vect  = (Vector)v;
    int    index = (int) ((Fixnum)i).value;
    Value  old   = vect.item[index];
    vect.item[index]   = o;
    return old;
  }
  public static Value vector_length (Value v) {
    Vector vect = (Vector)v;
    return Fixnum.create(vect.item.length);
  }
  public static Value vector (Value args[]) {
    return new Vector(args);
  }

  // String/Character-related functions.

  public static Value integer_to_char (Value n) {
    long i = ((Fixnum)n).value;
    return Character.create((int)i);
  }
  public static Value char_to_integer (Value c) {
    return Fixnum.create((int)(((Character)c).value));
  }
  public static Value string_length (Value s) {
    return Fixnum.create(((MutableString)s).content.length());
  }
  public static Value string_ref (Value s, Value i) {
    char c = ((MutableString)s).content.charAt((int) ((Fixnum)i).value);
    return Character.create(c);
  }
  public static Value string_set (Value s,
                                  Value i,
                                  Value c ) {
    MutableString str = (MutableString)s;
    int index = (int) ((Fixnum)i).value;
    char newChar = ((Character)c).value;
    return str.string_set(index, newChar);
  }
  public static Value make_string (Value args[]) {
    switch ( args.length ) {
    case 1: {
      int size = (int) ((Fixnum)args[0]).value;
      return new MutableString(size);
    }
    case 2: {
      int size = (int) ((Fixnum)args[0]).value;
      return new MutableString(size, ((Character)args[1]).value);
    }
    default: {
      throw new RuntimeException("Wrong arity for make-string");
    }
    }
  }
  public static Value string (Value args[]) {
    return new MutableString(args);
  }
  public static Value string_to_symbol (Value arg1) {
    return Symbol.create((MutableString)arg1);
  }

  // Special functions using the dynamic environment to obtain the
  // current port where to read/write/display.

  public static Value read (Value args[]) {
    switch ( args.length ) {
    //[ Evaluation
    case 0: {
      Object oin = Jaja.currentDynamicValue("input_port");
      if ( oin instanceof InputPort ) {
        InputPort in = (InputPort) oin;
        return in.read();
      } else {
        throw new RuntimeException("No current input port");
      }
    }
    //] Evaluation
    case 1: {
      return ((InputPort)(args[0])).read();
    }
    default: throw new RuntimeException("Wrong arity for read");
    }
  }
  public static Value display (Value args[]) {
    switch ( args.length ) {
    //[ Evaluation
    case 1: {
      Object oout =  Jaja.currentDynamicValue("output_port");
      if ( oout instanceof OutputPort ) {
        OutputPort out = (OutputPort) oout;
        out.print(args[0]);
        return Jaja.UNSPECIFIED;
      } else {
        throw new RuntimeException("No current output port");
      }
    }
    //] Evaluation
    case 2: {
      ((OutputPort)args[1]).print(args[0]);
      return Jaja.UNSPECIFIED;
    }
    default: throw new RuntimeException("Wrong arity for display");
    }
  }
  public static Value write (Value args[]) {
    switch ( args.length ) {
    //[ Evaluation
    case 1: {
      Object oout =  Jaja.currentDynamicValue("output_port");
      if ( oout instanceof OutputPort ) {
        OutputPort out = (OutputPort) oout;
        out.write(args[0]);
        return Jaja.UNSPECIFIED;
      } else {
        throw new RuntimeException("No current output port");
      }
    }
    //] Evaluation
    case 2: {
      ((OutputPort)args[1]).write(args[0]);
      return Jaja.UNSPECIFIED;
    }
    default: throw new RuntimeException("Wrong arity for write");
    }
  }
  public static Value newline (Value args[]) {
    switch ( args.length ) {
    //[ Evaluation
    case 0: {
      Object oout =  Jaja.currentDynamicValue("output_port");
      if ( oout instanceof OutputPort ) {
        OutputPort out = (OutputPort) oout;
        out.newline();
        return Jaja.UNSPECIFIED;
      } else {
        throw new RuntimeException("No current output port");
      }
    }
    //] Evaluation
    case 1: {
      ((OutputPort)args[0]).newline();
      return Jaja.UNSPECIFIED;
    }
    default: throw new RuntimeException("Wrong arity for newline");
    }
  }

  //[ Evaluation 
  // These two functions use the dynamic environment to determine the
  // current input/output ports that may be bound for a computation
  // that is while in the dynamic extent of these forms.

  public static Value current_input_port () {
    return (Value) Jaja.currentDynamicValue("input_port");
  }
  public static Value current_output_port () {
    return (Value) Jaja.currentDynamicValue("output_port");
  }
  //] Evaluation

  // Port-related functions.

  public static Value open_input_file (Value s) {
    return new InputPort(new String(((MutableString)s).content));
  }
  public static Value open_output_file (Value s) {
    return new OutputPort(new String(((MutableString)s).content));
  }
  public static Value close_port (Value p) {
    ((Port)p).close();
    return Jaja.UNSPECIFIED;
  }

  // <B>Very special functions</B>. These are special since they
  // invoke one of their arguments so they must be aware of the
  // invocation protocol.

  //[ Evaluation
  /** <CODE>callep</CODE> is a <CODE>call/cc</CODE> reduced to its
   * dynamic extent. */

  public static Value callep (Value arg) {
    Procedure f = (Procedure) arg;
    Value     k = new Escape();
    try {
      return f.invoke(k);
    } catch (EscapeObject e) {
      return e.value;
    }
  }
  //] Evaluation

  /** <CODE>apply</CODE> can only manages up to ten arguments. */

  public static Value apply (Value args[]) {
    if ( args.length >= 2 ) {
      Procedure f = (Procedure)(args[0]);
      // compute length of last argument of apply
      int n = (args[args.length - 1]).list_length();
      // total number of arguments of f: n + args.length - 2
      Value newargs[] = new Value[n + args.length - 2];
      int index = 0;
      for ( int i=1 ; i<=args.length-2 ; i++ ) {
        newargs[index++] = args[i];
      }
      for ( Value p = args[args.length - 1] ;
            p instanceof Pair ;
            p = ((Pair)p).cdr ) {
        newargs[index++] = ((Pair)p).car;
      }
      switch ( newargs.length ) {
      case 0: {
        return f.invoke();
      }
      case 1: {
        return f.invoke(newargs[0]);
      }
      case 2: {
        return f.invoke(newargs[0], newargs[1]);
      }
      case 3: {
        return f.invoke(newargs[0], newargs[1], newargs[2]);
      }
      default: {
        return f.invoke(newargs);
      }
      }
    } else {
      throw new RuntimeException("Wrong arity for apply");
    }
  }

  //[ Additional primitives.

  // Other primitives: they do not belong to Scheme but are useful.

  public static Value exit (Value arg1) {
    throw new ExitObject((Fixnum)arg1);
  }
  public static Value oblist () {
    return Symbol.oblist();
  }

  /** Parallelism. <CODE>(detach! function arguments...)</CODE> spawns
   * a new thread in background and returns immediately. The
   * continuation of that invokation throws away the obtained value
   * and commits suicide. It is not possible to escape that
   * continuation. Nevertheless, this invokation shares the dynamic
   * environment of the invoker. */

  public static Value detach (Value args[]) {
    int size = args.length;
    if ( size >= 1 ) {
      Value arguments[] = new Value[size - 1];
      for ( int i = 1 ; i<size ; i++ ) {
        arguments[i-1] = args[i];
      }
      WorldAble world = (WorldAble) Jaja.currentDynamicValue("world");
      Invokation ev = new Invokation(world, 
                                     Jaja.currentDynamicEnvironment(), 
                                     args[0], 
                                     arguments );
      // Just start it.
      ev.start();
      return UNSPECIFIED;
    } else {
      throw new RuntimeException("Wrong arity for detach");
    }
  }
  //] Evaluation
}

// end of Procedure.java
