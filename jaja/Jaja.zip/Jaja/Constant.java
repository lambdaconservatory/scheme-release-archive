/** @version $Id: Constant.java,v 2.2 1997/11/27 19:21:15 queinnec Exp $
 *  @author <A href="http://www-spi.lip6.fr/~queinnec/WWW/Queinnec.html">
 *          Christian.Queinnec@lip6.fr </A>
 * This file is part of the Jaja system: a Scheme interpreter written in 
 * Java including a Scheme->Java compiler. See
 * <A href="http://www-spi.lip6.fr/~queinnec/WWW/Jaja.html"> 
 *          Jaja documentation </a>.
 */

package Jaja;

/** This is the class of Scheme constants. It is refined into Boolean
 * and EmptyList classes.  */

public class Constant extends Value {

  /** Constants have an internal name that appears only when displayed. */

  private final String name;

  // Constructor

  public Constant (String n) {
    name = n;
  }

  // Printing

  public String toString () {
    return name;
  }

}

// end of Constant.java
