/*-----------------------------------------------------------------*-C-*---
 * File:    handc/cfg/gc/irc/ptrlist.c
 *
 *          Copyright (C)1997 Donovan Kolbly <d.kolbly@rscheme.org>
 *          as part of the RScheme project, licensed for free use.
 *          See <http://www.rscheme.org/> for the latest information.
 *
 * File version:     1.4
 * File mod date:    1997-11-29 23:10:46
 * System build:     v0.7.3.3-b14u, 2003-11-05
 *
 * Purpose:          IRC pointer list implementation
 *------------------------------------------------------------------------*/

#include "irc.h"

void IRC_ptrListAdd( struct IRC_PtrList *list, IRC_Header *item )
{
struct IRC_PtrBucket *b = list->last;

    if (!b || b->ptr == &b->contents[IRC_PTR_BUCKET_SIZE])
    {
	b = MALLOC(struct IRC_PtrBucket);
	b->next = NULL;
	b->ptr = b->contents;
	if (list->first)
	{
	    list->last->next = b;
	}
	else
	{
	    list->first = b;
	}
	list->last = b;
    }
    *(b->ptr)++ = item;
}
