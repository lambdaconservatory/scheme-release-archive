/*-----------------------------------------------------------------*-C-*---
 * File:    handc/hasht/hasht.h
 *
 *          Copyright (C)1997 Donovan Kolbly <d.kolbly@rscheme.org>
 *          as part of the RScheme project, licensed for free use.
 *          See <http://www.rscheme.org/> for the latest information.
 *
 * File version:     1.4
 * File mod date:    1997-11-29 23:10:44
 * System build:     v0.7.3.3-b14u, 2003-11-05
 *
 *------------------------------------------------------------------------*/

#ifndef _H_HASHT
#define _H_HASHT

#include <rscheme/hashmain.h>

#endif /* _H_HASHT */
