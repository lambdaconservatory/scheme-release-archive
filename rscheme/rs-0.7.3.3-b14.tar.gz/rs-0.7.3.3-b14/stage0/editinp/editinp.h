/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_EDITINP
#define _H_EDITINP

/***************** Public Interface for Module `editinp' *****************/
#include <rscheme/linktype.h>
extern struct module_descr module_editinp;
#endif /* _H_EDITINP */
