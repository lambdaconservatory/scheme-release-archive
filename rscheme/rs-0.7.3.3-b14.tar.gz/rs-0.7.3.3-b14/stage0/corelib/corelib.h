/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_CORELIB
#define _H_CORELIB

/***************** Public Interface for Module `corelib' *****************/
#include <rscheme/linktype.h>
extern struct module_descr module_corelib;
#endif /* _H_CORELIB */
