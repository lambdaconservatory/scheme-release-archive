/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_IOLIB_P
#define _H_IOLIB_P

/****************** Private Interface for Module `iolib' ******************/
#include "iolib.h"
#include <rscheme/scheme.h>
#include "cports.h"
#include "iolib_r.h"
UINT_8 *bc_stdio_extension( UINT_8 *pc, RS_bc_datum **args );
#endif /* _H_IOLIB_P */
