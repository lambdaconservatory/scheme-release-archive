/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_IOLIB
#define _H_IOLIB

/****************** Public Interface for Module `iolib' ******************/
#include <rscheme/linktype.h>
extern struct module_descr module_iolib;
#include <rscheme/stdiox.h>
#endif /* _H_IOLIB */
