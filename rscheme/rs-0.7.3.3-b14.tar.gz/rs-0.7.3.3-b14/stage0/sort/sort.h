/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_SORT
#define _H_SORT

/******************* Public Interface for Module `sort' *******************/
#include <rscheme/linktype.h>
extern struct module_descr module_sort;
#endif /* _H_SORT */
