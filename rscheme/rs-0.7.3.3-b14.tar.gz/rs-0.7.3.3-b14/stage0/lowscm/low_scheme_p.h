/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_LOW_SCHEME_P
#define _H_LOW_SCHEME_P

/*************** Private Interface for Module `low_scheme' ***************/
#include "low_scheme.h"
#include <rscheme/scheme.h>
#include <ctype.h>
#include "low_scheme_r.h"
#endif /* _H_LOW_SCHEME_P */
