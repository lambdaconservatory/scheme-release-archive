/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.3-b14u, 2003-11-05)
**********************************************/


#ifndef _H_OBJSYS
#define _H_OBJSYS

/****************** Public Interface for Module `objsys' ******************/
#include <rscheme/linktype.h>
extern struct module_descr module_objsys;
#endif /* _H_OBJSYS */
