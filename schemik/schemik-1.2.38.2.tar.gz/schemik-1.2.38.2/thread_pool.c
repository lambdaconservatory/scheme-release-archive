#include "config.h"
#define GC_THREADS
#include <gc/gc.h>
#include <pthread.h>
#include "thread_pool.h"

void * thread_pool_job(void * _arg)
{
	void *(*job)(void *);
	void * job_arg;
	thread_pool * arg = (thread_pool *)_arg;

	while (1) {
		pthread_mutex_lock(&arg->job_lock);
		job = arg->job;
		job_arg = arg->job_arg;
		pthread_mutex_unlock(&arg->manage_lock);
		job(job_arg);
	}
	return NULL;
}

thread_pool * thread_pool_create(int size)
{
	int i;
	thread_pool * result = GC_MALLOC(sizeof(thread_pool));
	result->th = GC_MALLOC(sizeof(pthread_t) * size);
	pthread_mutex_init(&result->manage_lock, NULL);
	pthread_mutex_init(&result->job_lock, NULL);
	pthread_mutex_lock(&result->job_lock);
	for (i = 0; i < size; i++) {
		pthread_create(&(result->th[i]), NULL, thread_pool_job, result);
		pthread_detach(result->th[i]);
	}
	return result;
}

void thread_pool_run(thread_pool * pool, void *(*routine)(void *), void * arg)
{
	pthread_mutex_lock(&pool->manage_lock);
	pool->job = routine;
	pool->job_arg = arg;
	pthread_mutex_unlock(&pool->job_lock);
}

void thread_pool_destroy(thread_pool * pool)
{
	// FIXME: TODO ;-]
}
