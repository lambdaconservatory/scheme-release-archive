/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Implementation of the environments
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
#ifndef ENV_C
#define ENV_C

#include "config.h"

#define GC_THREADS
#include <gc/gc.h>
#include <stdlib.h>
#include <strings.h>
#include <pthread.h>

#include "types.h"
#include "env.h"
#include "vm.h"
#include "vm.c"
#include "mutex.h"

#ifdef USE_STM
#include "tm_log.c"
#endif

#ifdef USE_STACK_DUMP
int last_env_id = 0;
#endif

/* 
 *
 * Array functions
 *
 */
static inline scm_env * scm_env_new_array(scm_env * parent, unsigned int initial_capacity)
{
	scm_env * result;
	if (initial_capacity <= 0) initial_capacity = 2;

#ifndef USE_COMPACT_ENVIRONMENT
	result = (scm_env *)GC_MALLOC(sizeof(scm_env));
	result->items.list = (struct env_item *) GC_MALLOC(sizeof(struct env_item) * initial_capacity);
#else
	/* bindings resides in the same memory block with informations about environment,
	 * this makes allocations faster, but complicates resizing of such environments*/
	result = (scm_env *)GC_MALLOC(sizeof(scm_env) + sizeof(struct env_item) * initial_capacity);
	result->items.list = (struct env_item *) (((char *)result) + sizeof(scm_env));
	result->compact = 1;
#endif

	result->parent = parent;
	result->capacity = initial_capacity;
	result->size = 0;
	result->naughty = parent->naughty;
#ifdef USE_STACK_DUMP
	result->id = last_env_id++;
#endif
#ifdef USE_STM
	result->version = 0;
#endif
	return result;
}

static inline void scm_env_add_array(scm_env * env, scm_value * key, scm_value * value)
{
	if (env->size == env->capacity) {
#ifndef USE_COMPACT_ENVIRONMENT
		env->capacity += env->capacity + 1;
		env->items.list = (struct env_item *) GC_REALLOC(env->items.list, sizeof(struct env_item) * env->capacity);
#else
		int new_capacity = env->capacity * 2 + 1;
		struct env_item * new_bindings = GC_MALLOC(sizeof(struct env_item) * new_capacity);
		memcpy(new_bindings, env->items.list, sizeof(struct env_item) * env->capacity);
		if (env->compact) {
			env->compact = 0;
			bzero(env->items.list, sizeof(struct env_item) * env->capacity);
		}

		env->capacity = new_capacity;
		env->items.list = new_bindings;
#endif
	}
	env->items.list[env->size].key = key;
	env->items.list[env->size].value = value;
	env->size++;
}

static inline struct env_item * scm_env_get_item_array(scm_env * env, scm_value * key)
{
	int i;
	struct env_item * item = env->items.list;
	for (i = 0; i < env->size; i++) {
		if (SCM_SYMBOL_EQ(item->key, key)) return item;
		item++;
	}

	return NULL;
}

static inline void scm_env_recycle_array(scm_env * env)
{
	env->size = 0;
}

static inline char ** scm_env_get_symbols_array(scm_env * env)
{
	// unsupported feature
	static char * result[] = {(char *)NULL};
	return result;
}

static inline scm_env * scm_env_new_hash(scm_env * parent, unsigned int hash_size)
{
	scm_env * result = (scm_env *)GC_MALLOC(sizeof(scm_env));
	result->parent = parent;
	result->items.hash = (struct env_item **) GC_MALLOC(sizeof(struct env_item *) * hash_size);
	result->hash_size = hash_size;
#ifdef USE_STACK_DUMP
	result->id = -1;
#endif
	return result;
}

static inline void scm_env_add_hash(scm_env * env, scm_value * key, scm_value * value)
{
	struct env_item * item = (struct env_item *) GC_MALLOC(sizeof(struct env_item));
	unsigned int ix = SCM_SYMBOL_HASH(key) % env->hash_size;
	item->key = key;
	item->value = value;
	item->next = env->items.hash[ix];
	env->items.hash[ix] = item;
	env->size++;
}

static inline struct env_item * scm_env_get_item_hash(scm_env * env, scm_value * key)
{
	struct env_item * item = env->items.hash[SCM_SYMBOL_HASH(key) % env->hash_size];
	while (item != NULL) {
		if (SCM_SYMBOL_EQ(key, item->key)) {
			if (SCM_PRE_BOUND(key) == NULL) SCM_PRE_BOUND(key) = item;
			return item;
		}
		item = item->next;
	}
	return NULL;
}

static inline char ** scm_env_get_symbols_hash(scm_env * env)
{
	int i, last = 0;
	char ** result = GC_MALLOC(sizeof(char *) * env->size);
	for (i = 0; i < env->hash_size; i++) {
		struct env_item * item = env->items.hash[i];
		while (item != NULL) {
			result[last++] = SCM_SYMBOL(item->key);
			item = item->next;
		}
	}

	return result;
}

/*
 *
 * General functions
 *
 */
scm_env * scm_env_new(scm_env * parent, unsigned int initial_capacity)
{
	return scm_env_new_array(parent, initial_capacity);
}

scm_env * scm_env_new_with_hash(scm_env * parent, unsigned int hash_size)
{
	return scm_env_new_hash(parent, hash_size);
}

void scm_env_add(scm_env * env, scm_value * key, scm_value * value)
{
	if (env->hash_size == 0) {
		scm_env_add_array(env, key, value);
		if (SCM_PRE_BOUND(key)) env->naughty = 1;
	} else scm_env_add_hash(env, key, value);
#ifdef USE_STM
	env->version++;
#endif
}

#ifndef USE_STM
scm_value * scm_env_get(struct scm_vm * vm, scm_env * env, scm_value * key)
{
	struct env_item * item = ((env->hash_size == 0)
			? scm_env_get_item_array(env, key)
			: scm_env_get_item_hash(env, key));
	if (item != NULL) return item->value;
	if (env->parent) return scm_env_get(vm, env->parent, key);
	return NULL;
}
#endif

#ifdef USE_STM
scm_value * scm_env_get(struct scm_vm * vm, scm_env * env, scm_value * key)
{
	if (vm->parent != NULL) {
		scm_value * log_value = tm_wlog_check(vm, env, key);
		if (log_value != NULL) {
			//tm_logr(vm->read_log, env, key, log_value);
			return log_value;
		}
	}
	struct env_item * item = ((env->hash_size == 0)
			? scm_env_get_item_array(env, key)
			: scm_env_get_item_hash(env, key));
	if (item != NULL) {
		if (vm->parent != NULL) {
			if (env->hash_size == 0) {
				if (env->epoch->vm != vm) {
					//tm_rlog_record(vm->read_log, env, key, item->value);
					tm_rlog_record(vm->read_log, TMI_ENV, env);
				} 
			}
		}
		return item->value;
	}

	if (env->parent) return scm_env_get(vm, env->parent, key);
	return NULL;
}
#endif

/* returns NULL if no such variable has been found */
scm_value * scm_env_set(struct scm_vm * vm, scm_env * env, scm_value * key, scm_value * value)
{
	struct env_item * item = ((env->hash_size == 0)
			? scm_env_get_item_array(env, key)
			: scm_env_get_item_hash(env, key));

	if (item != NULL) {
#ifndef USE_STM
		if (vm->parent == NULL) {
			item->value = value;
			return value;
		}
#else 
		if ((vm->parent == NULL) || (env->epoch->vm == vm)) {
			g_atomic_pointer_set(&(item->value), value);
//			if (vm->sub_threads > 0)
				g_atomic_int_inc(&(env->version));
		} else {
			tm_wlog_record(vm, env, key, value);
		}
#endif
		return value;
	}
	if (env->parent == NULL) return NULL;
	return scm_env_set(vm, env->parent, key, value);
}

void scm_env_recycle(scm_env * env)
{
	scm_env_recycle_array(env);
}

/* returns set of all symbols in environment with NULL at the end */ 
char ** scm_env_get_symbols(scm_env * env)
{
	if (env->hash_size == 0) return scm_env_get_symbols_array(env);
	return scm_env_get_symbols_hash(env);
}

struct env_item * scm_env_get_item(struct scm_vm * vm, scm_env * env, struct scm_value * key)
{
	struct env_item * item = ((env->hash_size == 0)
			? scm_env_get_item_array(env, key)
			: scm_env_get_item_hash(env, key));
	if (item != NULL) return item;
	if (env->parent) return scm_env_get_item(vm, env->parent, key);
	return NULL;
}

#endif
