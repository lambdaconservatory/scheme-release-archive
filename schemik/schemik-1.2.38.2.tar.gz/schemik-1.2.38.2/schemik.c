/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#define GC_THREADS
#include <gc/gc.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>

#include "types.h"
#include "int_funcs.h"
#include "rt.h"
#include "eval.h"

#ifdef USE_READLINE
#include "readline_wrapper.h"
#endif

#define BUF_SIZE	1024

#define RUN(x) (rt_eval_str(rt, x))
#define REP(x) { \
	scm_value * val = RUN(x);	\
	if  ((SCM_TYPE(val) != ERROR) && (val != SCM_CONST_VOID)) printf("%s\n", format(val, 0)); \
	printf("\n"); }

#define TEST_FOR_ARG_PARAMETER {	\
	if (argc == 1) {	\
		printf("Not enough arguments.\n");	\
		return 1;	\
	}	\
}

struct arguments {
	int argc;
	char **argv;
	unsigned int load_standard_lib;
	unsigned short number_of_threads;
	int start_repl;
	char * expression;
	char * script_file;
	scm_scheduler scheduler;
};

static char * load_standard_library(char * file_name)
{
	const int READLINK_BUF_SIZE = 1024;
	char * code = NULL;
	char buf[READLINK_BUF_SIZE];
	char * path = getenv("SCHEMIK_HOME");
	if (path) {
		code = load_file(path);
		if (code) return code;
	}
	
	int size = readlink("/proc/self/exe", buf, READLINK_BUF_SIZE);
	if (size) {
		*strrchr(buf, '/') = '\0';
		//strcat(buf, "/../share/schemik/1.2/base.scm");
		strcat(buf, "/../share/schemik/1.2/");
		strcat(buf, file_name);
		code = load_file(buf);
	}
	if (!code) {
		strcpy(buf, "scm/");
		strcat(buf, file_name);
		//code = load_file("scm/base.scm");
		code = load_file(buf);
	}
	return code;
}

static int process_arguments(struct arguments * args)
{
	int argc = args->argc;
	char **argv = args->argv;

	args->load_standard_lib = 1;
	args->start_repl = 1;
	args->expression = NULL;
	args->script_file = NULL;
	args->number_of_threads = 4;
	args->scheduler = backward_scheduler;

	argc--;
	argv++;
	while (argc > 0) {
		char * arg = *argv;
		if (!strcmp(arg, "-q")) args->load_standard_lib = 0;
		if (!strcmp(arg, "-s") || !strcmp(arg, "-c")) args->start_repl = 0;
		if (!strcmp(arg, "-s") || !strcmp(arg, "-l")) {
			char * file_name;
			TEST_FOR_ARG_PARAMETER;
			argc--;
			file_name = *++argv;
			args->script_file = load_file(file_name);
			if (args->script_file == NULL) {
				printf("Unable to open file: %s.\n", file_name);
				return 1;
			}

			char * f = args->script_file;
			if ((*f == '#') && (*(f + 1) == '!')) *f = ';';
		}

		if (!strcmp(arg, "-p")) {
			TEST_FOR_ARG_PARAMETER;
			argc--;
			argv++;
			if (!strcmp(*argv, "forward")) args->scheduler = forward_scheduler;
			else if (!strcmp(*argv, "backward")) args->scheduler = backward_scheduler;
			else {
				printf("Unknown scheduler.\n");
				return 1;
			}
		}

		if (!strcmp(arg, "-e") || !strcmp(arg, "-c")) {
			TEST_FOR_ARG_PARAMETER;
			argc--;
			args->expression = *++argv;	
		}

		if (!strcmp(arg, "-t") || !strcmp(arg, "--threads")) {
			TEST_FOR_ARG_PARAMETER;
			argc--;
			args->number_of_threads = atoi(*++argv);
		}

		if (!strcmp(arg, "-V") || !strcmp(arg, "--version")) {
			printf("Current configuration:\n");
			printf("Initial heap size:\t%i MiB\n", INITIAL_HEAP_SIZE);
			printf("STM:\t\t\t");
#ifdef USE_STM
			printf("yes\n");
#else
			printf("no\n");
#endif
			printf("Thread pooling:\t\t");
#ifdef USE_THREAD_POOLING
			printf("yes\n");
#else
			printf("no\n");
#endif
			printf("Explicit thread local alloc:\t");
#ifdef GC_REDIRECT_TO_LOCAL
			printf("yes\n");
#else
			printf("no\n");
#endif

			printf("Debug:\t\t\t");
#ifdef DEBUG
			printf("yes\n");
#else
			printf("no\n");
#endif
			printf("ReadLine:\t\t");
#ifdef USE_READLINE 
			printf("yes\n");
#else
			printf("no\n");
#endif
			args->start_repl = 0;
		}

		if (!strcmp(arg, "-h") || !strcmp(arg, "--help"))  {
			printf("Implicitly parallel Scheme\n");
			printf("Usage: schemik OPTIONS\n");
			printf("  -t N, --threads N\tevalute expressions using N threads [default: 4]\n");
			printf("  -p STRATEGY\t\tscheduler strategy (forward/backward) [default: backward]\n");
			printf("  -q\t\t\tignore base library\n");
			printf("  -s FILE\t\tevaluate scheme code in FILE and exit\n");
			printf("  -l FILE\t\tevaluate scheme code in FILE and start REPL\n");
			printf("  -c EXPR\t\tevaluate expression and exit\n");
			printf("  -e EXPR\t\tevaluate expression and start REPL\n");
			printf("  -h, --help\t\tdisplay this help and exit\n");
			printf("  -V, --version\t\tdisplay informations about current configuration\n");
			args->start_repl = 0;
		}
		argv++;
		argc--;
	}

	return 0;
}


static void load_lib(scm_rt * rt, char * file_name)
{
	char * code = load_standard_library(file_name);
	if (code != NULL) RUN(code);
	else fprintf(stderr, "%s not found. This file is part of the standard library. Particular functionality may be missing. Try to set variable SCHEMIK_HOME.\n", file_name);
}

void * main_thread(void * arg) {
	
	scm_rt * rt;
	int state;
	char * expr = NULL;
	struct arguments * args = (struct arguments *) arg;

	state = process_arguments(args);
	if (state) return NULL;
	
	scm_init_globals();
	rt = rt_new(args->number_of_threads, args->scheduler);

	if (args->load_standard_lib) {
		load_lib(rt, "base.scm");
		load_lib(rt, "doc-base.scm");
	}

	if (args->script_file != NULL) RUN(args->script_file);
	if (args->expression != NULL) RUN(args->expression);
	if (!args->start_repl) return NULL;

	while (1) {
		int i, parentheses;
		char * check_par_msg;

#ifdef USE_READLINE
		char * buf;
		char ** commands = scm_env_get_symbols(rt->env);
		if (expr == NULL) buf = readline_wrapper("schemik> ", commands);
		else buf = readline_wrapper("", commands);
		if (buf == NULL) {
			printf("\n");
			return NULL;
		}
#else
		char buf[BUF_SIZE];
		if (expr == NULL) printf("schemik> ");
		fgets(buf, BUF_SIZE, stdin);
#endif

		if (expr == NULL) expr = GC_MALLOC(strlen(buf) + 1);
		else expr = GC_REALLOC(expr, strlen(expr) + strlen(buf) + 1);
		strcat(expr, buf);

		int is_empty = 1;
		for (i = 0; i < strlen(expr); i++) {
			char c = expr[i];
			if (!(isblank(c) || iscntrl(c))) {
				is_empty = 0;
				break;
			}
		}

		if (is_empty) {
			GC_FREE(expr);
			expr = NULL;
			continue;
		}

		check_par_msg = check_parentheses(expr, &parentheses);
		if (parentheses <= 0) {
			if (parentheses == 0) REP(expr)
			else printf("parser error: %s\n", check_par_msg);
			GC_FREE(expr);
			expr = NULL;
		}
	}
	return NULL;
}

int main(int argc, char **argv) 
{
	GC_INIT();
	GC_expand_hp(INITIAL_HEAP_SIZE * 1024 * 1024);
	pthread_t thr;
	struct arguments args;
	args.argc = argc;
	args.argv = argv;
	pthread_create(&thr, NULL, main_thread, &args);
	pthread_join(thr, NULL);
	return 0;
}
