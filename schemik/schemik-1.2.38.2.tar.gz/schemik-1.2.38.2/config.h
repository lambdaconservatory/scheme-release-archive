#ifndef CONFIG_H
#define CONFIG_H

#define DUMP_TEXT	1
#define DUMP_LATEX	2


#define INITIAL_HEAP_SIZE       (256) /* in MiB */
//#define USE_STM
#define USE_READLINE
//#define USE_THREAD_POOLING	
//#define USE_STACK_DUMP		DUMP_LATEX
//#define USE_STACK_DUMP		DUMP_TEXT
//#define IGNORE_WAIT_AND_DROP_OPS 
// disabled by default #define GC_REDIRECT_TO_LOCAL
//#define USE_THREAD_INFO
#define USE_SMART_SCHEDULER
#define USE_COMPACT_ENVIRONMENT
#define USE_OUT_OF_STACK_EVAL
//#define USE_AGGRESSIVE_OUT_OF_STACK_EVAL

#ifdef DISABLE_READLINE
#undef USE_READLINE
#endif

#endif
