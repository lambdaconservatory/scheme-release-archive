#ifndef THREAD_POOL_H
#define THREAD_POOL_H
#include <pthread.h>

typedef struct thread_pool {
	pthread_mutex_t job_lock;
	pthread_mutex_t manage_lock;
	pthread_t * th;
	void *(*job)(void *);
	void * job_arg;
} thread_pool;

//void * thread_pool_job(thread_pool * arg)
thread_pool * thread_pool_create(int size);
void thread_pool_run(thread_pool * pool, void *(*routine)(void *), void * arg);
void thread_pool_destroy(thread_pool * pool);
#endif
