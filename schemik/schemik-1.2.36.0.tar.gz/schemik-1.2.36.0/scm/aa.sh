#!./schemik -s

(define (sha1sum file)
	(shell-unsafe "sha1sum" file))

(define (fib x)
  (if (< x 3) 1 (+ (fib (- x 1)) (fib (- x 2)))))
 
;(set! sha1sum (lambda (x) (fib 26)))

(define (check-sums dir)
  (define (loop files)
    (if (null? files) files
        (cons (sha1sum (string-append dir "/" (car files)))
		(loop (cdr files)))))
  (loop (ls dir)))

(map displayn (check-sums "XXX"))
