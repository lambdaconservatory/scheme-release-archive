/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Stack based evaluator
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#define GC_THREADS
#include <gc/gc.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "env.h"
#include "int_funcs.h"
#include "functions.h"

#include "vm.h"
#include "vm.c"
#include "eval.h"
#include "rt.h"
#include "dump_vm.c"

#define ARGUMENT_COUNT_SOFT_LIMIT	(16)

#define OP_ARGS scm_vm * vm, scm_env * env, scm_value * arg1, unsigned char tail_position

#define ABORT_OPERATION(__msg) { \
		vm_error(vm, scm_value_new_error(__msg)); \
		return;  \
	} 

#ifdef USE_AGGRESSIVE_OUT_OF_STACK_EVAL
#define vm_push_cmd_eval_fast_execution(vm, env, arg1, tail_position) \
	op_eval(vm, env, arg1, tail_position);
#else
#define vm_push_cmd_eval_fast_execution(vm, env, arg1, tail_position) \
	vm_push_cmd0(vm, OP_EVAL, env, arg1, tail_position);
#endif


static inline void op_eval(OP_ARGS);

static inline int list_length_ex(scm_value * value) {
	if (value->__length) return value->__length;
	int l = list_length(value);
	value->__length = l;
	return l;
}

static inline scm_value * eval_symbol(scm_vm * vm, scm_value * symbol, scm_env * env)
{
	if (SCM_TYPE(symbol) != SYMBOL) return symbol;

	// assumes that each readlog contains record on reading top environment
	if (SCM_PRE_BOUND(symbol) != NULL) {
		int naughty = env->naughty;
#ifdef USE_STM
		naughty |= tm_wlog_naughty(vm->write_log);
#endif
		if (!naughty) return SCM_PRE_BOUND(symbol)->value;
	}

	scm_value * val = scm_env_get(vm, env, symbol);

	if (val != NULL) return val;
	return scm_value_new_error(gc_sprintf("Unbound symbol '%s'", SCM_SYMBOL(symbol)));
}

static inline int load_args_into_env(scm_env * env, struct lambda * lambda, int argc, scm_value ** args)
{
	scm_value * arg_names = lambda->arg_list;
	while (1) {
		if (argc < 0) break;
		switch (SCM_TYPE(arg_names)) {
			case PAIR: scm_env_add(env, SCM_CAR(arg_names), args[0]);
				   arg_names = SCM_CDR(arg_names);
				   args++;
				   argc--;
				   break;
			case SYMBOL: scm_env_add(env, arg_names, list(argc, args, NULL));
				     argc = 0;
				     goto quit_loop;
			case NIL: goto quit_loop;
			default: printf("ay, caramba: %i\n", SCM_TYPE(arg_names));
				 goto quit_loop;
		}
	}
quit_loop:
	/* if argc < 1 -- too few arguments, argc > 1 too many arguments */
	return argc;
}

static inline scm_env * recycle_env(scm_env * parent, scm_env * env)
{
	scm_env_recycle(env);
	env->parent = parent;
	env->naughty = parent->naughty;
	return env;
}

static int push_let_bindings(scm_vm * vm, scm_env * env, scm_value * args)
{
	int err;
	scm_value * assoc;
	if (SCM_IS_NULL(args)) return 0;
	assoc = SCM_CAR(args);

	vm_rslt_push(vm, SCM_CAR(assoc));
	err = push_let_bindings(vm, env, SCM_CDR(args));
	if (err) return 1;

	if (!is_list(assoc) || (list_length_ex(assoc) != 2)) return 1;
	vm_push_cmd(vm, OP_EVAL, env, SCM_CADR(assoc));
	return 0;
}


static void __push_args(scm_vm * vm, scm_env * env, scm_value * args)
{
	if (SCM_IS_NULL(args)) return;
	__push_args(vm, env, SCM_CDR(args));
	vm_push_cmd0(vm, OP_EVAL, env, SCM_CAR(args), NOTAIL);
}

void push_args(scm_vm * vm, scm_env * env, scm_value * args)
{
	if (SCM_IS_NULL(args)) return;
	__push_args(vm, env, SCM_CDR(args));
	vm_push_cmd_eval_fast_execution(vm, env, SCM_CAR(args), NOTAIL);
}

static inline void invoke_special_form(scm_vm * vm, scm_spec_type spec_form, scm_env * env, scm_value * arg1, int tail_position)
{
	int arg_len = list_length_ex(arg1);
	scm_value * ar;
	switch (spec_form) {
		case SP_DEFINE:
			if (arg_len < 2) ABORT_OPERATION("define: syntax error");

			if (tail_position != HEAD) vm_push_cmd(vm, OP_DROP, NULL, NULL);
			vm_push_cmd(vm, OP_DEFINE, env, NULL);
			if (SCM_TYPE(SCM_CAR(arg1)) == SYMBOL) { 
				/* (define symbol (lambda ...))) */
				if (tail_position != HEAD)
					vm_push_cmd(vm, OP_WAIT, NULL, NULL);
				vm_push_cmd(vm, OP_EVAL, env, SCM_CADR(arg1));
				vm_rslt_push(vm, SCM_CAR(arg1));
			} else {
				/* (define (fun ...)) */
				if (SCM_TYPE(SCM_CAR(arg1)) != PAIR) ABORT_OPERATION("define: syntax error");

				scm_value * lmbd = C(S_lambda, C(SCM_CDR(SCM_CAR(arg1)), SCM_CDR(arg1)));
				if (tail_position != HEAD) vm_push_cmd(vm, OP_WAIT, NULL, NULL);
				vm_push_cmd(vm, OP_EVAL, env, lmbd);
				vm_rslt_push(vm, SCM_CAAR(arg1));
			}
			break;

		case SP_SET:
			if (arg_len != 2) ABORT_OPERATION("set!: requires two arguments");
#ifdef USE_STM
			vm_push_cmd(vm, OP_SET, env, NULL);
#else
			vm_push_cmd(vm, OP_DROP, env, SCM_CAR(arg1));
			vm_push_cmd(vm, OP_SET, env, NULL);
			vm_push_cmd(vm, OP_WAIT, NULL, NULL);
#endif
			vm_push_cmd(vm, OP_EVAL, env, SCM_CADR(arg1));
			vm_rslt_push(vm, SCM_CAR(arg1));
			break;
		case SP_IF:
			if ((arg_len != 2) && (arg_len != 3)) ABORT_OPERATION("if: requires two or three arguments");

			//vm_push_cmd0(vm, OP_IF, env, NULL, tail_position);
			vm_push_cmd0(vm, OP_IF, env, SCM_CDR(arg1), tail_position);
			//vm_push_cmd0(vm, OP_EVAL, env, SCM_CAR(arg1), NOTAIL);
			vm_push_cmd_eval_fast_execution(vm, env, SCM_CAR(arg1), NOTAIL);
			/*
			if (arg_len == 2) vm_rslt_push(vm, SCM_CONST_VOID);
			else vm_rslt_push(vm, SCM_CADDR(arg1));
			vm_rslt_push(vm, SCM_CADR(arg1));
			*/
			break;
		case SP_LAMBDA: 
			if (arg_len < 2) ABORT_OPERATION("lambda: syntax error");

			ar = SCM_CAR(arg1);
			while (SCM_TYPE(ar) == PAIR) {
				if (SCM_TYPE(SCM_CAR(ar)) != SYMBOL) 
					ABORT_OPERATION("lambda: arguments of lambda expression have to be symbols");
				ar = SCM_CDR(ar);
			}
			if ((SCM_TYPE(ar) != NIL) && (SCM_TYPE(ar) != SYMBOL)) 
				ABORT_OPERATION("lambda: arguments of lambda expression have to be symbols");

			env->closure = 1; /* environment became a closure */
			vm_rslt_push(vm, scm_value_new_lambda(env, SCM_CAR(arg1), SCM_CDR(arg1)));
			break;
		case SP_QUOTE:
			if (list_length_ex(arg1) != 1) ABORT_OPERATION("quote: requires one argument");
			vm_rslt_push(vm, SCM_CAR(arg1));
			break;
		case SP_CALLCC:
			if (arg_len != 1) ABORT_OPERATION("call/cc: requires one argument");
			vm_rslt_push(vm, scm_const_spec_callcc);
			vm_push_cmd(vm, OP_RUN, env, scm_value_new_int(1));
			vm_push_cmd(vm, OP_WAIT, NULL, NULL);
			vm_push_cmd(vm, OP_EVAL, env, SCM_CAR(arg1));
			break;
		case SP_APPLY:
			if (arg_len <= 1) ABORT_OPERATION("apply: requires at least two arguments");
			vm_push_cmd(vm, OP_APPLY, env, scm_value_new_int(list_length_ex(arg1)));
			push_args(vm, env, arg1);
			break;
		case SP_COND:
			if (SCM_IS_NULL(arg1)) {
				vm_rslt_push(vm, SCM_CONST_VOID);
				return;
			}
			if (SCM_TYPE(arg1) != PAIR) ABORT_OPERATION("cond: syntax error");
			if (SCM_TYPE(SCM_CAR(arg1)) != PAIR) ABORT_OPERATION("cond: syntax error");
			vm_push_cmd0(vm, OP_COND, env, SCM_CDAR(arg1), tail_position);
			vm_rslt_push(vm, SCM_CDR(arg1));

			if ((SCM_TYPE(SCM_CAAR(arg1)) == SYMBOL) && (SCM_SYMBOL_EQ(SCM_CAAR(arg1), scm_const_symbol_else)))
				vm_rslt_push(vm, SCM_CONST_TRUE);
			else vm_push_cmd(vm, OP_EVAL, env, SCM_CAAR(arg1));
			break;
		case SP_MAP:
			if (list_length_ex(arg1) <= 1) ABORT_OPERATION("map: requires at least two arguments");
			vm_push_cmd(vm, OP_MAP, env, scm_value_new_int(list_length_ex(arg1)));
			push_args(vm, env, arg1);
			break;
		case SP_LET:
			{
				int err;
				int named = 0;
				if (arg_len < 2) ABORT_OPERATION("let: syntax error");
				if (SCM_TYPE(SCM_CAR(arg1)) == SYMBOL) {
					if (arg_len < 3) ABORT_OPERATION("let (named): syntax error");
					vm_rslt_push(vm, SCM_CAR(arg1));
					arg1 = SCM_CDR(arg1);
					named = 1;
				}
				if (!is_list(SCM_CAR(arg1))) ABORT_OPERATION("let: syntax error - bad bindings");
				if (!named) vm_push_cmd0(vm, OP_LET, env, scm_value_new_int(list_length_ex(SCM_CAR(arg1))), tail_position);
				else vm_push_cmd0(vm, OP_LET_NAMED, env, scm_value_new_int(list_length_ex(SCM_CAR(arg1))), tail_position);
				vm_rslt_push(vm, SCM_CDR(arg1));
				err = push_let_bindings(vm, env, SCM_CAR(arg1));
				if (err) ABORT_OPERATION("let: syntax error - bad bindings");
			}
			break;
		case SP_LOAD:
			if (arg_len != 1) ABORT_OPERATION("if: requires one argument");
			vm_push_cmd(vm, OP_LOAD, env, NULL);
			vm_push_cmd(vm, OP_WAIT, NULL, NULL);
			vm_push_cmd(vm, OP_EVAL, env, SCM_CAR(arg1));
			break;
	}
}

static inline void op_inspect(OP_ARGS)
{
	scm_value * oper = vm_result_top(vm);
	scm_type type = SCM_TYPE(oper);
	if ((type == FUNC) || (type == LAMBDA)) {
		unsigned flag = SCM_FLAGS(oper);
		if (flag & SCM_SYNC_DROP) vm_push_cmd(vm, OP_DROP, NULL, NULL);
		vm_push_cmd0(vm, OP_RUN, env, scm_value_new_int(list_length_ex(arg1)), tail_position);
		if (flag & SCM_SYNC_WAIT) vm_push_cmd(vm, OP_WAIT, NULL, NULL);
		push_args(vm, env, arg1);
	}

	else if ((type == MACRO) || (type == PRECOMPILED_MACRO)) {
		vm_push_cmd(vm, OP_RETURN, env, NULL);
		vm_push_cmd(vm, OP_RUN, env, scm_value_new_int(list_length_ex(arg1)));
		while (!SCM_IS_NULL(arg1)) {
			vm_rslt_push(vm, SCM_CAR(arg1));
			arg1 = SCM_CDR(arg1);
		}
	}

	else if (type == CONTINUATION) {
		int cnt = list_length_ex(arg1);
		if (cnt > 1) ABORT_OPERATION("Escape function accepts one argument maximum.");
		//vm_push_cmd(vm, OP_RUN, NULL, scm_value_new_int(cnt)); // XXX: prostredi je uvedene zbytecne
		vm_push_cmd(vm, OP_RUN, env, scm_value_new_int(cnt));
		vm_push_cmd(vm, OP_WAIT, NULL, NULL);
		if (cnt == 1) vm_push_cmd(vm, OP_EVAL, env, SCM_CAR(arg1));

	} else if (type == SPEC_FORM) {
		scm_spec_type spec_form = SCM_SPEC_FORM(vm_rslt_pop(vm));
		invoke_special_form(vm, spec_form, env, arg1, tail_position);
	} else {
		vm_error(vm, scm_value_new_error(gc_sprintf("Wrong type to apply. Given value: %s", format(oper, 1))));
	}
}

static void load_commands(scm_vm * vm, scm_env * new_env, scm_value * cmds, int tail)
{
	if (SCM_IS_NULL(cmds)) return;
	if (SCM_IS_NULL(SCM_CDR(cmds))) {
		vm_push_cmd0(vm, OP_EVAL, new_env, SCM_CAR(cmds), tail);
	} else {
		load_commands(vm, new_env, SCM_CDR(cmds), tail);
		vm_push_cmd(vm, OP_DISCARD, NULL, NULL);
		vm_push_cmd0(vm, OP_EVAL, new_env, SCM_CAR(cmds), NOTAIL);
	}
}

static inline void invoke_internal_function(scm_vm * vm, scm_value * func_val, int argc, scm_value ** args)
{
	scm_func func = SCM_FUNC(func_val);
	scm_value * result = func(argc, args, vm);
	if (SCM_TYPE(result) == ERROR) vm_error(vm, result);
	else vm_rslt_push(vm, result);
}

static inline void invoke_user_function(scm_vm * vm, scm_env * env, scm_value * func_val, int argc, scm_value ** args, int tail_position)
{
	struct lambda * lmbd = SCM_LAMBDA(func_val);
	scm_env * new_env = ((tail_position && (!env->closure)) 
			? recycle_env(lmbd->parent, env)
			: scm_env_new(lmbd->parent, argc + lmbd->local_symbols));
#ifdef USE_STM
	new_env->epoch = vm->epoch;
#endif
	int state = load_args_into_env(new_env, lmbd, argc, args);

	if (state != 0) ABORT_OPERATION("Wrong count of arguments");

	// is already tested while calling (lambda ())
	// if (SCM_IS_NULL(lmbd->cmd_list)) ABORT_OPERATION("Lambda expression missing body");

	scm_value * cmds = lmbd->cmd_list;
#ifndef USE_OUT_OF_STACK_EVAL
	if (SCM_IS_NULL(lmbd->define_list)) load_commands(vm, new_env, cmds, TAIL);
#else
	if (SCM_IS_NULL(lmbd->define_list)) {
		scm_value * rest = SCM_CDR(cmds);
		load_commands(vm, new_env, rest, TAIL);
		if (SCM_IS_NULL(rest)) {
			op_eval(vm, new_env, SCM_CAR(cmds), TAIL);
		} else {
			vm_push_cmd(vm, OP_DISCARD, NULL, NULL);
			op_eval(vm, new_env, SCM_CAR(cmds), NOTAIL);
		}
	
	}
#endif
	else {
		vm_push_cmd0(vm, OP_BLOCK, new_env, cmds, HEAD);
		vm_push_cmd(vm, OP_DISCARD, NULL, NULL);
		cmds = lmbd->define_list;

		while (!SCM_IS_NULL(cmds)) {
			vm_push_cmd0(vm, OP_EVAL, new_env, SCM_CAR(cmds), HEAD);
			cmds = SCM_CDR(cmds);
			if (!SCM_IS_NULL(cmds)) 
				vm_push_cmd(vm, OP_DISCARD, NULL, NULL); 
		}
	}
}

static inline void op_eval(OP_ARGS)
{
	if (SCM_TYPE(arg1) == PAIR) {
		// XXX: shortcuts && optimalizations
#ifdef USE_OUT_OF_STACK_EVAL
		if (SCM_TYPE(SCM_CAR(arg1)) == SYMBOL) {
			scm_value * val = eval_symbol(vm, SCM_CAR(arg1), env);
			if ((SCM_TYPE(val)) == ERROR) {
				vm_error(vm, val);
				return;
			}

			scm_value * list = arg1;
			if (((SCM_TYPE(val) == FUNC) || (SCM_TYPE(val) == LAMBDA))
					&& (SCM_FLAGS(list) & SCM_SIMPLE_LIST)
					&& !(SCM_FLAGS(val) & (SCM_SYNC_WAIT | SCM_SYNC_DROP))) {
				int i;
				int argc = list_length_ex(arg1);

				scm_value * stack_args[ARGUMENT_COUNT_SOFT_LIMIT];
				scm_value ** args;
				scm_value * arg_list = SCM_CDR(arg1);

				if (argc > ARGUMENT_COUNT_SOFT_LIMIT)
					args = (scm_value **)GC_MALLOC(sizeof(scm_value *) * argc);
				else args = stack_args;

				for (i = 1; i < argc; i++, arg_list = SCM_CDR(arg_list)) {
					scm_value * val = eval_symbol(vm, SCM_CAR(arg_list), env);
					if ((SCM_TYPE(val)) != ERROR) args[i - 1] = val;
					else { 
						vm_error(vm, val);
						return;
					}
				}
				if (SCM_TYPE(val) == FUNC)
					invoke_internal_function(vm, val, argc - 1, args);
				else 
					invoke_user_function(vm, env, val, argc - 1, args, tail_position);
				return;
			}


			if (SCM_TYPE(val) == SPEC_FORM) {
				invoke_special_form(vm, SCM_SPEC_FORM(val), env, SCM_CDR(arg1), tail_position);
				return;
			}
			vm_rslt_push(vm, val);
			op_inspect(vm, env, SCM_CDR(arg1), tail_position);
			return;
		}
#endif

		// documented code:
		vm_push_cmd0(vm, OP_INSPECT, env, SCM_CDR(arg1), tail_position);
		vm_push_cmd(vm, OP_EVAL, env, SCM_CAR(arg1));
	} else if (SCM_TYPE(arg1) == SYMBOL) {
		scm_value * val = eval_symbol(vm, arg1, env);
		if ((SCM_TYPE(val)) != ERROR) vm_rslt_push(vm, val);
		else vm_error(vm, val);
	} else {
		scm_value * val = eval_symbol(vm, arg1, env);
		if ((SCM_TYPE(val)) != ERROR) vm_rslt_push(vm, val);
		else vm_error(vm, val);
	}
}

static inline void op_run(OP_ARGS)
{
	int i;
	int argc = SCM_INT(arg1);
	scm_value * stack_args[ARGUMENT_COUNT_SOFT_LIMIT];
	scm_value ** args;
	scm_value * func_val;

	if (argc > ARGUMENT_COUNT_SOFT_LIMIT) args = (scm_value **)GC_MALLOC(sizeof(scm_value *) * argc);
	else args = stack_args;

	for (i = argc - 1; i >= 0; i--)
		args[i] = vm_rslt_pop(vm);

	func_val = vm_rslt_pop(vm);

	if ((SCM_TYPE(func_val) == FUNC) || (SCM_TYPE(func_val) == PRECOMPILED_MACRO)) {
		invoke_internal_function(vm, func_val, argc, args);
		return;
	} 
	
	if ((SCM_TYPE(func_val) == LAMBDA) || (SCM_TYPE(func_val) == MACRO)) {
		invoke_user_function(vm, env, func_val, argc, args, tail_position);
		return;
	}

	if (SCM_TYPE(func_val) == CONTINUATION) {

		stack_item item;
		scm_value * esc;
		scm_vm * cont = SCM_CONTINUATION(func_val);

		if (argc == 0) esc = SCM_CONST_VOID;
		else esc = args[0];

		while (!stack_empty(vm->exct)) stack_pop(vm->exct);
		while (!stack_empty(vm->rslt)) stack_pop(vm->rslt);

		item = stack_internal_get_bottom(cont->rslt);
		while (!stack_internal_get_done(cont->rslt, item)) {
			vm_rslt_push(vm, stack_internal_get_value(cont->rslt, item));
			item = stack_internal_get_prev(cont->rslt, item);
		}

		item = stack_internal_get_bottom(cont->exct);
		while (!stack_internal_get_done(cont->exct, item)) {
			command * cmd = (command *)stack_internal_get_value(cont->exct, item);
			vm_push_cmd0(vm, cmd->op, cmd->env, cmd->arg1, cmd->tail_position);
			item = stack_internal_get_prev(cont->exct, item);
		}

		vm_rslt_push(vm, esc);
		return;

	}

	if (SCM_TYPE(func_val) == SPEC_FORM) {
		scm_spec_type sp = SCM_SPEC_FORM(func_val);
		if (sp == SP_CALLCC) {
			scm_value * continuation = scm_value_new_continuation(vm_clone(vm->runtime->main_vm));
			scm_value * receiver = args[0];
			vm_push_cmd0(vm, OP_RUN, env, scm_value_new_int(1), tail_position);
			vm_rslt_push(vm, receiver);
			vm_rslt_push(vm, continuation);
		}
		// AWFUL: 'apply' and 'map' are implemented as special forms but have to behave like functions
		if ((sp == SP_MAP) || (sp == SP_APPLY) || (sp == SP_LOAD)) {
			for (i = 0; i < argc; i++)
				vm_rslt_push(vm, args[i]);
			if (sp == SP_MAP) vm_push_cmd(vm, OP_MAP, env, scm_value_new_int(argc)); 
			if (sp == SP_APPLY) vm_push_cmd(vm, OP_APPLY, env, scm_value_new_int(argc)); 
		}

		return;
	}

	// otherwise:
	printf("ay, caramba! %i is not suitable type. Given value: %s\n", SCM_TYPE(func_val), format(func_val, 1));
}

static inline void op_define(OP_ARGS)
{
	scm_value * val = vm_rslt_pop(vm);
	scm_value * symbol = vm_rslt_pop(vm);
	if (SCM_TYPE(symbol) != SYMBOL) ABORT_OPERATION("define: first argument must be symbol");

	scm_env_add(env, symbol, val);
	vm_rslt_push(vm, val);
}

static inline void op_set(OP_ARGS)
{
	scm_value * val = vm_rslt_pop(vm);
	scm_value * symbol = vm_rslt_pop(vm);

	if (SCM_TYPE(symbol) != SYMBOL) ABORT_OPERATION("set!: argument of must be symbol");

	scm_value * result = scm_env_set(vm, env, symbol, val);
	if (result == NULL) ABORT_OPERATION("set!: undefined symbol");

	vm_rslt_push(vm, val);
}

static inline void op_apply(OP_ARGS)
{
	// FIXME: testovani na poviny tvar argumentu!
	int i;
	int argc = SCM_INT(arg1);
	int applied_argc = 0;
	scm_value * larg = vm_rslt_pop(vm);
	for (i = 0; i < argc - 1; i++)
		larg = SCM_CONS(vm_rslt_pop(vm), larg);


	scm_value * fn = SCM_CAR(larg);
	unsigned int flag = SCM_FLAGS(fn);

	while (SCM_TYPE(larg) == PAIR) {
#ifndef USE_STM
		vm_rslt_push(vm, SCM_CAR(larg));
		larg = SCM_CDR(larg);
#else
		vm_rslt_push(vm, TS_SCM_CAR(vm, larg));
		larg = TS_SCM_CDR(vm, larg);
#endif
		applied_argc++;
	}

	if (flag & SCM_SYNC_DROP) vm_push_cmd(vm, OP_DROP, NULL, NULL);
	vm_push_cmd0(vm, OP_RUN, env, scm_value_new_int(applied_argc - 1), tail_position);
	if (flag & SCM_SYNC_WAIT) vm_push_cmd(vm, OP_WAIT, NULL, NULL);
}

static inline void op_if(OP_ARGS)
{
	scm_value * result = SCM_CONST_VOID;
	scm_value * val = vm_rslt_pop(vm);
	/*
	scm_value * result1 = vm_rslt_pop(vm);
	scm_value * result2 = vm_rslt_pop(vm);

	if (SCM_TYPE(val) == BOOL) result = (SCM_BOOL(val) ? result1 : result2);
	else result = result1;
	*/
	if ((SCM_TYPE(val) == BOOL) && (!SCM_BOOL(val))) {
		if (SCM_IS_NULL(SCM_CDR(arg1))) result = SCM_CONST_VOID;
		else result = SCM_CADR(arg1);
	} else result = SCM_CAR(arg1);
	//vm_push_cmd0(vm, OP_EVAL, env, result, tail_position);
	vm_push_cmd_eval_fast_execution(vm, env, result, tail_position);
}

static inline void op_cond(OP_ARGS)
{
	scm_value * result = vm_rslt_pop(vm);
	scm_value * branch = arg1;
	scm_value * alt_branch = vm_rslt_pop(vm);
	int success = 1;
	if (SCM_TYPE(result) == BOOL) success = SCM_BOOL(result);
	if (success) {
		if (SCM_IS_NULL(branch)) {
			vm_rslt_push(vm, result);
			return;
		}
		if ((SCM_TYPE(branch) == PAIR) && (SCM_TYPE(SCM_CAR(branch)) == SYMBOL)
			&& (SCM_SYMBOL_EQ(SCM_CAR(branch), scm_const_symbol_geq))) {
			if (SCM_TYPE(SCM_CDR(branch)) != PAIR) ABORT_OPERATION("cond: syntax error");
			vm_push_cmd0(vm, OP_RUN, env, scm_value_new_int(1), tail_position);
			vm_push_cmd(vm, OP_PUSH, NULL, result);
			vm_push_cmd(vm, OP_EVAL, env, SCM_CADR(branch));
			return;
		}
		load_commands(vm, env, branch, tail_position);  
	} else {
		vm_push_cmd0(vm, OP_INSPECT, env, alt_branch, tail_position);
		vm_rslt_push(vm, scm_const_spec_cond); 
	}
}


static void map_values(scm_vm * vm, scm_env * env, scm_value * fn, scm_value ** lists, int list_count, int list_length_ex)
{
	int i, j;
	scm_value * values[list_length_ex][list_count];
	unsigned flag = SCM_FLAGS(fn);
	
	for (i = 0 ; i < list_length_ex; i++) {
		for (j = 0; j < list_count; j++) {
#ifndef USE_STM
			values[i][j] = SCM_CAR(lists[j]);
			lists[j] = SCM_CDR(lists[j]);
#else
			values[i][j] = TS_SCM_CAR(vm, lists[j]);
			lists[j] = TS_SCM_CDR(vm, lists[j]);
#endif
		}
	}

	for (i = list_length_ex - 1 ; i >= 0; i--) {
		if (flag & SCM_SYNC_DROP) vm_push_cmd(vm, OP_DROP, NULL, NULL);
		vm_push_cmd(vm, OP_RUN, env, scm_value_new_int(list_count));
		if (flag & SCM_SYNC_WAIT) vm_push_cmd(vm, OP_WAIT, NULL, NULL);
		for (j = 0; j < list_count; j++)
			vm_push_cmd(vm, OP_PUSH, NULL, values[i][j]);
		vm_push_cmd(vm, OP_PUSH, NULL, fn);
	}
}

static void op_map(OP_ARGS)
{

	WARN_TRANS_UNSAFE("map")
	int i, length;
	int list_count = SCM_INT(arg1) - 1;
	scm_value * fn;
	//scm_value ** lists = alloca(sizeof(scm_value *) * list_count);
	scm_value ** lists = GC_MALLOC(sizeof(scm_value *) * list_count);

	for (i = 0; i < list_count; i++) {
		lists[i] = vm_rslt_pop(vm);
#ifndef USE_STM
		if (!is_list(lists[i])) {
#else
		if (!ts_is_list(vm, lists[i])) {
#endif
			vm_error(vm, scm_value_new_error("map: wrong argument type"));
			return;
		}
	}
	fn = vm_rslt_pop(vm);

#ifndef USE_STM
	length = list_length(lists[0]);
#else
	length = ts_list_length(vm, lists[0]);
#endif
	for (i = 1; i < list_count; i++) {
#ifndef USE_STM
		if (list_length(lists[i]) != length) {
#else
		if (ts_list_length(vm, lists[i]) != length) {
#endif
			vm_error(vm, scm_value_new_error("map: all lists must have the same size"));
			return;
		}
	}
	vm_push_cmd(vm, OP_RUN, env, scm_value_new_int(length)); 
	vm_rslt_push(vm, scm_const_fn_list);
	map_values(vm, env, fn, lists, list_count, length);
}

static void op_let(OP_ARGS)
{
	int i;
	int argc = SCM_INT(arg1);
	scm_value * values[argc];
	scm_value * symbols[argc];
	scm_value * body;
	scm_env * new_env;

	for (i = argc - 1; i >= 0; i--)
	       values[i] = vm_rslt_pop(vm);	
	for (i = argc - 1; i >= 0; i--)
	       symbols[i] = vm_rslt_pop(vm);	
	body = vm_rslt_pop(vm);

	new_env = scm_env_new(env, argc);
#ifdef USE_STM
	new_env->epoch = vm->epoch;
#endif
	for (i = 0; i < argc; i++)
		scm_env_add(new_env, symbols[i], values[i]);

	load_commands(vm, new_env, body, tail_position);  
}

static void op_let_named(OP_ARGS)
{
	int i;
	int argc = SCM_INT(arg1);
	scm_value * values[argc];
	scm_value * symbols[argc];
	scm_value * symbol_list;
	scm_value * body, * func_name, * func;
	scm_env * new_env;

	for (i = argc - 1; i >= 0; i--)
	       values[i] = vm_rslt_pop(vm);	
	for (i = argc - 1; i >= 0; i--)
	       symbols[i] = vm_rslt_pop(vm);	
	body = vm_rslt_pop(vm);
	func_name = vm_rslt_pop(vm);

	new_env = scm_env_new(env, 1);
#ifdef USE_STM
	new_env->epoch = vm->epoch;
#endif

	symbol_list = list(argc, symbols, vm);
	func = scm_value_new_lambda(new_env, symbol_list, body);

	scm_env_add(new_env, func_name, func);
	invoke_user_function(vm, new_env, func, argc, values, 0);
}

static inline void op_load(OP_ARGS)
{
	char * source;
	scm_value * file_name = vm_rslt_pop(vm);
	if (SCM_TYPE(file_name) != STRING) ABORT_OPERATION("load: argument must be string");
	source = load_file(SCM_STRING(file_name));
	if (source == NULL) ABORT_OPERATION(gc_sprintf("load: unable to read '%s'", SCM_STRING(file_name)));

	scm_value * cmds = parse_input(source);
	if (SCM_TYPE(cmds) == ERROR) ABORT_OPERATION(SCM_ERROR(cmds));

	load_commands(vm, env, cmds, 0);
}

static inline void op_discard(OP_ARGS)
{
	vm_rslt_pop(vm);
}

static inline void op_return(OP_ARGS)
{
	scm_value * val = vm_rslt_pop(vm);
	vm_push_cmd(vm, OP_EVAL, env, val);
}

static inline void op_block(OP_ARGS)
{
	load_commands(vm, env, arg1, 1);
}

static inline void op_push(OP_ARGS)
{
	vm_rslt_push(vm, arg1);
}

static inline void op_feval(scm_vm * vm, command * cmd)
{
	scm_vm * master = vm;
	scm_vm * slave = cmd->vm;

	vm_emergency_stop(slave);
	vm_lock(slave);
	vm_join(master, slave, cmd);
	vm_unlock(slave);
}

static inline void op_drop(scm_vm * vm, command * cmd)
{
	vm_drop_fevals(vm);
}

void * eval_vm(void * arg_vm)
{
	scm_vm * vm = (scm_vm *)arg_vm;
	scm_rt * rt = vm_get_runtime(vm);
	unsigned int limiter = 0;
	int done = 0;
	int scheduler_limit = rt->scheduler_limit;

	vm_lock(vm);
	while (!vm_done(vm)) {

#ifdef USE_STACK_DUMP
		vm_print_stacks(vm);
#endif
		command * top = vm_pop_cmd(vm);
		scm_value * arg1 = top->arg1;
		scm_env * arg_env = top->env;
		unsigned char tail_position = top->tail_position; 

//		printf("aaa\n");
		switch (top->op) {
			case OP_EVAL: op_eval(vm, arg_env, arg1, tail_position); break;
			case OP_INSPECT: op_inspect(vm, arg_env, arg1, tail_position); break;
			case OP_RUN: op_run(vm, arg_env, arg1, tail_position); break;
			case OP_DEFINE: op_define(vm, arg_env, arg1, tail_position); break;
			case OP_SET: op_set(vm, arg_env, arg1, tail_position); break;
			case OP_IF: op_if(vm, arg_env, arg1, tail_position); break;
			case OP_DISCARD: op_discard(vm, arg_env, arg1, tail_position); break;
			case OP_RETURN: op_return(vm, arg_env, arg1, tail_position); break;
			case OP_COND: op_cond(vm, arg_env, arg1, tail_position); break;
			case OP_FEVAL:
				op_feval(vm, top); 
				limiter = rt->scheduler_limit + 1;
				break;
			case OP_WAIT: 
				if (vm->parent == NULL) done = 0;
				else {
					vm_push_cmd(vm, OP_WAIT, NULL, NULL);
					done = 1;
				}
				break;
			case OP_DROP: op_drop(vm, top); break;
			case OP_BLOCK: op_block(vm, arg_env, arg1, tail_position); break; 
			case OP_APPLY: op_apply(vm, arg_env, arg1, tail_position); break; 
			case OP_MAP: op_map(vm, arg_env, arg1, tail_position); break;
			case OP_PUSH: op_push(vm, arg_env, arg1, tail_position); break;
			case OP_LET: op_let(vm, arg_env, arg1, tail_position); break;
			case OP_LET_NAMED: op_let_named(vm, arg_env, arg1, tail_position); break;
			case OP_LOAD: op_load(vm, arg_env, arg1, tail_position); break;			      
		}

		/*if (!done) vm_command_free(vm, top);*/
		/*if (!done)*/ vm_command_free(vm, top);
		if (limiter < scheduler_limit) limiter++;
		else {
			rt_schedule_fevals(rt, vm);
			limiter = 0;
		}
		if (done) break;
	}
	/*
	rt_lock(rt);
	rt->sched_count--;
	rt_unlock(rt);
	*/
	// FIXME: log -- is out of order
	g_atomic_int_inc(&rt->sched_count);
	if (done) {
		rt_schedule_fevals(rt, vm);
	}
	vm_unlock(vm);

#ifdef USE_STACK_DUMP
		vm_print_stacks(vm);
#endif
	return NULL;
}
