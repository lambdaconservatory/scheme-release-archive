/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef INT_FUNCS_H
#define INT_FUNCS_H

#include <stdio.h>
#include <ctype.h>

#include "types.h"

char * format(scm_value * v, int debug);
int list_length(scm_value * list);
char * gc_sprintf(const char * fmt, ...);
char * gc_initstr(const char * str);
char * gc_concat(char * s1, char * s2);
scm_value * list_reverse(scm_value * list);
int is_list(scm_value * val);
char * load_file(char * filename);
char * freadstream(FILE * f);
scm_value * freadstream_to_list(FILE * f);
int is_number(char * input, int *is_float); // [+-]?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?
#ifdef USE_STM
int ts_is_list(struct scm_vm * vm, scm_value * val);
int ts_list_length(struct scm_vm * vm, scm_value * list);
#endif


#endif
