/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef TYPES_H
#define TYPES_H

#define SCM_CONST_NIL (scm_const_nil)
#define SCM_CONST_VOID	(scm_const_void)
#define SCM_CONST_FALSE	(scm_const_false)
#define SCM_CONST_TRUE	(scm_const_true)

#define INTEGER_POINTER_HACK 
#ifndef INTEGER_POINTER_HACK
	#define SCM_TYPE(x)	(x->type)
	#define SCM_INT(x)	(x->value.integer)
#else
	#define SCM_TYPE(x)	((((long)(x)) & 1) ? INT : x->type)
	#define	SCM_INT(x)	(int)((long)x >> 1)
#endif


#define SCM_BOOL(x)	(x->value.bool)
#define SCM_SYMBOL(x)	(x->value.symbol->name)
#define SCM_SYMBOL_HASH(x)	(x->value.symbol->hash)
#define SCM_FLOAT(x)	(x->value.flt)
#define SCM_PAIR(x)	(x->value.pair)
#define SCM_VECTOR(x)	(x->value.vector)
#define SCM_CAR(x)	(x->value.pair.ar)
#define SCM_CDR(x)	(x->value.pair.dr)
#define SCM_FUNC(x)	(x->value.func)
#define SCM_STRING(x)	(x->value.string)
#define SCM_SPEC_FORM(x)	(x->value.spec_form)
#define SCM_LAMBDA(x)	(x->value.lambda)
#define SCM_ERROR(x)	(x->value.err_desc)
#define SCM_CONTINUATION(x)    (x->value.continuation)
#define SCM_IS_NULL(x)	(SCM_TYPE(x) == NIL)
#define SCM_CONS(x,y)	(scm_value_new_pair(x, y))
#define SCM_FLAGS(x)    (x->flags)
#define SCM_PRE_BOUND(x)    (x->value.symbol->pre_bound)
#define SCM_SYMBOL_EQ(x,y)	(SCM_SYMBOL(x) == SCM_SYMBOL(y)) // it's not bug, all same symbols has same object

#define SCM_CAAR(x)	(SCM_CAR(SCM_CAR(x)))
#define SCM_CADR(x)	(SCM_CAR(SCM_CDR(x)))
#define SCM_CDDR(x)	(SCM_CDR(SCM_CDR(x)))
#define SCM_CDAR(x)	(SCM_CDR(SCM_CAR(x)))
#define SCM_CADDR(x)	(SCM_CAR(SCM_CDR(SCM_CDR(x))))
#define SCM_CDDDR(x)	(SCM_CDR(SCM_CDR(SCM_CDR(x))))
#define SCM_CDDAR(x)	(SCM_CDR(SCM_CDR(SCM_CAR(x))))
#define SCM_CADAR(x)	(SCM_CAR(SCM_CDR(SCM_CAR(x))))
#define SCM_CDDDDR(x)	(SCM_CDR(SCM_CDR(SCM_CDR(SCM_CDR(x)))))
#define SCM_CADDAR(x)	(SCM_CAR(SCM_CDR(SCM_CDR(SCM_CAR(x)))))
#define SCM_CAADAR(x)	(SCM_CAR(SCM_CAR(SCM_CDR(SCM_CAR(x)))))

#define SCM_SIMPLE_LIST	(1)
#define SCM_SYNC_WAIT		(0x01)
#define SCM_SYNC_DROP		(0x02)

#define S(x)		(scm_value_new_symbol(x))
#define C(x,y)		(scm_value_new_pair(x,y))

struct scm_value;
struct lambda;
struct scm_vm;
struct env_item;

#include "env.h"

typedef struct scm_value * (*scm_func)(int cnt, struct scm_value **, struct scm_vm * vm);

typedef enum scm_type {
	INT,
	FLOAT,
	PAIR,
	SYMBOL,
	FUNC,
	SPEC_FORM,
	LAMBDA,
	MACRO,
	BOOL,
	NIL,
	VOID,
	ERROR,
	CONTINUATION,
	PRECOMPILED_MACRO,
	VECTOR,
	STRING
} scm_type;

typedef enum scm_spec_type {
	SP_DEFINE, 
	SP_LAMBDA,
	SP_SET,
	SP_QUOTE,
	SP_IF,
	SP_CALLCC,
	SP_APPLY,
	SP_COND,
	SP_MAP,
	SP_LET,
	SP_LOAD
} scm_spec_type;

typedef struct scm_vector {
	int size;
	struct scm_value ** items;
} scm_vector;

typedef struct scm_symbol {
	char * name;
	unsigned int hash;
	struct env_item * pre_bound;
} scm_symbol;

typedef struct scm_value {
#ifdef USE_STM
	struct vm_epoch * epoch;
	volatile version_t version;
#endif

	unsigned char flags;
	unsigned short __length;
	scm_type type;
	union {
		int integer;
		double flt;
		int bool;
		scm_symbol * symbol;
		struct scm_pair {
			struct scm_value * ar;
			struct scm_value * dr;
		} pair;
		scm_vector * vector;
		scm_func func;
		scm_spec_type spec_form;
		struct lambda * lambda;
		char * err_desc;
		char * string;
		struct scm_vm * continuation;
	} value;

} scm_value;

struct lambda {
	scm_env * parent;
	scm_value * arg_list;
	scm_value * define_list;
	scm_value * cmd_list;
	unsigned int local_symbols;
};

#define CONSTANT(__name, __value)  extern scm_value * __name;
#include "constants.def"
#undef CONSTANT

#define S_lambda (scm_const_symbol_lambda)
#define S_define (scm_const_symbol_define)
#define S_let (scm_const_symbol_let)
#define S_quote (scm_const_symbol_quote)
#define S_if (scm_const_symbol_if)
#define S_true (scm_const_symbol_true)
#define S_false (scm_const_symbol_false)

void scm_init_globals();
#ifndef INTEGER_POINTER_HACK
scm_value * scm_value_new_int(int val);
#else
#define scm_value_new_int(__val) ((scm_value *)(long)(1 | ((__val) << 1))) 
#endif
scm_value * scm_value_new_symbol(char * symbol);
scm_value * scm_value_new_float(double val);
scm_value * scm_value_new_pair(scm_value * ar, scm_value * dr);
scm_value * scm_value_new_nil();
scm_value * scm_value_new_func(scm_func func);
scm_value * scm_value_new_spec_form(scm_spec_type type);
scm_value * scm_value_new_precompiled_macro(scm_func type);
scm_value * scm_value_new_lambda(scm_env * env, scm_value * arg_list, scm_value * cmd_list);
scm_value * scm_value_new_lambda_clone(scm_value * val);
scm_value * scm_value_new_bool(int value); 
scm_value * scm_value_new_void(); 
scm_value * scm_value_new_error(char * desc); 
scm_value * scm_value_new_continuation(struct scm_vm * continuation);
scm_value * scm_value_new_vector(int count, scm_value * val);
scm_value * scm_value_new_vector_from_list(scm_value * items);
scm_value * scm_value_set_flags(scm_value * value, unsigned char flags);
scm_value * scm_value_new_string(char * str);

#endif
