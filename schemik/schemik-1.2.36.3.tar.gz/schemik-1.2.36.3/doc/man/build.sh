#!/bin/bash

xsltproc /usr/share/xml/docbook/xsl-stylesheets-1.73.2/manpages/docbook.xsl schemik-man.xml
gzip schemik.1
