/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef STACK_H
#define STACK_H

typedef int stack_item;

struct stack {
	int size;
	int capacity;
	void ** data;
};
/*
static inline struct stack * stack_new();
static inline void stack_push(struct stack * stack, void * value);
static inline void * stack_pop(struct stack * stack);
static inline void * stack_top(struct stack * stack);
static inline int stack_empty(struct stack * stack);
static inline stack_item stack_internal_get_top(struct stack * stack);
static inline stack_item stack_internal_get_bottom(struct stack * stack);
static inline stack_item stack_internal_get_next(struct stack * stack, stack_item item);
static inline stack_item stack_internal_get_prev(struct stack * stack, stack_item item);
static inline int stack_internal_get_done(struct stack * stack, stack_item item);
static inline void * stack_internal_get_value(struct stack * stack, stack_item item);
static inline void stack_append(struct stack * s1, struct stack * s2);
*/
#endif
