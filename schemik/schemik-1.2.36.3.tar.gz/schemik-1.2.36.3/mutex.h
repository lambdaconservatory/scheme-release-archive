/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef MUTEX_H
#define MUTEX_H

#include <pthread.h>

#define mutex_t 	pthread_mutex_t
#define mutex_init(__mutex) { pthread_mutex_init(&__mutex, NULL); }
#define mutex_lock(__mutex) { pthread_mutex_lock(&__mutex); }
#define mutex_unlock(__mutex) { pthread_mutex_unlock(&__mutex); }

#include <glib.h>

typedef volatile int spinlock_t;

static inline void spinlock_init(spinlock_t * lock)
{
	*lock = 0;
}

static inline void spinlock_lock(spinlock_t * lock)
{
	while (!g_atomic_int_compare_and_exchange(lock, 0, 1)) {
		// SPIN
	}
}

static inline void spinlock_unlock(spinlock_t * lock)
{
	 g_atomic_int_set(lock, 0);
}


#endif


