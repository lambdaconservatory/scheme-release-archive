/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Initialization of the initial environment
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "types.h"
#include "env.h"
#include "functions.h"

#define REGISTER_SPEC_FORM(symbol,id) scm_env_add(env, scm_value_new_symbol(symbol), scm_value_new_spec_form(id));
#define REGISTER_FUNC(symbol,id) scm_env_add(env, scm_value_new_symbol(symbol), scm_value_new_func(id));
#define REGISTER_SYNC_FUNC(symbol,id,sync) scm_env_add(env, scm_value_new_symbol(symbol), scm_value_set_flags(scm_value_new_func(id), sync));
#define REGISTER_PRECOMP_MACRO(symbol,id) scm_env_add(env, scm_value_new_symbol(symbol), scm_value_new_precompiled_macro(id));
#define REGISTER_VALUE(symbol,value) scm_env_add(env, scm_value_new_symbol(symbol), value);

scm_env * get_initial_env(scm_env * parent) 
{
	scm_env * env = scm_env_new_with_hash(parent, 1000);

	REGISTER_VALUE("#f", SCM_CONST_FALSE);
	REGISTER_VALUE("#t", SCM_CONST_TRUE);
	
	/* special forms */
	REGISTER_SPEC_FORM("define", SP_DEFINE);
	REGISTER_SPEC_FORM("if", SP_IF);
	REGISTER_SPEC_FORM("lambda", SP_LAMBDA);
	REGISTER_SPEC_FORM("quote", SP_QUOTE);
	REGISTER_SPEC_FORM("set!", SP_SET);
	REGISTER_SPEC_FORM("call/cc", SP_CALLCC);
	REGISTER_SPEC_FORM("call-with-current-continuation", SP_CALLCC);
	REGISTER_SPEC_FORM("apply", SP_APPLY);
	REGISTER_SPEC_FORM("cond", SP_COND);
	REGISTER_SPEC_FORM("map", SP_MAP);
	REGISTER_SPEC_FORM("let", SP_LET);
	REGISTER_SPEC_FORM("load", SP_LOAD);

	#include "functions.def"

	return env;
}
