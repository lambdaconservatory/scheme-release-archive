#include "config.h"
#if (!defined(TM_LOG_C) && (defined(USE_STM)))
#define TM_LOG_C

#include <gc/gc.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "types.h"
#include "tm_log.h"
#include "env.h"
#include "vm.h"
#include <glib.h>

//
// WRITE LOGS
//

static tm_write_log * tm_wlog_new(int size)
{
	tm_write_log * result = GC_MALLOC(sizeof(tm_write_log));
	result->table = GC_MALLOC(sizeof(tm_write_log_item *) * size);
	result->capacity = size;
	result->size = 0;
	return result;
}

static inline void tm_rlog_record(tm_read_log * log, int type, void * object);
static inline scm_value * tm_wlog_check(struct scm_vm * vm, struct scm_env * env, struct scm_value * key)
{
	int i;
	tm_write_log * log = vm->write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) return item->value;
	}
	
	log = vm->parent_write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			tm_rlog_record(vm->read_log, TMI_WLOG, item);
			return item->value;
		}
	}
	return NULL;
}

static inline scm_value * tm_wlog_check_cons(struct scm_vm * vm, struct scm_value * pair, int part)
{
	return tm_wlog_check(vm, (scm_env *)pair, (part == 0 ? scm_const_car_part : scm_const_cdr_part));
}

static void tm_wlog_commit(struct scm_vm * vm, tm_write_log * log) 
{
	int i;
	for (i = 0 ; i < log->size; i++) {
		int v1 = log->table[i]->env->version;
		scm_value * key = log->table[i]->key;
		scm_value * value = log->table[i]->value;
		if (SCM_SYMBOL_EQ(key, scm_const_car_part)) {
			SCM_PAIR(((scm_value *)(log->table[i]->env))).ar = value;
		} else if (SCM_SYMBOL_EQ(key, scm_const_cdr_part)) {
			SCM_PAIR(((scm_value *)(log->table[i]->env))).dr = value;
		}else {

			scm_env_set(vm, log->table[i]->env, log->table[i]->key, log->table[i]->value);
		}
		int v2 = log->table[i]->env->version;
		if (v2 > v1) log->table[i]->committed = v2; 
	}
}

static void tm_wlog_resize(tm_write_log * log, int new_capacity)
{
	if (log->capacity >= new_capacity) return;
//	printf("wlog_resize:%i->%i\n", log->capacity, new_capacity);
	log->table = GC_REALLOC(log->table, sizeof(tm_write_log_item *) * new_capacity);
	log->capacity = new_capacity;
}

static inline void tm_wlog_record(struct scm_vm * vm, struct scm_env * env, struct scm_value * key, struct scm_value * value)
{
	int i;
	tm_write_log * log = vm->write_log;
	if (log->size + 1 >= log->capacity) tm_wlog_resize(log, log->capacity * 2);

	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			item->value = value;
			g_atomic_int_inc(&(item->version));
			return;
		}
	}
	i = log->size;
	log->table[i] = GC_MALLOC(sizeof(tm_write_log_item));
	log->table[i]->env = env;
	log->table[i]->key = key;
	log->table[i]->value = value;
	log->table[i]->version = 0;
	log->table[i]->owner = vm;
	log->size++;
	if (SCM_PRE_BOUND(key)) log->naughty++;

}


static inline void tm_wlog_record_cons(struct scm_vm * vm, struct scm_value * pair, int part, struct scm_value * value)
{
	if (pair->epoch == NULL) {
		if (vm->runtime->main_vm == vm) {
			if (part == 0) SCM_PAIR(pair).ar = value;
			else SCM_PAIR(pair).dr = value;
			return;
		}
	} else if (pair->epoch->vm == vm) {
		if (part == 0) SCM_PAIR(pair).ar = value;
		else SCM_PAIR(pair).dr = value;
		return;
	}


	tm_wlog_record(vm, (struct scm_env *) pair, part == 0 ? scm_const_car_part : scm_const_cdr_part, value);

}

static tm_write_log * tm_wlog_create_parent_wlog(struct scm_vm * parent_vm)
{
	int i, j;
	tm_write_log * log = parent_vm->write_log;
	tm_write_log * parent_log = parent_vm->parent_write_log;
	tm_write_log * result = tm_wlog_new(log->size + parent_log->size + 1);
	
	for (i = 0; i < log->size; i++)
		result->table[result->size++] = log->table[i];

	for (i = 0; i < parent_log->size; i++) {
		int overriding = 0;
		for (j = 0; j < log->size; j++) {
			tm_write_log_item * item = log->table[j];
			if ((item->env == parent_log->table[i]->env) 
				&& (SCM_SYMBOL_EQ(parent_log->table[i]->key, item->key))) {
				overriding = 1;
				break;
			}
		}

		if (!overriding) result->table[result->size++] = parent_log->table[i];
	}
	return result;
}

/* returns 1 if write logs contains modified global symbol */
static inline int tm_wlog_naughty(tm_write_log * log)
{
	return log->naughty;
}

//
// READ LOGS
//


static inline void __rlog_node_buffer_create(tm_read_log * log)
{
	log->node_buffer = GC_MALLOC(sizeof(tm_read_log_item) * RLOG_NODE_BUF_SIZE);
	log->node_buffer_pos = 0;
}

#define RB_RED  (1)
#define RB_BLACK        (0)
#define RB_IS_RED(__x)  ((__x) == NULL ? 0 : ((__x)->color == RB_RED))

static tm_read_log_item * __rlog_insert_node (tm_read_log * log, tm_read_log_item * h, void * object, int type, int ver)
{
	if (h == NULL) {
		//tm_read_log_item * n = GC_MALLOC(sizeof(tm_read_log_item));
		if (log->node_buffer_pos == RLOG_NODE_BUF_SIZE) __rlog_node_buffer_create(log);
		tm_read_log_item * n = log->node_buffer + log->node_buffer_pos;
		log->node_buffer_pos++;
		n->value.generic = object;
		n->type = type;
		n->version = ver;
		n->color = RB_RED;
		return n;
	}
	if (RB_IS_RED(h->left) && RB_IS_RED(h->right)) { /* color flip */
		h->color = !h->color;
		h->left->color = !h->left->color;
		h->right->color = !h->right->color;
	}


	if (h->value.generic == object) {
		h->type = type;
		h->version = ver;
	}

	else if (h->value.generic < object)  h->left = __rlog_insert_node(log, h->left, object, type, ver);
	else h->right = __rlog_insert_node(log, h->right, object, type, ver);

	if (RB_IS_RED(h->right) && !RB_IS_RED(h->left)) { /* rotate left */
		tm_read_log_item * x = h->right;
		h->right = x->left;
		x->left = h;
		x->color = x->left->color;
		x->left->color = RB_RED;
		h = x;
	}
	if (RB_IS_RED(h->left) && RB_IS_RED(h->left->left)) { /* rotate right */
		tm_read_log_item * x = h->left;
		h->left = x->right;
		x->right = h;
		x->color = x->right->color;
		x->right->color = RB_RED;
		h = x;

	}
	return h;
}


static tm_read_log * tm_rlog_new(int size) 
{
	
	tm_read_log * result = GC_MALLOC(sizeof(tm_read_log));
	result->root = NULL;
	__rlog_node_buffer_create(result);
	return result;
}

static inline void tm_rlog_record(tm_read_log * log, int type, void * object)
{
	int ver = 0;
	if (type == TMI_ENV) ver = g_atomic_int_get(&((scm_env *)object)->version);
	if (type == TMI_WLOG) ver = g_atomic_int_get(&((tm_write_log_item *)object)->version);

	log->root = __rlog_insert_node(log, log->root, object, type, ver);
	log->root->color = RB_BLACK;
}

static tm_read_log_item * __rlog_search(tm_read_log_item * h, void * object)
{
	if ((h == NULL) || (h->value.generic == object)) return h;
	if (h->value.generic < object) return __rlog_search(h->left, object);
	return __rlog_search(h->right, object);

}

#define MIN2(X, Y)  ((X) < (Y) ? (X) : (Y))
static void __rlog_paste_parent(struct scm_vm * vm, tm_read_log * master, tm_read_log * slave, tm_read_log_item * slave_node)
{
	if (slave_node == NULL) return;

	tm_read_log_item * x = __rlog_search(master->root, slave_node->value.generic);
	if (x == NULL) {
		master->root = __rlog_insert_node(master, master->root, slave_node->value.generic, slave_node->type, slave_node->version);
		master->root->color = RB_BLACK;
	} else x->version = MIN2(x->version, slave_node->version);

	__rlog_paste_parent(vm, master, slave, slave_node->left);
	__rlog_paste_parent(vm, master, slave, slave_node->right);
}

static void tm_rlog_paste_parent_log(struct scm_vm * vm, tm_read_log * master, tm_read_log * slave)
{
	__rlog_paste_parent(vm, master, slave, slave->root);
}

//
// COMMON
//

/*
 * returns 1 if transacations collidates
 */
static int tm_check_collision(tm_read_log * slave_read_log, tm_write_log * master_write_log)
{
	int i;
	for (i = 0; i < master_write_log->size; i++) {
		if (__rlog_search(slave_read_log->root, master_write_log->table[i]->env)) return 1;
	}
	return 0;
}

static int __rlog_adv_collision(tm_read_log_item * h)
{
	if (h == NULL) return 0;
	version_t v1 = -1;
	version_t v2 = h->version;

	if (h->type == TMI_WLOG) {
		v1 = h->value.wlog->version;
		if (h->value.wlog->committed) { 
			int x1 = h->value.wlog->env->version;
			int x2 = h->value.wlog->committed;
			if (x1 > x2) {
				return 1;
			}
		}
	}
	if (h->type == TMI_ENV) v1 = h->value.env->version;
	if (v1 > v2) return 1;

	if (__rlog_adv_collision(h->left)) return 1;
	if (__rlog_adv_collision(h->right)) return 1;

	return 0;
}

static int tm_check_collision_advanced_edition(tm_read_log * log)
{
	return __rlog_adv_collision(log->root);
}

static inline scm_value * tm_pair_get_generic(struct scm_vm * vm, scm_value * pair, int part)
{
	scm_value * result;
	if (pair->epoch == NULL) {
		if (vm->runtime->main_vm == vm) {
			return (part == 0 ? SCM_CAR(pair) : SCM_CDR(pair));
		}
	} else if (pair->epoch->vm == vm) {
		return (part == 0 ? SCM_CAR(pair) : SCM_CDR(pair));
	}

	result = tm_wlog_check_cons(vm, pair, part);

	if (result == NULL) result = (part == 0 ? SCM_CAR(pair) : SCM_CDR(pair));
	tm_rlog_record(vm->read_log, TMI_ENV, pair);
	return result;
}
#endif
