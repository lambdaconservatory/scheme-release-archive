/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Implementation of the runtime 
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#define GC_THREADS
#include <gc/gc.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>

#include "mutex.h"
#include "rt.h"
#include "vm.h"
#include "vm.c"
#include "types.h"
#include "env.h"
#include "initial_env.h"
#include "eval.h"
#include "int_funcs.h"
#include "stack.h"

#ifdef USE_THREAD_POOLING
#include "thread_pool.h"
#endif

#ifdef USE_STM
#include "tm_log.h"
#endif


scm_rt * rt_new(unsigned short max_threads, scm_scheduler scheduler)
{
	scm_rt * rt = (scm_rt *) GC_MALLOC(sizeof(scm_rt));
	rt->sched_count = 0;
	rt->max_threads = max_threads;
	rt->scheduler_limit = 1000;
	rt->env = get_initial_env(NULL);
	rt->scheduler = scheduler;
	mutex_init(rt->lock);
#ifdef USE_THREAD_POOLING
	rt->th_pool = thread_pool_create(max_threads);
#endif
	return rt; 
}
static void pre_bound_globals(scm_env * initial_env, scm_vm * vm, scm_value * value)
{
	switch (SCM_TYPE(value)) {
		case PAIR:
			pre_bound_globals(initial_env, vm, SCM_CAR(value));
			pre_bound_globals(initial_env, vm, SCM_CDR(value));
			break;
		case SYMBOL:
			SCM_PRE_BOUND(value) = scm_env_get_item(vm, initial_env, value);
			break;
	}
}

scm_value * rt_eval(scm_rt * rt, scm_value * value)
{
	scm_vm * vm;
	scm_value * result;

	/*
	rt_lock(rt);
	rt->sched_count = 0;
	rt_unlock(rt);
	*/
	g_atomic_int_set(&rt->sched_count, rt->max_threads + 1);

	vm = vm_new_init(rt, vm_command_new0(OP_EVAL, rt->env, value));
	rt->main_vm = vm;
#ifdef USE_STM
	rt->env->epoch = vm->epoch;
#endif

	pre_bound_globals(rt->env, vm, value);
	eval_vm(vm);

	vm_lock(vm);
	if (!stack_empty(vm->rslt)) result = vm_rslt_pop(vm); /* result stack contains only one result which is actually the result */
	else result = scm_value_new_error("Inconsistant stack");
	vm_unlock(vm);
	return result; 
}

#ifdef DEBUG
static void write_log_item(scm_rt * rt, FILE * f, struct thread_log * log_item, long * start)
{
	if (log_item->next == NULL) {
		*start = log_item->sec;
		return;
	}
	write_log_item(rt, f, log_item->next, start);
	if (log_item->count >= 0) {
		fprintf(f, "%ld.%ld\t%i\n", log_item->sec - *start, log_item->us, log_item->count + 1);
	}
}

static void write_log(scm_rt * rt)
{
	FILE * f = fopen("thread.log", "w+");
	long start;
	if (rt->log == NULL) return;
	write_log_item(rt, f, rt->log, &start);
	fflush(f);
	fclose(f);
}
#endif

scm_value * rt_eval_str(scm_rt * rt, char * str)
{
	scm_value * cmds = parse_input(str);
	scm_value * result = NULL;

	if (SCM_TYPE(cmds) == ERROR) return cmds;
	while (SCM_TYPE(cmds) == PAIR) {
		result = rt_eval(rt, SCM_CAR(cmds)) ;
		if (SCM_TYPE(result) == ERROR) {
			fprintf(stderr, "%s\n", SCM_ERROR(result));
			break;
		}
		cmds = SCM_CDR(cmds);
	}
#ifdef DEBUG
	write_log(rt);
#endif
	return result;
}

/* returns 1 if no other thread may be scheduled */
static inline int rt_schedule_on_eval(scm_rt * rt, scm_vm * vm, command * cmd)
{
	scm_vm * nvm; 
	int done = 0;
	// FIXME: log -- is out of order
	/*
	rt_lock(rt);
	if (rt->sched_count >= rt->max_threads) {
		rt_unlock(rt);
		return 1;
	} else {
		rt->sched_count++;
		if (rt->sched_count >= rt->max_threads) done = 1;
	}
	rt_unlock(rt);
	*/

	if (g_atomic_int_dec_and_test(&rt->sched_count)) {
		// XXX: race condition ???
		g_atomic_int_inc(&rt->sched_count);
		return 1;
	}


	nvm = vm_new_init(rt, vm_command_new0(OP_EVAL, cmd->env, cmd->arg1));
	nvm->parent = vm;
#ifdef USE_THREAD_INFO
	fprintf(stderr, "SCHEDULER:%s\n", format(cmd->arg1, 0));
#endif

#ifdef USE_STM
	vm->sub_threads++;
	if (vm->parent != NULL) nvm->parent_write_log = tm_wlog_create_parent_wlog(vm);
#endif
	cmd->op = OP_FEVAL;
	cmd->vm = nvm;
	vm_stats_register_feval(vm, cmd->arg1);

#ifndef USE_THREAD_POOLING
	pthread_t * thr = (pthread_t *)GC_MALLOC(sizeof(pthread_t));
	pthread_create(thr, NULL, eval_vm, nvm);
	pthread_detach(*thr);
#else
	thread_pool_run(rt->th_pool, eval_vm, nvm);
#endif

	return done;
}

/* returns 1 if no other thread may be scheduled */
static inline int try_to_schedule_feval(scm_rt * rt, scm_vm * vm, command * cmd)
{
	if (((SCM_FLAGS(cmd->arg1) & SCM_SIMPLE_LIST)) 
	   && SCM_TYPE(SCM_CAR(cmd->arg1)) == SYMBOL) {
		
		scm_value * test = scm_env_get(vm, rt->env, SCM_CAR(cmd->arg1));
		if (test && 
			((SCM_TYPE(test) == FUNC) 
			|| (SCM_TYPE(test) == SPEC_FORM) 
			|| (SCM_TYPE(test) == PRECOMPILED_MACRO))) 
			return 0;
	}
#ifdef USE_SMART_SCHEDULER
	vm_stat_item * stat = vm_stats_get(vm, cmd->arg1);
	if ((stat != NULL) && (stat->drops > 0)) return 0;
#endif

	int done = rt_schedule_on_eval(rt, vm, cmd);
	return done;
}

void backward_scheduler(scm_rt * rt, scm_vm * vm)
{
	stack_item xstack = stack_internal_get_bottom(vm->exct);
	if (stack_empty(vm->exct)) return;
	int hit = 0;
	while (!stack_internal_get_done(vm->exct, xstack)) {
		hit++;
		if (hit + 1 >= vm->exct->size) break;
		command * cmd = stack_internal_get_value(vm->exct, xstack);

		if ((cmd->op == OP_EVAL) && (SCM_TYPE(cmd->arg1) == PAIR) && (cmd->tail_position != HEAD)) {
			int done = try_to_schedule_feval(rt, vm, cmd);
			if (done) break;
		}
		xstack = stack_internal_get_prev(vm->exct, xstack);
	}
}

void forward_scheduler(scm_rt * rt, scm_vm * vm)
{
	//int limiter = 8;
	int limiter = 2;

	stack_item xstack = stack_internal_get_top(vm->exct);
	while (!stack_internal_get_done(vm->exct, xstack)) {
		command * cmd = stack_internal_get_value(vm->exct, xstack);

		if (cmd->op == OP_FEVAL) limiter--;
		if (cmd->op == OP_DROP) break;
		if ((cmd->op == OP_EVAL) && (SCM_TYPE(cmd->arg1) == PAIR) && (cmd->tail_position != HEAD)) {
			if (limiter == 0) {
				int done = try_to_schedule_feval(rt, vm, cmd);
				if (done) break;
			} else limiter--;
		}
		xstack = stack_internal_get_next(vm->exct, xstack);
	}
}

/* Assumes locked vm, unlocked rt */
void rt_schedule_fevals(scm_rt * rt, scm_vm * vm)
{
	/*
	rt_lock(rt);
	if (rt->sched_count >= rt->max_threads) {
		rt_unlock(rt);
		return;
	}
	rt_unlock(rt);
	*/
//#warning KOMPILUJES TO BLBE
//	if (vm->parent != NULL) return; // FIXME: odstranit --- totalne rozdrba planovac
	
	volatile int cnt = g_atomic_int_get(&rt->sched_count);
	if (cnt <= 1) return;
	
	scm_scheduler scheduler = rt->scheduler;
	scheduler(rt, vm);
}

void rt_lock(scm_rt * rt)
{
	mutex_lock(rt->lock);
}

void rt_unlock(scm_rt * rt) 
{
	mutex_unlock(rt->lock);
}
