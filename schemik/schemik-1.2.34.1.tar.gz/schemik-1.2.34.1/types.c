/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Implementation of data types
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#include <gc/gc.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "types.h"
#include "int_funcs.h"
#include "functions.h"

#define ALLOC_VAL		((scm_value *) GC_MALLOC(sizeof(scm_value)))
#define ALLOC_ATOMIC_VAL	((scm_value *) GC_MALLOC_ATOMIC(sizeof(scm_value)))

#define GST_INIT_SIZE	(50)
struct {
	int size;
	int capacity;
	scm_value ** symbols;
	pthread_mutex_t lock;
} global_symbol_table;

#define CONSTANT(__name, __value)  scm_value * __name = NULL;
#include "constants.def"
#undef CONSTANT


void scm_init_globals()
{
	pthread_mutex_init(&(global_symbol_table.lock), NULL);
	global_symbol_table.capacity = GST_INIT_SIZE;
	global_symbol_table.size = 0;
	global_symbol_table.symbols = GC_MALLOC(sizeof(scm_value *) * GST_INIT_SIZE);
	
	#define CONSTANT(__name, __value) __name = __value;
	#include "constants.def"
	#undef CONSTANT
}

#define GENERIC_TYPE(constructor,c_type,schemik_type,cell_slot) \
scm_value * constructor(c_type value) \
{ \
	scm_value * result = ALLOC_ATOMIC_VAL; \
	result->type = schemik_type; \
	result->value.cell_slot = value; \
	return result; \
}


#ifndef INTEGER_POINTER_HACK
GENERIC_TYPE(scm_value_new_int, int, INT, integer)
#else
/*
defined as macro in types.h
*/
#endif

/*
 *
 * Hash functions
 *
 */
static inline unsigned int hash_func(char *str) 
{ 
	unsigned int hash = 5381; 

	while (*str) { 
		hash = ((hash << 5) + hash) + *str; /* hash * 33 + c */
		str++;
	}

	return hash; 
}

scm_value * scm_value_new_symbol(char * symbol) 
{
	int i;
	scm_value * result;
	pthread_mutex_lock(&(global_symbol_table.lock));

	for (i = 0; i < global_symbol_table.size; i++) {
		if (!strcmp(SCM_SYMBOL(global_symbol_table.symbols[i]), symbol)) {
			result = global_symbol_table.symbols[i];
			pthread_mutex_unlock(&(global_symbol_table.lock));
			return result;
		}
	}

	result = ALLOC_VAL;
	result->type = SYMBOL;
	result->value.symbol = GC_MALLOC(sizeof(scm_symbol));
	result->value.symbol->name = symbol;
	result->value.symbol->hash = hash_func(symbol);

	if (global_symbol_table.size + 1 == global_symbol_table.capacity) {
		global_symbol_table.capacity *= 2;
		global_symbol_table.symbols = GC_REALLOC(global_symbol_table.symbols,
							 sizeof(scm_value *) * global_symbol_table.capacity);
	}
	global_symbol_table.symbols[global_symbol_table.size++] = result;

	pthread_mutex_unlock(&(global_symbol_table.lock));
	return result;
	
}

GENERIC_TYPE(scm_value_new_float, double, FLOAT, flt)
GENERIC_TYPE(scm_value_new_func, scm_func, FUNC, func)
GENERIC_TYPE(scm_value_new_spec_form, scm_spec_type, SPEC_FORM, spec_form)
GENERIC_TYPE(scm_value_new_precompiled_macro, scm_func, PRECOMPILED_MACRO, func)
GENERIC_TYPE(scm_value_new_bool, int, BOOL, bool)
GENERIC_TYPE(scm_value_new_error, char *, ERROR, err_desc)
GENERIC_TYPE(scm_value_new_string, char *, STRING, string)

scm_value * scm_value_new_pair(scm_value * ar, scm_value * dr) 
{
	scm_value * result = ALLOC_VAL;
	result->type = PAIR;
	result->value.pair.ar = ar;
	result->value.pair.dr = dr;
	return result;
}

scm_value * scm_value_new_nil()
{
	scm_value * result = ALLOC_ATOMIC_VAL;
	result->type = NIL;
	return result;
}

scm_value * scm_value_new_lambda(scm_env * env, scm_value * arg_list, scm_value * cmd_list)
{
	scm_value * result = ALLOC_VAL;
	struct lambda * fun = (struct lambda *) GC_MALLOC(sizeof(struct lambda));
	result->type = LAMBDA;
	fun->parent = env;
	fun->arg_list = arg_list;
	fun->define_list = SCM_CONST_NIL;

	while ((SCM_TYPE(cmd_list) == PAIR) && (SCM_TYPE(SCM_CAR(cmd_list)) == PAIR) && 
		(SCM_SYMBOL_EQ(SCM_CAAR(cmd_list), scm_const_symbol_define))) {
		fun->define_list = scm_value_new_pair(SCM_CAR(cmd_list), fun->define_list);
		cmd_list = SCM_CDR(cmd_list);
		fun->local_symbols++;
	}
	fun->cmd_list = cmd_list;
	result->value.lambda = fun; 
	return result;
}

scm_value * scm_value_new_lambda_clone(scm_value * val)
{
	scm_value * result = ALLOC_VAL;
	struct lambda * fun = (struct lambda *) GC_MALLOC(sizeof(struct lambda));
	memcpy(fun, val->value.lambda, sizeof(struct lambda));
	result->type = LAMBDA;
	result->value.lambda = fun;
	return result;
}

scm_value * scm_value_new_void()
{
	scm_value * result = ALLOC_ATOMIC_VAL;
	result->type = VOID;
	return result;
}

scm_value * scm_value_new_continuation(struct scm_vm * continuation)
{
	scm_value * result = ALLOC_VAL;
	result->type = CONTINUATION;
	result->value.continuation = continuation;
	return result;
}

static inline scm_value * empty_vector(int length)
{
	scm_value * result = ALLOC_VAL;
	scm_vector * vector = (scm_vector *)GC_MALLOC(sizeof(scm_vector));
	vector->size = length;
	vector->items = GC_MALLOC(sizeof(scm_value *) * length);
	result->type = VECTOR;
	result->value.vector = vector;
	return result;
}

scm_value * scm_value_new_vector_from_list(scm_value * items)
{
	int length = list_length(items);
	scm_value * result = empty_vector(length);
	int i = 0;

	while (SCM_TYPE(items) == PAIR) {
		SCM_VECTOR(result)->items[i] = SCM_CAR(items);
		i++;
		items = SCM_CDR(items);
	}
	return result;
}

scm_value * scm_value_new_vector(int count, scm_value * val)
{
	int i;
	scm_value * result = empty_vector(count);
	
	for (i = 0; i < count; i++)
		SCM_VECTOR(result)->items[i] = val;
	return result;
}

scm_value * scm_value_set_flags(scm_value * value, unsigned char flags)
{
	SCM_FLAGS(value) = flags;
	return value;
}

