/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "types.h"

#define SCM_ARGS 	int count, scm_value ** args

#define REGISTER_FUNC(__symbol, __name) scm_value * __name(SCM_ARGS);
#define REGISTER_SYNC_FUNC(__symbol, __name, __useless) scm_value * __name(SCM_ARGS);
#define REGISTER_PRECOMP_MACRO(__symbol, __name) scm_value * __name(SCM_ARGS);
#include "functions.def"
#undef REGISTER_FUNC
#undef REGISTER_SYNC_FUNC
#undef REGISTER_PRECOMP_MACRO
#endif
