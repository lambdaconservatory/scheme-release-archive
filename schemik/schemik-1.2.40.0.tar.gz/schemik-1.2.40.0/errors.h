#ifndef ERRORS_H
#define ERRORS_H
scm_value * err_bad_args(char * func_name, char * msg, int arg_count, scm_value ** args, int line);
scm_value * err_bad_args_ex(char * func_name, char * msg, int arg_count, scm_value ** args, int excl, int line);
scm_value * err_bad_spec_form(char * spec_form_name, char * msg, scm_value * values, int line);
scm_value * err_map_func(char * msg, scm_value * fn, int list_count, scm_value ** lists, int pos, int line);
#endif
