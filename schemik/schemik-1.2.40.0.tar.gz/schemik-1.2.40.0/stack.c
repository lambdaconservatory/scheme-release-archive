/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Implementation of the ``stack'' structure
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
#ifndef STACK_C
#define STACK_C

#include "config.h"

#include <gc/gc.h>

#include "stack.h"

//#define INITIAL_CAPACITY	16
#define INITIAL_CAPACITY	64
static inline struct stack * stack_new()
{
	struct stack * result = (struct stack *) GC_MALLOC(sizeof(struct stack));
	result->capacity = INITIAL_CAPACITY;
	result->size = 0;
	result->data = (void **) GC_MALLOC(sizeof(void *) * result->capacity);
	return result;
}

static inline void stack_push(struct stack * stack, void * value)
{
	if (stack->size + 1 >= stack->capacity) {
		stack->capacity *= 2;
		stack->data = (void **) GC_realloc(stack->data, sizeof(void *) * stack->capacity);
	}
	stack->data[stack->size++] = value;
}

static inline void * stack_pop(struct stack * stack)
{
	if (stack->size == 0) return NULL;
	void * result = stack->data[stack->size - 1];
	stack->data[--stack->size] = NULL;
	return result;
}

static inline void * stack_top(struct stack * stack)
{
	if (stack->size == 0) return NULL;
	return stack->data[stack->size - 1];
}


static inline int stack_empty(struct stack * stack)
{
	return (stack->size == 0);
}

static inline stack_item stack_internal_get_top(struct stack * stack)
{
	return stack->size;
}

static inline stack_item stack_internal_get_bottom(struct stack * stack)
{
	return 1;
}

static inline stack_item stack_internal_get_next(struct stack * stack, stack_item item)
{
	return item - 1;
}

static inline stack_item stack_internal_get_prev(struct stack * stack, stack_item item)
{
	return item + 1;
}

static inline stack_item stack_internal_get_done(struct stack * stack, stack_item item)
{
	return ((item <= 0) || (item > stack->size));
}

static inline void * stack_internal_get_value(struct stack * stack, stack_item item)
{
	return stack->data[item - 1];
}


static inline void stack_append(struct stack * s1, struct stack * s2)
{

	if (s2->size == 0) return;
//	mutex_t lck;
//	mutex_init(lck);
//	mutex_lock(lck); /* memcpy - threadsafe */

//	void * old = s1->data;
	if (s1->size + s2->size >= s1->capacity) {
		s1->data = GC_realloc(s1->data, sizeof(void *) * (s1->size + s2->size + 1));
		s1->capacity = (s1->size + s2->size + 1);
	}

	memcpy(s1->data + s1->size, s2->data, sizeof(void *) * s2->size);
	s2->capacity = INITIAL_CAPACITY;
	s2->data = (void **) GC_MALLOC(sizeof(void *) * s2->capacity);

	s1->size = s1->size + s2->size;
	s2->size = 0;
//	mutex_unlock(lck);
}

#endif
