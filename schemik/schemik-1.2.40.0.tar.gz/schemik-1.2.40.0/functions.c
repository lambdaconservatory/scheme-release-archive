/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Definition of primitive functions and macros
 *
 * Copyright (C) 2006-2009 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#include <gc/gc.h>
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

#include "types.h"
#include "functions.h"
#include "int_funcs.h"
#include "rt.h"
#include "vm.h"
#include "errors.h"

#ifdef USE_STM
#include "tm_log.c"
#endif

unsigned int gensym_last = 0;
pthread_mutex_t gensym_lock = PTHREAD_MUTEX_INITIALIZER;


#define BUF_SIZE (1024)

#define SCM_ASSERT_ARG_CNT_EQ(__cnt,__fn_name) \
	if (count != __cnt) return err_bad_args(__fn_name, gc_sprintf("expecting %i argument(s)", __cnt), count, args, vm->cur_line);

#define SCM_ASSERT_ARG_TYPE_EQ(__type,__position,__fn_name) \
	if (SCM_TYPE(args[__position]) != __type) \
		return err_bad_args_ex(__fn_name, gc_sprintf("argument of type '%s' expected at the %s position", #__type, ordinal_str(__position + 1)),  count, args, __position, vm->cur_line);

#define SCM_ASSERT_ARG_TYPE_NUMBER(__position,__fn_name) \
	if ((SCM_TYPE(args[__position]) != INT) && (SCM_TYPE(args[__position]) != FLOAT)) \
		return err_bad_args_ex(__fn_name, gc_sprintf("argument of type 'number' expected at the %s position", ordinal_str(__position + 1)), count, args, __position, vm->cur_line);

#define ERR_MSG(__fn, __msg, __pos) err_bad_args_ex(__fn, __msg, count, args, __pos, vm->cur_line)
#define ERR_MSG0(__fn, __msg) err_bad_args(__fn, __msg, count, args, vm->cur_line)

#define scm_float_num(x) (SCM_TYPE(x) == INT ? (double)SCM_INT(x) : SCM_FLOAT(x))
#define scm_int_num(x) (SCM_TYPE(x) == INT ? SCM_INT(x) : (int)SCM_FLOAT(x))

#define mk_list2(item1, item2) (C((item1), C((item2), SCM_CONST_NIL)))
#define mk_list3(item1, item2, item3) (C((item1), mk_list2(item2, item3)))
#define mk_list4(item1, item2, item3, item4) (C((item1), mk_list3(item2, item3, item4)))

scm_value * plus(SCM_ARGS)
{
	int i, result_float = 0;

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "plus")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = 0;
		for (i = 0; i < count; i++) 
			result += scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else { 
		int result = 0;
		for (i = 0; i < count; i++)
			result += scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * minus(SCM_ARGS)
{
	int i, result_float = 0;
	if (count == 0) return scm_value_new_int(0);
	if (count == 1) {
		SCM_ASSERT_ARG_TYPE_NUMBER(0, "minus")
		if (SCM_TYPE(args[0]) == INT) return scm_value_new_int(- SCM_INT(args[0]));
		if (SCM_TYPE(args[0]) == FLOAT) return scm_value_new_float(- SCM_FLOAT(args[0]));
	}

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "minus")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			result -= scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		//int result = scm_int_num(args[0]);
		int result = SCM_INT(args[0]);
		for (i = 1; i < count; i++) 
			result -= SCM_INT(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * multiply(SCM_ARGS)
{
	int i, result_float = 0;
	result_float = 0;
	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "multiply")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = 1;
		for (i = 0; i < count; i++) 
			result *= scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = 1;
		for (i = 0; i < count; i++) 
			result *= scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * divide(SCM_ARGS)
{
	int i, result_float;
	result_float = 0;
	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "divide")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
		if ((SCM_TYPE(args[i]) == INT) && (scm_int_num(args[i]) == 0) && (i > 0)) return ERR_MSG("divide", "division by zero", i); 
		if ((SCM_TYPE(args[i]) == FLOAT) && (scm_float_num(args[i]) == 0) && (i > 0)) return ERR_MSG("divide", "division by zero", i);
	}
	if (count == 1) {
		if ((SCM_TYPE(args[0]) == INT) && (scm_int_num(args[0]) == 0)) return ERR_MSG("divide", "division by zero", i);
		if ((SCM_TYPE(args[0]) == FLOAT) && (scm_float_num(args[0]) == 0)) return ERR_MSG("divide", "division by zero", i);
		if ((SCM_TYPE(args[0]) == INT) && (scm_int_num(args[0]) == 1)) return scm_value_new_int(1); 
		return scm_value_new_float(1 / scm_float_num(args[0]));
	}

	/* return floats at all situations */
	double result = scm_float_num(args[0]);
	for (i = 1; i < count; i++) 
		result /= scm_float_num(args[i]);
	return scm_value_new_float(result);
}

scm_value * quotient(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "quotient")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "quotient")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "quotient")
	
	return scm_value_new_int(SCM_INT(args[0]) / SCM_INT(args[1]));
}

scm_value * modulo(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "modulo")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "modulo")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "modulo")
	
	return scm_value_new_int(SCM_INT(args[0]) % SCM_INT(args[1]));
}

scm_value * pred_eqref(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_eqref")
	if (args[0] == args[1]) return SCM_CONST_TRUE;
	return SCM_CONST_FALSE;
}

scm_value * pred_eq(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_eq")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_eq");
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_eq");

	return pred_equal(count, args, vm);
}

scm_value * pred_equal(SCM_ARGS)
{
	scm_value * a1;
	scm_value * a2;

	SCM_ASSERT_ARG_CNT_EQ(2, "pred_equal")
	
	a1 = args[0];
	a2 = args[1];
	if ((SCM_TYPE(a1) == FLOAT) || (SCM_TYPE(a2) == FLOAT))
		return (scm_float_num(a1) == scm_float_num(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
	if (SCM_TYPE(a1) != SCM_TYPE(a2)) return SCM_CONST_FALSE;
	switch (SCM_TYPE(a1)) {
		case INT: return (SCM_INT(a1) == SCM_INT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case SYMBOL: return (SCM_SYMBOL_EQ(a1, a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case BOOL: return (SCM_BOOL(a1) == SCM_BOOL(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case STRING: return (strcmp(SCM_STRING(a1), SCM_STRING(a2)) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
		case NIL: return SCM_CONST_TRUE;
		case PAIR:
			  {
				  scm_value * nargs[4];
				  scm_value * v1;
				  scm_value * v2;
#ifndef USE_STM
				  nargs[0] = SCM_CAR(args[0]);
				  nargs[1] = SCM_CAR(args[1]);
				  nargs[2] = SCM_CDR(args[0]);
		 		  nargs[3] = SCM_CDR(args[1]);
#else
				  nargs[0] = TS_SCM_CAR(vm, args[0]);
				  nargs[1] = TS_SCM_CAR(vm, args[1]);
				  nargs[2] = TS_SCM_CDR(vm, args[0]);
		 		  nargs[3] = TS_SCM_CDR(vm, args[1]);

#endif

				  v1 = pred_equal(2, nargs, vm);
				  v2 = pred_equal(2, nargs + 2, vm);

				  if (SCM_BOOL(v1) && SCM_BOOL(v2)) return SCM_CONST_TRUE;
				  return SCM_CONST_FALSE;
			  }
		case VECTOR: 
			  {
				  if (SCM_VECTOR(args[0])->size != SCM_VECTOR(args[1])->size) return SCM_CONST_FALSE;
				  scm_value * nargs[2];
				  int i;
				  for (i = 0; i < SCM_VECTOR(args[0])->size; i++) {
					  nargs[0] = SCM_VECTOR(args[0])->items[i];
					  nargs[1] = SCM_VECTOR(args[1])->items[i];
					  scm_value * v = pred_equal(2, nargs, vm);
					  if (!SCM_BOOL(v)) return SCM_CONST_FALSE;
				  }
				  return SCM_CONST_TRUE;
			  }
	}
	return (a1 == a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_eqv(SCM_ARGS)
{
	scm_value * a1;
	scm_value * a2;

	SCM_ASSERT_ARG_CNT_EQ(2, "pred_equal")
	
	a1 = args[0];
	a2 = args[1];
	if (SCM_TYPE(a1) != SCM_TYPE(a2)) return SCM_CONST_FALSE;
	switch (SCM_TYPE(a1)) {
		case INT: return (SCM_INT(a1) == SCM_INT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case FLOAT: return (SCM_FLOAT(a1) == SCM_FLOAT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case SYMBOL: return (SCM_SYMBOL_EQ(a1, a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case BOOL: return (SCM_BOOL(a1) == SCM_BOOL(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case NIL: return SCM_CONST_TRUE;
	}
	return (a1 == a2 ? SCM_CONST_TRUE : SCM_CONST_FALSE);
}


scm_value * pred_lt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_lt")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_lt")
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_lt")
	
	if ((SCM_TYPE(args[0]) == FLOAT) || (SCM_TYPE(args[1]) == FLOAT)) {
		if (scm_float_num(args[0]) < scm_float_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	} else {
		if (scm_int_num(args[0]) < scm_int_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	}
}

scm_value * pred_gt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_gt")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_gt")
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_gt")

	if ((SCM_TYPE(args[0]) == FLOAT) || (SCM_TYPE(args[1]) == FLOAT)) {
		if (scm_float_num(args[0]) > scm_float_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	} else {
		if (scm_int_num(args[0]) > scm_int_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	}
}

#define TYPE_PREDICATE(fun_name,pred_type)	\
scm_value * fun_name(SCM_ARGS)	\
{	\
	SCM_ASSERT_ARG_CNT_EQ(1, #fun_name)	\
	if (SCM_TYPE(args[0]) == pred_type) return SCM_CONST_TRUE;	\
	else return SCM_CONST_FALSE;	\
}

TYPE_PREDICATE(pred_symbol, SYMBOL)
TYPE_PREDICATE(pred_boolean, BOOL)
TYPE_PREDICATE(pred_macro, MACRO)
TYPE_PREDICATE(pred_pair, PAIR)
TYPE_PREDICATE(pred_int, INT)
TYPE_PREDICATE(pred_float, FLOAT)
TYPE_PREDICATE(pred_vector, VECTOR)
TYPE_PREDICATE(pred_string, STRING)

scm_value * pred_procedure(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_procedure")
	return ((SCM_TYPE(args[0]) == LAMBDA) || (SCM_TYPE(args[0]) == FUNC)) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_number(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_number")
	return ((SCM_TYPE(args[0]) == INT) || (SCM_TYPE(args[0]) == FLOAT)) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_list(SCM_ARGS)
{
	scm_value * arg;
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_list")
	arg = args[0];
	while (1) {
		if (SCM_TYPE(arg) == NIL) return SCM_CONST_TRUE;
		if (SCM_TYPE(arg) == PAIR) arg = SCM_CDR(arg);
		else return SCM_CONST_FALSE;
	}
}

scm_value * display_dbg(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "display_value_dbg");
	printf("%s\n", format(args[0], 1));
	return SCM_CONST_VOID;
}

scm_value * list(SCM_ARGS)
{
	if (count == 0) return SCM_CONST_NIL;
#ifndef USE_STM
	return scm_value_new_pair(args[0], list(count - 1, args + 1, vm));
#else
	scm_value * v = scm_value_new_pair(args[0], list(count - 1, args + 1, vm));
	if (vm) v->epoch = vm->epoch;
	return v;
#endif
}

scm_value * reverse(SCM_ARGS)
{
	scm_value * l;
	scm_value * result = SCM_CONST_NIL;
	SCM_ASSERT_ARG_CNT_EQ(1, "reverse");
	l = args[0];
	while (SCM_TYPE(l) == PAIR) {
#ifndef USE_STM
		result = scm_value_new_pair(SCM_CAR(l), result);
		l = SCM_CDR(l);
#else
		result = scm_value_new_pair(TS_SCM_CAR(vm, l), result);
		l = TS_SCM_CDR(vm, l);
#endif
	}
	if (SCM_TYPE(l) == NIL) return result;
	return ERR_MSG("reverse", "requires a list as an argument", 0);
}

scm_value * is_null(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "is_null")

	if (SCM_TYPE(args[0]) == NIL) return SCM_CONST_TRUE;
	return SCM_CONST_FALSE;
}

scm_value * car(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "car")
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "car");
	
#ifndef USE_STM
	return SCM_CAR(args[0]);
#else
	return TS_SCM_CAR(vm, args[0]);
#endif
}

scm_value * cdr(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "cdr")
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "cdr");
	
#ifndef USE_STM
	return SCM_CDR(args[0]);
#else
	return TS_SCM_CDR(vm, args[0]);
#endif

}

scm_value * cons(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "cons")
#ifndef USE_STM
	return scm_value_new_pair(args[0], args[1]);
#else
	scm_value * result = scm_value_new_pair(args[0], args[1]);
	result->epoch = vm->epoch;
	return result;
#endif
}

scm_value * not(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "not")
	scm_value * result = SCM_CONST_FALSE;
	scm_value * val = args[0];
	if (SCM_TYPE(val) == BOOL) result = (SCM_BOOL(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
//	if (SCM_TYPE(val) == INT) result = (SCM_INT(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
//	if (SCM_TYPE(val) == FLOAT) result = (SCM_FLOAT(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
//	if (SCM_TYPE(val) == NIL) result = SCM_CONST_FALSE;

	return result;
}

scm_value * sleep_func(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "usleep")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "usleep");

	usleep(SCM_INT(args[0]));

	return SCM_CONST_VOID;
}

scm_value * gensym(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(0, "gensym");

	pthread_mutex_lock(&gensym_lock);
	int iid = gensym_last++;
	pthread_mutex_unlock(&gensym_lock);

	return scm_value_new_symbol(gc_sprintf("__gensym__%i", iid));
}

static scm_value * append_lists(scm_value * src, scm_value * dst, struct scm_vm * vm) {
	if (SCM_IS_NULL(src)) return dst;
#ifndef USE_STM
	scm_value * first = scm_value_new_pair(SCM_CAR(src), SCM_CONST_NIL);
	scm_value * last = first;
	scm_value * current = SCM_CDR(src);
	while (1) {
		if (SCM_IS_NULL(current)) {
			SCM_CDR(last) = dst;
			break;
		}
		SCM_CDR(last) = scm_value_new_pair(SCM_CAR(current), SCM_CONST_NIL);
		last = SCM_CDR(last);
		current = SCM_CDR(current);
	}
#else
	scm_value * first = scm_value_new_pair(TS_SCM_CAR(vm, src), SCM_CONST_NIL);
	scm_value * last = first;
	last->epoch = vm->epoch;
	scm_value * current = TS_SCM_CDR(vm, src);
	while (1) {
		if (SCM_IS_NULL(current)) {
			SCM_CDR(last) = dst;
			break;
		}
		SCM_CDR(last) = scm_value_new_pair(TS_SCM_CAR(vm, current), SCM_CONST_NIL);
		last = SCM_CDR(last);
		last->epoch = vm->epoch;
		current = TS_SCM_CDR(vm, current);
	}
#endif
	return first;
}

scm_value * append(SCM_ARGS)
{
	int i;
	if (count == 0) return SCM_CONST_NIL;
	if (count == 1) return args[0];

	for (i = 0; i < count; i++) {
		if (!is_list(args[i])) { // FIXME: udelat transaction safe
			return ERR_MSG("append", "all arguments are expected to be a list", i);
		}
	}
	scm_value * result = args[count - 1];
	for (i = count - 2; i >= 0; i--) {
		result = append_lists(args[i], result, vm);
	}
	
	return result;
}

scm_value * __get_last_cons(scm_value * list)
{
	while (1) {
		if (SCM_IS_NULL(SCM_CDR(list))) return list;
		list = SCM_CDR(list);
	}
}
scm_value * append_imper(SCM_ARGS)
{
	int i;
	int start = 0;
	if (count == 0) return SCM_CONST_NIL;
	if (count == 1) return args[0];

	for (i = 0; i < count; i++) {
		if (!is_list(args[i])) { // FIXME: udelat transaction safe
			return ERR_MSG("append", "all arguments are expected to be a list", i);
		}
	}

	while (1) {
		if (start == count) return SCM_CONST_NIL;
		if (SCM_IS_NULL(args[start])) start++;
		else break;
	}
	if (start == count) return SCM_CONST_NIL;
	scm_value * result = args[start];
	for (i = start; i < count - 1; i++) {
		if (SCM_IS_NULL(args[i])) continue;
		scm_value * last = __get_last_cons(args[i]);
#ifndef USE_STM
		SCM_PAIR(last).dr = args[i + 1];
#else
		tm_wlog_record_cons(vm, last, 1, args[i + 1]);
#endif
	}
	
	return result;
}

scm_value * vector(SCM_ARGS)
{
	int i;
	scm_value * result = scm_value_new_vector(count, SCM_CONST_NIL);
	for (i = 0; i < count; i++)
		SCM_VECTOR(result)->items[i] = args[i];
	return result;
}

scm_value * make_vector(SCM_ARGS)
{
	scm_value * val;
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "make-vector");
	if ((count != 1) && (count != 2)) return ERR_MSG0("make-vector", "requires two or three arguments");
	val = (count == 2 ? args[1] : SCM_CONST_FALSE);
	return scm_value_new_vector(SCM_INT(args[0]), val);
}

scm_value * vector_ref(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "vector-ref");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-ref");
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "vector-ref");

	scm_vector * vector = SCM_VECTOR(args[0]);
	if (SCM_INT(args[1]) >= vector->size) return ERR_MSG("vector-ref", "index out of range", 1);
	if (SCM_INT(args[1]) < 0) return ERR_MSG("vector-ref", "index out of range", 1);
#ifdef USE_STM
	/* FIXME: udelat vlastni funkci */
	tm_rlog_record_env(vm, vector, 0);
#endif
	return vector->items[SCM_INT(args[1])];
}

scm_value * vector_length(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "vector-length");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-length");

	return scm_value_new_int(SCM_VECTOR(args[0])->size);
}

#ifdef USE_STM
static inline scm_value * ts_scm_value_vector_from_list(scm_vm * vm, scm_value * items)
{
	int length = ts_list_length(vm, items);
	scm_value * result = scm_value_new_vector(length, NULL);
	int i = 0;

	while (SCM_TYPE(items) == PAIR) {
		SCM_VECTOR(result)->items[i] = TS_SCM_CAR(vm, items);
		i++;
		items = TS_SCM_CDR(vm, items);
	}
	return result;
}
#endif

scm_value * list_to_vector(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "list->vector");
	if (!is_list(args[0])) return ERR_MSG("list->vector", "argument is expected to be a list", 0);
#ifndef USE_STM
	return scm_value_new_vector_from_list(args[0]);
#else
	return ts_scm_value_vector_from_list(vm, args[0]);
#endif
}

scm_value * vector_to_list(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "vector->list");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector->list");
	int i;
	scm_vector * vector = SCM_VECTOR(args[0]);
	scm_value * result = SCM_CONST_NIL;
	for (i = vector->size - 1; i >= 0; i--)
		result = scm_value_new_pair(vector->items[i], result);
	return result;
}

scm_value * let_star(SCM_ARGS)
{
	int i;
	if (count < 2) return ERR_MSG0("let*", "syntax error - missing expression");
	scm_value * result = SCM_CONST_NIL;
	scm_value * variables = SCM_CONST_NIL;
	scm_value * values = SCM_CONST_NIL;
	scm_value * bindings = args[0];

	if (!is_list(bindings)) return ERR_MSG("let*", "syntax error - bad bindings", 0);
	while (!SCM_IS_NULL(bindings)) {
		scm_value * assoc = SCM_CAR(bindings);
		if (!is_list(assoc)) return ERR_MSG("let*", "syntax error - bad bindings", 0);
		if (list_length(assoc) != 2) return ERR_MSG("let*", "syntax error - bad bindings", 0);

		variables = C(SCM_CAR(assoc), variables);
		values = C(SCM_CADR(assoc), values);
		bindings = SCM_CDR(bindings);
	}


	for (i = count - 1; i >= 1; i--) 
		result = C(args[i], result);
	result = C(S_let, C(SCM_CONST_NIL, result));
	while (!SCM_IS_NULL(variables)) {
		scm_value * bind = C(C(SCM_CAR(variables), C(SCM_CAR(values), SCM_CONST_NIL)), SCM_CONST_NIL);
		result = C(S_let, C(bind, C(result, SCM_CONST_NIL)));
		variables = SCM_CDR(variables);
		values = SCM_CDR(values);
	}

	return result;
}

scm_value * letrec(SCM_ARGS)
{
	int i;
	if (count < 2) return ERR_MSG0("letrec", "syntax error - missing expression");
	scm_value * result = SCM_CONST_NIL;
	scm_value * variables = SCM_CONST_NIL;
	scm_value * values = SCM_CONST_NIL;
	scm_value * bindings = args[0];

	if (!is_list(bindings)) return ERR_MSG("let*", "syntax error - bad bindings", 0);
	while (!SCM_IS_NULL(bindings)) {
		scm_value * assoc = SCM_CAR(bindings);
		if (!is_list(assoc)) return ERR_MSG("let*", "syntax error - bad bindings", 0);
		if (list_length(assoc) != 2) return ERR_MSG("let*", "syntax error - bad bindings", 0);

		variables = C(SCM_CAR(assoc), variables);
		values = C(SCM_CADR(assoc), values);
		bindings = SCM_CDR(bindings);
	}


	for (i = count - 1; i >= 1; i--) 
		result = C(args[i], result);
	while (!SCM_IS_NULL(variables)) {
		scm_value * bind = C(S_define, C(SCM_CAR(variables), C(SCM_CAR(values), SCM_CONST_NIL)));
		result = C(bind, result);
		variables = SCM_CDR(variables);
		values = SCM_CDR(values);
	}
	result = C(C(S_lambda, C(SCM_CONST_NIL, result)), SCM_CONST_NIL);

	return result;
}

scm_value * __quasiquote(scm_value * arg, int level, int * is_splicing, scm_vm * vm)
{
	int flag;
	if (SCM_TYPE(arg) == PAIR) {
		if (SCM_TYPE(SCM_CAR(arg)) == SYMBOL) {
			if (SCM_SYMBOL_EQ(SCM_CAR(arg), S_unquote)) {
				if (level == 1) return SCM_CADR(arg);
				return mk_list3(S_cons,
						mk_list2(S_quote, S_unquote),
						__quasiquote(SCM_CDR(arg), level - 1, &flag, vm));
			}

			if (SCM_SYMBOL_EQ(SCM_CAR(arg), S_unquote_splicing)) {
				if (level == 1) {
					*is_splicing = 1;
					return SCM_CADR(arg);
				}
				return mk_list3(S_cons,
						mk_list2(S_quote, S_unquote_splicing),
						__quasiquote(SCM_CDR(arg), level - 1, &flag, vm));
			}

			if (SCM_SYMBOL_EQ(SCM_CAR(arg), S_quasiquote)) {
				return mk_list3(S_cons,
						mk_list2(S_quote, S_quasiquote),
						__quasiquote(SCM_CDR(arg), level + 1, &flag, vm));
			}
		}
		int flag1 = 0;
		int flag2 = 0;
		scm_value * car_part = __quasiquote(SCM_CAR(arg), level, &flag1, vm);
		scm_value * cdr_part = __quasiquote(SCM_CDR(arg), level, &flag2, vm);
		return mk_list3(flag1 ? scm_const_fn_append : scm_const_fn_cons,
				car_part,
				cdr_part);
	}

	if (SCM_TYPE(arg) == VECTOR) {
		scm_value * list = vector_to_list(1, &arg, vm);
		return mk_list2(scm_const_fn_list_to_vector,
				__quasiquote(list, level, &flag, vm));
	}
	return mk_list2(S_quote, arg);
}

scm_value * quasiquote(SCM_ARGS)
{
	int is_splicing;
	SCM_ASSERT_ARG_CNT_EQ(1, "quasiquote");
	scm_value * result = __quasiquote(args[0], 1, &is_splicing, vm);
	//printf("X%sX\n", format(result, 0));
        return result;
}

scm_value * and(SCM_ARGS)
{
	int i;
	scm_value * result = S_true;
	if (count == 0) return result;

	result = args[count - 1];
	for (i = count - 2; i >= 0; i--)
		result = mk_list4(S_if, args[i], result, S_false);
	return result;
}

scm_value * or(SCM_ARGS)
{
	int i;
	scm_value * result = S_false;
	for (i = count - 1; i >= 0; i--) {
		result = C(S_if, C(args[i], C(S_true, C(result, SCM_CONST_NIL))));
	}
	return result;
}

scm_value * min(SCM_ARGS)
{
	int i, result_float = 0;
	
	if (count < 1) return ERR_MSG0("min", "requires at least one argument");

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "min")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			if (result > scm_float_num(args[i])) result = scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = scm_int_num(args[0]);
		for (i = 1; i < count; i++)
			if (result > scm_int_num(args[i])) result = scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * max(SCM_ARGS)
{
	int i, result_float = 0;
	
	if (count < 1) return ERR_MSG0("max", "requires at least one argument");

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "max")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			if (result < scm_float_num(args[i])) result = scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = scm_int_num(args[0]);
		for (i = 1; i < count; i++)
			if (result < scm_int_num(args[i])) result = scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * member(SCM_ARGS)
{
	scm_value * nargs[2];
	scm_value * list = args[1];
#ifndef USE_STM
	if (!is_list(list)) return ERR_MSG("member", "the second argument must be a list", 1);

	nargs[0] = args[0];
	while (!SCM_IS_NULL(list)) {
		nargs[1] = SCM_CAR(list);
		if (SCM_BOOL(pred_equal(2, nargs, vm))) return list;
		list = SCM_CDR(list);
	}
	return SCM_CONST_FALSE;
#else
	if (!ts_is_list(vm, list)) return ERR_MSG("member", "the second argument must be a list", 1);

	nargs[0] = args[0];
	while (!SCM_IS_NULL(list)) {
		nargs[1] = TS_SCM_CAR(vm, list);
		if (SCM_BOOL(pred_equal(2, nargs, vm))) return list;
		list = TS_SCM_CDR(vm, list);
	}
	return SCM_CONST_FALSE;

#endif
}

scm_value * length(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "length");
#ifndef USE_STM
	if (!is_list(args[0])) return ERR_MSG("length", "argument must be a list", 0);
	return scm_value_new_int(list_length(args[0]));
#else
	if (!ts_is_list(vm, args[0])) return ERR_MSG("length", "argument must be a list", 0);
	return scm_value_new_int(ts_list_length(vm, args[0]));

#endif
}

scm_value * macro(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "macro");
	SCM_ASSERT_ARG_TYPE_EQ(LAMBDA, 0, "macro");

	scm_value * result = scm_value_new_lambda_clone(args[0]);
	result->type = MACRO;
	return result;
}

scm_value * display(SCM_ARGS)
{
	/* note: display doesn't need to be thread safe, since its called only from the top-level transaction,
	 * that has no entries in write-log*/
	SCM_ASSERT_ARG_CNT_EQ(1, "display");
	fprintf(stdout, "%s", format(args[0], 0));
	return SCM_CONST_VOID;
}

scm_value * newline(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(0, "newline");
	printf("\n");
	return SCM_CONST_VOID;
}

scm_value * setcar(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "set-car!");
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "set-car!");
#ifndef USE_STM
	SCM_PAIR(args[0]).ar = args[1];
#else
	tm_wlog_record_cons(vm, args[0], 0, args[1]);
#endif
	return args[0];
}

scm_value * setcdr(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "set-cdr!");
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "set-cdr!");
#ifndef USE_STM
	SCM_PAIR(args[0]).dr = args[1];
#else
	tm_wlog_record_cons(vm, args[0], 1, args[1]);
#endif

	return args[0];
}

scm_value * vector_set(SCM_ARGS) {
	SCM_ASSERT_ARG_CNT_EQ(3, "vector-set!");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-set!");
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "vector-set!");

        scm_value * vector = args[0];
	scm_value * k = args[1];
	scm_value * val = args[2];

	if ((SCM_INT(k) < 0) || (SCM_INT(k) >= SCM_VECTOR(vector)->size))
		return ERR_MSG("vector-set!", "index out of range", 1);
#ifndef USE_STM
	SCM_VECTOR(vector)->items[SCM_INT(k)] = val;
#else
	tm_wlog_record_vector(vm, vector, k, val);
#endif
	return vector;
}

scm_value * fn_sin(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "sin");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "sin");

	return scm_value_new_float(sin(scm_float_num(args[0])));
}

scm_value * fn_cos(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "cos");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "cos");

	return scm_value_new_float(cos(scm_float_num(args[0])));
}

scm_value * fn_sqrt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "sqrt");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "sqrt");
	if (scm_float_num(args[0]) < 0) return ERR_MSG("sqrt", "argument cannot be lesser than zero", 0);

	return scm_value_new_float(sqrt(scm_float_num(args[0])));
}

#define ROUND_FUNC(__scheme_fn_name, __scheme_str_name, __c_function) \
scm_value * __scheme_fn_name(SCM_ARGS) \
{  \
	SCM_ASSERT_ARG_CNT_EQ(1, __scheme_str_name); \
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "floor"); \
	if (SCM_TYPE(args[0]) == INT) return args[0]; \
	return scm_value_new_float(__c_function(scm_float_num(args[0]))); \
}

ROUND_FUNC(fn_floor, "floor", floor)
ROUND_FUNC(fn_ceiling, "ceiling", ceil)
ROUND_FUNC(fn_round, "round", round)
ROUND_FUNC(fn_trucate, "truncate", trunc)

scm_value * string_append(SCM_ARGS)
{
	int i;
	int length = 0;
	for (i = 0; i < count; i++) {
		if (SCM_TYPE(args[i]) != STRING) return ERR_MSG("string-append", "all arguments are expected to be a string", i);
		else length += strlen(SCM_STRING(args[i]));
	}
	char * result = GC_MALLOC_ATOMIC(length + 1);
	*result = '\0';
	for (i = 0; i < count; i++)
		strcat(result, SCM_STRING(args[i]));
	return scm_value_new_string(result);
}

scm_value * number_to_string(SCM_ARGS)
{
	if (count != 1) return ERR_MSG("number->string", "exactly one argument required; function does not support optional radix argument", 0); 
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "number->string");
	return scm_value_new_string(format(args[0], 0));
}

scm_value * object_to_string(SCM_ARGS)
{
	if (count != 1) return ERR_MSG("object->string", "exactly one argument required", 0); 
	return scm_value_new_string(format(args[0], 0));
}

scm_value * string_to_number(SCM_ARGS)
{
	if (count != 1) return ERR_MSG("string->number", "exactly one argument required; function does not support optional radix argument", 0); 
	SCM_ASSERT_ARG_TYPE_EQ(STRING, 0, "string->number");

	int is_float;
	char * input = SCM_STRING(args[0]);
	char * in = alloca(strlen(input + 1));

	strcpy(in, input);
	char * end = in + strlen(in);
	while (isspace(*end)) {
		*end = '\0';
		end--;
	}
	while (*in && isspace(*in)) in++;

	if (!is_number(in, &is_float)) return SCM_CONST_FALSE;
	if (is_float) return scm_value_new_float(strtod(in, NULL));
	else return scm_value_new_int(atoi(in));
}	

#define RETURN_STRING 	(1)
#define RETURN_LIST	(2)

pthread_mutex_t shell_lock;
// (ext:shell* <result-type> <program> [ <input> <arg-1> ... <arg-n> ])
scm_value * shell_call(SCM_ARGS)
{
	int readingpipe[2];
	int writingpipe[2];
	scm_value * input_items;
	scm_value * result = SCM_CONST_NIL;
	char * exec_args[count];
	char * exec_command;
	char * rstring;
	int result_type = 0;

	WARN_TRANS_UNSAFE("ext:shell*");
	rt_schedule_fevals(vm->runtime, vm); // FIXME: awful hack

	if (count < 2) return ERR_MSG0("ext:shell*", "requires at least two arguments");
	SCM_ASSERT_ARG_TYPE_EQ(STRING, 1, "ext:shell*");
	SCM_ASSERT_ARG_TYPE_EQ(SYMBOL, 0, "ext:shell*");

	if (count >= 3) input_items = args[2];
	else input_items = SCM_CONST_NIL;

	rstring = SCM_SYMBOL(args[0]);
	if (!strcasecmp(rstring, "string")) result_type = RETURN_STRING;
	if (!strcasecmp(rstring, "list")) result_type = RETURN_LIST;
	if (!result_type) return ERR_MSG0("ext:shell*", "the first argument has to be a symbol `LIST' or `STRING'");

	exec_command = SCM_STRING(args[1]);
	exec_args[0] = exec_command;

	int j = 1;
	exec_args[0] = SCM_STRING(args[0]);
	for (int i = 3; i < count; i++)
		exec_args[j++] = format(args[i], 0);
	exec_args[j] = NULL;

	mutex_lock(shell_lock);

	pipe(readingpipe);
	pipe(writingpipe);
	
	pid_t pid = vfork();
	if (pid < 0) return scm_value_new_error("shell: fork failed");
	if (pid == 0) {
		close(readingpipe[0]);
		close(writingpipe[1]);
		dup2(writingpipe[0], STDIN_FILENO);
		dup2(readingpipe[1], STDOUT_FILENO);

		if (count <= 2) execvp(exec_command, NULL);
		else execvp(exec_command, exec_args);
		exit(1);
	}
	close(readingpipe[1]);
	close(writingpipe[0]);
	
	FILE * fw = fdopen(writingpipe[1], "w");
	if (!fw) {
		fprintf(stderr, "write pipe error: %s\n", strerror(errno));
		goto error;
	}
	FILE * fr = fdopen(readingpipe[0], "r");
	mutex_unlock(shell_lock);
	if (!fr) {
		fprintf(stderr, "read pipe error: %s\n", strerror(errno));
		goto error;
	}

	if (!SCM_IS_NULL(input_items)) {
		if (is_list(input_items)) {
			while (!SCM_IS_NULL(input_items)) {
				fputs(format(SCM_CAR(input_items), 0), fw); 
				fputs("\n", fw);
				input_items = SCM_CDR(input_items);
			}
		} else fputs(format(input_items, 0), fw); 
	}
	fflush(fw);
	fclose(fw);

	if (result_type == RETURN_LIST) {
		result = freadstream_to_list(fr);
		if (result == NULL) result = SCM_CONST_NIL;
	}
	if (result_type == RETURN_STRING) {
		char * r = freadstream(fr); 
		if (r == NULL) result = scm_value_new_string("");
		else result = scm_value_new_string(r);
	}
	fclose(fr);
error:
	waitpid(pid, NULL, 0);
	return result;
}
