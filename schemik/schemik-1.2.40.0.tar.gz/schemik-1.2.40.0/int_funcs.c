/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Internal functions used across the implementation 
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#include <gc/gc.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <stdarg.h>

#include "int_funcs.h"
#include "types.h"
#include "lexer.h"

#ifdef USE_STM
#include "tm_log.c"
#endif

#define INITIAL_STR_SIZE	(100)
#define BUF_SIZE		(10)

char * gc_initstr(const char * str)
{
	char * result = GC_MALLOC_ATOMIC(INITIAL_STR_SIZE);
	result = strcpy(result, str);
	result[strlen(str) + 1] = '\0';
	return result;
}

char * gc_sprintf(const char * fmt, ...)
{
	int n, size = INITIAL_STR_SIZE;
	char *p;
	va_list ap;

	p = GC_MALLOC_ATOMIC(size * sizeof(char));

	while (1) {
		/* Try to print in the allocated space. */
		va_start(ap, fmt);
		n = vsnprintf(p, size, fmt, ap);
		va_end(ap);
		/* If that worked, return the string. */
		if (n > -1 && n < size) return p;
		/* Else try again with more space. */
		if (n > -1)  size = n + 1; /* glibc 2.1: precisely what is needed */
		else size *= 2;  /* glibc 2.0: twice the old size */
		p = GC_REALLOC(p, size);
	}
}

char * gc_concat(char * s1, char * s2)
{
	int size = strlen(s1) + strlen(s2) + 1;
	s1 = (char *)GC_REALLOC(s1, size * sizeof(char));
	strcat(s1, s2);
	return s1;
}

// XXX: this function is not used
scm_value * list_reverse(scm_value * list)
{
	scm_value * result = SCM_CONST_NIL;
	while (SCM_TYPE(list) != NIL) {
		result = scm_value_new_pair(SCM_CAR(list), result);
		list = SCM_CDR(list);
		
	}
	return result;
}

char * load_file(char * filename) 
{
	struct stat stats;
	char * result;
	FILE * f = fopen(filename, "r");

	if (f == NULL) return NULL;	
	stat(filename, &stats);
	result = (char *) GC_MALLOC_ATOMIC(stats.st_size + 1);
	fread(result, 1, stats.st_size, f);
	fclose(f);
	
	return result; 
}

int is_list(scm_value * val)
{
	if (SCM_TYPE(val) == NIL) return 1;
	if (SCM_TYPE(val) == PAIR) return is_list(SCM_CDR(val));
	return 0;
}

/*
int is_list(scm_value * val)
{
	if ((SCM_TYPE(val) != NIL) && (SCM_TYPE(val) != PAIR)) return 0;
	if (SCM_FLAGS(val) & SCM_IS_CONSTANT) return SCM_FLAGS(val) & SCM_IS_LIST;
	return __is_list(val);
}
*/
int list_length(scm_value * list)
{
	int result = 0;

	while (SCM_TYPE(list) == PAIR) {
		list = SCM_CDR(list);
		result++;
	}
	if (SCM_TYPE(list) != NIL) result = -1;

	return result;
}

static inline char * freadline(FILE * f)
{
	char buf[BUF_SIZE];
	char * line = NULL;
	if (!fgets(buf, BUF_SIZE, f)) return NULL;
	line = gc_initstr(buf);

	while (!(strchr(buf, '\n') || (strchr(buf, '\r')))) {
		if (!fgets(buf, BUF_SIZE, f)) continue;
		line = gc_concat(line, buf);
		if (feof(f)) break;
	}
	if (strchr(buf, '\n')) *(strchr(line, '\n')) = '\0';
	// FIXME: pokud je radek zalomeny \r dela to paseku
	if (strchr(buf, '\r')) *(strchr(line, '\r')) = ' ';
	return line;
}

char * freadstream(FILE * f)
{
	char buf[BUF_SIZE];
	char * line = NULL;
	if (!fgets(buf, BUF_SIZE, f)) return NULL;
	line = gc_initstr(buf);

	while (!feof(f)) {
		if (!fgets(buf, BUF_SIZE, f)) continue;
		line = gc_concat(line, buf);
	}
	return line;
}

scm_value * freadstream_to_list(FILE * f)
{
	scm_value * result_head = scm_value_new_pair(SCM_CONST_NIL, SCM_CONST_NIL);
	scm_value * result_tail = result_head;
	while (!feof(f)) {
		char * line = freadline(f);
		if (!line) continue;

		scm_value * x = scm_value_new_pair(scm_value_new_string(line), SCM_CONST_NIL);
		SCM_CDR(result_tail) = x;
		result_tail = x;
	}
	return SCM_CDR(result_head);
}

char * ordinal_str(int i) {
	char * suffix = "th";
	if ((i / 10) != 1) { // solves the issue of 11th, 12th, etc.
		if (i % 10 == 1) suffix = "st";
		if (i % 10 == 2) suffix = "nd";
		if (i % 10 == 3) suffix = "rd";
	}
	return gc_sprintf("%i%s", i, suffix);
}

#ifdef USE_STM
int ts_is_list(struct scm_vm * vm, scm_value * val)
{
	if (SCM_TYPE(val) == NIL) return 1;
	if (SCM_TYPE(val) == PAIR) return ts_is_list(vm, TS_SCM_CDR(vm, val));
	return 0;
}

int ts_list_length(scm_vm * vm, scm_value * list)
{
	int result = 0;

	while (SCM_TYPE(list) != NIL) {
		list = TS_SCM_CDR(vm, list);
		result++;
	}

	return result;
}
#endif

#define CASE_GENERIC_FORMAT_0(type,value) \
	case type: return gc_sprintf("%s", value);

#define CASE_GENERIC_FORMAT_EX(type,normal_format,debug_format,value) \
	case type: return gc_sprintf((debug ? debug_format : normal_format), value);

#define CASE_GENERIC_FORMAT_FN(type,name,val) \
	case type: return gc_sprintf("#<%s %s>", name, format(val->value.lambda->arg_list, 0));

static char * format_list(scm_value * list) 
{
#ifdef CONTRACT_QUOTATIONS
	if (list_length(list) && (SCM_TYPE(SCM_CAR(list)) == SYMBOL)) {
		if (SCM_SYMBOL_EQ(SCM_CAR(list), S_quote))
			return gc_sprintf("'%s", format(SCM_CADR(list), 0));
		if (SCM_SYMBOL_EQ(SCM_CAR(list), S_unquote))
			return gc_sprintf(",%s", format(SCM_CADR(list), 0));
		if (SCM_SYMBOL_EQ(SCM_CAR(list), S_quasiquote))
			return gc_sprintf("`%s", format(SCM_CADR(list), 0));
		if (SCM_SYMBOL_EQ(SCM_CAR(list), S_unquote_splicing))
			return gc_sprintf(",@%s", format(SCM_CADR(list), 0));
	}
#endif
	char * result = gc_initstr("(");
	while (SCM_TYPE(list) != NIL) {
		result = gc_concat(result, format(SCM_CAR(list), 0));
		list = SCM_CDR(list);
		if (SCM_TYPE(list) != NIL) result = gc_concat(result, " ");
	}
	result = gc_concat(result, ")");
	return result;
}

static char * format_vector(scm_value * val, int debug) 
{
	int i;
	char * result = gc_initstr(debug ? "#<vector (" : "#(");
	for (i = 0; i < SCM_VECTOR(val)->size; i++) {
		result = gc_concat(result, format(SCM_VECTOR(val)->items[i], debug));
		if (i < (SCM_VECTOR(val)->size - 1)) result = gc_concat(result, " ");
	}
	return gc_concat(result, ")");
}

char * format(scm_value * val, int debug)
{
	if (!debug && (is_list(val))) return format_list(val);
	switch (SCM_TYPE(val)) {
		CASE_GENERIC_FORMAT_FN(LAMBDA, "lambda", val);
		CASE_GENERIC_FORMAT_FN(MACRO, "macro", val);
		CASE_GENERIC_FORMAT_EX(SYMBOL, "%s", "#<symbol (%s)>", SCM_SYMBOL(val))
		CASE_GENERIC_FORMAT_EX(INT, "%i", "#<int (%i)>", SCM_INT(val))
		CASE_GENERIC_FORMAT_EX(FLOAT, "%f", "#<float (%f)>", SCM_FLOAT(val))
		CASE_GENERIC_FORMAT_EX(BOOL, "%s", "#<bool (%s)>", SCM_BOOL(val) ? "#t" : "#f")
		CASE_GENERIC_FORMAT_EX(ERROR, "%s", "#<error (%s)>", SCM_ERROR(val))
		CASE_GENERIC_FORMAT_EX(STRING, "%s", "#<string (\"%s\")>", SCM_STRING(val))
		CASE_GENERIC_FORMAT_0(FUNC, "#<func>")
		CASE_GENERIC_FORMAT_0(SPEC_FORM, "#<spec>")
		CASE_GENERIC_FORMAT_0(VOID, "#<void>")
		CASE_GENERIC_FORMAT_0(NIL, "()")
		CASE_GENERIC_FORMAT_0(CONTINUATION, "#<continuation>")
		case PAIR: return gc_sprintf("(%s . %s)", format(SCM_CAR(val), debug), format(SCM_CDR(val), debug));
		case VECTOR: return format_vector(val, debug);
		default: return "";
	}
}

int is_number(char * input, int *is_float) 
{
	struct lexer * lex = lexer_new(input);
	struct token * t = lexer_next0(lex);
	if (t->tok_id == T_WHITE_SPACE) t = lexer_next0(lex);
	if ((t->tok_id != T_NUMBER) && (t->tok_id != T_FLOAT_NUMBER)) return 0;
	if (t->tok_id == T_NUMBER) *is_float = 0;
	if (t->tok_id == T_FLOAT_NUMBER) *is_float = 1;
	t = lexer_next0(lex);
	if (t == NULL) return 1;
	if (((t->tok_id == T_WHITE_SPACE)) && (!lexer_next0(lex))) return 1;
	return 0;
}
