#include <gc/gc.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "types.h"
#include "lexer.h"
#include "int_funcs.h"
#include "eval.h"

#define NT_SYMBOL	(10001)
#define NT_SYMBOLS	(10002)

struct parser {
	struct lexer * lex;
	struct token * stack;
} parser;

static int shift(struct parser * p)
{
	struct token * t = lexer_next(p->lex);
	if (!t) return 0;
	t->next = p->stack;
	p->stack = t;
	return 1;
}

static inline struct token * new_nonterminal(int tok_id, scm_value * value, int line)
{
	struct token * t = GC_MALLOC(sizeof(struct token));
	t->tok_id = tok_id;
	t->parsed = value;
	t->line = line;
	return t;
}

static inline scm_value * make_quotation(char * keyword, scm_value * value, int line)
{
	return scm_value_set_line(C(S(keyword), C(value, SCM_CONST_NIL)), line);
}

#define MATCH (int [])
#define RETURN 	/* syntactical sugar */
#define OF_TYPE	/* syntactical sugar */
#define LINE	(tokens[0]->line)
#define P(x)	(tokens[x]->parsed)
#define T(x)	(tokens[x]->text)

#define RULE(condition, transformation, type) \
{ \
	int * rules = condition; \
	int rules_size = sizeof(condition) / sizeof(int); \
	int match = 1; \
	struct token * stack = p->stack; \
	struct token * tokens[rules_size];\
	for (int i = 0; i < rules_size; i++) { \
		if ((stack == NULL) || (stack->tok_id != rules[rules_size - i - 1])) { \
			match = 0;\
			break;\
		}	\
		tokens[rules_size - i - 1] = stack; \
		stack = stack->next;\
	}\
	if (match) { \
		scm_value * trans = transformation; \
		if (trans) { \
			struct token * t = new_nonterminal(type, trans, tokens[0]->line); \
			t->next = stack; \
			p->stack = t; \
			return 1; \
		} \
	}\
}
static int reduce(struct parser * p)
{
	if (!p->stack) return 0;

	RULE((MATCH { NT_SYMBOL, T_DOT, NT_SYMBOL }),
 	     (RETURN scm_value_set_line(scm_value_new_pair(P(0), P(2)), LINE)),
	     (OF_TYPE NT_SYMBOLS))

	RULE((MATCH { T_VECTOR, T_LEFT_PAREN, NT_SYMBOLS, T_RIGHT_PAREN }),
	     (RETURN scm_value_new_vector_from_list(P(2))),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_LEFT_PAREN, NT_SYMBOLS, T_RIGHT_PAREN }),
 	     (RETURN P(1)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { NT_SYMBOL, NT_SYMBOLS }),
 	     (RETURN scm_value_set_line(scm_value_new_pair(P(0), P(1)), LINE)),
	     (OF_TYPE NT_SYMBOLS))

	RULE((MATCH { T_LEFT_PAREN, T_RIGHT_PAREN }),
 	     (RETURN SCM_CONST_NIL),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_QUOTE, NT_SYMBOL }),
	     (RETURN make_quotation("quote", P(1), LINE)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_QUASIQUOTE, NT_SYMBOL }),
	     (RETURN make_quotation("quasiquote", P(1), LINE)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_UNQUOTE, NT_SYMBOL }),
	     (RETURN make_quotation("unquote", P(1), LINE)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_UNQUOTE_SPLICING, NT_SYMBOL }),
	     (RETURN make_quotation("unquote-splicing", P(1), LINE)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_FALSE }),
	     (RETURN SCM_CONST_FALSE),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_TRUE }),
	     (RETURN SCM_CONST_TRUE),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_SYMBOL }),
	     (RETURN scm_value_set_line(scm_value_new_symbol(T(0)), LINE)),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_NUMBER }),
	     (RETURN scm_value_new_int(atoi(T(0)))),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_FLOAT_NUMBER }),
	     (RETURN scm_value_new_float(atof(T(0)))),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { T_STRING }),
	     (RETURN scm_value_new_string(T(0))),
	     (OF_TYPE NT_SYMBOL))

	RULE((MATCH { NT_SYMBOL }),
	     (RETURN (((lexer_top(p->lex) == NULL) || (lexer_top(p->lex)->tok_id == T_RIGHT_PAREN))
			? scm_value_set_line(scm_value_new_pair(P(0), SCM_CONST_NIL), LINE)
			: NULL)),
	     (OF_TYPE NT_SYMBOLS))

	return 0;
}

static int check_simple_lists(scm_value * val);

static scm_value * parser_error(char * str)
{
	return scm_value_new_pair(scm_value_new_error(gc_sprintf("parser error: %s", str)), SCM_CONST_NIL);
}

scm_value * parse_input(char * input)
{
	int i;
	char * check_par = check_parentheses(input, &i);
	if (check_par) return parser_error(check_par);

	struct parser p;
	p.stack = NULL;
	p.lex = lexer_new(input);
	while (1) {
		if (!shift(&p)) break;
		while (reduce(&p));
	}
	while (reduce(&p));
	if (!p.stack) return SCM_CONST_NIL;
	if (p.stack->tok_id != NT_SYMBOLS) return parser_error("generic syntax horror");
	scm_value * result = p.stack->parsed;
	check_simple_lists(result);
	return result;
}

/* returns error message if parentheses do not match, othwerwise NULL */
char * check_parentheses(char * expr, int * status)
{
	int count = 0;
	int line = 0;
	struct lexer * lex = lexer_new(expr);
	while (1) {
		struct token * t = lexer_next(lex);
		if (!t) break;
		line = t->line;
		if (t->tok_id == T_LEFT_PAREN) count++;
		if (t->tok_id == T_RIGHT_PAREN) count--;
		if (count < 0) break;
		if (t->tok_id == T_ERROR) {
			*status = 0;
			return t->text;
		}
	}

	*status = count;
	if (count < 0) return gc_sprintf("unmatched right parenthesis at line %i", line + 1);
	if (count > 0) return gc_sprintf("unmatched left parenthesis at line %i", line + 1);

	return NULL;
}

static int check_simple_lists(scm_value * val)
{
	if (SCM_TYPE(val) == NIL) return 1;
	if (SCM_TYPE(val) == PAIR) {
		if (SCM_TYPE(SCM_CAR(val)) == PAIR) {
			check_simple_lists(SCM_CAR(val));
			check_simple_lists(SCM_CDR(val));
		} else {
			if (check_simple_lists(SCM_CDR(val))) {
				SCM_FLAGS(val) |= SCM_SIMPLE_LIST;
				return 1;
			}
		}
	}
	return 0;
}
