/**
 * This code is based on tutorial provided by GNU Readline Manual.
 *
 * http://tiswww.case.edu/php/chet/readline/readline.html
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

#include <gc/gc.h>

/* Contains all words worth completing */
char ** readline_words;


char *word_generator (const char *, int);

/* Attempt to complete on the contents of TEXT.  START and END
 * bound the region of rl_line_buffer that contains the word to
 * complete.  TEXT is the word to complete.  We can use the entire
 * contents of rl_line_buffer in case we want to do some simple
 * parsing.  Returnthe array of matches, or NULL if there aren't any. */
char ** word_completion (const char *text, int start, int end)
{
	if (start == 0) return rl_completion_matches (text, word_generator);
	return NULL;
}

/* Generator function for word completion.  STATE lets us
 * know whether to start from scratch; without any state
 * (i.e. STATE == 0), then we start at the top of the list. */
char * word_generator (const char * text, int state)
{
	static int list_index, len;
	char *word;

	/* If this is a new word to complete, initialize now.  This
	 * includes saving the length of TEXT for efficiency, and
	 * initializing the index variable to 0. */
	if (!state)
	{
		list_index = 0;
		len = strlen (text);
	}

	/* Return the next word which partially matches from the
	 * word list. */
	while ((word = readline_words[list_index]) != NULL)
	{
		list_index++;
		if (strncmp (word, text, len) == 0) {
			char * result = malloc(strlen(word) + 1);
			strcpy(result, word);
			return result;
		}
	}

	/* If no words matched, then return NULL. */
	return ((char *)NULL);
}

/* CAUTION: this function is not thread safe */
char * readline_wrapper(char * prompt, char ** words) 
{
	char * line;
	char * result;

	readline_words = words;

	rl_readline_name = "schemik";
	rl_basic_word_break_characters = "()[],#`@ \n\t";
	rl_attempted_completion_function = word_completion;
	rl_completion_entry_function = word_generator;

	line = readline (prompt);

	if (!line) return NULL;
	if (*line) add_history (line);

	result = GC_MALLOC(sizeof(char) * (strlen(line) + 2));
	strcpy(result, line);
	strcat(result, "\n");
	free (line);
	return result;
}
