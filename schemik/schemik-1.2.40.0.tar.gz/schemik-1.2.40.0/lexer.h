#ifndef LEXER_H
#define LEXER_H

#define T_WHITE_SPACE		0
#define T_SYMBOL		1
#define T_LEFT_PAREN		2
#define T_RIGHT_PAREN		3
#define T_DOT			4
#define T_NUMBER		5
#define T_FLOAT_NUMBER		6
#define T_STRING		7
#define T_QUOTE			100
#define T_UNQUOTE		101
#define T_QUASIQUOTE		102
#define T_UNQUOTE_SPLICING	103
#define T_TRUE			104
#define T_FALSE			105
#define T_VECTOR		106
#define	T_COMMENT		107
#define T_ERROR			1000

struct scm_value;

struct token {
	unsigned int tok_id;
	char * text;
	struct token * next;
	struct scm_value * parsed;
	int line;
};

struct lexer {
	char * input;
	unsigned int input_length;
	unsigned int position;
	struct token * top;
	int cur_line;
};

struct lexer * lexer_new(char * input);
struct token * lexer_next(struct lexer * lex);
struct token * lexer_next0(struct lexer * lex);
struct token * lexer_top(struct lexer * lex);
#endif
