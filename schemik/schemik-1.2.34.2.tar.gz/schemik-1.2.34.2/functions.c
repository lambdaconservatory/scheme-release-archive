/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Definition of internal functions and macros
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#include "config.h"

#include <gc/gc.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>

#include "types.h"
#include "functions.h"
#include "int_funcs.h"


unsigned int gensym_last = 0;
pthread_mutex_t gensym_lock = PTHREAD_MUTEX_INITIALIZER;

#define SCM_ASSERT_ARG_CNT_EQ(__cnt,__fn_name) \
	if (count != __cnt) return scm_value_new_error(gc_sprintf("%s: requires %i argument(s)\n", __fn_name, __cnt));

#define SCM_ASSERT_ARG_TYPE_EQ(__type,__position,__fn_name) \
	if (SCM_TYPE(args[__position]) != __type) \
		return scm_value_new_error(gc_sprintf("%s: argument of type '%s' required at %i position\n", __fn_name, #__type, __position + 1));

#define SCM_ASSERT_ARG_TYPE_NUMBER(__position,__fn_name) \
	if ((SCM_TYPE(args[__position]) != INT) && (SCM_TYPE(args[__position]) != FLOAT)) \
		return scm_value_new_error(gc_sprintf("%s: argument of type 'number' required at position %i\n", __fn_name, __position + 1));

#define scm_float_num(x) (SCM_TYPE(x) == INT ? (double)SCM_INT(x) : SCM_FLOAT(x))
#define scm_int_num(x) (SCM_TYPE(x) == INT ? SCM_INT(x) : (int)SCM_FLOAT(x))

scm_value * plus(SCM_ARGS)
{
	int i, result_float = 0;
	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "plus")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = 0;
		for (i = 0; i < count; i++) 
			result += scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else { 
		int result = 0;
		for (i = 0; i < count; i++)
			result += scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * minus(SCM_ARGS)
{
	int i, result_float = 0;
	if (count == 0) return scm_value_new_int(0);
	if (count == 1) {
		SCM_ASSERT_ARG_TYPE_NUMBER(0, "minus")
		if (SCM_TYPE(args[0]) == INT) return scm_value_new_int(- SCM_INT(args[0]));
		if (SCM_TYPE(args[0]) == FLOAT) return scm_value_new_float(- SCM_FLOAT(args[0]));
	}

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "minus")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			result -= scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		//int result = scm_int_num(args[0]);
		int result = SCM_INT(args[0]);
		for (i = 1; i < count; i++) 
			result -= SCM_INT(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * multiply(SCM_ARGS)
{
	int i, result_float = 0;
	result_float = 0;
	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "multiply")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = 1;
		for (i = 0; i < count; i++) 
			result *= scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = 1;
		for (i = 0; i < count; i++) 
			result *= scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * divide(SCM_ARGS)
{
	int i, result_float;
	result_float = 0;
	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "divide")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
		if ((SCM_TYPE(args[i]) == INT) && (scm_int_num(args[i]) == 0) && (i > 0)) return scm_value_new_error("Division by zero"); 
		if ((SCM_TYPE(args[i]) == FLOAT) && (scm_float_num(args[i]) == 0) && (i > 0)) return scm_value_new_error("Division by zero"); 
	}
	if (count == 1) {
		if ((SCM_TYPE(args[0]) == INT) && (scm_int_num(args[0]) == 0)) return scm_value_new_error("Division by zero"); 
		if ((SCM_TYPE(args[0]) == FLOAT) && (scm_float_num(args[0]) == 0)) return scm_value_new_error("Division by zero"); 
		if ((SCM_TYPE(args[0]) == INT) && (scm_int_num(args[0]) == 1)) return scm_value_new_int(1); 
		return scm_value_new_float(1 / scm_float_num(args[0]));
	}

	/* return floats at all situations */
	double result = scm_float_num(args[0]);
	for (i = 1; i < count; i++) 
		result /= scm_float_num(args[i]);
	return scm_value_new_float(result);
}

scm_value * quotient(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "quotient")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "quotient")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "quotient")
	
	return scm_value_new_int(SCM_INT(args[0]) / SCM_INT(args[1]));
}

scm_value * modulo(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "modulo")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "modulo")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "modulo")
	
	return scm_value_new_int(SCM_INT(args[0]) % SCM_INT(args[1]));
}

scm_value * pred_eqref(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_eqref")
	if (args[0] == args[1]) return SCM_CONST_TRUE;
	return SCM_CONST_FALSE;
}

scm_value * pred_eq(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_eq")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_eq");
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_eq");

	return pred_equal(count, args);
}

scm_value * pred_equal(SCM_ARGS)
{
	scm_value * a1;
	scm_value * a2;

	SCM_ASSERT_ARG_CNT_EQ(2, "pred_equal")
	
	a1 = args[0];
	a2 = args[1];
	if ((SCM_TYPE(a1) == FLOAT) || (SCM_TYPE(a2) == FLOAT))
		return (scm_float_num(a1) == scm_float_num(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
	if (SCM_TYPE(a1) != SCM_TYPE(a2)) return SCM_CONST_FALSE;
	switch (SCM_TYPE(a1)) {
		case INT: return (SCM_INT(a1) == SCM_INT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case SYMBOL: return (SCM_SYMBOL_EQ(a1, a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case BOOL: return (SCM_BOOL(a1) == SCM_BOOL(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case STRING: return (strcmp(SCM_STRING(a1), SCM_STRING(a2)) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
		case NIL: return SCM_CONST_TRUE;
		case PAIR:
			  {
				  scm_value * nargs[4];
				  scm_value * v1;
				  scm_value * v2;

				  nargs[0] = SCM_CAR(args[0]);
				  nargs[1] = SCM_CAR(args[1]);
				  nargs[2] = SCM_CDR(args[0]);
				  nargs[3] = SCM_CDR(args[1]);

				  v1 = pred_equal(2, nargs);
				  v2 = pred_equal(2, nargs + 2);

				  if (SCM_BOOL(v1) && SCM_BOOL(v2)) return SCM_CONST_TRUE;
				  return SCM_CONST_FALSE;
			  }
		case VECTOR: 
			  {
				  if (SCM_VECTOR(args[0])->size != SCM_VECTOR(args[1])->size) return SCM_CONST_FALSE;
				  scm_value * nargs[2];
				  int i;
				  for (i = 0; i < SCM_VECTOR(args[0])->size; i++) {
					  nargs[0] = SCM_VECTOR(args[0])->items[i];
					  nargs[1] = SCM_VECTOR(args[1])->items[i];
					  scm_value * v = pred_equal(2, nargs);
					  if (!SCM_BOOL(v)) return SCM_CONST_FALSE;
				  }
				  return SCM_CONST_TRUE;
			  }
	}
	return (a1 == a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_eqv(SCM_ARGS)
{
	scm_value * a1;
	scm_value * a2;

	SCM_ASSERT_ARG_CNT_EQ(2, "pred_equal")
	
	a1 = args[0];
	a2 = args[1];
	if (SCM_TYPE(a1) != SCM_TYPE(a2)) return SCM_CONST_FALSE;
	switch (SCM_TYPE(a1)) {
		case INT: return (SCM_INT(a1) == SCM_INT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case FLOAT: return (SCM_FLOAT(a1) == SCM_FLOAT(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case SYMBOL: return (SCM_SYMBOL_EQ(a1, a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case BOOL: return (SCM_BOOL(a1) == SCM_BOOL(a2) ? SCM_CONST_TRUE : SCM_CONST_FALSE);
		case NIL: return SCM_CONST_TRUE;
	}
	return (a1 == a2 ? SCM_CONST_TRUE : SCM_CONST_FALSE);
}


scm_value * pred_lt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_lt")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_lt")
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_lt")
	
	if ((SCM_TYPE(args[0]) == FLOAT) || (SCM_TYPE(args[1]) == FLOAT)) {
		if (scm_float_num(args[0]) < scm_float_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	} else {
		if (scm_int_num(args[0]) < scm_int_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	}
}

scm_value * pred_gt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "pred_gt")
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "pred_gt")
	SCM_ASSERT_ARG_TYPE_NUMBER(1, "pred_gt")

	if ((SCM_TYPE(args[0]) == FLOAT) || (SCM_TYPE(args[1]) == FLOAT)) {
		if (scm_float_num(args[0]) > scm_float_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	} else {
		if (scm_int_num(args[0]) > scm_int_num(args[1])) return SCM_CONST_TRUE;
		return SCM_CONST_FALSE;
	}
}

#define TYPE_PREDICATE(fun_name,pred_type)	\
scm_value * fun_name(SCM_ARGS)	\
{	\
	SCM_ASSERT_ARG_CNT_EQ(1, #fun_name)	\
	if (SCM_TYPE(args[0]) == pred_type) return SCM_CONST_TRUE;	\
	else return SCM_CONST_FALSE;	\
}

TYPE_PREDICATE(pred_symbol, SYMBOL)
TYPE_PREDICATE(pred_boolean, BOOL)
TYPE_PREDICATE(pred_macro, MACRO)
TYPE_PREDICATE(pred_pair, PAIR)
TYPE_PREDICATE(pred_int, INT)
TYPE_PREDICATE(pred_float, FLOAT)
TYPE_PREDICATE(pred_vector, VECTOR)
TYPE_PREDICATE(pred_string, STRING)

scm_value * pred_procedure(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_procedure")
	return ((SCM_TYPE(args[0]) == LAMBDA) || (SCM_TYPE(args[0]) == FUNC)) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_number(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_number")
	return ((SCM_TYPE(args[0]) == INT) || (SCM_TYPE(args[0]) == FLOAT)) ? SCM_CONST_TRUE : SCM_CONST_FALSE;
}

scm_value * pred_list(SCM_ARGS)
{
	scm_value * arg;
	SCM_ASSERT_ARG_CNT_EQ(1, "pred_list")
	arg = args[0];
	while (1) {
		if (SCM_TYPE(arg) == NIL) return SCM_CONST_TRUE;
		if (SCM_TYPE(arg) == PAIR) arg = SCM_CDR(arg);
		else return SCM_CONST_FALSE;
	}
}

scm_value * display_dbg(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "display_value_dbg");
	printf("%s\n", format(args[0], 1));
	return SCM_CONST_VOID;
}

scm_value * list(SCM_ARGS)
{
	if (count == 0) return SCM_CONST_NIL;
	return scm_value_new_pair(args[0], list(count - 1, args + 1));
}

scm_value * reverse(SCM_ARGS)
{
	scm_value * l;
	scm_value * result = SCM_CONST_NIL;
	SCM_ASSERT_ARG_CNT_EQ(1, "reverse");
	l = args[0];
	while (SCM_TYPE(l) == PAIR) {
		result = scm_value_new_pair(SCM_CAR(l), result);
		l = SCM_CDR(l);
	}
	if (SCM_TYPE(l) == NIL) return result;
	return scm_value_new_error("reverse: requires list as an argument");
}

scm_value * is_null(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "is_null")

	if (SCM_TYPE(args[0]) == NIL) return SCM_CONST_TRUE;
	return SCM_CONST_FALSE;
}

scm_value * car(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "car")
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "car");
	
	return SCM_CAR(args[0]);
}

scm_value * cdr(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "cdr")
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "cdr");
	
	return SCM_CDR(args[0]);
}

scm_value * cons(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "cons")
	return scm_value_new_pair(args[0], args[1]);
}

scm_value * not(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "not")
	scm_value * result = SCM_CONST_FALSE;
	scm_value * val = args[0];
	if (SCM_TYPE(val) == BOOL) result = (SCM_BOOL(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
	if (SCM_TYPE(val) == INT) result = (SCM_INT(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
	if (SCM_TYPE(val) == FLOAT) result = (SCM_FLOAT(val) ? SCM_CONST_FALSE : SCM_CONST_TRUE);
	if (SCM_TYPE(val) == NIL) result = SCM_CONST_FALSE;

	return result;
}

scm_value * sleep_func(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "usleep")
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "usleep");

	usleep(SCM_INT(args[0]));

	return SCM_CONST_VOID;
}

scm_value * gensym(SCM_ARGS)
{
	unsigned int iid;
	char * id = (char *) GC_MALLOC(1024);
	
	SCM_ASSERT_ARG_CNT_EQ(0, "gensym");

	pthread_mutex_lock(&gensym_lock);
	iid = gensym_last++;
	pthread_mutex_unlock(&gensym_lock);

	//sprintf(id, "#;g %i#", iid);
	sprintf(id, "__gensym__%i", iid);
	return scm_value_new_symbol(id);
}

static scm_value * append_lists(scm_value * src, scm_value * dst) {
	if (SCM_IS_NULL(src)) return dst;
	return scm_value_new_pair(SCM_CAR(src), append_lists(SCM_CDR(src), dst));
}

scm_value * append(SCM_ARGS)
{
	int i;
	if (count == 0) return SCM_CONST_NIL;
	if (count == 1) return args[0];

	for (i = 0; i < count; i++) {
		if (!is_list(args[i])) {
			return scm_value_new_error("append: all arguments must be lists");
		}
	}
	scm_value * result = args[count - 1];
	for (i = count - 2; i >= 0; i--) {
		result = append_lists(args[i], result);
	}
	
	return result;
}

scm_value * vector(SCM_ARGS)
{
	int i;
	scm_value * result = scm_value_new_vector(count, SCM_CONST_NIL);
	for (i = 0; i < count; i++)
		SCM_VECTOR(result)->items[i] = args[i];
	return result;
}

scm_value * make_vector(SCM_ARGS)
{
	scm_value * val;
	SCM_ASSERT_ARG_TYPE_EQ(INT, 0, "make-vector");
	if ((count != 1) && (count != 2)) return scm_value_new_error("make-vector: requires two or three arguments");
	val = (count == 2 ? args[1] : SCM_CONST_FALSE);
	return scm_value_new_vector(SCM_INT(args[0]), val);
}

scm_value * vector_ref(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "vector-ref");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-ref");
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "vector-ref");

	scm_vector * vector = SCM_VECTOR(args[0]);
	if (SCM_INT(args[1]) >= vector->size) return scm_value_new_error("vector-ref: index out of range");
	if (SCM_INT(args[1]) < 0) return scm_value_new_error("vector-ref: index out of range");
	return vector->items[SCM_INT(args[1])];
}

scm_value * vector_length(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "vector-length");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-length");

	return scm_value_new_int(SCM_VECTOR(args[0])->size);
}

scm_value * list_to_vector(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "list->vector");
	if (!is_list(args[0])) return scm_value_new_error("list->vector: arguments must be lists");
	return scm_value_new_vector_from_list(args[0]);
}

scm_value * vector_to_list(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "vector->list");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector->list");
	int i;
	scm_vector * vector = SCM_VECTOR(args[0]);
	scm_value * result = SCM_CONST_NIL;
	for (i = vector->size - 1; i >= 0; i--)
		result = scm_value_new_pair(vector->items[i], result);
	return result;
}

scm_value * begin(SCM_ARGS)
{
	int i;
	scm_value * result = SCM_CONST_NIL;
	for (i = count - 1; i >= 0; i--)
		result = C(args[i], result);

	result = C(S_lambda, C(SCM_CONST_NIL, result));
	result = C(result, SCM_CONST_NIL);
	return result;
}

scm_value * let_star(SCM_ARGS)
{
	int i;
	if (count < 2) return scm_value_new_error("let*: syntax error - missing expression");
	scm_value * result = SCM_CONST_NIL;
	scm_value * variables = SCM_CONST_NIL;
	scm_value * values = SCM_CONST_NIL;
	scm_value * bindings = args[0];

	if (!is_list(bindings)) return scm_value_new_error("let*: syntax error - bad bindings");
	while (!SCM_IS_NULL(bindings)) {
		scm_value * assoc = SCM_CAR(bindings);
		if (!is_list(assoc)) return scm_value_new_error("let*: syntax error - bad binding");
		if (list_length(assoc) != 2) return scm_value_new_error("let*: syntax error - bad binding");

		variables = C(SCM_CAR(assoc), variables);
		values = C(SCM_CADR(assoc), values);
		bindings = SCM_CDR(bindings);
	}


	for (i = count - 1; i >= 1; i--) 
		result = C(args[i], result);
	result = C(S_let, C(SCM_CONST_NIL, result));
	while (!SCM_IS_NULL(variables)) {
		scm_value * bind = C(C(SCM_CAR(variables), C(SCM_CAR(values), SCM_CONST_NIL)), SCM_CONST_NIL);
		result = C(S_let, C(bind, C(result, SCM_CONST_NIL)));
		variables = SCM_CDR(variables);
		values = SCM_CDR(values);
	}

	return result;
}

scm_value * letrec(SCM_ARGS)
{
	int i;
	if (count < 2) return scm_value_new_error("letrec: syntax error - missing expression");
	scm_value * result = SCM_CONST_NIL;
	scm_value * variables = SCM_CONST_NIL;
	scm_value * values = SCM_CONST_NIL;
	scm_value * bindings = args[0];

	if (!is_list(bindings)) return scm_value_new_error("letrec: syntax error - bad bindings");
	while (!SCM_IS_NULL(bindings)) {
		scm_value * assoc = SCM_CAR(bindings);
		if (!is_list(assoc)) return scm_value_new_error("letrec: syntax error - bad binding");
		if (list_length(assoc) != 2) return scm_value_new_error("letrec: syntax error - bad binding");

		variables = C(SCM_CAR(assoc), variables);
		values = C(SCM_CADR(assoc), values);
		bindings = SCM_CDR(bindings);
	}


	for (i = count - 1; i >= 1; i--) 
		result = C(args[i], result);
	while (!SCM_IS_NULL(variables)) {
		scm_value * bind = C(S_define, C(SCM_CAR(variables), C(SCM_CAR(values), SCM_CONST_NIL)));
		result = C(bind, result);
		variables = SCM_CDR(variables);
		values = SCM_CDR(values);
	}
	result = C(C(S_lambda, C(SCM_CONST_NIL, result)), SCM_CONST_NIL);

	return result;
}


#define __QUOTE_SYMBOL(arg) (C(S_quote, C(arg, SCM_CONST_NIL)))
//#define __QUOTE_JOIN(op,arg1,arg2) (C(S(op), C(arg1, C(arg2, SCM_CONST_NIL))))
#define __QUOTE_JOIN(op,arg1,arg2) (C(op, C(arg1, C(arg2, SCM_CONST_NIL))))

scm_value * __quasiquote(scm_value * arg)
{
	scm_value * result = NULL;
	int is_vector = 0;

	if (SCM_TYPE(arg) == VECTOR) {
		arg = vector_to_list(1, &arg);
		is_vector = 1;
	}
	if (SCM_TYPE(arg) == PAIR) {
		if (SCM_TYPE(SCM_CAR(arg)) == PAIR) {
			scm_value * sublist = SCM_CAAR(arg);
			if (SCM_TYPE(sublist) == SYMBOL) {
				if (SCM_SYMBOL_EQ(scm_const_symbol_unquote, sublist))
					result = __QUOTE_JOIN(scm_const_symbol_cons, 
								SCM_CADAR(arg), 
								__quasiquote(SCM_CDR(arg)));
				else if (SCM_SYMBOL_EQ(scm_const_symbol_unquote_splicing, sublist))
					result = __QUOTE_JOIN(scm_const_symbol_append, 
								SCM_CADAR(arg), 
								__quasiquote(SCM_CDR(arg)));
				else result = __QUOTE_JOIN(scm_const_symbol_cons, 
							__quasiquote(SCM_CAR(arg)), 
							__quasiquote(SCM_CDR(arg)));
			} else result = __QUOTE_JOIN(	scm_const_symbol_cons, 
							__quasiquote(SCM_CAR(arg)),
							__quasiquote(SCM_CDR(arg)));
		} else result = __QUOTE_JOIN(	scm_const_symbol_cons, 
						__quasiquote(SCM_CAR(arg)), 
						__quasiquote(SCM_CDR(arg)));
	} else if (SCM_TYPE(arg) != VECTOR) result = __QUOTE_SYMBOL(arg);
	if (is_vector) {
		result = scm_value_new_pair(scm_const_symbol_list_to_vector, scm_value_new_pair(result, SCM_CONST_NIL));
	}
	if (result == NULL) scm_value_new_error("quasiquote: syntax error");
	return result;
}

scm_value * quasiquote(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "quasiquote");
	return __quasiquote(args[0]);
}

scm_value * and(SCM_ARGS)
{
	int i;
	scm_value * result = S_true;
	for (i = count - 1; i >= 0; i--) {
		result = C(S_if, C(args[i], C(result, C(S_false, SCM_CONST_NIL))));
	}
	return result;
}

scm_value * or(SCM_ARGS)
{
	int i;
	scm_value * result = S_false;
	for (i = count - 1; i >= 0; i--) {
		result = C(S_if, C(args[i], C(S_true, C(result, SCM_CONST_NIL))));
	}
	return result;
}

scm_value * min(SCM_ARGS)
{
	int i, result_float = 0;
	
	if (count < 1) return scm_value_new_error("min: requires at least one argument");

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "min")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			if (result > scm_float_num(args[i])) result = scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = scm_int_num(args[0]);
		for (i = 1; i < count; i++)
			if (result > scm_int_num(args[i])) result = scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * max(SCM_ARGS)
{
	int i, result_float = 0;
	
	if (count < 1) return scm_value_new_error("max: requires at least one argument");

	for (i = 0; i < count; i++) {
		SCM_ASSERT_ARG_TYPE_NUMBER(i, "min")
		if (SCM_TYPE(args[i]) == FLOAT) result_float = 1;
	}

	if (result_float) {
		double result = scm_float_num(args[0]);
		for (i = 1; i < count; i++) 
			if (result < scm_float_num(args[i])) result = scm_float_num(args[i]);
		return scm_value_new_float(result);
	} else {
		int result = scm_int_num(args[0]);
		for (i = 1; i < count; i++)
			if (result < scm_int_num(args[i])) result = scm_int_num(args[i]);
		return scm_value_new_int(result);
	}
}

scm_value * member(SCM_ARGS)
{
	scm_value * nargs[2];
	scm_value * list = args[1];
	if (!is_list(list)) return scm_value_new_error("member: second argument must be list.");

	nargs[0] = args[0];
	while (!SCM_IS_NULL(list)) {
		nargs[1] = SCM_CAR(list);
		if (SCM_BOOL(pred_equal(2, nargs))) return list;
		list = SCM_CDR(list);
	}
	return SCM_CONST_FALSE;
}

scm_value * length(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "length");
	if (!is_list(args[0])) return scm_value_new_error("length: argument must be list.");
	return scm_value_new_int(list_length(args[0]));

}

scm_value * macro(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "macro");
	SCM_ASSERT_ARG_TYPE_EQ(LAMBDA, 0, "macro");

	scm_value * result = scm_value_new_lambda_clone(args[0]);
	result->type = MACRO;
	return result;
}

scm_value * display(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "display");
	printf("%s", format(args[0], 0));
	return SCM_CONST_VOID;
}

scm_value * newline(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(0, "newline");
	printf("\n");
	return SCM_CONST_VOID;
}

scm_value * setcar(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "set-car!");
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "set-car!");
	SCM_PAIR(args[0]).ar = args[1];

	return args[0];
}

scm_value * setcdr(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(2, "set-cdr!");
	SCM_ASSERT_ARG_TYPE_EQ(PAIR, 0, "set-cdr!");
	SCM_PAIR(args[0]).dr = args[1];

	return args[0];
}

scm_value * vector_set(SCM_ARGS) {
	SCM_ASSERT_ARG_CNT_EQ(3, "vector-set!");
	SCM_ASSERT_ARG_TYPE_EQ(VECTOR, 0, "vector-set!");
	SCM_ASSERT_ARG_TYPE_EQ(INT, 1, "vector-set!");

        scm_value * vector = args[0];
	scm_value * k = args[1];
	scm_value * val = args[2];

	if ((SCM_INT(k) < 0) || (SCM_INT(k) >= SCM_VECTOR(vector)->size))
		return scm_value_new_error("vector-set!: index out of range");

	SCM_VECTOR(vector)->items[SCM_INT(k)] = val;
	return vector;
}

scm_value * fn_sin(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "sin");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "sin");

	return scm_value_new_float(sin(scm_float_num(args[0])));
}

scm_value * fn_cos(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "cos");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "cos");

	return scm_value_new_float(cos(scm_float_num(args[0])));
}

scm_value * fn_sqrt(SCM_ARGS)
{
	SCM_ASSERT_ARG_CNT_EQ(1, "sqrt");
	SCM_ASSERT_ARG_TYPE_NUMBER(0, "sqrt");
	if (scm_float_num(args[0]) < 0) return scm_value_new_error("sqrt: argument cannot be lesser than zero");

	return scm_value_new_float(sqrt(scm_float_num(args[0])));
}
