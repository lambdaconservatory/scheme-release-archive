#include "config.h"
#if (!defined(TM_LOG_C) && (defined(USE_STM)))
#define TM_LOG_C

#include <gc/gc.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "types.h"
#include "tm_log.h"
#include "env.h"
#include "vm.h"
#include <glib.h>

//
// WRITE LOGS
//

#define TMI_ENV 	(1)
#define TMI_WLOG 	(2)

static tm_write_log * tm_wlog_new(int size)
{
	tm_write_log * result = GC_MALLOC(sizeof(tm_write_log));
	result->table = GC_MALLOC(sizeof(tm_write_log_item *) * size);
	result->capacity = size;
	result->size = 0;
	return result;
}

static inline void tm_rlog_record(tm_read_log * log, int type, void * object);
static inline scm_value * tm_wlog_check(struct scm_vm * vm, struct scm_env * env, struct scm_value * key)
{
	int i;
	tm_write_log * log = vm->write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) return item->value;
	}
	
	log = vm->parent_write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			tm_rlog_record(vm->read_log, TMI_WLOG, item);
			return item->value;
		}
	}
	return NULL;
}

static void tm_wlog_commit(struct scm_vm * vm, tm_write_log * log) 
{
	int i;
	for (i = 0 ; i < log->size; i++) {
			int v1 = log->table[i]->env->version;
			scm_env_set(vm, log->table[i]->env, log->table[i]->key, log->table[i]->value);
			int v2 = log->table[i]->env->version;
			if (v2 > v1) log->table[i]->committed = v2; 
	}
}

static void tm_wlog_resize(tm_write_log * log, int new_capacity)
{
	if (log->capacity >= new_capacity) return;
//	printf("wlog_resize:%i->%i\n", log->capacity, new_capacity);
	log->table = GC_REALLOC(log->table, sizeof(tm_write_log_item *) * new_capacity);
	log->capacity = new_capacity;
}

static inline void tm_wlog_record(struct scm_vm * vm, struct scm_env * env, struct scm_value * key, struct scm_value * value)
{
	int i;
	tm_write_log * log = vm->write_log;
	if (log->size + 1 >= log->capacity) tm_wlog_resize(log, log->capacity * 2);

	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			item->value = value;
			g_atomic_int_inc(&(item->version));
			return;
		}
	}
	i = log->size;
	log->table[i] = GC_MALLOC(sizeof(tm_write_log_item));
	log->table[i]->env = env;
	log->table[i]->key = key;
	log->table[i]->value = value;
	log->table[i]->version = 0;
	log->table[i]->owner = vm;
	log->size++;
	if (SCM_PRE_BOUND(key)) log->naughty++;

}

static tm_write_log * tm_wlog_create_parent_wlog(struct scm_vm * parent_vm)
{
	int i, j;
	tm_write_log * log = parent_vm->write_log;
	tm_write_log * parent_log = parent_vm->parent_write_log;
	tm_write_log * result = tm_wlog_new(log->size + parent_log->size + 1);
	
	for (i = 0; i < log->size; i++)
		result->table[result->size++] = log->table[i];

	for (i = 0; i < parent_log->size; i++) {
		int overriding = 0;
		for (j = 0; j < log->size; j++) {
			tm_write_log_item * item = log->table[j];
			if ((item->env == parent_log->table[i]->env) 
				&& (SCM_SYMBOL_EQ(parent_log->table[i]->key, item->key))) {
				overriding = 1;
				break;
			}
		}

		if (!overriding) result->table[result->size++] = parent_log->table[i];
	}
	return result;
}

/* returns 1 if write logs contains modified global symbol */
static inline int tm_wlog_naughty(tm_write_log * log)
{
	return log->naughty;
}

//
// READ LOGS
//

static tm_read_log * tm_rlog_new(int size) 
{
	tm_read_log * result = GC_MALLOC(sizeof(tm_read_log));
	result->table = GC_MALLOC(sizeof(tm_read_log_item *) * size);
	result->capacity = size;
	result->size = 0;
	return result;
}

static inline void tm_rlog_record(tm_read_log * log, int type, void * object)
{
	int i;
	for (i = 0; i < log->size; i++)
		if (log->table[i]->value.generic == object) return;

	if (log->size + 1 >= log->capacity) {
		log->capacity *= 2;
		log->table = GC_REALLOC(log->table, sizeof(tm_read_log_item *) * log->capacity);
	}

	int ver = 0;
	if (type == TMI_ENV) ver = g_atomic_int_get(&((scm_env *)object)->version);
	if (type == TMI_WLOG) ver = g_atomic_int_get(&((tm_write_log_item *)object)->version);

	tm_read_log_item * item = GC_MALLOC(sizeof(tm_read_log_item));
	item->type = type;
	item->version = ver;
	item->value.generic = object;
	log->table[log->size] = item;
	log->size++;
}

#define min(X, Y)  ((X) < (Y) ? (X) : (Y))
static void tm_rlog_paste_parent_log(struct scm_vm * vm, tm_read_log * master, tm_read_log * slave)
{
	int i, j;
	int old_msize = master->size;
	for (i = 0; i < slave->size; i++) {
//		if ((slave->table[i]->type == TMI_ENV) && (slave->table[i]->value.env->epoch->vm == vm)) continue;
//		if ((slave->table[i]->type == TMI_WLOG) && (slave->table[i]->value.wlog->owner == vm)) continue;
		
		for (j = 0; j < old_msize; j++) {
			if (master->table[j]->value.generic == slave->table[i]->value.generic) {
				master->table[j]->version = min(slave->table[i]->version, master->table[j]->version);
				break;
			}
		}

		if (master->size + 1 >= master->capacity) {
			master->capacity *= 2;
			master->table = GC_REALLOC(master->table, sizeof(tm_read_log_item *) * master->capacity);
		}
		master->table[master->size] = slave->table[i];
		master->size++;
	}
}

//
// COMMON
//

/*
 * returns 1 if transacations collidates
 */
static int tm_check_collision(tm_read_log * slave_read_log, tm_write_log * master_write_log)
{
	int i, j;
	for (i = 0; i < master_write_log->size; i++) {
		for (j = 0; j < slave_read_log->size; j++)
			if (slave_read_log->table[j]->value.generic == master_write_log->table[i]->env) return 1;
	}
	return 0;
}

static int tm_check_collision_advanced_edition(tm_read_log * log)
{
	int i;
	for (i = 0; i < log->size; i++) {
		version_t v1 = -1;
		version_t v2 = log->table[i]->version;
		
		if (log->table[i]->type == TMI_WLOG) {
			v1 = log->table[i]->value.wlog->version;
			if (log->table[i]->value.wlog->committed) { 
				int x1 = log->table[i]->value.wlog->env->version;
				int x2 = log->table[i]->value.wlog->committed;
				if (x1 > x2) {
					//printf("fff\n");
					return 1;
				}
			}
		}
		if (log->table[i]->type == TMI_ENV) v1 = log->table[i]->value.env->version;
		if (v1 > v2) return 1;
	}
	return 0;
}
#endif
