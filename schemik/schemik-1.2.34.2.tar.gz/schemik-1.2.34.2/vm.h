/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef VM_H
#define VM_H

#include <gc/gc.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "types.h"
#include "mutex.h"
#include "env.h"
#include "rt.h"
#include "stack.h"
#include "tm_log.h"

#define NOTAIL	(0)
#define	TAIL	(1)
#define HEAD	(2)

enum command_op {
	OP_EVAL, 
	OP_INSPECT, 
	OP_RUN, 
	OP_DEFINE, 
	OP_IF,
	OP_SET,
	OP_DISCARD,
	OP_RETURN,
	OP_FEVAL,
	OP_WAIT,
	OP_DROP,
	OP_BLOCK,
	OP_APPLY,
	OP_COND,
	OP_MAP,
	OP_PUSH,
	OP_LET,
	OP_LET_NAMED,
	OP_LOAD
};

struct scm_vm;
struct vm_epoch;

typedef struct command {
	enum command_op op;	
	scm_value * arg1; 
	scm_env *env;
	struct scm_vm * vm;
	struct command * next_pooled;
	unsigned char tail_position;
} command;

typedef struct vm_stat_item {
	scm_value * expr;
	unsigned int fevals;
	unsigned int drops;
} vm_stat_item;

struct vm_stat {
	int size;
	int capacity;
	vm_stat_item * items;
};

typedef struct scm_vm {
	scm_rt * runtime;
	struct stack * exct;
	struct stack * rslt;	
	struct scm_vm * parent;
	mutex_t lock;
	command * command_pool;
	volatile int emergency_stop;
	struct vm_stat stats;
#ifdef USE_STM
	tm_write_log * write_log;
	tm_write_log * parent_write_log;
	tm_read_log * read_log;
	int sub_threads;
	struct vm_epoch * epoch;
#endif

} scm_vm;

#endif
