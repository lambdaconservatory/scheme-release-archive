#include "int_funcs.h"
#include "types.h"
#include "errors.h"

static char * display_args(int arg_count, scm_value ** args, int exclamation_arg)
{
	char * r = gc_initstr("");
	for (int i = 0; i < arg_count; i++) {
		r = gc_concat(r, gc_sprintf("  #%i:%s%s\n", i + 1,
					(exclamation_arg == i ? ">" : " "), 
					format(args[i], 0)));
	}
	return r;
}

scm_value * err_bad_args(char * func_name, char * msg, int arg_count, scm_value ** args, int line)
{
	return err_bad_args_ex(func_name, msg, arg_count, args, -1, line);
}

scm_value * err_bad_args_ex(char * func_name, char * msg, int arg_count, scm_value ** args, int excl, int line)
{
	return scm_value_new_error(
			gc_sprintf("%s: %s at line %i\n  passed %i argument(s)%s%s",
			func_name, msg, (line + 1), 
			arg_count, (arg_count > 0 ? ":\n" : ".\n"),
			display_args(arg_count, args, excl)));
}

scm_value * err_bad_spec_form(char * spec_form_name, char * msg, scm_value * values, int line)
{
	int arg_count = list_length(values);
	scm_value * args[arg_count];
	for (int i = 0; i < arg_count; i++) {
		args[i] = SCM_CAR(values);
		values = SCM_CDR(values);
	}
	return err_bad_args(spec_form_name, msg, arg_count, args, line);
}

scm_value * err_map_func(char * msg, scm_value * fn, int list_count, scm_value ** lists, int pos, int line)
{
	scm_value * args[list_count + 1];
	args[0] = fn;
	for (int i = 0; i < list_count; i++)
		args[list_count - i] = lists[i];
	return err_bad_args_ex("map", msg, list_count + 1, args, pos, line);
}
