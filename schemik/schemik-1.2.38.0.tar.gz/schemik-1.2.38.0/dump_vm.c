#ifdef USE_STACK_DUMP
#include <stdio.h>
#include "int_funcs.h"

/*
 * Text-output specific macros
 */

#if USE_STACK_DUMP == DUMP_TEXT

#define CASE_EMPTY(op,desc) \
	case op: fprintf(f, "[%s]", desc); break;

#define CASE_ENV_ARG(op,desc) \
	case op: fprintf(f, "[%s E%li %s]", desc, cmd->env->id, format(cmd->arg1, 0)); break;

#define CASE_ENV(op,desc) \
	case op: fprintf(f, "[%s E%li]", desc, cmd->env->id); break;

#define CASE_ENV_TAIL(op,desc)	CASE_ENV(op,desc)

#define CASE_ARG(op,desc) \
	case op: fprintf(f, "[%s %s]", desc, format(cmd->arg1, 0)); break;

#define DUMP_DELIM	" "
#define DUMP_EBEGIN	"E: "
#define DUMP_EEND	"\n"
#define DUMP_RBEGIN	"R: "
#define DUMP_REND	"\n\n"
//#define DUMP_VALUE(x)	display_value_generic(f, x, 0);
#define DUMP_VALUE(x)	fprintf(f, "%s", format(x, 0));

#endif

/*
 * LaTeX-output specific macros
 */
#if USE_STACK_DUMP == DUMP_LATEX

static char * __get_assoc_symbol(scm_vm * vm, scm_value * val)
{
	scm_env * env = vm->runtime->env;
	char ** symbols = scm_env_get_symbols(env); 

	if ((SCM_TYPE(val) == SPEC_FORM) && (SCM_SPEC_FORM(val) == SP_CALLCC)) return "call/cc";
	if ((SCM_TYPE(val) == SPEC_FORM) && (SCM_SPEC_FORM(val) == SP_COND)) return "cond";

	while (symbols != NULL) {
		if ((*symbols != NULL) && (scm_env_get(vm, env, scm_value_new_symbol(*symbols)) == val)) {
			return gc_sprintf("%s", *symbols);
		}
		symbols++;
	}
	return "";
}

static char * __format_env(long id)
{
	if (id == -1) return "{\\env{E}_t}";
	return gc_sprintf("{\\env{E}_%li}", id);
}

static char * __format_flag(unsigned char flag)
{
	return (flag == TAIL ? "{TAIL}" : "{NOTAIL}");
}

static char * latex_format_list(scm_vm * vm, scm_value * list) 
{
	char * result = gc_initstr("(");
	while (SCM_TYPE(list) != NIL) {
		result = gc_concat(result, format(SCM_CAR(list), 0));
		list = SCM_CDR(list);
		if (SCM_TYPE(list) != NIL) result = gc_concat(result, " ");
	}
	result = gc_concat(result, ")");
	return result;
}

static char * latex_format(scm_vm * vm, scm_value * val);
static char * latex_format_vector(scm_vm * vm, scm_value * val)
{
	int i;
	char * result = gc_initstr("\\#(");
	for (i = 0; i < SCM_VECTOR(val)->size; i++) {
		result = gc_concat(result, latex_format(vm, SCM_VECTOR(val)->items[i]));
		if (i < (SCM_VECTOR(val)->size - 1)) result = gc_concat(result, " ");
	}
	return gc_concat(result, ")");
}

#define CASE_LATEX_FORMAT_0(type,value) \
	        case type: return gc_sprintf("%s", value);

#define CASE_LATEX_FORMAT_EX(type,format,value) \
	        case type: return gc_sprintf(format, value);

#define CASE_LATEX_FORMAT_FN(type,name,val) \
	        case type: return gc_sprintf("#<%s %s>", name, format(val->value.lambda->arg_list, 0));


static char * latex_format(scm_vm * vm, scm_value * val)
{
	if (is_list(val)) return gc_sprintf("{\\tt %s}", latex_format_list(vm, val));

	switch (SCM_TYPE(val)) {
		// FIXME: does not show defines!
		case LAMBDA: return gc_sprintf("{\\em user-defined\\ func.\\ $\\langle$%s, %s, %s\\rangle$}",
					     latex_format(vm, val->value.lambda->arg_list),
					     latex_format(vm, val->value.lambda->cmd_list),
					     (val->value.lambda->parent->id == -1)
					      	? "$\\env{E}_t"
						: gc_sprintf("$\\env{E}_%li", val->value.lambda->parent->id));
		CASE_LATEX_FORMAT_EX(SYMBOL, "{\\tt %s}", SCM_SYMBOL(val))
		CASE_LATEX_FORMAT_EX(INT, "$%i$", SCM_INT(val))
		CASE_LATEX_FORMAT_EX(FLOAT, "$%f$", SCM_FLOAT(val))
		CASE_LATEX_FORMAT_EX(BOOL, "%s", SCM_BOOL(val) ? "{\\tt \\#t}" : "{\\tt \\#f}")
		CASE_LATEX_FORMAT_EX(FUNC, "\\arg{primitive\\ func.} {\\tt %s}", __get_assoc_symbol(vm, val));
		CASE_LATEX_FORMAT_EX(SPEC_FORM, "\\arg{special\\ operator} {\\tt %s}", __get_assoc_symbol(vm, val));
		CASE_LATEX_FORMAT_0(VOID, "{\\tt \\#v}")
		CASE_LATEX_FORMAT_0(NIL, "()")
		CASE_LATEX_FORMAT_EX(ERROR, "\\#<Err (%s)>", SCM_ERROR(val))
		CASE_LATEX_FORMAT_EX(MACRO, "\\#<Macro %s>", latex_format(vm, val->value.lambda->arg_list))
		CASE_LATEX_FORMAT_0(CONTINUATION, "\\arg{continuation}")
		case PAIR: return gc_sprintf("(%s . %s)", latex_format(vm, SCM_CAR(val)), 
					   		  latex_format(vm, SCM_CDR(val)));
		case VECTOR: return latex_format_vector(vm, val);
	}
	return "XXX";
}

#define CASE_EMPTY(op,desc) \
	case op: fprintf(f, "\\E{%s}{}{}{}", desc); break;

#define CASE_ENV_ARG(op,desc) \
	case op: fprintf(f, "\\E{%s}{%s}%s%s", desc, latex_format(vm, cmd->arg1), __format_env(cmd->env->id), __format_flag(cmd->tail_position)); break;

#define CASE_ARG(op,desc) \
	case op: fprintf(f, "\\E{%s}{%s}{}{}", desc, latex_format(vm, cmd->arg1)); break;

#define CASE_ENV(op,desc) \
	case op: fprintf(f, "\\E{%s}{}%s{}", desc, __format_env(cmd->env->id)); break;

#define CASE_ENV_TAIL(op,desc) \
	case op: fprintf(f, "\\E{%s}{}%s%s", desc, __format_env(cmd->env->id), __format_flag(cmd->tail_position)); break;

#define DUMP_DELIM	", "
#define DUMP_EBEGIN	"\\VMTRANS{"
#define DUMP_EEND	"\n"
#define DUMP_RBEGIN	"}{ "
#define DUMP_REND	"}\n"
#define DUMP_VALUE(x)	fprintf(f, "%s", latex_format(vm, x));

#endif

/*
 * Generic function
 */

static void vm_print_stacks(scm_vm * vm)
{
	stack_item item;
	FILE * f = stderr;
	fprintf(f, DUMP_EBEGIN);
	
	item = stack_internal_get_top(vm->exct);
	while (!stack_internal_get_done(vm->exct, item)) {
		command * cmd = (command *)stack_internal_get_value(vm->exct, item);
		switch (cmd->op) {
			CASE_ENV_ARG(OP_EVAL, "EVAL")
			CASE_ENV_ARG(OP_INSPECT, "INSPECT")
			CASE_ENV_ARG(OP_RUN, "FUNCALL")
			CASE_ENV(OP_DEFINE, "DEFINE")
			CASE_ENV_TAIL(OP_IF, "IF")
			CASE_EMPTY(OP_WAIT, "WAIT")
			CASE_EMPTY(OP_DROP, "DROP")
			CASE_EMPTY(OP_DISCARD, "DISCARD")
			CASE_ENV(OP_SET, "SET")
			CASE_ENV(OP_RETURN, "RETURN")
			CASE_ENV_ARG(OP_MAP, "MAP")
			CASE_ENV_ARG(OP_APPLY, "APPLY")
			CASE_ARG(OP_PUSH, "PUSH")
			CASE_ENV_ARG(OP_COND, "COND")
			CASE_ENV_ARG(OP_BLOCK, "BLOCK")
			CASE_ENV_ARG(OP_LET, "LET")
			CASE_ENV_ARG(OP_LET_NAMED, "LET_NAMED")
			default:
				fprintf(f, "FIXME");
				break;
		}

		item = stack_internal_get_next(vm->exct, item);
		if (!stack_internal_get_done(vm->exct, item)) fprintf(f, DUMP_DELIM);
	}
	fprintf(f, DUMP_EEND);

	fprintf(f, DUMP_RBEGIN);
	item = stack_internal_get_top(vm->rslt);
	while (!stack_internal_get_done(vm->rslt, item)) {
		DUMP_VALUE(stack_internal_get_value(vm->rslt, item));
		item = stack_internal_get_next(vm->rslt, item);
		if (!stack_internal_get_done(vm->rslt, item)) fprintf(f, DUMP_DELIM);
	}
	fprintf(f, DUMP_REND);
}

#endif
