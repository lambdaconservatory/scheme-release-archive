#include <gc/gc.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

#include "lexer.h"
#include "int_funcs.h"

#define DEFINE_FIXED_TOKEN_CHECK(__name, __token) \
static int __name(struct lexer * lex) \
{ \
	for (int i = 0; i < strlen(__token); i++) { \
		char c = lex->input[lex->position + i]; \
		if (tolower(c) != tolower(__token[i])) return 0; \
	} \
	return strlen(__token); \
}

struct lexer * lexer_new(char * input)
{
	struct lexer * result = GC_MALLOC(sizeof(struct lexer));
	result->position = 0;
	result->input = GC_MALLOC(strlen(input) + 1);
	result->input_length = strlen(input);
	strcpy(result->input, input);
	return result;
}

DEFINE_FIXED_TOKEN_CHECK(check_left_paren, "(")
DEFINE_FIXED_TOKEN_CHECK(check_right_paren, ")")
DEFINE_FIXED_TOKEN_CHECK(check_left_bracket, "[")
DEFINE_FIXED_TOKEN_CHECK(check_right_bracket, "]")
DEFINE_FIXED_TOKEN_CHECK(check_quote, "'")
DEFINE_FIXED_TOKEN_CHECK(check_unquotesplicing, ",@")
DEFINE_FIXED_TOKEN_CHECK(check_unquote, ",")
DEFINE_FIXED_TOKEN_CHECK(check_quasiquote, "`")
DEFINE_FIXED_TOKEN_CHECK(check_dot, ".")
DEFINE_FIXED_TOKEN_CHECK(check_true, "#t")
DEFINE_FIXED_TOKEN_CHECK(check_false, "#f")
DEFINE_FIXED_TOKEN_CHECK(check_hash, "#")

static int check_white_space(struct lexer * lex)
{
	int i = 1;
	char c = lex->input[lex->position];
	if (!isspace(c)) return 0;
	while (lex->position + i < lex->input_length) {
		c = lex->input[lex->position + i];
		if (isspace(c)) i++;
		else break;
	}
	return i;
}

static int is_end_of_token(struct lexer * lex, int pos)
{
	int res;
	lex->position += pos;
	res = check_white_space(lex) || check_left_paren(lex) || check_right_paren(lex) 
		|| check_left_bracket(lex) || check_right_bracket(lex);
	lex->position -= pos;
	return res;
}

static int check_number(struct lexer * lex)
{
	int i = 1;
	char c = lex->input[lex->position];
	if (!((isdigit(c) || strchr("+-", c)))) return 0;
	if (strchr("+-", c)) {
		c = lex->input[lex->position + i];
		if ((c == '\0') || (!isdigit(c))) return 0;
		i++;
	}
	while (1) {
		c = lex->input[lex->position + i];
		if ((c == '\0') || (is_end_of_token(lex, i))) return i;
		if (isdigit(c)) i++;
		else return 0;
	}
	return i;
}

static int issymbol(char c, int initial)
{
	if (initial) return (isalnum(c) || strchr("+*-\\=?!<>_/~:%@", c));
	else return (isalnum(c) || strchr("+*-\\=?!<>_/~:%',@`.", c));
}

static int check_symbol(struct lexer * lex)
{
	int i = 1;
	char c = lex->input[lex->position];
	if (!issymbol(c, 1)) return 0;
	while (1) {
		c = lex->input[lex->position + i];
		if (c == '\0') return i;
		if (issymbol(c, 0)) i++;
		else return i;
	}
}

static int check_comment(struct lexer * lex) 
{
	int i = 1;
	char c = lex->input[lex->position];
	if (c != ';') return 0;
	while (1) {
		c = lex->input[lex->position + i];
		if ((c == '\n') || (c == '\0')) return i;
		i++;
	}
}

static int check_string(struct lexer * lex)
{
	int i = 1;
	char c = lex->input[lex->position];
	if (c != '"') return 0;
	while (1) {
		c = lex->input[lex->position + i];
		if (c == '\0') return -1;
		if (c == '"') return i + 1;
		if ((c == '\\') && (lex->input[lex->position + i + 1] == '"')) i += 2;
		else i++;
	}
}

static char * unescape_string(char * s)
{
	int i;
	char * r = GC_MALLOC(strlen(s) + 1);
	for (i = 0; *s != '\0'; i++) {
		if (*s == '\\') {
			switch (*(s + 1)) {
				case 'n': r[i] = '\n'; s += 2; break;
				case 'r': r[i] = '\r'; s += 2; break;
				case 't': r[i] = '\t'; s += 2; break;
				case 'b': r[i] = '\b'; s += 2; break;
				case 'f': r[i] = '\f'; s += 2; break;
				case '"': r[i] = '"'; s += 2; break;
				default: r[i] = *s; s++;
			}
		} else {
			r[i] = *s;
			s++;
		}
	}
	return r;
}

static int check_float(struct lexer * lex) // [+-]?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?
{
	int i = 0;
	int exp_len = 0;
	char c = lex->input[lex->position];
	if (!((isdigit(c) || strchr("+-.", c)))) return 0;
	if (isdigit(c)) goto integer_part;
	if (c == '.') goto point; 
// sign:
	i++;
	c = lex->input[lex->position + i];
	if (c == '.') goto point;
	if (isdigit(c)) goto integer_part;
	return 0;

integer_part:
	while (1) {
		c = lex->input[lex->position + i];
		if (c == '\0') return i;
		if (c == '.') goto point; 
		if ((c == 'e') || (c == 'E')) goto exp;
		if (isdigit(c)) i++;
		else if (is_end_of_token(lex, i)) return i;
		else return 0;
	}
point:
	i++;
	while (1) {
		c = lex->input[lex->position + i];
		if (c == '\0') return i;
		if (c == '.') goto point; 
		if ((c == 'e') || (c == 'E')) goto exp;
		if (isdigit(c)) i++;
		else if (is_end_of_token(lex, i)) return i;
		else return 0;
	}
exp:
	i++;
	c = lex->input[lex->position + i];
	if (isdigit(c)) goto exp_num;
	if (!strchr("+-", c)) return 0;
	i++;
exp_num:
	while (1) {
		c = lex->input[lex->position + i];
		if (c == '\0') return (exp_len > 0 ? i : 0);
		if (isdigit(c)) i++, exp_len++;
		else if (is_end_of_token(lex, i)) return (exp_len ? i : 0);
		else return 0;
	}

	return i;
}

struct token * token_new(struct lexer * lex, unsigned int tok_id, int length)
{
	struct token * t = GC_MALLOC(sizeof(struct token));
	t->text = GC_MALLOC(length + 1);
	t->tok_id = tok_id;
	t->line = lex->cur_line;
	strncpy(t->text, lex->input + lex->position, length);
	return t;
}

#define CHECK(__func, __id) { \
	int __i = __func(lex);	\
	if (__i) {\
		struct token * t = token_new(lex, __id, __i);\
		lex->position += __i;\
		return t; \
	} \
}

struct token * lexer_next0(struct lexer * lex)
{
	char c = lex->input[lex->position];
	if (c == '\0') return NULL;
	CHECK(check_white_space, T_WHITE_SPACE);
	CHECK(check_left_paren, T_LEFT_PAREN);
	CHECK(check_right_paren, T_RIGHT_PAREN);
	CHECK(check_left_bracket, T_LEFT_PAREN);
	CHECK(check_right_bracket, T_RIGHT_PAREN);
	CHECK(check_number, T_NUMBER);
	CHECK(check_dot, T_DOT);
	CHECK(check_float, T_FLOAT_NUMBER);
	CHECK(check_symbol, T_SYMBOL);
	CHECK(check_quote, T_QUOTE);
	CHECK(check_unquotesplicing, T_UNQUOTE_SPLICING);
	CHECK(check_unquote, T_UNQUOTE);
	CHECK(check_quasiquote, T_QUASIQUOTE);
	CHECK(check_true, T_TRUE);
	CHECK(check_false, T_FALSE);
	CHECK(check_hash, T_VECTOR);
	CHECK(check_comment, T_COMMENT);
	int i = check_string(lex);
	if (i) {
		if (i == -1) {
			struct token * t = GC_MALLOC(sizeof(struct token));
			t->tok_id = T_ERROR;
			t->line = lex->cur_line;
			t->text = gc_sprintf("unterminated string at line %i", t->line);
			lex->position = lex->input_length;
			return t;
		}
		struct token * t = GC_MALLOC(sizeof(struct token));
		char * raw_string = GC_MALLOC(i + 1);
		t->tok_id = T_STRING;
		strncpy(raw_string, lex->input + lex->position + 1, i - 2);
		t->text = unescape_string(raw_string);
		t->line = lex->cur_line;
		lex->position += i;
		return t;
	}
	struct token * t = GC_MALLOC(sizeof(struct token));
	t->tok_id = T_ERROR;
	t->text = gc_sprintf("syntax horror at line %i", t->line);
	t->line = lex->cur_line;
	lex->position = lex->input_length;
	return t;
}

struct token * lexer_top(struct lexer * lex)
{
	struct token * t;
	if (lex->top) return lex->top;
	t = lexer_next(lex);
	lex->top = t;
	return t;
}

static int count_new_lines(char * x)
{
	int count = 0;
	for (int i = 0; i < strlen(x); i++)
		if (x[i] == '\n') count++;
	return count;
}

struct token * lexer_next(struct lexer * lex)
{
	if (lex->top != NULL) {
		struct token * t = lex->top;
		lex->top = NULL;
		return t;
	}
	struct token * t = lexer_next0(lex);
	if (t) {
		t->line = lex->cur_line;
		lex->cur_line += count_new_lines(t->text);
		if ((t->tok_id == T_COMMENT) || (t->tok_id == T_WHITE_SPACE)) return lexer_next(lex);
	}
	return t;
}
