/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef ENV_H
#define ENV_H
#include "config.h"
#include "types.h"
#include "mutex.h"

struct scm_vm;
typedef int version_t;

typedef struct vm_epoch {
	volatile struct scm_vm * vm;
	struct vm_epoch * next;
	int time;		
} vm_epoch;

struct env_item {
	//char * key;
	struct scm_value * key;
	struct scm_value * value;
	struct env_item * next;
};

typedef struct scm_env {
#ifdef USE_STM
	struct vm_epoch * epoch;
	volatile version_t version;
#endif
	struct scm_env * parent;
	union {
		struct env_item * list;
		struct env_item ** hash;
	} items;
	unsigned int capacity;
	unsigned int size;
	unsigned int hash_size;
	unsigned char closure;
	unsigned char naughty;
	unsigned char compact;
#ifdef USE_STACK_DUMP
	long id;
#endif
} scm_env;


struct scm_env * scm_env_new(scm_env * parent, unsigned int initial_capacity);
struct scm_env * scm_env_new_with_hash(scm_env * parent, unsigned int hash_size);
void scm_env_add(scm_env * env, struct scm_value * key, struct scm_value * value);
struct scm_value * scm_env_get(struct scm_vm *, scm_env * env, struct scm_value * key);
struct scm_env * scm_env_get_env(scm_env * env, struct scm_value * key);
struct scm_value * scm_env_set(struct scm_vm *, scm_env * env, struct scm_value * key, struct scm_value * value);
void scm_env_recycle(scm_env * env);
void scm_env_print(scm_env * env);
char ** scm_env_get_symbols(scm_env * env);
struct env_item * scm_env_get_item(scm_env * env, struct scm_value * key);
#endif
