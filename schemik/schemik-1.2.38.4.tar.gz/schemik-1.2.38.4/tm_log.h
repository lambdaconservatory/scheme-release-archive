#ifndef TM_LOG_H
#define TM_LOG_H

#include "env.h"
#include "types.h"

#define TMI_ENV         (1)
#define TMI_WLOG        (2)
#define TMI_CONS	(3)
#define TMI_VECTOR	(4)

//struct scm_env;
struct scm_value;
struct scm_vm;

typedef struct tm_write_log_item {
	struct scm_value * key;
	struct scm_value * value;
	struct scm_env * env;
	volatile version_t version;
	int committed;
	struct scm_vm * owner;
	unsigned char object_type;
} tm_write_log_item;

typedef struct tm_write_log {
	struct tm_write_log_item ** table;
	int capacity;
	int size;
	int naughty;
} tm_write_log;

typedef struct tm_read_log_item {
	struct tm_read_log_item * left;
	struct tm_read_log_item * right;
	union {
		scm_env * env;
		tm_write_log_item * wlog;
		void * generic;
	} value;
	int color;
	int type;
	//version_t version;
	int version;
	int owned; /* FIXME: REMOVEME: pouzival jsem to pouze k debugovani */
} tm_read_log_item;

#define RLOG_NODE_BUF_SIZE	(1000)
#define RLOG_CACHE_SIZE		(1000)
#define RLOG_CACHE_TRESHOLD	(500)

typedef struct tm_read_log {
	tm_read_log_item * root;
	tm_read_log_item * node_buffer;
	int node_buffer_pos;
	int size;
	int count_cons;
	int count_env;
#ifdef USE_RLOG_CACHE
	void ** rlog_cache;
	int rlog_cache_size;
#endif
} tm_read_log;


#define TS_SCM_CAR(vm, pair) (tm_pair_get_generic(vm, pair, 0))
#define TS_SCM_CDR(vm, pair) (tm_pair_get_generic(vm, pair, 1))

static void tm_wlog_resize(tm_write_log * log, int new_capacity);
static inline void tm_rlog_generic_record(tm_read_log * log, int type, void * object, int owned);
#endif
