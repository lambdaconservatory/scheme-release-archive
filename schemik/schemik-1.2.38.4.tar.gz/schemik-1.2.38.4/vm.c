/*
 * Schemik -- Implicitly Parallel Scheme
 * 
 * Virtual machine used by the stack based evalutors and runtimes
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 
#endif* 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef VM_C
#define VM_C

#include "config.h"

#include <gc/gc.h>
#include <glib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "mutex.h"
#include "types.h"
#include "env.h"
#include "vm.h"
#include "rt.h"
#include "stack.c"
#include "vm.h"
#include "int_funcs.h"
#ifdef USE_STM
#include "tm_log.h"
#include "tm_log.c"
#endif

static inline scm_vm * vm_new(scm_rt * runtime);
static inline scm_vm * vm_new_init(scm_rt * runtime, command * initial_command);
static inline int vm_done(scm_vm * vm);
static inline void vm_push_cmd(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg);
static inline void vm_push_cmd0(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg, unsigned char tail_position);
static inline command * vm_pop_cmd(scm_vm * vm);
static inline scm_value * vm_result_top(scm_vm * vm);
static inline scm_value * vm_rslt_pop(scm_vm * vm);
static inline void vm_rslt_push(scm_vm * vm, scm_value * value);
static inline void vm_join(scm_vm * vm, scm_vm * slave, command * cmd);
static inline void vm_lock(scm_vm * vm);
static inline void vm_unlock(scm_vm * vm);
static inline void vm_emergency_stop(scm_vm * vm);
static inline void vm_drop_fevals(scm_vm * vm);
static inline scm_rt * vm_get_runtime(scm_vm * vm);
static inline void vm_command_free(scm_vm * vm, command * cmd);
static inline command * vm_command_new(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg, unsigned char tail_position);
static inline void vm_error(scm_vm * vm, scm_value * error);


static inline scm_vm * vm_new(scm_rt * runtime)
{
	scm_vm * result = (scm_vm *)GC_MALLOC(sizeof(scm_vm));
	result->runtime = runtime;
	result->exct = stack_new();
	result->rslt = stack_new();
	result->parent = NULL;
	result->command_pool = NULL;

	result->stats.capacity = 50;
	result->stats.items = (vm_stat_item *)GC_MALLOC(sizeof(vm_stat_item) * result->stats.capacity);
#ifdef USE_STM
	result->write_log = tm_wlog_new(20);
	result->parent_write_log = tm_wlog_new(1);
	result->read_log = tm_rlog_new(20);
	result->read_log_cons = tm_rlog_new(20);
	tm_rlog_record_env(result, runtime->env, 0);
	result->epoch = GC_MALLOC(sizeof(vm_epoch));
	result->epoch->vm = result;
	result->epoch->next = NULL;
#endif

	mutex_init(result->lock);
	return result;
}

static inline scm_vm * vm_new_init(scm_rt * runtime, command * initial_command)
{
	scm_vm * result = vm_new(runtime);
	vm_push_cmd(result, initial_command->op, initial_command->env, initial_command->arg1);
	return result;
}

/** vraci 0 pokud nejsou dalsi prikazy ke zpracovani */
static inline int vm_done(scm_vm * vm)
{
	volatile int e_stop = g_atomic_int_get(&vm->emergency_stop);
	if (e_stop) {
//		printf("Stop!\n");
		return 1;
	}
	return (stack_empty(vm->exct));
}

static inline void vm_push_cmd(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg)
{
#ifdef IGNORE_WAIT_AND_DROP_OPS
	if ((op == OP_WAIT) || (op == OP_DROP)) return;
#endif
	stack_push(vm->exct, vm_command_new(vm, op, env, arg, NOTAIL));
}

static inline void vm_push_cmd0(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg, unsigned char tail_position)
{
	stack_push(vm->exct, vm_command_new(vm, op, env, arg, tail_position));
}

static inline command * vm_pop_cmd(scm_vm * vm)
{
	return stack_pop(vm->exct);
}

static inline command * vm_command_new(scm_vm * vm, enum command_op op, scm_env * env, scm_value * arg, unsigned char tail_position)
{
	command * cmd;
	if (vm->command_pool == NULL) cmd = (command *)GC_MALLOC(sizeof(command));
	else {
		cmd = vm->command_pool;
		vm->command_pool = vm->command_pool->next_pooled;
	}

	cmd->env = env;
	cmd->op = op;
	cmd->arg1 = arg;
	cmd->tail_position = tail_position;	
	cmd->cur_line = vm->cur_line;
	return cmd;
}

static inline command * vm_command_new0(enum command_op op, scm_env * env, scm_value * arg)
{
	command * cmd = (command *)GC_MALLOC(sizeof(command));

	cmd->env = env;
	cmd->op = op;
	cmd->arg1 = arg;
	
	return cmd;
}

static inline void vm_command_free(scm_vm * vm, command * cmd)
{
	cmd->next_pooled = vm->command_pool;
	vm->command_pool = cmd;
	cmd->arg1 = NULL;
	cmd->env = NULL;
	cmd->vm = NULL;
}

/** vraci prvek na pozici v navratovem zasobniku */
static inline scm_value * vm_result_top(scm_vm * vm)
{
	return stack_top(vm->rslt);
}

static inline scm_value * vm_rslt_pop(scm_vm * vm)
{
	return stack_pop(vm->rslt);
}

static inline void vm_rslt_push(scm_vm * vm, scm_value * value)
{
	stack_push(vm->rslt, value);
}

/* assumess locked vm */
static void drop_thread(scm_vm * vm)
{
	while (!stack_empty(vm->exct)) {
		command * cmd = vm_pop_cmd(vm);
		if (cmd->op == OP_FEVAL) {
			cmd->op = OP_EVAL;
			vm_emergency_stop(cmd->vm);
			vm_lock(cmd->vm);
			drop_thread(cmd->vm);
			vm_unlock(cmd->vm);
		}
	}
}

static inline void __append_stacks(scm_vm * master, scm_vm * slave)
{
	stack_append(master->exct, slave->exct);
	stack_append(master->rslt, slave->rslt);
}

static inline void __subthread_age_interval(scm_value * time_stamps, int * min, int * max)
{
	if (SCM_IS_NULL(time_stamps)) {
		*min = -1, *max = -1;
		return;
	}
	*min = SCM_INT(SCM_CAR(time_stamps));
	*max = *min;

	time_stamps = SCM_CDR(time_stamps);
	while (!SCM_IS_NULL(time_stamps)) {
		int a = SCM_INT(SCM_CAR(time_stamps));
		if (a < *min) *min = a;
		if (a > *max) *max = a;
		time_stamps = SCM_CDR(time_stamps);
	}
}
static inline vm_stat_item * vm_stats_get(scm_vm * vm, scm_value * expr);
/* Appends appropriate stacks from slave vm into master vm, assumes taht all vms are locked */
void vm_join(scm_vm * master, scm_vm * slave, command * cmd)
{
#ifdef USE_STM
//	master->sub_threads--;
	if (tm_check_collision(slave->read_log, master->write_log)
			||  (tm_check_collision_advanced_edition(slave))
		)
			 {
//pthread_mutex_lock(&acommit_lock);
#ifdef USE_THREAD_INFO
		fprintf(stderr, "ABORT\n");
#endif
		//drop_thread(slave);
		vm_drop_fevals(slave);
		vm_push_cmd(master, OP_EVAL, cmd->env, cmd->arg1);
		
		vm_stat_item * stat = vm_stats_get(master, cmd->arg1);
		if (stat != NULL) stat->drops++;
	} else {
//		master->sub_threads += slave->sub_threads;
		int a = 0;
		vm_epoch * e = slave->epoch;
		while (e) {
			//e->vm = master;
			g_atomic_pointer_set(&(e->vm), master);
//			e->vm = master->runtime->main_vm;
			e = e->next;
			a++;
		}


		e = master->epoch;
		int b = 1;
		while (e->next != NULL) e = e->next, b++;
		e->next = slave->epoch;
//		printf("AAA:%i:%i\n", a, b);
		__append_stacks(master, slave);
		tm_wlog_commit(master, slave->write_log);

		if (master->parent == NULL) {
#ifdef USE_THREAD_INFO
			fprintf(stderr, "COMMIT:helper->main\n");
#endif
		} else {
			tm_rlog_paste_parent_log(master, slave);
#ifdef USE_THREAD_INFO
			fprintf(stderr, "COMMIT:helper->helper\n");
#endif
		}
	}
#else
	stack_append(master->exct, slave->exct);
	stack_append(master->rslt, slave->rslt);
#endif
}

static inline void vm_lock(scm_vm * vm) 
{
	mutex_lock(vm->lock);
}

static inline void vm_unlock(scm_vm * vm)
{
	mutex_unlock(vm->lock);
}

static inline void vm_emergency_stop(scm_vm * vm)
{
	g_atomic_int_set(&(vm->emergency_stop), 1);
}

static inline scm_rt * vm_get_runtime(scm_vm * vm)
{
	return vm->runtime;
}

static inline void drop_all_threads(scm_vm * vm)
{
	stack_item exct = stack_internal_get_top(vm->exct);
	while (!stack_internal_get_done(vm->exct, exct)) {
		command * cmd = (command *)stack_internal_get_value(vm->exct, exct);
		if (cmd->op == OP_FEVAL) {
			fprintf(stderr, "DROP\n");
			cmd->op = OP_EVAL;
			vm_emergency_stop(cmd->vm);
			vm_lock(cmd->vm);
			drop_thread(cmd->vm);
			vm_unlock(cmd->vm);
		} 
		exct = stack_internal_get_next(vm->exct, exct);
	}
}

/* assumes locked vm */
void vm_drop_fevals(scm_vm * vm)
{
	drop_all_threads(vm);
}

static inline void vm_error(scm_vm * vm, scm_value * error)
{
	drop_all_threads(vm);
	while (!stack_empty(vm->exct))
		stack_pop(vm->exct);
	while (!stack_empty(vm->rslt))
		stack_pop(vm->rslt);
	stack_push(vm->rslt, error);
}

static inline scm_vm * vm_clone(scm_vm * vm)
{
	scm_vm * clon = vm_new(vm->runtime);

	stack_item item = stack_internal_get_bottom(vm->rslt);
	while (!stack_internal_get_done(vm->rslt, item)) {
		vm_rslt_push(clon, stack_internal_get_value(vm->rslt, item));
		item = stack_internal_get_prev(vm->rslt, item);
	}

	item = stack_internal_get_bottom(vm->exct);
	while (!stack_internal_get_done(vm->exct, item)) {
		command * cmd = (command *)stack_internal_get_value(vm->exct, item);
		if (cmd->op != OP_FEVAL)
			vm_push_cmd0(clon, cmd->op, cmd->env, cmd->arg1, cmd->tail_position);
		else
			vm_push_cmd0(clon, OP_EVAL, cmd->env, cmd->arg1, cmd->tail_position);
		item = stack_internal_get_prev(vm->exct, item);
	}

	return clon;
}

static inline vm_stat_item * vm_stats_get(scm_vm * vm, scm_value * expr)
{
	int i;
	for (i = 0; i < vm->stats.size; i++)
		if (vm->stats.items[i].expr == expr) {
			return vm->stats.items + i;
		}
	return NULL;
}

static inline void vm_stats_register_feval(scm_vm * vm, scm_value * expr)
{
	vm_stat_item * stat = vm_stats_get(vm, expr);
	if (stat != NULL) {
		stat->fevals++;
		return;
	}

	if (vm->stats.size + 2 >= vm->stats.capacity) {
		vm->stats.capacity *= 2;
		vm->stats.items = (vm_stat_item *)GC_REALLOC(vm->stats.items, sizeof(vm_stat_item) * vm->stats.capacity);
	}
	vm->stats.items[vm->stats.size].expr = expr;
	vm->stats.size++;
}

#endif
