#if (!defined(TM_LOG_C) && (defined(USE_STM)))
#define TM_LOG_C

#include <gc/gc.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <glib.h>

#include "types.h"
#include "tm_log.h"
#include "env.h"
#include "vm.h"
#include "int_funcs.h"

#define minimum(X, Y)  ((X) < (Y) ? (X) : (Y))

//
// WRITE LOGS
//

static tm_write_log * tm_wlog_new(int size)
{
	tm_write_log * result = GC_MALLOC(sizeof(tm_write_log));
	result->table = GC_MALLOC(sizeof(tm_write_log_item *) * size);
	result->capacity = size;
	result->size = 0;
	return result;
}

static inline scm_value * tm_wlog_check(struct scm_vm * vm, struct scm_env * env, struct scm_value * key)
{
	int i;
	tm_write_log * log = vm->write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) return item->value;
	}
	log = vm->parent_write_log;
	for (i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			tm_rlog_generic_record(vm->read_log, TMI_WLOG, item, 0);
			return item->value;
		}
	}
	return NULL;
}

static inline scm_value * tm_wlog_check_cons(struct scm_vm * vm, struct scm_value * pair, int part)
{
	return tm_wlog_check(vm, (scm_env *)pair, (part == 0 ? scm_const_car_part : scm_const_cdr_part));
}

/* tries to update record in writelog, if successful returns 1, otherwise 0 */
static inline int __update_wlog(tm_write_log * log, scm_env * env, scm_value * key, scm_value * value)
{
	for (int i = 0; i < log->size; i++) {
		tm_write_log_item * item = log->table[i];
		if ((item->env == env) && (SCM_SYMBOL_EQ(key, item->key))) {
			g_atomic_int_inc(&(item->version));
			item->value = value;
			return 1;
		}
	}
	return 0;
}

static inline void tm_wlog_add_record(tm_write_log * log, tm_write_log_item * log_item)
{
	if (log->size + 1 >= log->capacity) tm_wlog_resize(log, log->capacity * 2);
	log->table[log->size++] = log_item;
	if (SCM_PRE_BOUND(log_item->key)) log->naughty++;
}

static inline void __update_env(struct scm_vm * vm, tm_write_log_item * log_item)
{
	scm_env * env = log_item->env;
	struct env_item * item = scm_env_get_item(env, log_item->key);

	if (item != NULL) {
		struct scm_vm * owner = (struct scm_vm *)g_atomic_pointer_get(&(env->epoch->vm));
		if ((vm->parent == NULL) || (owner == vm)) {
				g_atomic_pointer_set(&(item->value), log_item->value);
				g_atomic_int_inc(&(env->version));
				log_item->committed = env->version;
		} else {
			tm_write_log * log = vm->write_log;
			if (__update_wlog(log, env, log_item->key, log_item->value)) return;
			tm_wlog_add_record(log, log_item);
		}
	}
}

static void tm_wlog_commit(struct scm_vm * vm, tm_write_log * log) 
{
	int i;
	for (i = 0 ; i < log->size; i++) {
		scm_value * key = log->table[i]->key;
		scm_value * value = log->table[i]->value;

		if (log->table[i]->object_type == TMI_ENV) __update_env(vm, log->table[i]);

		if (log->table[i]->object_type == TMI_CONS) {
			scm_value * pair = (scm_value *)(log->table[i]->env);

			if (((pair->epoch == NULL) && (vm->runtime->main_vm == vm))
			                        || (pair->epoch->vm == vm)) {
				if (SCM_SYMBOL_EQ(key, scm_const_car_part)) SCM_PAIR(pair).ar = value;
				else SCM_PAIR(pair).dr = value;
				g_atomic_int_inc(&(pair->version));
			} else {
				tm_wlog_add_record(log, log->table[i]);
			}
		}

		if (log->table[i]->object_type == TMI_VECTOR) {
			scm_value * vector = (scm_value *)(log->table[i]->env);
			if (((vector->epoch == NULL) && (vm->runtime->main_vm == vm))
					|| (vector->epoch->vm == vm)) {
				SCM_VECTOR(vector)->items[SCM_INT(key)] = value;
				g_atomic_int_inc(&(vector->version));
			} else {
				tm_wlog_add_record(log, log->table[i]);
			}
		}
	}
	if (log->size) g_atomic_int_add(&(vm->runtime->clk), 1);
}

static void tm_wlog_resize(tm_write_log * log, int new_capacity)
{
	if (log->capacity >= new_capacity) return;
	log->table = GC_REALLOC(log->table, sizeof(tm_write_log_item *) * new_capacity);
	log->capacity = new_capacity;
}


static tm_read_log_item * __rlog_search(tm_read_log_item * h, void * object);
static inline void tm_wlog_record(struct scm_vm * vm, struct scm_env * env, struct scm_value * key, struct scm_value * value, unsigned char object_type)
{

	if (__update_wlog(vm->write_log, env, key, value)) return;

	tm_write_log_item * item = GC_MALLOC(sizeof(tm_write_log_item));
	item->env = env;
	item->key = key;
	item->value = value;
	item->version = 0;
	item->owner = vm;
	item->object_type = object_type;

	tm_wlog_add_record(vm->write_log, item);
}

static inline void tm_wlog_record_cons(struct scm_vm * vm, struct scm_value * pair, int part, struct scm_value * value)
{

	if (((pair->epoch == NULL) && (vm->runtime->main_vm == vm))
			|| (pair->epoch->vm == vm)) {
		g_atomic_int_inc(&(pair->version));
		if (part == 0) SCM_PAIR(pair).ar = value;
		else SCM_PAIR(pair).dr = value;
		return;
	}

	tm_wlog_record(vm, (struct scm_env *) pair, part == 0 ? scm_const_car_part : scm_const_cdr_part, value, TMI_CONS);
}

static inline void tm_wlog_record_vector(struct scm_vm * vm, struct scm_value * vector, struct scm_value * index, struct scm_value * value)
{
	if (((vector->epoch == NULL) && (vm->runtime->main_vm == vm))
			|| (vector->epoch->vm == vm)) {
		SCM_VECTOR(vector)->items[SCM_INT(index)] = value;
		return;
	}

	tm_wlog_record(vm, (struct scm_env *) vector, index, value, TMI_VECTOR);
}

static tm_write_log * tm_wlog_create_parent_wlog(struct scm_vm * parent_vm)
{
	int i, j;
	tm_write_log * log = parent_vm->write_log;
	tm_write_log * parent_log = parent_vm->parent_write_log;
	tm_write_log * result = tm_wlog_new(log->size + parent_log->size + 1);

	for (i = 0; i < log->size; i++)
		result->table[result->size++] = log->table[i];

	for (i = 0; i < parent_log->size; i++) {
		if (parent_log->table[i]->committed) continue;
		int overriding = 0;
		for (j = 0; j < log->size; j++) {
			tm_write_log_item * item = log->table[j];
			if (item->env == parent_log->table[i]->env) {
				if ((SCM_TYPE(item->key) == SYMBOL)
						&& (SCM_SYMBOL_EQ(parent_log->table[i]->key, item->key)))  {
					overriding = 1;
					break;
				}
				else if ((SCM_TYPE(item->key) == INT)
						&& (SCM_INT(parent_log->table[i]->key) == SCM_INT(item->key)))  {
					overriding = 1;
					break;
				}
			}
		}
		if (!overriding) result->table[result->size++] = parent_log->table[i];
	}
	return result;
}

/* returns 1 if write logs contains modified global symbol */
static inline int tm_wlog_naughty(tm_write_log * log)
{
	return log->naughty;
}

//
// READ LOGS
//

static inline void __rlog_node_buffer_create(tm_read_log * log)
{
	log->node_buffer = GC_MALLOC(sizeof(tm_read_log_item) * (RLOG_NODE_BUF_SIZE ));
	log->node_buffer_pos = 0;
}

#define RB_RED  (1)
#define RB_BLACK        (0)
#define RB_IS_RED(__x)  ((__x) == NULL ? 0 : ((__x)->color == RB_RED))

static tm_read_log_item * __rlog_insert_node (tm_read_log * log, tm_read_log_item * h, void * object, int type, int ver, int owned)
{
	if (h == NULL) {
		log->size++;
		if (log->node_buffer_pos == RLOG_NODE_BUF_SIZE) __rlog_node_buffer_create(log);
		tm_read_log_item * n = log->node_buffer + log->node_buffer_pos;
		log->node_buffer_pos++;
		n->value.generic = object;
		n->type = type;
		n->version = ver;
		n->color = RB_RED;
		n->owned = owned;
		return n;
	}

	if (RB_IS_RED(h->left) && RB_IS_RED(h->right)) { /* color flip */
		h->color = !h->color;
		h->left->color = !h->left->color;
		h->right->color = !h->right->color;
	}

	if (h->value.generic == object) {
		h->type = type;
		h->version = minimum(h->version, ver);
	}

	else if (h->value.generic < object)  h->left = __rlog_insert_node(log, h->left, object, type, ver, owned);
	else h->right = __rlog_insert_node(log, h->right, object, type, ver, owned);

	if (RB_IS_RED(h->right) && !RB_IS_RED(h->left)) { /* rotate left */
		tm_read_log_item * x = h->right;
		h->right = x->left;
		x->left = h;
		x->color = x->left->color;
		x->left->color = RB_RED;
		h = x;
	}
	if (RB_IS_RED(h->left) && RB_IS_RED(h->left->left)) { /* rotate right */
		tm_read_log_item * x = h->left;
		h->left = x->right;
		x->right = h;
		x->color = x->right->color;
		x->right->color = RB_RED;
		h = x;

	}
	return h;
}


static tm_read_log * tm_rlog_new(int size) 
{
	tm_read_log * result = GC_MALLOC(sizeof(tm_read_log));
	result->root = NULL;
	__rlog_node_buffer_create(result);
#ifdef USE_RLOG_CACHE
	result->rlog_cache = GC_MALLOC(sizeof(void *) * RLOG_CACHE_SIZE);
#endif
	return result;
}
#define PTR_TO_HASH(x)	((unsigned int)((unsigned long)x >> 3) * 5531)

/* returns 1 if the object is already in the cache */
#ifdef USE_RLOG_CACHE
static inline int tm_rlog_mark_in_cache(tm_read_log * log, void * obj)
{
	int ix = PTR_TO_HASH(obj) % RLOG_CACHE_SIZE;
	while (1) {
		if (log->rlog_cache[ix] == obj) return 1;
		else if (log->rlog_cache[ix] == NULL) break;
		else {
			ix++;
			ix %= RLOG_CACHE_SIZE;
		}
	}

	if (log->rlog_cache_size > RLOG_CACHE_TRESHOLD) {
		for (int i = 0; i < RLOG_CACHE_SIZE; i++)
			log->rlog_cache[i] = NULL;
		ix = PTR_TO_HASH(obj) % RLOG_CACHE_SIZE;
		log->rlog_cache_size = 0;
	}
	log->rlog_cache[ix] = obj;
	log->rlog_cache_size++;
	return 0;
}
#endif

static inline void tm_rlog_generic_record(tm_read_log * log, int type, void * object, int owned)
{
	int ver = 0;
#ifdef USE_RLOG_CACHE
	if (tm_rlog_mark_in_cache(log, object)) return;
#endif
	if (type == TMI_ENV) {
		ver = g_atomic_int_get(&((scm_env *)object)->version);
	}
	if (type == TMI_WLOG) {
		ver = g_atomic_int_get(&((tm_write_log_item *)object)->version);
	}

	log->root = __rlog_insert_node(log, log->root, object, type, ver, owned);
	log->root->color = RB_BLACK;
}

static inline void tm_rlog_record_env(struct scm_vm * vm, void * object, int owned)
{
	tm_rlog_generic_record(vm->read_log, TMI_ENV, object, owned);
}

static inline void tm_rlog_record_cons(struct scm_vm * vm, void * object)
{
	/* FIXME: TMI_ENV se pouziva i pro consy => muze to byt pruser */
	tm_rlog_generic_record(vm->read_log_cons, TMI_ENV, object, 0); 
}

static tm_read_log_item * __rlog_search(tm_read_log_item * h, void * object)
{
	if ((h == NULL) || (h->value.generic == object)) return h;
	if (h->value.generic < object) return __rlog_search(h->left, object);
	return __rlog_search(h->right, object);

}

static void __rlog_paste_parent(struct scm_vm * vm, tm_read_log * master, tm_read_log * slave, tm_read_log_item * slave_node)
{
	if (slave_node == NULL) return;
	if ((slave_node->type == TMI_ENV) && (slave_node->value.env->epoch->vm == vm)) {
		goto skip;
	}
	if ((slave_node->type == TMI_WLOG) && (slave_node->value.wlog->owner == vm)) {
		goto skip;
	}


	tm_read_log_item * x = __rlog_search(master->root, slave_node->value.generic);
	if (x == NULL) {
		//master->root = __rlog_insert_node(master, master->root, slave_node->value.generic, slave_node->type, slave_node->version, slave_node->owned);
		master->root = __rlog_insert_node(master, master->root, slave_node->value.generic, slave_node->type, slave_node->version, slave_node->owned);
		master->root->color = RB_BLACK;
	} else {
		x->version = minimum(x->version, slave_node->version);
	}
skip:
	__rlog_paste_parent(vm, master, slave, slave_node->left);
	__rlog_paste_parent(vm, master, slave, slave_node->right);
}

static void tm_rlog_paste_parent_log(struct scm_vm * master, struct scm_vm * slave)
{
	__rlog_paste_parent(master, master->read_log, slave->read_log, slave->read_log->root);
	__rlog_paste_parent(master, master->read_log_cons, slave->read_log_cons, slave->read_log->root);
}

//
// COMMON
//

/*
 * returns 1 if transacations collidates
 */
static int tm_check_collision(tm_read_log * slave_read_log, tm_write_log * master_write_log)
{
	int i;
	for (i = 0; i < master_write_log->size; i++) {
		tm_read_log_item * x = __rlog_search(slave_read_log->root, master_write_log->table[i]->env);
		if (x) {
			return 1;
		}
	}
	return 0;
}

static int __rlog_adv_collision(struct scm_vm * vm, tm_read_log_item * h)
{
	if (h == NULL) return 0;
	version_t v1 = -1;
	version_t v2 = h->version;

	if (h->type == TMI_WLOG) {
		v1 = h->value.wlog->version;

		if (h->value.wlog->committed) { 
			int x1 = h->value.wlog->env->version;
			int x2 = h->value.wlog->committed;
			if (x1 > x2) {
				return 1;
			}
		}
	}
	if (h->type == TMI_ENV) v1 = h->value.env->version;
	if (v1 > v2) {
		return 1;
	}

	if (__rlog_adv_collision(vm, h->left)) return 1;
	if (__rlog_adv_collision(vm, h->right)) return 1;

	return 0;
}

static int tm_check_collision_advanced_edition(struct scm_vm * vm)
{
	int clk = g_atomic_int_get(&(vm->runtime->clk));
	int a = 0;
	if (clk != vm->start_clk) {
		a = __rlog_adv_collision(vm, vm->read_log->root)
			|| __rlog_adv_collision(vm, vm->read_log_cons->root);
	}
	return a;
}

static inline scm_value * tm_pair_get_generic(struct scm_vm * vm, scm_value * pair, int part)
{
	scm_value * result = NULL;
	if (((pair->epoch == NULL) && (vm->runtime->main_vm == vm))
			|| ((pair->epoch != NULL) && (pair->epoch->vm == vm))) {
		return (part == 0 ? SCM_CAR(pair) : SCM_CDR(pair));
	}

	result = tm_wlog_check_cons(vm, pair, part);
	if (result == NULL) result = (part == 0 ? SCM_CAR(pair) : SCM_CDR(pair));
	tm_rlog_record_cons(vm, pair);
	return result;
}
#endif
