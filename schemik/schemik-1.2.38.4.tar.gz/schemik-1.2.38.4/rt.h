/*
 * Schemik -- Implicitly Parallel Scheme
 *
 * Copyright (C) 2006-2008 Petr Krajca <krajcap@inf.upol.cz>
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

#ifndef RT_H
#define RT_H
#include "config.h"

#include "mutex.h"
#include "types.h"
#include "env.h"

#ifdef USE_THREAD_POOLING
#include "thread_pool.h"
#endif

struct scm_vm;
struct scm_rt;
struct command;

typedef void (*scm_scheduler)(struct scm_rt * rt, struct scm_vm * vm);

typedef struct scm_rt {
	scm_env * env;
	struct scm_vm * main_vm;
	mutex_t lock;
	volatile int sched_count;
	unsigned short max_threads;
	unsigned int scheduler_limit;
	struct thread_log * log;
	scm_scheduler scheduler;
#ifdef USE_THREAD_POOLING
	thread_pool * th_pool;
#endif
#ifdef USE_STM
	volatile int clk;
#endif
} scm_rt;


scm_rt * rt_new(unsigned short max_threads, scm_scheduler scheduler);
scm_value * rt_eval(scm_rt * rt, scm_value * value);
scm_value * rt_eval_str(scm_rt * rt, char * str);
void rt_schedule_fevals(scm_rt * rt, struct scm_vm * vm);
void rt_lock(scm_rt * rt);
void rt_unlock(scm_rt * rt);

void backward_scheduler(scm_rt * rt, struct scm_vm * vm);
void forward_scheduler(scm_rt * rt, struct scm_vm * vm);
#endif
