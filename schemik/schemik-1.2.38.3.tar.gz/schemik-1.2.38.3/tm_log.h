#ifndef TM_LOG_H
#define TM_LOG_H

#include "env.h"
#include "types.h"

#define TMI_ENV         (1)
#define TMI_WLOG        (2)

//struct scm_env;
struct scm_value;
struct scm_vm;

typedef struct tm_write_log_item {
	struct scm_value * key;
	struct scm_value * value;
	struct scm_env * env;
	volatile version_t version;
	int committed;
	struct scm_vm * owner;
} tm_write_log_item;

typedef struct tm_write_log {
	struct tm_write_log_item ** table;
	int capacity;
	int size;
	int naughty;
} tm_write_log;

typedef struct tm_read_log_item {
	int color;
	int type;
	struct tm_read_log_item * left;
	struct tm_read_log_item * right;
	union {
		scm_env * env;
		tm_write_log_item * wlog;
		void * generic;
	} value;
	//version_t version;
	int version;
} tm_read_log_item;

#define RLOG_NODE_BUF_SIZE	(1000)

typedef struct tm_read_log {
	/* REMOVEME
	tm_read_log_item ** table;
	int size;
	int capacity;
	*/
	tm_read_log_item * root;
	tm_read_log_item * node_buffer;
	int node_buffer_pos;
} tm_read_log;


#define TS_SCM_CAR(vm, pair) (tm_pair_get_generic(vm, pair, 0))
#define TS_SCM_CDR(vm, pair) (tm_pair_get_generic(vm, pair, 1))

#endif
