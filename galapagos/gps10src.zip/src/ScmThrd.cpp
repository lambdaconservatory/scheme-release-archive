// SCMTHRD.cpp - Threads for SCM

#include "stdafx.h"
#include "Shell.h"
#include "ShellDoc.h"
#include "ShellView.h"
#include "MsgQ.h"
#include "comb.h"
#include "GCd.h"

#include "mydebug.h"
#include "scm.h"
#include "ScmThrd.h"


/* This is used to force a check for UrgentMessages during calculations: */
#define POLL_COUNT_MAX  1000L
THREAD unsigned int poll_count = POLL_COUNT_MAX;   

#ifdef TC16_THREAD	    
# define tc16_thread TC16_THREAD
#else
long tc16_thread;
#endif

// MakeThreadObj creates a SCM Thread smob on the heap and set cur_thread_obj to it.
// It is in the initialization of a SCM thread.
void MakeThreadObj()
{
	cur_thread_obj = cons(tc16_thread, (SCM)(TheCombination.pTheInputQueue));
}

// KillThreadObj is called after a SCM thread dies. 
// This will make all references to this cur_thread_obj get it as a dead thread.
void KillThreadObj()
{
	THRDQ(cur_thread_obj)=NULL;
}


// ---------- Threads primities -------------------------

static SCM __cdecl is_1st_thread_p()    { return IsFirstSCMThread? BOOL_T:BOOL_F; } 

static SCM __cdecl this_thread()
{
	return cur_thread_obj;
}

static int __cdecl print_thread(SCM exp, SCM port, int writing)
{
	if (CDR(exp)==NULL)
		lputs ("#<dead thread>", port);
	else
	{
		lputs("#<thread 0x", port);
		
		intprint(HIWORD(THRDQ(exp)), 16, port);
 		intprint(LOWORD(THRDQ(exp)), 16, port);
		lputc('>', port);
	}
	return !0;
}

static SCM __cdecl thread_p(SCM x)
{
	return THREADP(x)? BOOL_T:BOOL_F;
}

static SCM __cdecl active_threads()
{
	return MAKINUM(Threads);
}

extern CShellApp theApp;
extern CShellView* MeanWhile_TheActiveView;
extern "C" extern THREAD int dblprec;

#define myname "new-thread"
static SCM __cdecl m_new_thread(SCM args, SCM env)
{
	ASSERT(NNULLP(CDR(args)), args, WNA, myname);
	//theApp.m_pInterpreterDocTemplate->OpenDocumentFile(NULL);
	CCombTransfer* xfer = new CCombTransfer;

	xfer->comb=TheCombination;
	xfer->sys_protects=new long [num_protects];
	for (size_t i=0; i<num_protects; i++) xfer->sys_protects[i]=sys_protects[i];
	xfer->dblprec=dblprec;

	args=CDR(args);
	xfer->form=cons(IM_BEGIN,args);
	xfer->env=env;
	
	CMessageQueue Q; 
	xfer->returnQ = &Q;

	CWinThread* pWT=
		AfxBeginThread (SCM_SubThread,(LPVOID)xfer);
	
	CMessage msg;
	Q.Get(msg);
	return msg.msg;
}
#undef myname

// (break& form form form) - Breaks the thread (by calling
// (abort) and evaluates the forms in the thread base env

#define myname "break&"
extern "C" extern SCM abrt();
static SCM __cdecl m_break_and(SCM args, SCM env) 
{
	args=CDR(args);
	if (1 < ilength(args)) args=cons(IM_BEGIN, args);
	startup_form=args;
	return abrt();
}
#undef myname

// --------------- console (CShellView) primitives ---------------

static SCM __cdecl bound_to_console_p() { return IsBoundToConsole? BOOL_T:BOOL_F; }

#define myname "bind-to-console"
static SCM __cdecl bind_console()
{
	if (IsBoundToConsole ||
		(TheCombination.pTheView!=NULL)) return BOOL_F;
	CMessageQueue Q;
	CString Title;
	Title.Format("SCM interpreter 0x%X", THRDQ(cur_thread_obj));
	TheOutputQueue.Post(CMessage(MSG_OPEN_CONSOLE, (DWORD)(&Title), &Q));
	CMessage msg;
	Q.Get(msg);
	TheCombination.pTheView=(CShellView*)msg.ptr;
	TheCombination.pTheView->m_pCombination= &TheCombination;
	IsBoundToConsole=1;
	return BOOL_T;
}
#undef myname	

#define myname "unbind-console"
SCM __cdecl unbind_console()
{ 
	if ((!IsBoundToConsole) ||
		(TheCombination.pTheView==NULL)) return BOOL_F;
	ASSERT(!IsFirstSCMThread, UNDEFINED, "can't unbind main thread", myname);
	IsBoundToConsole=0;
	CMessageQueue Q;
	TheOutputQueue.Post(CMessage(MSG_CLOSE_CONSOLE, (DWORD)TheCombination.pTheView, &Q));
	CMessage msg;
	Q.Get(msg);

	return BOOL_T;
}
#undef myname	

#define myname "rename-console"
static SCM __cdecl rename_console(SCM name)
{
	ASSERT (SYMBOLP(name) || STRINGP(name), name, ARG1, myname);
	CString* pS=new CString(CHARS(name));
	TheOutputQueue.Post(CMessage(MSG_SETNAME_TXTWIN, (DWORD)pS, (DWORD)TheCombination.pTheView));
	return UNSPECIFIED;
}
#undef myname

//---------------- Quitting --------------

#define myname "quit-thread"
static SCM __cdecl quit_thread()
{
	ASSERT(!IsFirstSCMThread, UNDEFINED, "can't quit-thread from main thread", myname);
	return quit(MAKINUM(EXIT_SUCCESS));
}
#undef myname	

#define myname "quit-program"
static SCM __cdecl quit_program()
{
	ASSERT(IsFirstSCMThread, UNDEFINED, "quit-program - only from main thread", myname);
	ASSERT(Threads==1, UNDEFINED, "subthreads are still running", myname);
	return quit(MAKINUM(EXIT_SUCCESS));
}
#undef myname	

//---------------- Urgentmessage handling ---------------

// (install-handler f) takes a function f/1, and installs is as the thread's umsg handler.
// It returns the old handler. The initial handler, nil, means ignore umessags.
// When a umsg arrives, the handler is called with the new message as a sole argument.
// (by HandleUrgentMessageSCM)

static SCM __cdecl get_handler()        { return urgentmessages_handler;          }

#define myname "install-handler"
static SCM __cdecl install_handler(SCM proc)
{
	ASSERT(CELLP(proc) && CLOSUREP(proc), proc, ARG1, myname);
	
	/* Check that argument list of proc can match 1 arg. - copied from eval. ceval*/
	SCM x = CAR(CODE(proc));
	ASSERT(NIMP(x), proc, "handler function must take 1 argument", myname);
	if CONSP(x) 
	{
		x = CDR(x);
		ASSERT(NULLP(x) || NCONSP(x), proc, "handler function must take 1 argument", myname);
	}
	x = urgentmessages_handler;
	urgentmessages_handler = proc;
	return x;
}
#undef myname

// (tell-thread th x) is a very badly named function, to send the thread th the urgentmessage x;
// Returns #t if sent, or #f if th is already dead meat.

#define myname "tell-thread"
static SCM __cdecl send_thrd_umsg(SCM th, SCM umsg)
{
	ASSERT(THREADP(th), th, ARG1, myname);

	CMessageQueue* hisQ = (CMessageQueue*)THRDQ(th);
	if (hisQ == NULL) return BOOL_F;
	hisQ->PostUrgent(CMessage(0,MSGMSG_SCMURGENT,umsg));
	return BOOL_T;
}


// HandleUrgentMessageSCM is called whenever a SCM thread recieves a SCM urgent message.
// the argument is a SCM object which is passed to the Scheme special handler
// (it is called by HandleUrgentMessage from within the CMessageQueue::Get*)

void HandleUrgentMessageSCM(SCM umsg)
{
	if NIMP(urgentmessages_handler)
		apply(urgentmessages_handler, umsg, listofnull);
}

// poll_routine is called from ceval() once every POLL_COUNT_MAX times ceval is 
// called (including the tail-recursion gotos). We use it to allow recieving of
// UrgentMessages during calculations. 

extern "C" void poll_routine()
{
	poll_count=POLL_COUNT_MAX;
	while (TheCombination.pTheInputQueue->UrgentMessagesWaiting())
	{
		CMessage msg;
		TheCombination.pTheInputQueue->CMsgQx::Get(msg);
		HandleUrgentMessage(msg);
	}
}



//-----------------------------


static smobfuns thread_smob = 
{ 
	(SCM(__cdecl*)(SCM)) mark0, 
	(sizet(__cdecl*)(CELLPTR)) free0, 
	(int(__cdecl*)(SCM,SCM,int))print_thread, 
	0 
};
	
#define FIXF(_f) ( (SCM(__cdecl*)())(_f) )

static iproc subr0s[] = {
	{"this-thread", FIXF(this_thread)},
	{"active-threads", FIXF(active_threads)},
	{"bind-to-console", FIXF(bind_console)},
	{"bound-to-console?", FIXF(bound_to_console_p)},
	{"unbind-console", FIXF(unbind_console)},
	{"quit-thread", FIXF(quit_thread)},
	{"quit-program", FIXF(quit_program)},
	{"is-first-thread?", FIXF(is_1st_thread_p)},
	{"get-handler", FIXF(get_handler)},
	{0,0} };
	
static iproc subr2s[] = {
		{"tell-thread", FIXF(send_thrd_umsg)},
		{0,0}};
					
static iproc subr1s[] = {
				{"thread?", FIXF(thread_p)},
				{"rename-console", FIXF(rename_console)},
				{"install-handler", FIXF(install_handler)},
				{0,0} };
/*				
static iproc subr1os[] = {
					{0,0} };

*/


extern "C" SCM make_synt(char *name, SCM (*macroizer)(), SCM (*fcn)()); /*eval.c*/


extern "C" void init_thread()
{ 
	urgentmessages_handler = EOL;
#ifndef TC16_THREAD
	tc16_thread = 
#endif
		newsmob (&thread_smob);
	init_iprocs(subr0s, tc7_subr_0);
	init_iprocs(subr1s, tc7_subr_1);
	init_iprocs(subr2s, tc7_subr_2);
//	init_iprocs(subr1os, tc7_subr_1o);
	make_synt("new-thread", FIXF(makacro), FIXF(m_new_thread));
	make_synt("break&", FIXF(makacro), FIXF(m_break_and));
/*
	init_iprocs(subr2os, tc7_subr_2o);
	init_iprocs(lsubrs, tc7_lsubr);
	*/
	MakeThreadObj();
	bind_console();
	GCNotifyThreadStarts(cur_thread_obj);
}



//---------------------- NON-SCM FUNCTIONS -------------------------

// ThrdwiseSleep() is our implementation of sleep which handles urgentmessages.

extern "C" void ThrdwiseSleep(int seconds) // Accuracy is not the name of the game...
{ 
	CMessage msg;

	TheCombination.pTheInputQueue->GetByType(msg, MSG_NEVERUSED, seconds);
}

