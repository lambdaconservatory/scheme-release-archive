/* scm4win.c */

#include <windows.h>


extern void init_msgq();
extern void init_gfx();
extern void init_explicit();
extern void init_thread();

int init_stuff()
{

	init_explicit(); /* Explicit enviroments; also sets base env */
	init_msgq();     /* Message queues */
	init_gfx();      /* Turtles, views */
	init_thread();   /* Threads */
	return 0;
}


