
// BoardView.cpp : implementation of the CBoardView class
#include "stdafx.h"
#include "Board.h"
#include "Shell.h"
#include "MainFrm.h"
#include "BoardDoc.h"
#include "BoardView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <stdlib.h>
#include <math.h>
#include "MsgQ.h"
#include "TurtleMsg.h"
#include "messages.h"
#include "Colors.h"
#include "Threads.h"
//#include "error.h"
/////////////////////////////////////////////////////////////////////////////
// CBoardView

IMPLEMENT_DYNCREATE(CBoardView, CScrollView)

BEGIN_MESSAGE_MAP(CBoardView, CScrollView)
	//{{AFX_MSG_MAP(CBoardView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_NEW, OnNew)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_TIMER()
	ON_COMMAND(ID_FILE_OPENBITMAP, OnOpenBitmap)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBoardView construction/destruction

extern CShellApp theApp;

CBoardView::CBoardView()
{ 
   m_pMyQueue = &TheOutputQueue;           // the global message queue
   m_LinePen.CreatePen(PS_SOLID, 2, COLOR_BLUE);
   CMessage Msg;
   Msg.type = MSG_TYPE_NEW_VIEW;   // I'm alive
   Msg.ptr = this;
   m_pMyQueue->Post(Msg);
   m_Alive = TRUE;
   m_BgColor = COLOR_WHITE;
   m_MaxX = MAX_BOARD_X;
   m_MaxY = MAX_BOARD_Y;

   m_pUserIntQ = NULL;
   m_UserIntMsg = 0;
   m_ppDeathIndicator = NULL;
}

CBoardView::~CBoardView()
{  	m_Alive = FALSE;
	for (int i=0;i<m_Turtles.GetSize();i++) delete m_Turtles[i];
	m_Turtles.RemoveAll();  // cleaning the array
    if (m_ppDeathIndicator && *m_ppDeathIndicator) *m_ppDeathIndicator = NULL; 
	delete m_pBitMap;
}

/////////////////////////////////////////////////////////////////////////////
// CBoardView drawing

void CBoardView::OnDraw(CDC* pDC)
// Redrews the picture on given CDC
{ 	pDC->BitBlt(0, 0, m_MaxX, m_MaxY, &m_ThePicture, 0, 0, SRCCOPY);  // just copy the bitmap
  	DrawTurtles(pDC);  // draw all the turtles on it
}

void CBoardView::OnInitialUpdate()
{

	CSize sizeTotal;
		 // Adjusting the scrolling
	sizeTotal.cx = m_MaxX;
	sizeTotal.cy = m_MaxY;
	SetScrollSizes(MM_TEXT, sizeTotal);
	SetScrollRange(SB_HORZ, 0, m_MaxX-1);
	SetScrollRange(SB_VERT, 0, m_MaxY-1);
		
	CScrollView::OnInitialUpdate();
	
       
	   // Creating the bitmap
    CDC *pDC = GetDC();
	m_ThePicture.CreateCompatibleDC(pDC);   // connecting the bitmap to the view
	m_pBitMap = new CBitmap;
	m_pBitMap->CreateCompatibleBitmap(pDC, m_MaxX, m_MaxY);
	m_ThePicture.SelectObject(m_pBitMap); 
	m_ThePicture.FillSolidRect(0,0, m_MaxX, m_MaxY, m_BgColor);	// fill it with color
	ReleaseDC(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CBoardView diagnostics

#ifdef _DEBUG
void CBoardView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CBoardView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CBoardDoc* CBoardView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBoardDoc)));
	return (CBoardDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBoardView message handlers

BOOL CBoardView::RefreshPicture(CPoint From, CPoint To, CDC *pDC)
// Refrshs the picture, in the rectangle From, To (upper left and lower right)
// Input coordinates are in bitmap-relative
{ int Flag = 0;
  if (pDC == NULL) 
  { pDC = GetDC();
    Flag = 1;
  }

  RECT Rectom;
  CPoint Scroll = GetScrollPosition();
  Rectom.left = __min(From.x, To.x) - Scroll.x;
  Rectom.top = __min(From.y, To.y)  - Scroll.y;
  Rectom.left -= REFRESH_BOX_ERROR;
  Rectom.top -= REFRESH_BOX_ERROR;
   
  Rectom.right = __max(From.x, To.x) - Scroll.x;
  Rectom.bottom = __max(From.y, To.y) - Scroll.y;
  Rectom.right += REFRESH_BOX_ERROR;
  Rectom.bottom += REFRESH_BOX_ERROR;


  pDC->GetWindow()->InvalidateRect(&Rectom, FALSE);
  if (Flag) ReleaseDC(pDC);
 	
  return TRUE;
}


BOOL CBoardView::RefreshPicture(RECT Rectom)
// Refrshes the picture in a given rectangle
// The rectangle in windowise coordinated
{ CDC *pDC = GetDC();
  
  Rectom.left -= REFRESH_BOX_ERROR;
  Rectom.top -= REFRESH_BOX_ERROR;
  Rectom.right += REFRESH_BOX_ERROR;
  Rectom.bottom += REFRESH_BOX_ERROR;

  pDC->GetWindow()->InvalidateRect(&Rectom, FALSE);
  ReleaseDC(pDC);
  
  CPoint Scroll = GetScrollPosition();

  return TRUE;
}


CTurtle *CBoardView::NewTurtle(void *UserInner, double Heading, COLORREF Color, UINT Width)
// Creates a new turtle, returns the turtles pointer
{ CTurtle *T = new CTurtle(this, &m_ThePicture,UserInner,Heading,Color,Width, m_BgColor);
  if (!T) return NULL; 
  m_Turtles.Add(T);	   // Adding it to the turtles array
  return T;
}

  
#define MAX_NUMBER_LENGTH 30
CString CBoardView::TurtleInfoMessage(UINT Id, CPoint Position, double Heading)
// Returns a CString that holds the turtles info
{ double foo = Heading;
  foo +=90;
  if (foo > 360) foo -= 360;
    
  CString S;
  S.Format("Turtle %d\nPositon %d,%d\nHeading %f", Id, Position.x, Position.y, foo);
  return S;
}

BOOL CBoardView::DrawTurtles(CPoint UL, CPoint DR)
// Draw all the turtrles inside a rectangle (UL = upper left corner, DR = down right)
{ CDC *pDC = GetDC();
  CPoint Scroll = GetScrollPosition();  
  SetPolyFillMode(pDC->GetSafeHdc(), WINDING);
  
  for (int i = m_Turtles.GetSize() -1; i>=0; i--)
  if (m_Turtles[i]->InRect(UL, DR)) 
  m_Turtles[i]->_Draw(Scroll, pDC); 
  ReleaseDC(pDC);
  
  return TRUE;
}

#undef MAX_NUMBER_LENGTH

BOOL CBoardView::DrawTurtles(CDC *pDC)
// Redraws all the turtles
{ SetPolyFillMode(pDC->GetSafeHdc(), WINDING);
  CPoint Scroll = GetScrollPosition();
  for (int i=0;i<m_Turtles.GetSize();i++)
	  m_Turtles[i]->_Draw(CPoint(0,0), pDC);
  
  
  return TRUE;

}

CTurtle * CBoardView::WhichTurtle(CMessage Msg)
// returns the turtle pointer in the Msg
{ return (CTurtle *)(Msg.msg);
}

BOOL CBoardView::SendMessage(CTurtle *pT, UINT Command = MSG_CMD_ERROR, LONG Param)
// send a message
{  CTurtle_Msg *pTMsg;
   pTMsg = new CTurtle_Msg(Command, Param);
   m_pMyQueue->Post(CMessage(MSG_TYPE_TURTLE, DWORD(pTMsg), DWORD (pT)));
   return TRUE;									   
}

void CBoardView::OnLButtonDown(UINT nFlags, CPoint point) 
// start drawing, act according to the m_DrawShape flag
{ 	CPoint Scroll = GetScrollPosition();
    RECT Rectom;
	CRectTracker TRect;
	CDC *pDC;
	m_LastUserPoint = point;
	m_LastUserPoint.Offset(Scroll);
	switch (theApp.m_pMainFrame->m_DrawShape)
	{ case DRAW_FREE: SetCapture();
                      m_ThePicture.SelectObject(theApp.m_pMainFrame->m_pUserPen);    // the user pen   
	                  point.Offset(Scroll);
	                  m_LastUserPoint = point;
					  return;

	  case DRAW_LINE: SetCapture();
                      m_ThePicture.SelectObject(theApp.m_pMainFrame->m_pUserPen);    // the user pen   
                      pDC = GetDC();
		              m_pOldPen = pDC->SelectObject(&m_LinePen);
			          m_LastUserPoint = point;
					  pDC->MoveTo(point);
					  ReleaseDC(pDC);
					  return;
		  
	  case DRAW_RECT: m_ThePicture.SelectObject(theApp.m_pMainFrame->m_pUserPen);    // the user pen   
		              if (TRect.TrackRubberBand(this, point));
					  { TRect.GetTrueRect(&Rectom);
					    Rectom.right += theApp.m_pMainFrame->m_UserPenW;
						Rectom.left  -= theApp.m_pMainFrame->m_UserPenW;
						Rectom.top -= theApp.m_pMainFrame->m_UserPenW;
						Rectom.bottom += theApp.m_pMainFrame->m_UserPenW;
					    DrawRect(Rectom);
					  }
					  CallTurtlesInterrupts();//CPoint(Rectom.top, Rectom.left), CPoint(Rectom.bottom, Rectom.right));
		              return;
	  case MOVE_TURTLE:SetCapture();
				       m_pCurrT = GetCloseTurtle(point);

					   return;
	  case LOOK_AHEAD: //pDC = GetDC();         // checking the sight
		              m_pCurrT = GetCloseTurtle(point);
					  if (m_pCurrT) 
						  if(m_pCurrT->Look4Turtle(NULL, 30, 50))
					  //  if(m_pCurrT->Look4Turtle(30, 50))
						  AfxMessageBox("Gotcha", MB_OK | MB_ICONINFORMATION);
					  //ReleaseDC(pDC);
					  return;
	  case SEND_INTERRUPT: m_pCurrT = GetCloseTurtle(point);
		                   if (m_pCurrT)
							   AfxMessageBox("Interrupt");


	}  // switch
	
}

void CBoardView::OnMouseMove(UINT nFlags, CPoint point) 
// drawing
{   RECT Rectom;
	CDC *pDC;
	double Heading;
	CPoint Scroll, Location;
	
	switch (theApp.m_pMainFrame->m_DrawShape)
    { case DRAW_FREE:    if (GetCapture() == this)
	                     { Scroll = GetScrollPosition();
		                   point.Offset(Scroll);
						   m_ThePicture.MoveTo(m_LastUserPoint);
                           m_ThePicture.LineTo(point);
	                       RefreshPicture(m_LastUserPoint, point);
	                       m_LastUserPoint = point;
	                     }  
						 return;
	    case DRAW_LINE:  pDC = GetDC();
			             if (GetCapture() == this)
						 { Rectom.top = __min(point.y, m_LastUserPoint.y);  // will this delete the last line?
			               Rectom.left = __min(point.x, m_LastUserPoint.x);
						   Rectom.bottom = __max(point.y, m_LastUserPoint.y);
						   Rectom.right = __max(point.x, m_LastUserPoint.x);
						   RefreshPicture(Rectom); 		           
						   pDC->MoveTo(m_LastUserPoint);
						   pDC->LineTo(point);
						   ReleaseDC(pDC);
						  
						 }
						 return;
						 
        case DRAW_RECT:	 return;
		case MOVE_TURTLE:if ((GetCapture() == this) && m_pCurrT)
						 {  Scroll = GetScrollPosition();
			                if (nFlags & MK_CONTROL)
						   { Location = m_pCurrT->Location();
							 Location.x -= Scroll.x;
							 Location.y -= Scroll.y;
							 Heading = Angle(Location, point);
							 m_pCurrT->SetAbsHeading(Heading);
						   }
			               else
						   { point.Offset(Scroll);
						     m_pCurrT->Move2Abs(&point, FALSE);
						   }
						 } // big if 
						 return;
    }

}

void CBoardView::OnLButtonUp(UINT nFlags, CPoint point) 
// yet more drawing
{ RECT Rectom;
  CDC *pDC;
  CPoint Scroll, Location;
  double Heading;
  
  switch (theApp.m_pMainFrame->m_DrawShape)
  { case DRAW_FREE: if (GetCapture() == this)
                    { CPoint Scroll = GetScrollPosition();
	                  point.Offset(Scroll);
	                  m_ThePicture.MoveTo(m_LastUserPoint);
                      m_ThePicture.LineTo(point);
	                  RefreshPicture(m_LastUserPoint, point);
	                  ReleaseCapture();
                      break;
                    }
    case DRAW_LINE: pDC = GetDC();
		            if (GetCapture() == this)
					{ Rectom.top = __min(point.y,m_LastUserPoint.y);  // will this delete the last line?
			          Rectom.left = __min(point.x, m_LastUserPoint.x);
					  Rectom.bottom = __max(point.y, m_LastUserPoint.y);
					  Rectom.right = __max(point.x, m_LastUserPoint.x);	  
					  DrawLine(m_LastUserPoint, point);
					  RefreshPicture(Rectom);
					  pDC->SelectObject(m_pOldPen);
					  ReleaseCapture();
					  ReleaseDC(pDC);
					  break;
					}
    case DRAW_RECT:   return;
	case MOVE_TURTLE:if ((GetCapture() == this) && m_pCurrT)
						 {  Scroll = GetScrollPosition();
			                if (nFlags & MK_CONTROL)
						   { Location = m_pCurrT->Location();
							 Location.x -= Scroll.x;
							 Location.y -= Scroll.y;
							 Heading = Angle(Location, point);
							 m_pCurrT->SetAbsHeading(Heading);
						   }
						 } // big if 
						 ReleaseCapture();
		                 break;
	default: return;     // do not need to call the interrupts
  }
  
  CallTurtlesInterrupts();
}



void CBoardView::OnRButtonDown(UINT nFlags, CPoint point) 
// user or turtle interrupts
{ CMessage Msg;
  CTurtle *pT;
  pT = GetCloseTurtle(point);
  if (pT) pT->UserInterrupt();  // was next to a turtle
  else if (m_pUserIntQ) // in open space - does the view have a user interrupt
  {	Msg.type = 0;
    Msg.msg = MSGMSG_SCMURGENT;
	Msg.ptr = LPVOID(m_UserIntMsg);
	m_pUserIntQ->CMsgQx::PostUrgent(Msg);
  }
}


BOOL CBoardView::CreateTurtle(CMessageQueue *pReturn)
// Creates a new turtle
{ CTurtle *pT = NewTurtle();
  CMessage Msg;
  Msg.type = MSG_ANS_NEW_TURTLE;
  Msg.msg = 0;
  Msg.ptr = pT;

  CDC *pDC = GetDC();
  pT->_Draw(GetScrollPosition(), pDC);
  pReturn->Post(Msg);
  ReleaseDC(pDC);
  return TRUE;
}

BOOL CBoardView::AddTurtle(CTurtle *pT)
// Add a new turtle
{ m_Turtles.Add(pT);
  
  pT->NewView(this, &m_ThePicture);
  CDC *pDC = GetDC();
  pT->_Draw(GetScrollPosition(), pDC);
  ReleaseDC(pDC);
  return TRUE;

}


void CBoardView::OnNew() 
// a new default turtle
{ CreateTurtle(m_pMyQueue);
}


BOOL CBoardView::SendTurtle(CTurtle *pT, CBoardView *pV)
// Sends turtle pT to View pV and removes it from this view
{  CPoint P = pT->Location();

   int Index = GetIndex(pT);
   if (Index < 0) return FALSE;		// This turtle is not mine

   m_Turtles.RemoveAt(Index);

   CDC *pDC = GetDC();
   RefreshPicture(P,P, pDC);   // refresh the picture 
   ReleaseDC(pDC);
   pV->AddTurtle(pT);			   // send it away
   
   return TRUE;
}

int CBoardView::GetIndex(CTurtle *pT)
// finds the index of turtle pT
{ for (int i=0; i<m_Turtles.GetSize();i++)
  { if (m_Turtles[i] == pT)
	return i;
  }

  return -1;  // not found
}

BOOL CBoardView::KillTurtle(CTurtle *pT)
{ int Index = GetIndex(pT);
  if (Index < 0) return FALSE;   // not mine
  
  CPoint Location = pT->Location();
  m_Turtles.RemoveAt(Index);
  
  if (m_Alive)
  {  CDC *pDC = GetDC();
     RefreshPicture(Location, Location, pDC);
     ReleaseDC(pDC);
  }
  
  return TRUE;
}



BOOL CBoardView::DrawRect(RECT Rectom)
// Draw a rectangle on the bitmap
{  CPoint Scroll = GetScrollPosition();
   CPen *OldPen = m_ThePicture.SelectObject(theApp.m_pMainFrame->m_pUserPen);
   m_ThePicture.MoveTo(Rectom.left + Scroll.x, Rectom.top + Scroll.y);
   m_ThePicture.LineTo(Rectom.left + Scroll.x, Rectom.bottom + Scroll.y);
   m_ThePicture.LineTo(Rectom.right + Scroll.x, Rectom.bottom + Scroll.y);
   m_ThePicture.LineTo(Rectom.right + Scroll.x, Rectom.top + Scroll.y);
   m_ThePicture.LineTo(Rectom.left + Scroll.x, Rectom.top + Scroll.y);
   m_ThePicture.SelectObject(OldPen);
   RefreshPicture(Rectom);
   return TRUE;
}


BOOL CBoardView::DrawLine(CPoint Begin, CPoint End)
// Draws a line from begin to end on the bit map
{ CPoint Scroll = GetScrollPosition();
  Begin.Offset(Scroll);
  End.Offset(Scroll);
  m_ThePicture.MoveTo(Begin);
  m_ThePicture.LineTo(End);
  RefreshPicture(Begin, End);
  return TRUE;
}



CTurtle * CBoardView::GetCloseTurtle(CPoint P)
// Returns a pointer to the first close turtle to the point P, null if none exist
{ CTurtle *pT = NULL;
  CPoint Scroll = GetScrollPosition();
  int i=0;
  int flag = 0;
  
    	 
  P.Offset(Scroll);
  while ((i < m_Turtles.GetSize()) && !flag) // iterate the array
  { if (m_Turtles[i]->Close(P))
    { flag=1; 
      pT = m_Turtles[i]; 
    }
  	i++;
  } 
 
  return pT;
}

double CBoardView::Rad2Deg(double Rad)
// convert Radians to degrees
{  return (Rad / (2 * CONST_PI)) * 360;
}

double CBoardView::Angle(CPoint X, CPoint Y)
// Returns the Angle between 2 points
{ double Ans = Rad2Deg(atan2(abs(X.x - Y.x), abs(X.y - Y.y)));
  if ((X.x <= Y.x) && (X.y <= Y.y)) Ans = 180- Ans;   // 2'nd quarter
  if ((X.x >= Y.x) && (X.y < Y.y))  Ans += 180;       // 3'rd quarter
  if ((X.x > Y.x) && (X.y >= Y.y))  Ans = 360 - Ans ; // 4'th quarter

  return Ans;
}


BOOL CBoardView::DotTurtles(CPoint Base, CPoint Left, CPoint Right, UINT Distance, CPoint UL, CPoint DR, CTurtle *pAskT)
// finds if a turtle is in the given view area, if not return FALSE
{  	CPoint Loc;
	for (int i=0;i<m_Turtles.GetSize();i++)
    { if ((m_Turtles[i] != pAskT) && (m_Turtles[i]->InRect(UL, DR)))
      { Loc = m_Turtles[i]->Location();
        if ((m_Turtles[i]->Det(Base.x, Base.y, Left.x , Left.y , Loc.x, Loc.y) >= 0) &&  // inside the rays
		    (m_Turtles[i]->Det(Base.x, Base.y, Right.x, Right.y, Loc.x, Loc.y) <= 0) &&
		    (m_Turtles[i]->FindDistance(Base, Loc.x, Loc.y) <= Distance))
    	     	return TRUE;
	  } 
    }


  return FALSE;  // not found
}


#define F_ARG ((CViewOpenFileParams *)(Msg->Arg))  // open file arguments

BOOL CBoardView::ReadAndEval(CView_Msg *Msg)
// reads and operates on a message sent
{ switch (Msg->Cmd)
  {	case VMSG_CMD_SET_COLOR:  SetBgColor((COLORREF)(Msg->Arg));
		                      delete Msg;
							  return TRUE;
	case VMSG_CMD_CLS:        Cls();
			                  delete Msg;
							  return TRUE;

	case VMSG_CMD_OPEN_FILE:  GetBitMap(F_ARG->FileName, F_ARG->DestLocation,F_ARG->IsMiddle, F_ARG->AnsQ);
							  delete Msg->Arg;
							  delete Msg;
							  return TRUE;

	case VMSG_CMD_SAVE_FILE:  SaveBitMap(*((CString *)(Msg->Arg)),(CMessageQueue *)(Msg->Ptr));
		                      delete (CString *)(Msg->Arg);
							  delete Msg;
							  return TRUE;

	case MSG_CMD_USER_INT: 	  m_pUserIntQ = ((CMessageQueue *) (Msg->Ptr));
		                      m_UserIntMsg = (DWORD(Msg->Arg));
							  delete Msg;
							  return TRUE;

	case MSG_CMD_DEL_USER_INT:m_pUserIntQ = NULL;
		                      delete Msg;
							  return TRUE;
	
	case MSG_CMD_DEATH_PP:	  m_ppDeathIndicator = ((DWORD **)(Msg->Arg));
		                      delete Msg;
							  return TRUE;

    default: return FALSE;
  }
}



void CBoardView::Cls()
// Paints the board in  m_BgColor color
{ m_ThePicture.FillSolidRect(0,0, m_MaxX, m_MaxY, m_BgColor);
  RefreshPicture(CPoint(0, 0), CPoint(m_MaxX, m_MaxY));
}

UINT CBoardView::MaxX()
{ return m_MaxX;

}

UINT CBoardView::MaxY()
{ return m_MaxY;

}

void CBoardView::SetBgColor(COLORREF Color)
// Sets the background color of the view
{ m_BgColor = Color;
  for (int i=0; i< m_Turtles.GetSize();i++)
	  m_Turtles[i]->SetBgColor(Color);
}


void CBoardView::CallTurtlesInterrupts(CPoint From, CPoint To)
// Call all the turtles in the rectangle to do their interrupts
// The points are in bitmap coordinates
{  CPoint UL(__min(From.x, To.x), __min(From.y, To.y));
   CPoint DR(__max(From.x, To.x), __max(From.y, To.y));
   
	
	for (int i=0;i<m_Turtles.GetSize();i++)
		m_Turtles[i]->DoAllInterrupts(UL, DR);
}

void CBoardView::CallTurtlesInterrupts()
// All the turtles do their interrupts
{  	CPoint UL(0,0);
    CPoint DR(MAX_BOARD_X, MAX_BOARD_Y);
	for (int i=0;i<m_Turtles.GetSize();i++)
       m_Turtles[i]->DoAllInterrupts(UL, DR);

}




#define GET_FILE_ERROR  { if (AnsQueue)\
                          { Ans.type = MSG_TYPE_ANS_FILE_OPEN;\
                            Ans.msg  = MSG_FILE_OPEN_ERROR;\
				 	        AnsQueue->Post(Ans);\
                          }\
						  return FALSE; }

BOOL CBoardView::GetBitMap(CString FileName, CPoint DestLocation, BOOL IsMid, CMessageQueue *AnsQueue)
// open a bitmap file and place it in the background, if IsMid is TRUE the bitmap is centered
// else it is in the upper left corner of the window
{  	
	CFile ZeFile;
	HANDLE hfbm; 
	BITMAPFILEHEADER bmfh;
	DWORD dwRead;
	BITMAPINFOHEADER bmih;
	HGLOBAL hmem1, hmem2;
	BITMAPINFO* lpbmi;
	LPVOID lpvBits;   // locker
	HBITMAP hbm;
	BOOL fDisplayBitmap = FALSE;
	CMessage Ans;
	
	if (!ZeFile.Open(FileName, CFile::modeRead | CFile::shareDenyWrite))
	{ 
		GET_FILE_ERROR;
	}
	
	
	hfbm = HANDLE(ZeFile.m_hFile);
	
	/* Retrieve the BITMAPFILEHEADER structure. */ 
	
	ReadFile(hfbm, &bmfh, sizeof(BITMAPFILEHEADER), 
		&dwRead, (LPOVERLAPPED)NULL); 
	
	/* Retrieve the BITMAPINFOHEADER structure. */ 
	
	ReadFile(hfbm, &bmih, sizeof(BITMAPINFOHEADER), 
		&dwRead, (LPOVERLAPPED)NULL); 
	
	if (bmih.biCompression != BI_RGB)
	{
		if (!AnsQueue) AfxMessageBox("Comressed files not supported", MB_OK|MB_ICONEXCLAMATION);
		CloseHandle(hfbm);
		GET_FILE_ERROR;
	}
	
	UINT colorssize= ( (bmih.biBitCount < 16) ? ((1<<bmih.biBitCount) * sizeof(RGBQUAD)) : 0 );
	
	/* Allocate memory for the BITMAPINFO structure. */ 
	
	hmem1 = GlobalAlloc(GHND, sizeof(BITMAPINFOHEADER) + colorssize);
	
	lpbmi = (BITMAPINFO *)GlobalLock(hmem1); 
	
	/* 
	* Load BITMAPINFOHEADER into the BITMAPINFO 
	* structure. 
	*/ 
	
	lpbmi->bmiHeader.biSize = bmih.biSize; 
	lpbmi->bmiHeader.biWidth = bmih.biWidth; 
	lpbmi->bmiHeader.biHeight = bmih.biHeight; 
	lpbmi->bmiHeader.biPlanes = bmih.biPlanes; 
	lpbmi->bmiHeader.biBitCount = bmih.biBitCount; 
	lpbmi->bmiHeader.biCompression = bmih.biCompression; 
	lpbmi->bmiHeader.biSizeImage = bmih.biSizeImage; 
	lpbmi->bmiHeader.biXPelsPerMeter = bmih.biXPelsPerMeter; 
	lpbmi->bmiHeader.biYPelsPerMeter = bmih.biYPelsPerMeter; 
	lpbmi->bmiHeader.biClrUsed = bmih.biClrUsed; 
	lpbmi->bmiHeader.biClrImportant = bmih.biClrImportant; 
	
	/* 
	* Retrieve the color table. 
	* 1 << bmih.biBitCount == 2 ^ bmih.biBitCount 
	*/ 
	
	if (colorssize>0)
		ReadFile(hfbm, lpbmi->bmiColors, colorssize, &dwRead, (LPOVERLAPPED) NULL); 
	
	
		/* 
	* Allocate memory for the required number of 
	* bytes. 
	*/ 
	
	hmem2 = GlobalAlloc(GHND, (bmfh.bfSize - bmfh.bfOffBits)); 
	
	
	lpvBits = GlobalLock(hmem2); 
	
	/* Retrieve the bitmap data. */ 
	
	SetFilePointer(hfbm, bmfh.bfOffBits, NULL, FILE_BEGIN);
  
	ReadFile(hfbm, lpvBits, 
		(bmfh.bfSize - bmfh.bfOffBits), 
		&dwRead, (LPOVERLAPPED) NULL); 
	
		/* 
		* Create a bitmap from the data stored in the 
		* .BMP file. 
	*/ 
	
	hbm = CreateDIBitmap(m_ThePicture, &bmih, 
		CBM_INIT, lpvBits, 
		lpbmi, DIB_RGB_COLORS); 
	
		/* 
		* Unlock the global memory objects and 
		* close the .BMP file. 
	*/ 
	
	CDC NewDC;
	NewDC.CreateCompatibleDC(&m_ThePicture);
	NewDC.SelectObject(hbm);
	
	
	if (IsMid)            // center it
	{ DestLocation.x = (m_MaxX - bmih.biWidth) / 2;
	  DestLocation.y = (m_MaxY - bmih.biHeight) / 2;
	}
	
	m_ThePicture.BitBlt(DestLocation.x, DestLocation.y, bmih.biWidth, bmih.biHeight, //bm.bmWidth, bm.bmHeight, 
	&NewDC, 0,0, SRCCOPY); 
	
	GlobalFree(hmem1);
	GlobalFree(hmem2);
	GlobalUnlock(hmem1); 
	GlobalUnlock(hmem2); 
	CloseHandle(hbm);
	ZeFile.Close();
	
	
	RefreshPicture(CRect(0,0,MAX_BOARD_X,MAX_BOARD_Y));
	if (AnsQueue)
	{ Ans.type = MSG_TYPE_ANS_FILE_OPEN;
	Ans.msg = MSG_FILE_OPEN_OK;
	Ans.ptr = this;
	AnsQueue->Post(Ans);
	}
	
	
	return TRUE;
}


BOOL CBoardView::GetBitMap()
// user getbitmap from the menu, create a dialog box to find the file name
{ 
	CFileDialog FileD( 
		TRUE, "bmp", NULL, 
		OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES, 
		"Bitmap Files (*.bmp) | *.bmp; ||");
	
	if (FileD.DoModal() == IDOK)
	{ 
		if (GetBitMap(FileD.GetPathName(), CPoint (0,0), TRUE))
			return TRUE;
		else AfxMessageBox("File not found", MB_OK | MB_ICONEXCLAMATION);
	}
	return FALSE;
	
}



// save file error, send a message if needed

#define SAVE_ERROR { if (AnsQ)\
{ AnsMsg.type = MSG_TYPE_ANS_FILE_SAVE;\
	AnsMsg.msg = MSG_FILE_SAVE_ERROR;\
	AnsQ->Post(AnsMsg);\
}\
return FALSE; }



BOOL CBoardView::SaveBitMap(CString FileName, CMessageQueue *AnsQ)
// save the view bitmap into a file
{ 
	BOOL FileOpen = FALSE;
	BITMAP bmp; 
	PBITMAPINFO pbmi; 
	WORD    cClrBits; 
	CMessage AnsMsg;
	
	// Retrieve the bitmap's color format, width, and height.  
	
	CBitmap *pBit = m_ThePicture.GetCurrentBitmap();
	pBit->GetBitmap(&bmp);
	
	
	
	
	/* Convert the color format to a count of bits. */ 
	
	cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel); 
	
	if (cClrBits == 1) 
		cClrBits = 1; 
	else if (cClrBits <= 4) 
		cClrBits = 4; 
	else if (cClrBits <= 8) 
		cClrBits = 8; 
	else if (cClrBits <= 16) 
		cClrBits = 16; 
	else if (cClrBits <= 24) 
		cClrBits = 24; 
	else 
		cClrBits = 32; 
	
		/* 
		* Allocate memory for the BITMAPINFO structure. (This structure 
		* contains a BITMAPINFOHEADER structure and an array of RGBQUAD data 
		* structures.) 
	*/ 
	
	if (cClrBits < 16)
		pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
								sizeof(BITMAPINFOHEADER) + 
								sizeof(RGBQUAD) * (2^cClrBits)); 
	
								/* 
								* There is no RGBQUAD array for the 24-bit-per-pixel format. 
	*/ 
	
	else 
		pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
								sizeof(BITMAPINFOHEADER)); 
	
	
	
	/* Initialize the fields in the BITMAPINFO structure. */ 
	
	pbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER); 
	pbmi->bmiHeader.biWidth = bmp.bmWidth; 
	pbmi->bmiHeader.biHeight = bmp.bmHeight; 
	pbmi->bmiHeader.biPlanes = bmp.bmPlanes; 
	pbmi->bmiHeader.biBitCount = bmp.bmBitsPixel; 
	if (cClrBits < 16) 
		pbmi->bmiHeader.biClrUsed = 2^cClrBits; 
	
	
	/* If the bitmap is not compressed, set the BI_RGB flag. */ 
	
	pbmi->bmiHeader.biCompression = BI_RGB; 
	
	/* 
	* Compute the number of bytes in the array of color 
	* indices and store the result in biSizeImage. 
	*/ 
	
	pbmi->bmiHeader.biSizeImage = (pbmi->bmiHeader.biWidth + 7) /8 
		* pbmi->bmiHeader.biHeight 
		* cClrBits; 
	
		/* 
		* Set biClrImportant to 0, indicating that all of the 
		* device colors are important. 
	*/ 
	
	pbmi->bmiHeader.biClrImportant = 0; 
	
	
	HBITMAP hBMP;
	hBMP  = HBITMAP(*pBit);     // get the hdc
	
	
	HANDLE hf;                  /* file handle */ 
	BITMAPFILEHEADER hdr;       /* bitmap file-header */ 
	PBITMAPINFOHEADER pbih;     /* bitmap info-header */ 
	LPBYTE lpBits;              /* memory pointer */ 
	DWORD dwTotal;              /* total count of bytes */ 
	DWORD cb;                   /* incremental count of bytes */ 
	BYTE *hp;                   /* byte pointer */ 
	DWORD dwTmp; 
	
	
	pbih = (PBITMAPINFOHEADER) pbmi; 
	lpBits = (LPBYTE) GlobalAlloc(GMEM_FIXED, pbih->biSizeImage);
	
	/* 
	* Retrieve the color table (RGBQUAD array) and the bits 
	* (array of palette indices) from the DIB. 
	*/
	
	
	if (!GetDIBits (m_ThePicture, hBMP, 0, (WORD) pbih->biHeight, 
		lpBits, pbmi, DIB_RGB_COLORS)) 
		SAVE_ERROR;
	
	
	/* Create the .BMP file. */ 
	
	hf = CreateFile(FileName, 
		GENERIC_READ | GENERIC_WRITE, 
		(DWORD) 0, 
		(LPSECURITY_ATTRIBUTES) NULL, 
		CREATE_ALWAYS, 
		FILE_ATTRIBUTE_NORMAL, 
		(HANDLE) NULL); 
	
	if (hf == INVALID_HANDLE_VALUE) 
	{
		//errhandler("CreateFile", hwnd);  
		CloseHandle(hf);
		SAVE_ERROR;
	}
	//FileOpen = TRUE;
	hdr.bfType = 0x4d42;        /* 0x42 = "B" 0x4d = "M" */ 
	
	/* Compute the size of the entire file. */ 
	
	hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
		pbih->biSize + pbih->biClrUsed 
		* sizeof(RGBQUAD) + pbih->biSizeImage); 
	
	hdr.bfReserved1 = 0; 
	hdr.bfReserved2 = 0; 
	
	/* Compute the offset to the array of color indices. */ 
	
	hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
		pbih->biSize + pbih->biClrUsed 
		* sizeof (RGBQUAD); 
	
	/* Copy the BITMAPFILEHEADER into the .BMP file. */ 
	
	if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER), 
		(LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
		//errhandler("WriteFile", hwnd); 
	{ 
		CloseHandle(hf);
		SAVE_ERROR;
	}   
	
	/* Copy the BITMAPINFOHEADER and RGBQUAD array into the file. */ 
	
	if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFOHEADER) 
		+ pbih->biClrUsed * sizeof (RGBQUAD), 
		(LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
		//errhandler("WriteFile", hwnd); 
	{ 
		CloseHandle(hf);
		SAVE_ERROR;
	}
	
	/* Copy the array of color indices into the .BMP file. */ 
	
	dwTotal = cb = pbih->biSizeImage; 
	hp = lpBits; 
	
#define MAXWRITE 50000   // miki - ask Elad about that one
	
	while (cb > MAXWRITE)  { 
		if (!WriteFile(hf, (LPSTR) hp, (int) MAXWRITE, 
			(LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
		{ CloseHandle(hf);
		SAVE_ERROR;
		}
		cb-= MAXWRITE; 
		hp += MAXWRITE; 
	} 
	if (!WriteFile(hf, (LPSTR) hp, (int) cb, 
		(LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
	{
		CloseHandle(hf);
		SAVE_ERROR;
	}
	
	/* Close the .BMP file. */ 
	
	if (!CloseHandle(hf)) 
		SAVE_ERROR;
	
	/* Free memory. */
	
	GlobalFree((HGLOBAL)lpBits);
	
	if(AnsQ)
	{
		AnsMsg.type = MSG_TYPE_ANS_FILE_SAVE;
		AnsMsg.msg = MSG_FILE_SAVE_OK;
		AnsQ->Post(AnsMsg);
	}
	return TRUE;
}



void CBoardView::nullDI()
// the death indicator is NULL, used in GC
{ m_ppDeathIndicator = NULL;
}

void CBoardView::OnOpenBitmap() 
// menu command
{
	GetBitMap();	
}
