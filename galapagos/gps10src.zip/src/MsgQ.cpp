// MsgQ.cpp

// CMsgQx is a MT-safe message queue.

// Urgent Messages support: This should be posted with PostUrgent and have type 0.
// If such exist in the queue, Peek* always return TWO; Read* always read it and return TWO.
// Read* can get a pointer to some other Queue's Urgent event. In this case, if the
// other queue has an Urgent message, THREE is returned.

// CMessageQueue is a CMsgQx with no UrgentMessage support, but which will listen
// to urgent messages on TheCombination.pTheInputQueue and will handle them,
// (during Get* only)

#include "stdafx.h"

#include "MsgQ.h"
#include "comb.h"

#ifdef _TRACE_MESSAGEQUEUELOCKS
# define START_CRITICAL(why) { TRACE ("Thrd%d MessageQueue Locks   [" why "]\n", Thrd); CritSec.Lock();   }
# define END_CRITICAL(why)   { TRACE ("Thrd%d MessageQueue Unlocks [" why "]\n", Thrd); CritSec.Unlock(); }
#else
# define START_CRITICAL(why) CritSec.Lock()
# define END_CRITICAL(why)   CritSec.Unlock()
#endif

#ifndef _DEBUG
# define MyAssertValid() /**/
#endif
CMsgQx::CMsgQx() :
ReadingEvent (FALSE/*InitiallyOwned*/,FALSE/*Automatic*/),
UrgentEvent (FALSE/*InitiallyOwned*/,FALSE/*Automatic*/),
CritSec (),
UrgentMessages (0)
{
	m_pHead=new MsgNode(NULL, m_pTail=new MsgNode(NULL,NULL));
	m_pTail->prev=m_pHead;
}

// CMsgQx destructor: Detsructs all of the MsgNodes in the linked list.
// Messages that contain pointers, deletion is not recursive.
// (SCM messages are safe because they only contain pointers to hplim
// stuff which can later be GC'd; C-level Queuees should be empty
// when destructed here)

CMsgQx::~CMsgQx()
{
	MsgNode* pPrev;
	MsgNode* pN = m_pHead;
	while (pN != NULL)
	{
		pN=(pPrev=pN)->next;	
		delete pPrev;
		
	}
}




void CMsgQx::Post (CMessage Msg)
{
	MsgNode* pNode = new MsgNode(Msg, NULL, NULL);

	START_CRITICAL("Post");
	pNode->prev=m_pTail->prev;
	pNode->next=m_pTail;
	m_pTail->prev->next = pNode;
	m_pTail->prev=pNode;
	END_CRITICAL("Post");
	ReadingEvent.SetEvent();
}

void CMsgQx::PostUrgent (CMessage Msg)
{
	ASSERT(Msg.type == 0);
	MsgNode* pNode = new MsgNode(Msg, NULL, NULL);

	START_CRITICAL("PostUrgent");
	pNode->prev=m_pTail->prev;
	pNode->next=m_pTail;
	m_pTail->prev->next = pNode;
	m_pTail->prev=pNode;
	UrgentMessages++;
	END_CRITICAL("PostUrgent");
	UrgentEvent.SetEvent();
}

// PostUrgentAtHead() Posts an urgent message in such a way that it'll appear before any other
// Urgent message. This is done by chaining it just before the first message in the list.
// This is non-destructive to the queue, because (at current implementation) the queue is 
// rescanned from the head whenever needed.

void CMsgQx::PostUrgentAtHead (CMessage Msg)
{
	ASSERT(Msg.type == 0);
	MsgNode* pNode = new MsgNode(Msg, NULL, NULL);

	START_CRITICAL("PostUrgentAtHead");
	pNode->prev=m_pHead;
	pNode->next=m_pHead->next;
	m_pHead->next->prev = pNode;
	m_pHead->next=pNode;
	UrgentMessages++;
	END_CRITICAL("PostUrgentAtHead");
	UrgentEvent.SetEvent();
}



TRIBOOL CMsgQx::Peek()
{	TRIBOOL t;
	START_CRITICAL("Peek");
	if (UrgentMessages) t=TWO;
	else t= m_pHead->next->next != NULL;
	END_CRITICAL("Peek");
	return t;
}

TRIBOOL CMsgQx::PeekByType(DWORD type)
{
		return PeekByTypePtr(type, 0);
}

TRIBOOL CMsgQx::PeekByTypePtr(DWORD type, LPVOID ptr)
{
		//if (type==0 && ptr==0) return Peek();
		START_CRITICAL("PeekByTypePtr");
		if (UrgentMessages)
		{ 
			END_CRITICAL("PeekByTypePtr TWO");
		  return TWO;
		}
		for (MsgNode* pNode=m_pHead->next; pNode!=m_pTail; pNode=pNode->next)
			if ( (type==0 || type==pNode->data.type) &&
			     (ptr==0  || ptr ==pNode->data.ptr))
		{
				END_CRITICAL("PeekByTypePtr TRUE");
				return TRUE;
		}
		END_CRITICAL("PeekByTypePtr FALSE");
		return FALSE;
}

TRIBOOL CMsgQx::GetByType(CMessage& msg, DWORD type, DWORD seconds,CEvent* pOtherUrgentEvent)
{
	return GetByTypePtr (msg, type, 0, seconds, pOtherUrgentEvent);
}

TRIBOOL CMsgQx::GetByTypePtr(CMessage& msg, DWORD type, LPVOID ptr, DWORD seconds, CEvent*pOtherUrgentEvent)
{
	MyAssertValid();
	MsgNode* pNode;
	CTime StartTime = CTime::GetCurrentTime();
	
	for (;;)
	{	
		START_CRITICAL("GetByType");
		if (UrgentMessages) return EC_GetUrgentMessage(msg);
		for (pNode=m_pHead->next ; pNode != m_pTail ; pNode = pNode->next)
			if ( (type==0 || type==pNode->data.type) &&
			(ptr==0  || ptr ==pNode->data.ptr))
		{							
			msg=pNode->data;			
			pNode->next->prev = pNode->prev;
			pNode->prev->next = pNode->next;
			END_CRITICAL("GetByType Found");
			
			delete pNode;
			return TRUE;
		}
		END_CRITICAL("GetByType GoingToSleep");
		//CSingleLock ReadingLock(&ReadingEvent);
		CSyncObject* LockList[3]={ &ReadingEvent, &UrgentEvent, pOtherUrgentEvent };
		CMultiLock ReadingLock(LockList, (pOtherUrgentEvent==NULL)?2:3);
		DWORD rv;
		if (seconds==INFINITE)
			rv=ReadingLock.Lock(INFINITE,FALSE);
		else
		/*
		{
		ReadingLock.Lock(seconds*1000L);  // For some odd reason, this ALWAYS returns 1.
		seconds -= ( CTime::GetCurrentTime() - StartTime ).GetTotalSeconds(); 
		if ( (signed long)seconds < 0 )
		return FALSE; // "Nope. No messages. No, sorry. If you want a message, 'here' is definitely not the place to look for"
		}
		*/
		
		rv=ReadingLock.Lock(seconds*1000L,FALSE);
		switch(rv)
		{
		case WAIT_OBJECT_0+2:  // Other lock kicked
			return THREE;
		case WAIT_TIMEOUT: // timeout
			return FALSE;
		}
	}
}		

TRIBOOL CMsgQx::EC_GetUrgentMessage(CMessage& msg)
{
	ASSERT (UrgentMessages>=0);
	MsgNode* pNode;
	for (pNode=m_pHead->next ; pNode->data.type != 0 ; pNode = pNode->next);
	msg=pNode->data;			
	pNode->next->prev = pNode->prev;
	pNode->prev->next = pNode->next;
	UrgentMessages--;
	END_CRITICAL("EC_GetUrgentMessage Found");
	delete pNode;

	return TWO;
}

int CMsgQx::UrgentMessagesWaiting()
{
	START_CRITICAL("UrgentMessagesWaiting");
	int i=UrgentMessages;
	END_CRITICAL("UrgentMessagesWaiting");
	return i;
}

//------------------- CMessageQueue ---------------------------

BOOL CMessageQueue::GetByType(CMessage& msg, DWORD type, DWORD seconds)
{
	return GetByTypePtr (msg, type, 0, seconds);
}

BOOL CMessageQueue::GetByTypePtr(CMessage& msg, DWORD type, LPVOID ptr, DWORD seconds)
{
	MyAssertValid();
	
	MsgNode* pNode;
	CTime StartTime = CTime::GetCurrentTime();
	
	for (;;)
	{
		START_CRITICAL("GetByType");
		if (UrgentMessages) 
		{
			EC_HandleUrgentMessage();
			START_CRITICAL("GetByType after EC_HandleUrgentMessage");
		}
		for (pNode=m_pHead->next ; pNode != m_pTail ; pNode = pNode->next)
			if ( (type==0 || type==pNode->data.type) &&
			(ptr==0  || ptr ==pNode->data.ptr))
		{							
			msg=pNode->data;			
			pNode->next->prev = pNode->prev;
			pNode->prev->next = pNode->next;
			END_CRITICAL("GetByType Found");
			
			delete pNode;
			return TRUE;
		}
		END_CRITICAL("GetByType GoingToSleep");
		//CSingleLock ReadingLock(&ReadingEvent);
		
		if (seconds != INFINITE)
		{
			seconds -= ( CTime::GetCurrentTime() - StartTime ).GetTotalSeconds(); 
			if ( (signed long)seconds <= 0 ) return FALSE;
		}

		StartTime = CTime::GetCurrentTime();
		CSyncObject* LockList[3]={ &ReadingEvent, &UrgentEvent, TheCombination.pTheInputQueue->GetEvent() };
		CMultiLock ReadingLock(LockList, (LockList[2]==LockList[1])?2:3);
		DWORD rv;
		if (seconds==INFINITE)
			rv=ReadingLock.Lock(INFINITE,FALSE);
		else
			rv=ReadingLock.Lock(seconds*1000L,FALSE);
		if (rv==0xFFFFFFFF) 
		{
			DWORD dw=GetLastError();
			TRACE("Thrd%d:ReadingLock.Lock error %u\n", Thrd, dw);
		}
		if(rv==WAIT_OBJECT_0+2)
		{// Other lock kicked
			TheCombination.pTheInputQueue->CMsgQx::Get(msg);
			HandleUrgentMessage(msg);
		}
	}
}		

void CMessageQueue::EC_HandleUrgentMessage()
{
	ASSERT (UrgentMessages>=0);
	MsgNode* pNode;
	for (pNode=m_pHead->next ; pNode->data.type != 0 ; pNode = pNode->next);
	CMessage msg=pNode->data;			
	pNode->next->prev = pNode->prev;
	pNode->prev->next = pNode->next;
	UrgentMessages--;
	END_CRITICAL("EC_HandleUrgentMessage Found");
	delete pNode;
	
	HandleUrgentMessage(msg);
}
