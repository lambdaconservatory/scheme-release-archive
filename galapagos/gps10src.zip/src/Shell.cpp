// Shell.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Shell.h"
#include <afxdisp.h>

#include "threads.h"
#include "MsgQ.h"
#include "MainFrm.h"
#include "ShellFrm.h"
#include "ShellDoc.h"
#include "ShellView.h"
#include "BoardDoc.h"
#include "BoardView.h"
#include "BoardFrm.h"
#include "comb.h"
#include "turtlemsg.h"
#include "Splash.h"

extern "C" UINT SCM_FirstThread(LPVOID pParam); // Comb.cpp

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShellApp

BEGIN_MESSAGE_MAP(CShellApp, CWinApp)
	//{{AFX_MSG_MAP(CShellApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_ON_HELP, OnHelp) 
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShellApp construction

CShellApp::CShellApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_bInGC = FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CShellApp object

CShellApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CShellApp initialization

BOOL CShellApp::InitInstance()
{
	// CG: The following block was added by the Splash Screen component.
	
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	
	CSplashWnd::EnableSplashScreen(cmdInfo.m_bShowSplash);
	
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)


	::AfxEnableControlContainer();

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	m_pInterpreterDocTemplate=new CMultiDocTemplate(
		IDR_SHELLTYPE,
		RUNTIME_CLASS(CShellDoc),
		RUNTIME_CLASS(CShellFrame), // custom MDI child frame
		RUNTIME_CLASS(CShellView));
	AddDocTemplate(m_pInterpreterDocTemplate);

	m_pGraphicWindowDocTemplate=new CMultiDocTemplate(
		IDR_BOARDTYPE,
		RUNTIME_CLASS(CBoardDoc),
		RUNTIME_CLASS(CBoardFrame),
		RUNTIME_CLASS(CBoardView));
	AddDocTemplate(m_pGraphicWindowDocTemplate);

	// create main MDI Frame window
	m_pMainFrame = new CMainFrame;
	if (!m_pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = m_pMainFrame;

	// Parse command line for standard shell commands, DDE, file open
	//CCommandLineInfo cmdInfo;
	//ParseCommandLine(cmdInfo);
	

	// Dispatch commands specified on the command line
	//if (!ProcessShellCommand(cmdInfo))	return FALSE;

	AfxBeginThread (SCM_FirstThread, NULL);

	// The main window has been initialized, so show and update it.
	m_pMainFrame->ShowWindow(m_nCmdShow);
	m_pMainFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CShellApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CShellApp commands

CMessageQueue TheOutputQueue;

BOOL CShellApp::OnIdle(LONG lCount) 
{
	
	CWinApp::OnIdle(lCount);

	// Give total precedence Windows messages, because that's the GUI input
	if (!TheOutputQueue.Peek()) return TRUE;

	CMessage msg;
	MSG winmsgfoo;
	
	// Pack up and handle all to-textwindow messages first
	
	if (TheOutputQueue.PeekByType(STR_INTERPRETER2WINDOW) &&
		!::PeekMessage( &winmsgfoo, NULL, 0, 0, PM_NOREMOVE ) )
	{
		TheOutputQueue.GetByType(msg, STR_INTERPRETER2WINDOW);
loop1:
		ASSERT(msg.type == STR_INTERPRETER2WINDOW);
		CString s=*(CString*)(msg.msg);
		delete (CString*)(msg.msg);		
		LPVOID ptr=msg.ptr;
		
		// Concat consequent text messages, as long as  MFC is free
		while (TheOutputQueue.PeekByTypePtr(STR_INTERPRETER2WINDOW,ptr) &&
			!::PeekMessage( &winmsgfoo, NULL, 0, 0, PM_NOREMOVE ) )
		{
			TheOutputQueue.GetByTypePtr(msg, STR_INTERPRETER2WINDOW, ptr);
			ASSERT(msg.type=STR_INTERPRETER2WINDOW);
			s += *(CString*)(msg.msg);
			delete (CString*)(msg.msg);
		}
		((CShellView*)ptr)->Print(s);
		return TRUE;
	}
	
	TheOutputQueue.Get(msg);
	
	switch(msg.type)
	{ 
	case MSG_TYPE_TURTLE: 
		((CTurtle *)(msg.ptr))->ReadAndEval((CTurtle_Msg *)(msg.msg));
		break;
	case MSG_TYPE_VIEW:
		((CBoardView*)(msg.ptr))->ReadAndEval((CView_Msg*)(msg.msg));
		break;
	case MSG_TYPE_NEW_TURTLE:
		((CBoardView *)(msg.ptr))->CreateTurtle((CMessageQueue *)(msg.msg));
		break; 
	case MSG_TYPE_CLONE_TURTLE:
		((CTurtle *)(msg.ptr))->Clone((CMessageQueue *)(msg.msg));
		break;
	case MSG_TYPE_NEW_VIEW:
		//			m_Views[m_ViewCount++] = (CBoardView *)(Msg.ptr);
		break;
	case MSG_TYPE_CREATE_VIEW:  
		{
			CShellDoc * pD= (CShellDoc*)(theApp.m_pGraphicWindowDocTemplate->OpenDocumentFile(NULL));
			POSITION pos = pD->GetFirstViewPosition();
			CShellView *pV= (CShellView*)pD->GetNextView( pos );
			CMessageQueue *pQ= (CMessageQueue*)msg.ptr;
			if (pQ) // send back the view* if needed
				pQ->Post(CMessage(MSG_TYPE_ANS, 0, pV)) ;
			break;
		}	
	case MSG_TYPE_KILL_TURTLE: 
		delete (CTurtle *)(msg.ptr);
		break;

	case MSG_OPEN_CONSOLE:
		{
			CShellDoc* pD=(CShellDoc*)( theApp.m_pInterpreterDocTemplate->OpenDocumentFile(NULL) );
			ASSERT(pD!=NULL);
			pD->SetTitle(*(CString*)(msg.msg));
			POSITION pos = pD->GetFirstViewPosition();
			CShellView* pV=(CShellView*)( pD->GetNextView(pos) );
			((CMessageQueue*)(msg.ptr))->Post(CMessage(0,0,pV));
			break;
		}
	case MSG_CLOSE_CONSOLE:
		{
			CShellDoc* pD= ((CShellView*)(msg.msg))->GetDocument();
			ASSERT(pD!=NULL);
			pD->OnCloseDocument();
			((CMessageQueue*)(msg.ptr))->Post(CMessage(0,0,(DWORD)0));
			break;
		}
	case MSG_SETNAME_GFXWIN:
		{
			CString* s = (CString*)(msg.msg);
			((CBoardView*)(msg.ptr))->GetDocument()->SetTitle(*s);
			delete s;
			break;
		}
	case MSG_SETNAME_TXTWIN:
		{
			CString* s = (CString*)(msg.msg);
			((CShellView*)(msg.ptr))->GetDocument()->SetTitle(*s);
			delete s;
			break;
		}

	case STR_INTERPRETER2WINDOW: 
		goto loop1;
	default:
		ASSERT(FALSE);  // Unknown msg
	}
	return TRUE;
}

BOOL CShellApp::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following line was added by the Splash Screen component.
	CSplashWnd::PreTranslateAppMessage(pMsg);

	return CWinApp::PreTranslateMessage(pMsg);
}
