// SCMMUTEX.cpp - Mutexes interface for Scheme

// This is a beginning, which doesn't seem to work.

#include "stdafx.h"
#include "Shell.h"
#include "ShellDoc.h"
#include "ShellView.h"
#include "MsgQ.h"
#include "comb.h"
#include "GCd.h"

#include "mydebug.h"
#include "scm.h"

#ifdef TC16_MUTEX
# define tc16_mutex TC16_MUTEX
#else
long tc16_mutex;
#endif
#define MUTEXP(x)  (CELLP(x) && (TYP16(x) == tc16_mutex))
#define MTXPTR(x)  (CDR(x))

#define BOOL2SCM(k) ( (k)? BOOL_T:BOOL_F )

// (make-mutex) makes a mutex
SCM make_mutex()
{
	SCM x;
	CMutex* pMX = new CMutex;
	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_mutex;
	CDR(x)=(SCM)pMX;
	ALLOW_INTS;
	return x;
}

#define myname "mutex-locked?"
SCM try_mutex(SCM mtx)
{
	ASSERT(MUTEXP(mtx), mtx, ARG1, myname);
	CSingleLock L( (CMutex*)MTXPTR(mtx) );
	return BOOL2SCM( L.IsLocked() );
}
#undef myname

#define myname "lock-mutex"
SCM lock_mutex(SCM mtx)
{
	ASSERT(MUTEXP(mtx), mtx, ARG1, myname);
	

	CSyncObject* LockList[2]={ (CMutex*)MTXPTR(mtx), TheCombination.pTheInputQueue->GetEvent()  };
	CMultiLock ALock(LockList, 2);
	for (;;)
	{
		if (ALock.Lock(INFINITE,FALSE) == WAIT_OBJECT_0) // mutex freed
			return UNSPECIFIED;

		// Got urgentmessage. This will get them out of the way:
		CMessage msg;
		TheCombination.pTheInputQueue->GetByType(msg, MSG_NEVERUSED);
	}	
}
#undef myname

#define myname "unlock-mutex"
SCM unlock_mutex(SCM mtx)
{
	ASSERT(MUTEXP(mtx), mtx, ARG1, myname);
	CSingleLock L( (CMutex*)MTXPTR(mtx) );
	L.Unlock();
	return UNSPECIFIED;
}
#undef myname

SCM mutex_p(SCM x) { return BOOL2SCM(MUTEXP(x)); } 

static sizet free_mutex(SCM cel)
{
	delete (CMutex*)MTXPTR(cel);
	return 0;
}

static int print_mutex (SCM exp, SCM port, int writing)
{
  lputs("#<", port);

  CSingleLock L( (CMutex*)MTXPTR(exp) );
  if (L.IsLocked())
	  lputs("locked ", port);
  lputs("mutex 0x", port);
  intprint(MTXPTR(exp), 16, port);
  lputc('>', port);
  return !0;
}




//-----------------------------------------------------------------


static smobfuns mutex_smob = 
{ 
	(SCM(__cdecl*)(SCM)) mark0, 
	(sizet(__cdecl*)(CELLPTR)) free_mutex, 
	(int(__cdecl*)(SCM,SCM,int))print_mutex, 
	0 
};
	
#define FIXF(_f) ( (SCM(__cdecl*)())(_f) )

static iproc subr0s[] = {
	{"make-mutex", FIXF(make_mutex)},
	{"mutex?", FIXF(mutex_p)},
	{0,0} };
					
static iproc subr1s[] = {
				{"lock-mutex", FIXF(lock_mutex)},
				{"unlock-mutex", FIXF(unlock_mutex)},
				{"mutex-locked?", FIXF(try_mutex)},
				{"mutex?", FIXF(mutex_p)},
				{0,0} };



extern "C" void init_mutex()
{ 
#ifndef TC16_MUTEX
	tc16_mutex =
#endif
		newsmob (&mutex_smob);
	init_iprocs(subr0s, tc7_subr_0);
	init_iprocs(subr1s, tc7_subr_1);
}



