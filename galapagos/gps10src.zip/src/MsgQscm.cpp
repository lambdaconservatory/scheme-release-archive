// MsgQSCM.cpp - CMessageQ SCM interface

#include "stdafx.h"
#include "MsgQ.h"
#include "comb.h"

#include "mydebug.h"
#include "scm.h"
extern "C" {
#include "setjump.h"  /* for STACKITEM */
}
#ifdef TC16_MSGQ		    
# define tc16_msgq TC16_MSGQ
#else
long tc16_msgq;
#endif

#define MSGQP(x) (CELLP(x) && (TYP16(x) == tc16_msgq))
#define MSGQPTR(x) ((CMessageQueue*)CDR(x))

//inline msgqP(SCM x) { return NIMP(x) && MSGQP(x); }

static SCM __cdecl make_msgq()
{	SCM x;
	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_msgq;
	CDR(x) = (SCM)new CMessageQueue;
	ALLOW_INTS;
	return x;
}

static int __cdecl print_msgq(SCM exp, SCM port, int writing)
{
	lputs("#<message-queue 0x", port);
	intprint(CDR(exp), 16, port);
	lputc('>', port);
	return !0;
}

// mark_msgq() is called by the GC whenever a msgq is met. 
// Note that only SCM object which are straight within the CMessage
// are marked. SCM objects that are indirectly pointed from the
// queue are not marked. Messages sent within the SCM interpreter
// are safe, because the information is sent within the CMessage.

extern "C" void mark_locations(STACKITEM x[], sizet n); // sys.c
SCM __cdecl mark_msgq(SCM cel)
{
	mark0(cel); // Mark myself
	CMsgQx* pQ = MSGQPTR(cel);
	for (MsgNode* pN = pQ->m_pHead->next; pN->next != NULL; pN=pN->next)
		mark_locations ((STACKITEM*)&(pN->data),  sizeof(CMessage)/sizeof(STACKITEM));
	return BOOL_F;
}

static sizet __cdecl free_msgq(SCMPTR cel)
{
	CMessageQueue* q = (CMessageQueue*)(CDR(cel));
	delete q;
	return sizeof CMessageQueue;
}

static SCM __cdecl msgq_p(SCM x)
{
	return MSGQP(x)? BOOL_T:BOOL_F;
}

#define myname "peek-message"
static SCM __cdecl peek_msgq(SCM msgq, SCM type/*optional*/)
{
	ASSERT(MSGQP(msgq), msgq, ARG1, myname);
	if UNBNDP(type) type=0;
	return (MSGQPTR(msgq)->PeekByType(type)) ? BOOL_T:BOOL_F;
}
#undef myname

#define myname "post-message"
static SCM __cdecl post_msgq(SCM msgq, SCM type_msg)
{
	ASSERT(MSGQP(msgq), msgq, ARG1, myname);
	ASSERT(NIMP(type_msg) && CONSP(type_msg), type_msg, ARG2, myname);
	
	MSGQPTR(msgq)->Post(CMessage(CAR(type_msg),CDR(type_msg)));
	return UNDEFINED;
}
#undef myname


#define myname "get-message"
static SCM __cdecl get_msgq(SCM args) /* (get-message [timeout(seconds)] queue [type] */
{
	SCM x=args, msgq, type;
	DWORD timeout;
	ASSERT(NNULLP(x), args, WNA, myname);
	if MSGQP(CAR(x))
		timeout=INFINITE;
	else
	{
		timeout=num2ulong(CAR(x), (char*)ARG1, myname);
		x=CDR(x);
		ASSERT(NNULLP(x), args, WNA, myname);
		ASSERT(MSGQP(CAR(x)), CAR(x), ARG2, myname);
	}
	msgq=CAR(x);
	x=CDR(x);
	if NULLP(x) type=0;
	else 
	{	ASSERT(NULLP(CDR(x)), args, WNA, myname);
	type=CAR(x);
	}
	CMessage msg;
	if ( MSGQPTR(msgq)->GetByType(msg, type, timeout) )
		return  cons(msg.type, msg.msg);
	return BOOL_F;
}
#undef myname

static smobfuns msgq_smob = {
	(SCM(__cdecl*)(SCM)) mark_msgq, 
		(sizet(__cdecl*)(CELLPTR)) free_msgq, 
		(int(__cdecl*)(SCM,SCM,int))print_msgq, 
		0 };

static iproc subr0s[] = {
	{"make-queue", (SCM(__cdecl*)())make_msgq},
	{0,0} };

static iproc subr2os[] = {
	{"peek-message", (SCM(__cdecl*)())peek_msgq},
	{0,0}};

static iproc lsubrs[] = {
	{"get-message", (SCM(__cdecl*)())get_msgq},
	{0,0}};

static iproc subr1s[] = {
	{"message-queue?", (SCM(__cdecl*)())msgq_p},
	{0,0} };

static iproc subr2s[] = {
	{"post-message", (SCM(__cdecl*)())post_msgq},
	{0,0} };



extern "C" void init_msgq()
{ 
#ifndef TC16_MSGQ
	tc16_msgq = 
#endif
		newsmob (&msgq_smob);
	init_iprocs(subr0s, tc7_subr_0);
	init_iprocs(subr1s, tc7_subr_1);
	init_iprocs(subr2s, tc7_subr_2);
	init_iprocs(subr2os, tc7_subr_2o);
	init_iprocs(lsubrs, tc7_lsubr);
}

