// TURTLE.CPP	
#include "stdafx.h"
#include <math.h>
#include "BoardView.h"
// Implementation of Turtle.h
#include "Board.h"
#include "Turtle.h"
#include "MsgQ.h"
#include "TurtleMsg.h"
#include "Threads.h"





void CTurtleInterrupt::Go(CPoint UL, CPoint DR)
// invoke the interrupt, call the turtle to look and return the result
{ CMessage AnsMsg;
  CString S;
  switch (Kind)
  { case INT_KIND_COLOR:  if (pMyTurtle->Look4Color(Color, Degree, Distance, UL, DR))
                          { if (First)
                            { First = FALSE;
						      if (Which & IS_ON)
							  {
                              AnsMsg.type = 0;
		                      AnsMsg.msg = MSGMSG_SCMURGENT;
							  AnsMsg.ptr = LPVOID(MsgIs);
							  pAnsQueue->CMsgQx::PostUrgent(AnsMsg);
							  }
			 	   			 }
                          } 
                          else     // The color is not found
							if (!First)
						    {  First = TRUE;
						       if (Which & NOT_ON)
						      { AnsMsg.type = 0;
		                        AnsMsg.msg = MSGMSG_SCMURGENT;
							    AnsMsg.ptr = LPVOID(MsgNot);
							    pAnsQueue->CMsgQx::PostUrgent(AnsMsg);
						      }
			 	   			 }
                          break;

  case INT_KIND_TURTLE: if (pMyTurtle->Look4Turtle(pT, Degree, Distance, UL, DR))
						  { if (First)
						    {  First = FALSE;
							   if (Which & IS_ON)
						      { AnsMsg.type = 0;
		                        AnsMsg.msg = MSGMSG_SCMURGENT;
							    AnsMsg.ptr = LPVOID(MsgIs);
							    pAnsQueue->CMsgQx::PostUrgent(AnsMsg);
						      }
			 	   			 }

						  }
		                  else    // no turtle around
						    if (!First)
						    { First = TRUE;
						      if (Which & NOT_ON)
							  { AnsMsg.type = 0;
		                        AnsMsg.msg = MSGMSG_SCMURGENT;
							    AnsMsg.ptr = LPVOID(MsgNot);
								pAnsQueue->CMsgQx::PostUrgent(AnsMsg);
							  }
						    }
		                  break;
  }	  // end switch

}



CTurtleInterrupt::CTurtleInterrupt(CTurtleInterrupt& I)
// just copy
{ Color = I.Color;
  Degree = I.Degree;
  Distance = I.Distance;
  Kind = I.Kind;
  MsgIs = I.MsgIs;
  MsgNot = I.MsgNot;
  pAnsQueue = I.pAnsQueue;
  pMyTurtle = I.pMyTurtle;
  pT = I.pT;
  Which = I.Which;
  First = I.First;
}
	


CTurtleInterrupt::CTurtleInterrupt()
{ // a lot of thought went into this one :-)
}

void CTurtleInterrupt::SetTurtle(CTurtle *T)
// to which turtle do I belong?
{  pMyTurtle = T;
}




//--------------------------------------------------------------------------------------------





CTurtle::CTurtle(CBoardView *pView, CDC *pPicture, void* UserInner , double Heading, COLORREF Color, UINT nPenWidth, COLORREF BgColor, BOOL Hidden, BOOL Erase)
// Major defaults
{   
	m_pView = pView;
	m_pPicture = pPicture;
	m_Heading = Heading - 90;
	if (m_Heading < 0) m_Heading += 360;+
	m_pUserInner = UserInner;
    m_PenUp = FALSE;
	m_Pen = new CPen(PS_SOLID, nPenWidth,Color);
	m_Location.x = MIDDLE_POINT_X;
	m_Location.y = MIDDLE_POINT_Y;
	m_IsSolid = TRUE;
	m_BgColor = BgColor;
	m_Color = Color;
	m_Hidden = Hidden;
	m_Erase = Erase;
	m_Interrupts.SetSize(0);
	m_ppDeathIndicator = NULL;
	m_pUserIntQ = NULL;
	m_UserIntMsg = 0;
}





BOOL CTurtle::SetHeading(double Diff)
// Sets a new heading, diff is the difference from the current
{ if ((m_Heading + Diff) <= 0) m_Heading += 360;
  m_Heading += Diff;
  if (m_Heading > 360) m_Heading -= 360;
  m_pView->RefreshPicture(Dp2Cp(m_Location), Dp2Cp(m_Location));
  if (m_DoInterrupts) DoAllInterrupts(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return TRUE;
}


double CTurtle::Deg2Rad(double Deg)
// convert degrees to redians
{ return ((CONST_PI / 180) * Deg);
}


CTurtle::CTurtle(CTurtle &T)
// Initializes the new turtle to have the same inner state as T
{ m_BgColor = T.m_BgColor;
  m_Color = T.m_Color;
  m_DoInterrupts = T.m_DoInterrupts;
  m_Erase = T.m_Erase;
  m_Heading = T.m_Heading;
  m_Hidden = T.m_Hidden;
  m_IsSolid = T.m_IsSolid;
  m_Location.x = T.m_Location.x;
  m_Location.y = T.m_Location.y;
  m_Pen = new CPen;
  LOGPEN foo;                // Since CPen has no =
  T.m_Pen->GetLogPen(&foo);  
  m_Pen->CreatePenIndirect(&foo); 
  m_PenUp = T.m_PenUp;
  m_pPicture = T.m_pPicture;
  m_pView = T.m_pView;
  m_pUserInner = T.m_pUserInner;

    // copy the interrupts
  
  m_Interrupts.SetSize(0);
  CTurtleInterrupt *pI;
  for (int i=0;i<T.m_Interrupts.GetSize();i++)
  { pI = new CTurtleInterrupt(*(T.m_Interrupts[i]));
    pI -> SetTurtle(this);
    m_Interrupts.Add(pI);
  }

  m_ppDeathIndicator = NULL;

  m_pUserIntQ = T.m_pUserIntQ;
  m_UserIntMsg = T.m_UserIntMsg;
}

CTurtle & CTurtle::operator = (CTurtle &T)
// make a turtle just like the other one
{ CTurtle *pT;
  pT = new CTurtle(T);
  return *pT;
}


BOOL CTurtle::SetPenWidth(UINT Width)
// New Pen width
{ LOGPEN foo;
  
  if (Width > 20) return FALSE; 
  m_Pen->GetLogPen(&foo);
  delete m_Pen;
  foo.lopnWidth.x = Width;
  m_Pen = new CPen;
  m_Pen->CreatePenIndirect(&foo);
  return TRUE;
}

BOOL CTurtle::SetPenColor(COLORREF Color)
// New pen color
{ LOGPEN foo;
  m_Pen->GetLogPen(&foo);
  delete m_Pen;
  foo.lopnColor = Color;
  m_Pen = new CPen;
  m_Color = Color;
  m_Pen->CreatePenIndirect(&foo);
  m_pView->RefreshPicture(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return TRUE;
  
}

BOOL CTurtle::PenDown()
// PenDown - we draw
{ LOGPEN foo;
  m_Pen->GetLogPen(&foo);
  delete m_Pen;
  foo.lopnColor = m_Color;
  m_Pen = new CPen;
  m_Pen->CreatePenIndirect(&foo);
	
  if (!m_PenUp) return FALSE;
  m_Erase = FALSE;
  m_PenUp = FALSE;
  return TRUE;
}

BOOL CTurtle::PenUp()
// PenUp - we do not draw
{ if (m_PenUp) return FALSE;
  m_PenUp = TRUE;
  m_Erase = FALSE;
  return TRUE;
}




#define CLOSE_ENOUGTH 5 	// 5 pixels from a turtle

BOOL CTurtle::Close(CPoint P)
// TURE if the turtle is close to the point P
{ if ((abs(int(floor(m_Location.x - double(P.x))))    < CLOSE_ENOUGTH) && 
	  (abs(int(floor(m_Location.y - double(P.y))))<CLOSE_ENOUGTH)) return TRUE;
  return FALSE;
  
}

double CTurtle::Heading()
// return my true heading
{ return m_Heading + 90;
}



BOOL CTurtle::SetHollow()
// Hollow turtle - will not fill the polygon
{ BOOL Result = (m_IsSolid == FALSE);
  m_IsSolid = FALSE;
  m_pView->RefreshPicture(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return Result;
}

BOOL CTurtle::SetSolid()
// Solid turtle - will fill the polygon
{ BOOL Result = (m_IsSolid == TRUE);
  m_IsSolid = TRUE;
  m_pView->RefreshPicture(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return Result;
}

#define RECT_ERROR  5   
BOOL CTurtle::InRect(CPoint UL, CPoint DR)
// TRUE if the turtle is inside the rectangle
{
  if ((m_Location.x > UL.x - RECT_ERROR) && (m_Location.x < DR.x + RECT_ERROR) && (m_Location.y > UL.y - RECT_ERROR) && (m_Location.y < DR.y + RECT_ERROR)) 
	  return TRUE;
  return FALSE;
}

CPoint CTurtle::Location()
// my location in CPoint
{ return Dp2Cp(m_Location);
}

BOOL CTurtle::FD(int Ste)
// Move the turtle forward (in m_Heading direction) Ste length
{ double Heading = m_Heading;
  if (Ste < 0) 
  { Heading -= 180;
    Ste = -Ste;
  }
  
  double dX = cos(Deg2Rad(Heading)) * Ste;
  double dY = sin(Deg2Rad(Heading)) * Ste;
  CPen *OldPicturePen = m_pPicture->SelectObject(m_Pen); // save old pen
  CPoint OldLocation = Dp2Cp(m_Location);//.x, m_Location.y);

  
  m_pPicture->MoveTo(OldLocation);
  m_Location.Offset(dX,dY);
  if (!m_PenUp) // == TRUE)
    m_pPicture->LineTo(Dp2Cp(m_Location));
  else m_pPicture->MoveTo(Dp2Cp(m_Location));
  m_pPicture->SelectObject(OldPicturePen);
  m_pView->RefreshPicture(OldLocation, Dp2Cp(m_Location));
  m_pView->CallTurtlesInterrupts(OldLocation, Dp2Cp(m_Location));
  return TRUE;
}

BOOL CTurtle::SetAbsHeading(double Heading)  
// sets the absolute heading
{ m_Heading = Heading; 
  if (m_Heading < 0) m_Heading = -m_Heading;
  if (m_Heading > 360) m_Heading = long (m_Heading) % 360;
  m_Heading -= 90;     // some minor adjustment
  m_pView->RefreshPicture(Dp2Cp(m_Location), Dp2Cp(m_Location));
  if (m_DoInterrupts) DoAllInterrupts(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return TRUE;
}

#define LOOK_COLOR(X)    (COLORREF(((CTurtleLookArgs *)(X))->Arg))
#define LOOK_TURTLE(X)   ((CTurtle *) (((CTurtleLookArgs *)(X)) ->Arg))

#define LOOK_DISTANCE(X) (((CTurtleLookArgs *)(X))->Distance)
#define LOOK_DEGREE(X)   (((CTurtleLookArgs *)(X))->Degree)
#define LOOK_QUEUE(X)    (((CTurtleLookArgs *)(X))->AnsQueue)


BOOL CTurtle::ReadAndEval(CTurtle_Msg *Msg) 
// Reads the CTurtle_Msg Msg and act upon what is written there
{	UINT UMisc;
	int IMisc;
	double DMisc;
	COLORREF Color;
	BOOL Answer;
    CMessage AnsMsg;							 // a ready answer
    CTurtleInnerState *pInner;
	LOGPEN *pLogPen;
	BOOL IntFlag = FALSE;
	
	switch (Msg->Cmd)
    { case MSG_CMD_FD:       UMisc = UINT(Msg->Arg);
							 delete Msg;
							 Answer  =  FD(UMisc);
							 IntFlag = TRUE;
	  						 break;
	  case MSG_CMD_LEFT:     IMisc = int(Msg->Arg);
							 delete Msg;
							 Answer  =  SetHeading(-IMisc);
							 IntFlag = TRUE;
    						 break;

	  case MSG_CMD_RIGHT:    IMisc = int(Msg->Arg);
							 delete Msg;
		                     Answer =  SetHeading(IMisc);
							 IntFlag = TRUE;
	  						 break;

      case MSG_CMD_PENUP:     delete Msg;
		                      Answer =  PenUp();
	  						  break;

	  case MSG_CMD_PENDOWN:	 delete Msg;
		                     Answer =  PenDown();
	  						 break;

	  case MSG_CMD_COLOR:    Color = COLORREF(Msg->Arg);
							 delete Msg;
							 Answer  =  SetPenColor(Color);
	  						 break;

	  case MSG_CMD_WIDTH:    UMisc = UINT(Msg->Arg);
							 delete Msg;
							 Answer  =  SetPenWidth(UMisc);
	  						 break;

      case MSG_CMD_SOLID:    delete Msg;
							 Answer  =  SetSolid();
	  						 break;

      case MSG_CMD_HOLLOW:   delete Msg;
							 Answer  =  SetHollow();
	  						 break;

	  case MSG_CMD_HEADING:	 DMisc = double(Msg->Arg);
							 delete Msg;
		                     Answer =  SetAbsHeading(DMisc);
							 IntFlag = TRUE;
							 break;

	  case MSG_CMD_HIDE:     delete Msg;
		                     Answer =  Hide();
							 break;

	  case MSG_CMD_SHOW:     delete Msg;
		                     Answer =  Show();
							 break;

	  case MSG_CMD_MOVE:     MoveView((CBoardView *)(Msg->Arg));
		                     delete Msg;
							 Answer  =  TRUE;
							 IntFlag = TRUE;
							 break;

	  case MSG_CMD_ERASE:	 delete Msg;
							 Answer  =  PenErase();
							 break;

	  
	  case MSG_CMD_MOVE_ABS: Answer = Move2Abs((CPoint *)(Msg->Arg));
		                     delete Msg;
							 IntFlag = TRUE;
							 break;

	  case MSG_CMD_GLIDE:    Answer = GlideTo(*((CPoint *)(Msg->Arg)));
		                     delete Msg;
							 IntFlag = TRUE;
							 break;

	  case MSG_ASK_INNER:	 pLogPen = new LOGPEN;
		                     m_Pen->GetLogPen(pLogPen);
		                     pInner = new CTurtleInnerState(m_Color, m_BgColor, m_Erase, m_Heading, m_Hidden,  m_IsSolid, Dp2Cp(m_Location),  m_PenUp, m_pUserInner, pLogPen->lopnWidth.x);
		                     AnsMsg.type = MSG_TYPE_ANS_INNER;
							 AnsMsg.msg = DWORD(pInner);
							 AnsMsg.ptr = this;
							 ((CMessageQueue *)(Msg->Arg))->Post(AnsMsg);
							 delete Msg;
							 Answer  =  TRUE;
							 break;

	  case MSG_CMD_LOOK4C:   Answer = Look4Color(LOOK_COLOR(Msg->Arg), LOOK_DEGREE(Msg->Arg), LOOK_DISTANCE(Msg->Arg)); 
							 AnsMsg.type = MSG_ANS_LOOK;
							 AnsMsg.msg = Answer;
							 AnsMsg.ptr = this;
							 LOOK_QUEUE(Msg->Arg)->Post(AnsMsg);
		                     delete (CTurtleLookArgs *)(Msg->Arg);
							 delete Msg;
							 break;

	  case MSG_CMD_LOOK4T:   Answer = Look4Turtle(LOOK_TURTLE(Msg->Arg), LOOK_DEGREE(Msg->Arg), LOOK_DISTANCE(Msg->Arg));
                             AnsMsg.type = MSG_ANS_LOOK;
							 AnsMsg.msg = Answer;
							 AnsMsg.ptr = this;
							 LOOK_QUEUE(Msg->Arg)->Post(AnsMsg);
		                     delete (CTurtleLookArgs *)(Msg->Arg);
							 delete Msg;
							 break;
	  
	  case MSG_CMD_INTERRUPT:Answer = AddInterrupt((CTurtleInterrupt *)(Msg->Arg));
		                     delete Msg;
                             Answer = TRUE;
							 break;

	  case MSG_CMD_CLR_INTS: Answer = ClearInterrupts();
		                     delete Msg;
                             Answer = TRUE;
							 break;

	  case MSG_CMD_SET_INTS: Answer = SetInterrupts();
			                 delete Msg;
                             Answer = TRUE;
							 break;

	  case MSG_CMD_DEL_INT : Answer = DeleteInterrupt(*((CTurtleInterrupt *)(Msg->Arg)));
		                     delete Msg;
                             Answer = TRUE;
							 break;
	
	  case MSG_CMD_USER_INT: m_UserIntMsg = (DWORD(Msg->Arg));
							 m_pUserIntQ = ((CMessageQueue *)(Msg->Ptr));
                             delete Msg;
                             Answer = TRUE;
                             break;

	  case MSG_CMD_DEATH_PP: m_ppDeathIndicator = (DWORD **)(Msg->Arg);
		                     delete Msg;
                             Answer = TRUE;
						     break;

	  case MSG_CMD_DEL_ALL_INTS: DeleteAllInterrupts();
		                         Answer = TRUE;
								 break;

	  default: 
		  ASSERT(FALSE); // Unknown Command
		  return ERROR;
    }

	return Answer;
}				  


#define NUM_VERTICES_IN_POLYGON 4

BOOL CTurtle::_Draw(CPoint Scroll, CDC *pDC)
// draws the turtle on the board
{ if (m_Hidden) return FALSE;  // I'm hidden
	
  POINT TurtlePoly[NUM_VERTICES_IN_POLYGON];
  LOGPEN foo;
  double CurrHeading = Deg2Rad(m_Heading);
  CPoint Location = Dp2Cp(m_Location);
  m_Pen->GetLogPen(&foo);

  CPen *pPolyPen;
  CPen *pOldPen;
  CBrush *pPolyBrush;
  if (m_IsSolid) pPolyBrush = new CBrush(m_Color);
  else pPolyBrush = new CBrush(m_BgColor);
  CBrush *pOldBrush = pDC->SelectObject(pPolyBrush);
  
  int dX = int(cos (CurrHeading) * 10);
  int dY = int(sin (CurrHeading) * 10);

  TurtlePoly[0].x = Location.x + dX;  // head
  TurtlePoly[0].y = Location.y + dY;
  
  CurrHeading += CONST_PI;   // moving to tail
  
  dX = int (cos (CurrHeading) * 5);
  dY = int (sin (CurrHeading) * 5);
  TurtlePoly[2].x = Location.x + dX; // tail
  TurtlePoly[2].y = Location.y + dY;
  
  dX = int (cos (CurrHeading) * 10);
  dY = int (sin (CurrHeading) * 10);
  int TailX = Location.x + dX; // tail
  int TailY = Location.y + dY;


  
  CurrHeading += CONST_PI / 2;   // left point
  dX = int (ceil(cos (CurrHeading) * 7));
  dY = int (sin (CurrHeading) * 7);
    
  TurtlePoly[1].x = TailX + dX;
  TurtlePoly[1].y = TailY + dY;
  
    
  CurrHeading += CONST_PI;    // right point
  dX = int (cos (CurrHeading) * 7);
  dY = int (sin (CurrHeading) * 7);
 
  TurtlePoly[3].x = TailX + dX;
  TurtlePoly[3].y = TailY + dY;
  
  for (int i=0;i<4;i++)
  { TurtlePoly[i].x -= Scroll.x;
    TurtlePoly[i].y -= Scroll.y;
  }

  if (m_IsSolid)
  {  pPolyPen = new CPen(PS_SOLID, 1 , m_Color);
	 pOldPen = pDC->SelectObject(pPolyPen);
	 pDC->Polygon(TurtlePoly, NUM_VERTICES_IN_POLYGON);
     pDC->FloodFill(Location.x - Scroll.x, Location.y - Scroll.y, m_Color);
  }

  else
  {  pPolyPen = new CPen(PS_SOLID, 1, m_BgColor);
	 pDC->Polygon(TurtlePoly, NUM_VERTICES_IN_POLYGON);
     pDC->FloodFill(Location.x - Scroll.x, Location.y - Scroll.y, m_BgColor);
	 delete pPolyPen;
	 pPolyPen = new CPen(PS_SOLID, 1, m_Color);
	 pDC->SelectObject(pPolyPen);
	 pDC->Polygon(TurtlePoly, NUM_VERTICES_IN_POLYGON);
  }
     
  

  pDC->SelectObject(pOldPen);
  pDC->SelectObject(pOldBrush);
  delete pPolyPen;
  delete pPolyBrush;
  
  return TRUE;
}



BOOL CTurtle::PenErase()
// pen is in the color of the view's background
{ 	LOGPEN foo;
    m_Pen->GetLogPen(&foo);
	delete m_Pen;
	foo.lopnColor = m_BgColor;
	m_Pen = new CPen;
	m_Pen->CreatePenIndirect(&foo);
	m_Erase = TRUE;
	m_PenUp = FALSE;
	return TRUE; 

}


BOOL CTurtle::Clone(CMessageQueue *pReturn)
// return a CTurtle with the same innter state
{  CTurtle *pT = new CTurtle(*this);
   CMessage Msg(MSG_ANS_NEW, 0, pT);
   m_pView->AddTurtle(pT);
   pReturn->Post(Msg);
   return TRUE;

}


CPoint CTurtle::Dp2Cp(CDoublePoint Cd)
// Converts a CDoublePoint to a CPoint
{  CPoint *pCP;
    
   pCP = new CPoint(Double2Long(Cd.x), Double2Long(Cd.y));
   return *pCP;

}

LONG CTurtle::Double2Long(double D)
// convert long to double
{  LONG L = LONG(D);
   if (D - double(L) >= 0.5) L++;
   return L;
}

BOOL CTurtle::Hide()
// change the hidden flag to be true
{ if (m_Hidden) return FALSE;
  m_Hidden = TRUE;
  m_pView->RefreshPicture(Dp2Cp(m_Location),Dp2Cp(m_Location)); 
  return TRUE;

}

BOOL CTurtle::Show()
// make the turtle visible
{ if (!m_Hidden) return FALSE;
  m_Hidden = FALSE;
  m_pView->RefreshPicture(Dp2Cp(m_Location),Dp2Cp(m_Location)); 
  return TRUE;
}

BOOL CTurtle::NewView(CBoardView *View, CDC *Picture)
// new view parameters
{ m_pView = View;
  m_pPicture = Picture;

  return TRUE;
}


CTurtle::~CTurtle()
{  m_pView->KillTurtle(this);
   for (int i = 0;i<m_Interrupts.GetSize();i++) delete m_Interrupts[i];
   if (m_ppDeathIndicator && *m_ppDeathIndicator) *m_ppDeathIndicator = NULL; 
   delete (m_Pen);
}

BOOL CTurtle::MoveView(CBoardView *pV)
// move to a new view
{ m_pView->KillTurtle(this);
  if (pV) pV->AddTurtle(this);
  pV->CallTurtlesInterrupts(Dp2Cp(m_Location), Dp2Cp(m_Location));
  return TRUE;
}

BOOL CTurtle::Move2Abs(CPoint *Location, BOOL DoInts)
// Move to an absolote position
{  if ((Location->x < 0) || (Location->y < 0) || (Location->x > double(m_pView->MaxX())) || (Location->y > double(m_pView->MaxY()))) 
   return FALSE;
   
   CPoint OldLocation = Dp2Cp(m_Location);
   m_Location.x = double(Location->x);
   m_Location.y = double(Location->y);

   m_pView->RefreshPicture(OldLocation, OldLocation);
   m_pView->RefreshPicture(*Location, *Location);
   if (DoInts)
   { m_pView->CallTurtlesInterrupts(OldLocation, OldLocation);
     m_pView->CallTurtlesInterrupts(*Location, *Location);
   }
   
   return TRUE;
}


BOOL CTurtle::Look4Color(COLORREF Color, double Deg, UINT Distance, CPoint UL, CPoint DR)
// Looks for a color in the pie, Deg is half of the view range
// Returns TRUE if there is a pixel in color Color in the triangle
// UL and DR are the rectangle where the chage on the board happed, if it does not cross with
// our search rectangle then return FALSE
{  double TDeg;
  
  CPoint Base = Dp2Cp(m_Location);
  CPoint Right = Base;   // the right (clockwise) point
  CPoint Left = Base; // the left (anti clockwise) point
  double dX,dY;       // location calculation
  
  TDeg = m_Heading + Deg;
  if (TDeg > 360) TDeg -= 360;
  dX = cos(Deg2Rad(TDeg)) * Distance;
  dY = sin(Deg2Rad(TDeg)) * Distance;
  Right.Offset(int(dX), int(dY));


  TDeg = m_Heading - Deg;
  if (TDeg < 0) TDeg += 360;
  dX = cos(Deg2Rad(TDeg)) * Distance;
  dY = sin(Deg2Rad(TDeg)) * Distance;
  Left.Offset(int(dX), int(dY));

     // claculating the search rectangle
  long MaxX = __max(__max(Base.x, Left.x), Right.x);
  long MaxY = __max(__max(Base.y, Left.y), Right.y);
  long MinX = __min(__min(Base.x, Left.x), Right.x);
  long MinY = __min(__min(Base.y, Left.y), Right.y);

  // does the changed region interest us?
  if (!CrossRects(UL,DR,CPoint(MinX, MinY), CPoint(MaxX, MaxY))) return FALSE;
  
  
   // searching
  int x,y;
  for (x = MinX; x <= MaxX; x++)
  {    for (y = MinY; y <= MaxY; y++)
       { if ((Det(Base.x, Base.y, Left.x , Left.y , x, y) >= 0) &&  // inside the rays
		     (Det(Base.x, Base.y, Right.x, Right.y, x, y) <= 0) &&
			 (FindDistance(Base, x, y) <= Distance))
    	    	if (m_pPicture->GetPixel(x,y) == Color) return TRUE;
	   }
  }


  return FALSE;  // not found
}




BOOL CTurtle::Look4Turtle(CTurtle *pT, double Deg, UINT Distance, CPoint UL, CPoint DR)
// Looking for a turtle pT in the view region(Deg, Distance)
// If pT is NULL then look for any turtle there
// The method is building a small bitmap and every relevant turtle will place a red dot on it
// Then search the bitmap and if a point is in the view region and has the right color we return
// TRUE
{ double TDeg;
  CPoint MiscPoint;
  CPoint Base = Dp2Cp(m_Location);
  CPoint Right = Base;
  CPoint Left = Base; // point of the tirangle
  double dX,dY;       // location calculation
  

  if (pT && (pT->View() != m_pView)) // not on the same view
    return FALSE; 
  
  // calculate the triangle
  TDeg = m_Heading + Deg;
  if (TDeg > 360) TDeg -= 360;
  dX = cos(Deg2Rad(TDeg)) * Distance;
  dY = sin(Deg2Rad(TDeg)) * Distance;
  Right.Offset(int(dX), int(dY));


  TDeg = m_Heading - Deg;
  if (TDeg < 0) TDeg += 360;
  dX = cos(Deg2Rad(TDeg)) * Distance;
  dY = sin(Deg2Rad(TDeg)) * Distance;
  Left.Offset(int(dX), int(dY));

    // the search square
  long MaxX = __max(__max(Base.x, Left.x), Right.x);
  long MaxY = __max(__max(Base.y, Left.y), Right.y);
  long MinX = __min(__min(Base.x, Left.x), Right.x);
  long MinY = __min(__min(Base.y, Left.y), Right.y);

  if (!CrossRects(UL, DR, CPoint(MinX, MinY), CPoint(MaxX, MaxY))) return FALSE;

  if (pT)
  { MiscPoint = pT->Location();
	if ((Det(Base.x, Base.y, Left.x ,Left.y , MiscPoint.x, MiscPoint.y) >= 0) &&  // inside the rays
		(Det(Base.x, Base.y, Right.x, Right.y, MiscPoint.x, MiscPoint.y) <= 0) &&
	    (FindDistance(Base, MiscPoint.x, MiscPoint.y) <= Distance))
	     return TRUE;
	else return FALSE;
  }
    	 
  return m_pView->DotTurtles(Base, Left, Right, Distance, CPoint(MinX, MinY), CPoint(MaxX, MaxY), this);  
  
}



CBoardView *CTurtle::View()
// my view
{ return m_pView;

}

BOOL CTurtle::DoAllInterrupts(CPoint UL, CPoint DR)
// does all the interrupts
{  	if (!m_DoInterrupts) return FALSE;
    for (int i=0;i<m_Interrupts.GetSize();i++)
    { m_Interrupts[i]->Go(UL, DR);
	}
   return TRUE;

}

BOOL CTurtle::AddInterrupt(CTurtleInterrupt *pInt)
// Adds an iterrupt to the turtle's interrupt array
{ int InsertIndex = -1;
  m_DoInterrupts = TRUE;
  for (int i=0;i<m_Interrupts.GetSize();i++)
	  if (*m_Interrupts[i] == *pInt) InsertIndex = i;

  if (InsertIndex < 0) m_Interrupts.Add(pInt); // a new interrupt
  else
  { delete m_Interrupts[InsertIndex];
    m_Interrupts[InsertIndex] = pInt;
  }
  pInt->Go(CPoint(0,0), CPoint(MAX_BOARD_X, MAX_BOARD_Y));
  return TRUE;
}


BOOL CTurtle::DeleteInterrupt(CTurtleInterrupt Int)
// delelte an interrupt from the interrupt array
{ for (int i=0;i<m_Interrupts.GetSize();i++)
 	if ((*(m_Interrupts[i])) == Int)
    { delete m_Interrupts[i];
	  m_Interrupts.RemoveAt(i);
	  if (!m_Interrupts.GetSize()) m_DoInterrupts = FALSE;	   // no more interrupts
	  return TRUE;
    }
  return FALSE;

}


BOOL CTurtle::SetInterrupts()
// set the interrupt flag to be true
{ if (!m_Interrupts.GetSize()) return FALSE; // no one to do
  m_DoInterrupts = TRUE;
  return TRUE;
}

BOOL CTurtle::ClearInterrupts()
// set the interrupt flag to be false
{ if (!m_DoInterrupts) return FALSE;
  m_DoInterrupts = FALSE;
  return TRUE;
}

void CTurtle::SetBgColor(COLORREF Color)
// the view got a new background color
{ m_BgColor = Color;
}

BOOL CTurtle::GlideTo(CPoint P)
// moving to point P without drawing
{ double OldHeading = Heading();

  SetAbsHeading(m_pView->Angle(Location(), P));
  UINT Distance = FindDistance(P, int(m_Location.x), int(m_Location.y)); //UINT(sqrt(pow(abs(m_Location.x - P.x), 2) + pow(abs(m_Location.y - P.y),2)));
  FD(Distance);
  SetAbsHeading(OldHeading);
  return TRUE;
}


int CTurtle::Det(int BegLineX, int BegLineY, int EndLineX, int EndLineY, int PointX, int PointY)
// calculates if Point is clockwise or anti clockwise to the line BegLine - EndLine
// > 0 means clockwise
// < 0 means anti clockwise
// = 0 means it's on the line
{ return BegLineX * (EndLineY - PointY) - EndLineX * (BegLineY - PointY) + PointX * (BegLineY - EndLineY);
}


UINT CTurtle::FindDistance(CPoint P1, int x, int y)
// calculates the distance between P1 and P2
{ return UINT(sqrt(pow(abs(P1.x - x), 2) + pow(abs(P1.y - y),2)));
}

BOOL CTurtle::CrossRects(CPoint UL1, CPoint DR1, CPoint UL2, CPoint DR2)
// return true is the areas of the rectangles cross
{ if ((UL1.y <= UL2.y) && (UL2.y <= DR1.y) && (UL1.x <= DR2.x) && (DR2.x <= DR1.x)) return TRUE;
  if ((UL1.y <= UL2.y) && (UL2.y <= DR1.y) && (UL1.x <= UL2.x) && (UL2.x <= DR1.x)) return TRUE; 
  if ((UL1.y <= DR2.y) && (DR2.y <= DR1.y) && (UL1.x <= UL2.x) && (UL2.x <= DR1.x)) return TRUE;
  if ((UL2.y <= UL1.y) && (UL1.y <= DR2.y) && (UL2.x <= UL1.x) && (UL1.x <= DR2.x)) return TRUE;
  
  return FALSE;
}


BOOL CTurtle::DeleteAllInterrupts()
// deletes all the interrupts and resized the array to be of size 0
{ for (int i=0;i<m_Interrupts.GetSize();i++)
   delete m_Interrupts[i];
  m_Interrupts.SetSize(0);
  m_DoInterrupts = FALSE;
  return TRUE;
}

BOOL CTurtle::UserInterrupt()
// the user right clicked next to the turtle, send the message to the queue if exsist
{  CMessage Msg;
   if (m_pUserIntQ)
   { Msg.type = 0;
     Msg.msg = MSGMSG_SCMURGENT;
	 Msg.ptr = LPVOID(m_UserIntMsg);
	 m_pUserIntQ->CMsgQx::PostUrgent(Msg);
   	 return TRUE;
   }

   return FALSE;
}


BOOL CTurtle::nullDI()
// Set the pointer on the stack to NULL -> turtle not alive
{ if (m_ppDeathIndicator == NULL) return FALSE;
  m_ppDeathIndicator = NULL;
  return TRUE;
}

void CTurtle::DelUserInterrupt()
// delete the user interrupt, actually just make the queue NULL
{ m_pUserIntQ = NULL;
}

BOOL CTurtle::IterateInts(Msgs *Ms)
// interator on all the interrupts, used for GC
{ if (m_IntsIterator == m_Interrupts.GetSize()) return FALSE;
  Ms->MsgIs = m_Interrupts[m_IntsIterator]->MsgIs;								  
  Ms->MsgNot = m_Interrupts[m_IntsIterator]->MsgNot;								  
  Ms->Kind = m_Interrupts[m_IntsIterator]->Kind;								  
  m_IntsIterator++;
  return TRUE;
}

BOOL CTurtle::ResetIterateInts()
// Reset the interrupts iterator
{ if (m_Interrupts.GetSize() == 0) return FALSE;
  m_IntsIterator = 0;
  return TRUE;

}

