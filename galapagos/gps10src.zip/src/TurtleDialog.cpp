// TurtleDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Shell.h"
#include "Board.h"
#include "TurtleDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTurtleDialog dialog


CTurtleDialog::CTurtleDialog(CPoint location, UINT heading, BOOL penup, CWnd* pParent /*=NULL*/)
	: CDialog(CTurtleDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTurtleDialog)
	m_X = location.x;
	m_Y = location.y;
	m_Heading = heading;
	m_PenUp = penup;
	//}}AFX_DATA_INIT
}


void CTurtleDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTurtleDialog)
	DDX_Text(pDX, IDC_TURTLE_X, m_X);
	DDV_MinMaxUInt(pDX, m_X, 0, MAX_BOARD_X);
	DDX_Text(pDX, IDC_TURTLE_Y, m_Y);
	DDV_MinMaxUInt(pDX, m_Y, 0, MAX_BOARD_Y);
	DDX_Text(pDX, IDC_TURTLE_HEADING, m_Heading);
	DDV_MinMaxUInt(pDX, m_Heading, 0, 360);
	DDX_Check(pDX, IDC_CHECK1, m_PenUp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTurtleDialog, CDialog)
	//{{AFX_MSG_MAP(CTurtleDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTurtleDialog message handlers
