// ShellView.cpp : implementation of the CShellView class
//

#include "stdafx.h"
#include "Shell.h"

#include "ShellDoc.h"
#include "ShellView.h"
#include "MsgQ.h"
#include "comb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define ThisEdit GetEditCtrl()

/////////////////////////////////////////////////////////////////////////////
// CShellView

IMPLEMENT_DYNCREATE(CShellView, CEditView)

BEGIN_MESSAGE_MAP(CShellView, CEditView)
	//{{AFX_MSG_MAP(CShellView)
	ON_WM_CHAR()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_SCM_BREAK, OnScmBreak)
	ON_COMMAND(ID_SCM_FORK, OnScmFork)
	ON_COMMAND(ID_SCM_UN_BIND, OnScmUnbind)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_SCM_GC, OnScmGc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShellView construction/destruction

CShellView::CShellView()
{
	// TODO: add construction code here
	m_MaxLines=10000;
	m_InputLine="";
	m_pCombination=NULL;
}

CShellView::~CShellView()
{
}

BOOL CShellView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping
	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CShellView drawing

void CShellView::OnDraw(CDC* pDC)
{

	CShellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CShellView diagnostics

#ifdef _DEBUG
void CShellView::AssertValid() const
{
	CEditView::AssertValid();
}

void CShellView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CShellDoc* CShellView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CShellDoc)));
	return (CShellDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShellView message handlers

void CShellView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
// if the char in not newline just print it, otherwise send the current line to 
// the interpreter
{ char Line[255];
  switch(nChar)
  { case VK_RETURN: 
                Line[ThisEdit.GetLine(ThisEdit.LineFromChar(),Line,254)] = '\0';
				m_InputLine = Line;
				m_InputLine += "\n";
   				if (m_InputLine.Left(1) == ">")
					m_InputLine=m_InputLine.Mid(1);
				
				if (ThisEdit.LineIndex() == ThisEdit.LineIndex(ThisEdit.GetLineCount()-1))
				{
				  GotoEOL();
				  ThisEdit.ReplaceSel("\r\n");
				}
			
				if (m_pCombination != NULL)
					m_pCombination->pTheInputQueue->Post(CMessage(STR_WINDOW2INTERPRETER,(DWORD)new CString(m_InputLine)));

			
				if (ThisEdit.GetLineCount() >= m_MaxLines)  // delete the first lines
				{ 
					int savestart, saveend, start, end;
					ThisEdit.GetSel(savestart,saveend);
					while ( ThisEdit.GetLineCount() > m_MaxLines )
					{
						ThisEdit.SetSel(0,0,FALSE);
						GotoEOL();
						ThisEdit.GetSel(start,end);
						end+=2;
						ThisEdit.SetSel(0, end);
						ThisEdit.Clear();
						ThisEdit.SetSel(savestart,saveend);
					}
				}
				else 
				{ GotoEOF();
				}
				  
                
				break;

	  default:
				CEditView::OnChar(nChar, nRepCnt, nFlags);
				
	}
}

void CShellView::OnInitialUpdate() 
{

	CEditView::OnInitialUpdate();
	
}

void CShellView::Clear()
{		ThisEdit.Clear();
}


inline void CShellView::GotoEOL() 
// goto the end of the current line
{ int loc;

  loc = ThisEdit.LineIndex()+ThisEdit.LineLength(ThisEdit.LineIndex());
  ThisEdit.SetSel(loc,loc,TRUE) ;
}

void CShellView::GotoEOF()
// goto the end of the file
{ int End = ThisEdit.LineIndex(ThisEdit.GetLineCount()-1);
  End+= ThisEdit.LineLength(ThisEdit.GetLineCount()-1) + 1;
  ThisEdit.SetSel(End,End,TRUE);
}


void CShellView::Print (CString str)
// prints the string str
{ GotoEOF();
  ThisEdit.ReplaceSel (str);
}

extern CShellView * MeanWhile_TheActiveView;

void CShellView::OnSetFocus(CWnd* pOldWnd) 
// sets this window to be the active one
{
	CEditView::OnSetFocus(pOldWnd);
	MeanWhile_TheActiveView = this;
		
}

extern CShellApp theApp;

void CShellView::OnScmBreak() 
// send a urgent message to the interpreter, telling it to break
{
	m_pCombination->pTheInputQueue->CMsgQx::PostUrgent(CMessage(
		0,
		MSGMSG_URGENTSTR,
		"(break& (newline) (display \"User break\") (newline))"));
}

void CShellView::OnScmFork() 
// create a new interpreter with a console
{
	m_pCombination->pTheInputQueue->CMsgQx::PostUrgent(CMessage(
		0,
		MSGMSG_URGENTSTR,
		"(new-thread (bind-to-console))"));
}

void CShellView::OnScmUnbind() 
// unbinds the thread form the console
{
	m_pCombination->pTheInputQueue->CMsgQx::PostUrgent(CMessage(
		0,
		MSGMSG_URGENTSTR,
		"(unbind-console)"));
}

void CShellView::OnScmGc() 
// starts GC
{ m_pCombination->pTheInputQueue->CMsgQx::PostUrgent(CMessage(
		0,
		MSGMSG_URGENTSTR,
		"(gc)"));
	
}
