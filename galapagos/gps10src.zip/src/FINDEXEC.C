/* elad!

	Consider dumping this file.
	No Threadwise modification
*/

/* This file was part of DLD, a dynamic link/unlink editor for C.

   Copyright (C) 1990 by W. Wilson Ho.

   The author can be reached electronically by how@cs.ucdavis.edu or
   through physical mail at:

   W. Wilson Ho
   Division of Computer Science
   University of California at Davis
   Davis, CA 95616

Fri Sep 14 22:16:14 1990  Edgar Roeder  (edgar at megamaster)

	* added a separate DLDPATH environment variable in
	dld_find_executable so that users may specify a special path
	for object modules.

Thu Feb  3 01:46:16 1994  Aubrey Jaffer  (jaffer@jacal)

	* find_exec.c (dld_find_executable): added stat check for
	linux so that it doesn't think directories with the same name
	as the program are executable.

Wed Feb 21 23:06:35 1996  Aubrey Jaffer  <jaffer@jacal.bertronics>

	* find_exec.c: extracted for general use.  Generalized to
	MS-DOS.  */

/* This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 1, or (at your option) any
   later version. */

/* Given a filename, dld_find_executable searches the directories
   listed in the environment variable PATH for a file with that
   filename.  A new copy of the complete path name of that file is
   returned.  This new string may be disposed by free() later on.  */

#ifdef _WIN32 /*elad*/
# include <malloc.h> /*elad*/
# include <string.h> /*elad*/
# include <direct.h> /*elad*/
# include <stdlib.h> /*elad*/
# include <io.h> /*elad*/
# define MAXPATHLEN 250 /*elad*/
# define X_OK 4 /*elad*/
# define DEFAULT_PATH "."	  /*elad*/
#else /*elad*/
# include <sys/file.h>
# include <sys/param.h>
# include <strings.h>
#endif /*elad*/
#ifdef linux
# include <stdlib.h>
# include <sys/stat.h>
# include <unistd.h>     /* for X_OK define */
#endif
#ifdef __svr4__
# include <stdlib.h>
# include <sys/stat.h>
# include <unistd.h>     /* for X_OK define */
#endif
#ifndef __STDC__
# define const /**/
#endif

#ifndef DEFAULT_PATH
# define DEFAULT_PATH ".:~/bin::/usr/local/bin:/usr/new:/usr/ucb:/usr/bin:/bin:/usr/hosts"
#endif

#ifndef linux
# ifndef _WIN32 /*elad*/
#  define linux			/* should work with any unix */
# endif /*elad*/
#endif linux

static char *copy_of(s)
     register const char *s;
{
  register char *p = (char *) malloc(strlen(s)+1);
  if (!p) return 0;
  *p = 0;
  strcpy(p, s);
  return p;
}

/* ABSOLUTE_FILENAME_P(fname): True if fname is an absolute filename */
#ifdef atarist
# define ABSOLUTE_FILENAME_P(fname)	((fname[0] == '/') || \
	(fname[0] && (fname[1] == ':')))
#else
# define ABSOLUTE_FILENAME_P(fname)	(fname[0] == '/')
#endif /* atarist */

#ifndef _WIN32
char *dld_find_executable(file)
     const char *file;
{
  char *search;
  register char *p;
  char name[MAXPATHLEN];

  if (ABSOLUTE_FILENAME_P(file))
    return copy_of(file);

# ifdef linux
  if ((file[0] == '.') && (file[1] == '/')) {
    getcwd(name, MAXPATHLEN);
    strcat(name, file+1);
    return copy_of(name);
  }
# endif

  if (((search = (char *) getenv("DLDPATH")) == 0) &&
      ((search = (char *) getenv("PATH")) == 0))
    search = DEFAULT_PATH;

  p = search;

  while (*p) {
    register char *next;

    next = name;

    if (p[0]=='~' && p[1]=='/' && getenv("HOME")) {
      strcpy(name, getenv("HOME"));
      next = name + strlen(name);
      p++;
    }

    /* copy directory name into [name] */
    while (*p && *p != ':') *next++ = *p++;
    *next = 0;
    if (*p) p++;

    if (name[0] == '.' && name[1] == 0)
      getcwd(name, MAXPATHLEN);	/* was getwd(name); */
    else if (name[0]=='~' && name[1]==0 && getenv("HOME"))
      strcpy(name, getenv("HOME"));

    strcat(name, "/");
    strcat(name, file);

    if (access(name, X_OK) == 0) {
# ifdef linux
      struct stat stat_temp;
      if (stat(name,&stat_temp)) continue;
      if (S_IFREG != (S_IFMT & stat_temp.st_mode)) continue;
# endif/* linux */
      return copy_of(name);
    }
  }

  return 0;
}
#endif /* _WIN32 */