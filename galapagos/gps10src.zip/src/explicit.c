/* explicit.c - explicit environments, closures etc for SCM */

#include "scm.h"
#include "comb.h"

extern SCM make_synt(char *name, SCM (*macroizer)(), SCM (*fcn)()); /*eval.c*/

#ifdef TC16_ENVW
# define tc16_envw TC16_ENVW
#else
 int tc16_envw;
#endif

#define ENVWP(x) (CELLP(x) && (TYP16(x)==tc16_envw))

/*
  An environment is a cons (frame . nextenv). The top environment is an immediate, EOL.
  A frame is a cons (vars . vals). These are same-length lists of variables and their
  values 
*/


//static smobfuns promsmob = {markcdr, free0, prinprom};

static int printenvw(SCM exp, SCM port, int writing)
{
  lputs("#<environment 0x", port);
  intprint(CDR(exp), 16, port);
  lputc('>', port);
  return !0;
}



SCM cdr_eq (SCM x, SCM y)
{ return ( CDR(x)==CDR(y) ) ? BOOL_T : BOOL_F;
}
//#define ASSERT(_cond, _arg, _pos, _subr) if(!(_cond))wta(_arg, (char *)(_pos), _subr);

SCM proc_env (SCM c)
{	SCM result;
	ASSERT(CELLP(c) && CLOSUREP(c), c, ARG1, "closure-environment");
	DEFER_INTS;
	NEWCELL(result);
	CAR(result)=tc16_envw;
	CDR(result)=ENV(c);
	ALLOW_INTS;
	return result;
}

SCM env2list (SCM envw)
{	ASSERT(ENVWP(envw), envw, ARG1, "environment->list");
	return CDR(envw);
}

/* A clone of an environment */
SCM clone_list(SCM);
#define myname "clone-environment"
SCM clone_env (SCM envw, SCM depth)  /* tc7_subr_2o: depth is optional */
{	int j;
	SCM x,y,src,result, *t;

	ASSERT(ENVWP(envw), envw, ARG1, myname);
	src=CDR(envw);
	if (depth == UNDEFINED)
	{	j=ilength(src);
		ASSERT (j!=-1, envw, ARG1, myname);
	}
	else 
	{	ASSERT(INUMP(depth), depth, ARG2, myname); /*elad!del line?*/
		j=num2ulong(depth, ARG1, myname);
	}
	DEFER_INTS;
	NEWCELL(result);
	CAR(result)=tc16_envw;
	t=&(CDR(result));
	while (j>0)
	{	NEWCELL(y);
		CAR(y)=clone_list(CAR(CAR(src))); /* clone variables */
		CDR(y)=clone_list(CDR(CAR(src))); /* clone values */
		NEWCELL(x);
		CAR(x)=y;
		*t=x;
		t=&(CDR(x));
		src=CDR(src);
		--j;
	}
	*t=src;
	ALLOW_INTS;
	
	return result;
}
#undef myname

/* clone_list gets a list and copies it. It will stuck on endless loops. */
SCM clone_list (SCM src)
{	SCM x,y, result;

	if IMP(src) return src;

	NEWCELL(x); result=x;

	for(;;)
	{
		CAR(x)=CAR(src);
		src=CDR(src);
		if NULLP(src)
		{
			CDR(x)=src;
			return result;
		}
		NEWCELL(y);
		CDR(x)=y;
		x=y;
	}
}

/* pop_env returns an envw without the first frane */

#define myname "pop-environment"
SCM pop_env (SCM envw)
{	SCM x;
	ASSERT(ENVWP(envw), envw, ARG1, myname);
	ASSERT(CELLP(CDR(envw)), envw, ARG1, myname);
	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_envw;
	CDR(x)=CDR(CDR(envw));
	ALLOW_INTS;
	return x;
}
#undef myname

/* ext_env returns an envw with a new empty first frame */

#define myname "extend-environment"
SCM ext_env (SCM envw)
{	SCM x;
	ASSERT(ENVWP(envw), envw, ARG1, myname);

	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_envw;
	CDR(x)=acons(EOL,EOL,CDR(envw));
	ALLOW_INTS;
	return x;
}		
#undef myname

#define myname "current-environment"
SCM m_cur_env (SCM args, SCM env)
{	SCM z;

	ASSERT (NULLP(CDR(args)), args ,WNA, myname); 
	DEFER_INTS;
	NEWCELL(z);
	CAR(z)=tc16_envw;
	CDR(z)=env;
	ALLOW_INTS;
	return z;
}
#undef myname

#define myname "environment?"
SCM envp (SCM x)
{	return ENVWP(x)? BOOL_T:BOOL_F;
}
#undef myname

#define myname "parent-environment"
SCM par_env()
{	SCM x;
	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_envw;
	CDR(x)=parent_env;
	ALLOW_INTS;
	return x;
}
#undef myname
#define myname "base-environment"
SCM base_env()
{	SCM x;
	DEFER_INTS;
	NEWCELL(x);
	CAR(x)=tc16_envw;
	CDR(x)=cur_base_env;
	ALLOW_INTS;
	return x;
}
#undef myname

#define myname "set-base-environment"
SCM set_base_env(SCM envw)
{	ASSERT (ENVWP(envw), envw, ARG1, myname);
	cur_base_env = CDR(envw);
	return UNDEFINED;
}
#undef myname

#define myname "eval@"  /* (eval@ env f1 f2 f3) */
SCM m_eval_at(SCM args, SCM env) 
{ 
	SCM envwp;
	ASSERT(ilength(args)>=3, args, WNA, myname);
	args=CDR(args);
	envwp=ceval(CAR(args), env);
	ASSERT(ENVWP(envwp), envwp, ARG1, myname);
	args=CDR(args);
	return ceval(cons(IM_BEGIN, args), CDR(envwp));
}
#undef myname

#define myname "eval@p" /* (eval@p x) evaluates x in parent's env */
SCM m_eval_at_parent(SCM args, SCM env)
{
	ASSERT(ilength(args)>=2, args, WNA, myname);
	return ceval(cons(IM_BEGIN, CDR(args)), parent_env);
}
#undef myname	


static smobfuns envw_smob = { markcdr, free0, printenvw, cdr_eq };

static iproc subr0s[] = {
	{"base-environment", base_env},
	{"parent-environment", par_env},
	{0,0} };

static iproc subr1s[] = {
	{"procedure-environment", proc_env},
	{"environment->list",   env2list},
	{"extend-environment",  ext_env},
	{"pop-environment",  pop_env},
	{"environment?", envp},
	{"set-base-environment", set_base_env},
	{0, 0} };

static iproc subr2os[] = {
	{"clone-environment", clone_env},
	{0,0} };


void init_explicit()
{ 
	tc16_envw = newsmob (&envw_smob);
	init_iprocs(subr0s, tc7_subr_0);
	init_iprocs(subr1s, tc7_subr_1);
	init_iprocs(subr2os, tc7_subr_2o);
	make_synt("current-environment", makacro, m_cur_env);
	make_synt("eval@", makacro, m_eval_at);
	make_synt("eval@p", makacro, m_eval_at_parent);
	cur_base_env=EOL; /* Initial env - toplevel */
}

/* Let's talk about macros. There are 3 types of macros:
   type0 (procedure->syntax) makacro()  such as: quasiquote, delay 
   type1 (procedure->macro)  makmacro()
   type2 (procedure->mmacro) makmmacro() like all special forms in SCM.
   All the underlying functions get two arguments, the first is the form eval'd
   as a list (its car is always the procedure itself); the second is the 
   environment they were called at. The difference is at what happens to the
   value the macro computes in context of the evaluator:
   type0 treats the result as data, and does not attempt to evaluate it.
   type1 treats the result as code, evaluates it, and treats the result
         as the result of the whole expression.
   type2 is like type1, but also "memoizes" the macro expansion. That is,
         a second attempt to evaluate the same expression will not need to
		 reexpand the macro, and will get it expanded. The reason all of SCM's
         special symbols are type2, is this: In memoization process, "or" for
		 example get replaced with the special symbol "#@or", which can then
		 be scanned through directly inside ceval() - faster
		 -elad*/
