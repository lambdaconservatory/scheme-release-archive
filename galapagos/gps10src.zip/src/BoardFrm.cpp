// BoardFrm.cpp : implementation of the CBoardFrame class
//

#include "stdafx.h"
#include "Shell.h"

#include "BoardFrm.h"
#include "BoardDoc.h"
#include "BoardView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CBoardFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CBoardFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CBoardFrame)
	ON_WM_GETMINMAXINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CBoardFrame::CBoardFrame()
{
	// TODO: add member initialization code here
	
}

CBoardFrame::~CBoardFrame()
{
}

BOOL CBoardFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return CMDIChildWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CBoardFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CBoardFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

void CBoardFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CRect R(0,0,MAX_BOARD_X,MAX_BOARD_Y);
	::AdjustWindowRect (R, WS_CAPTION|WS_CHILD|WS_THICKFRAME|WS_VISIBLE|WS_HSCROLL|WS_VSCROLL ,FALSE);
	lpMMI->ptMaxTrackSize=CPoint(R.right-R.left+3,
		R.bottom-R.top+3);
}


