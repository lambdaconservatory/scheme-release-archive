// GCD.cpp - the GC deamon implementation

/*
	GC is handled by a GC deamon, which is a special thread always running, but
	usually as dormant as a very bad rag. It is not counted as a SCM interpreter
	but it handles its internals.

	When a SCM interpreter needs more memory than available, it signals the GC
	deamon and waits. Cd can accept overlapping multiple GC request.

  GC deamon protocol:
	  
	1. GCd accepts a GC request
	2. GCd sends all thread a GC request, and signals GC request in freelist
	3. GCd collects mark information from all threads.
	4. Mark 
	5. Sweep
	6. GCd sets freelist and signals all thread to continue.

  SCM thread protocol:

	1. SCM recieves a GC request (as an UrgentMessage)
	2. SCM sends immediately a Mark Information Block
	3. Suspend until GCd says otherwise.

  or, in an Out of memory condition:

	1. SCM sends a GC request.
	2. SCM suspends and waits to a feedback GC request from GCd
	3. SCM sends a Mark Information Block.
	4. Suspend until GCd says otherwise.

	Many interpreters can "initiate" GC, this will probably happen in a out of memory condition.
	Since the GCd only responds to one of those requests, it is ok. However, Since an initiating
	thread will wait for 'confirmation' before sending its Mark information, any number of same-
	time GC request will only yield in one GC actually happening.

	GCd is also informed whenever a thread dies or is born, and will process these messages at all
	times. GCd saves an internal list of all running threads.

	Two "external" variables are used.
	The_GC_deamon_status is set by the GCd to indicate status (idle, mark, sweep)
	GC_NextGCis4NewCell is set from outside. If TRUE during GC, the GCd will also initialize
	more heap space if needed. This variable is set to FALSE automatically after GC.

*/


#include "stdafx.h"
#include "shell.h"
#include "mainfrm.h"
#include "threads.h"
#include "MsgQ.h"
#include "comb.h"
#include "mydebug.h"

#include "scm.h"
extern "C" {
#include "setjump.h"
           }
#include "ScmThrd.h"

#include "GCd.h" // Very large file 


#define GCD_THREAD_STARTS 1   // A SCM thread starts SCMing
#define GCD_THREAD_ENDS   2   // A SCM thread stops SCMing
#define GCD_DIE           3   // Ask the GC deamon to die
#define GCD_MARKINFO      4   // Accompanies Mark information
#define GCD_REQUEST_GC    5   // Request GC

extern "C" struct CMarkInfoBlock 
{ 
	jmp_buf regs;			// The outcome ot setjmp() saves all registers
	STACKITEM* stk;			// The interesting part of a thread's running stack
	sizet stksz;			// ,,,and it's size (in terms on STACKITEM)
	SCM* sys_protects;		// the thread's TLS sys_protects.
};

//extern "C" typedef CMarkInfoBlock* CMarkInfoBlockPtr;

class CGCdeamon
{
public:
	CGCdeamon(int& StatusIndicator, BOOL& Next);
	CMsgQx Q; // Queue used to send messages to the GC deamon
	friend void GCNotifyThreadStarts(SCM thrdobj);
	friend void GCNotifyThreadEnds(SCM thrdobj);
	friend void GCNotifyKillDeamon(SCM thrdobj);
	friend void GCNotifyRequestGC(SCM thrdobj);
	friend void GCNotifyMarkInfo(SCM thrdobj, CMarkInfoBlockPtr p);
	
	CEvent DoneEvent; 
	
protected:
	void Main(); // This is called by AfxBeginThread()
	int& StatusIndicator; // Set by the GC deamon to indicate status
	BOOL& NextGCis4NewCell; // In TRUE, then the current GC will have to yield free space

	// CMap is an associative array whose indices are (pointers to) Thread Objects (smobs).
	// The values they get ether NULL (initially), and then a pointer to the MarkInfoBlock
	// sent by the thread - block of information it wishes marked.
	CMap<SCM, SCM&, CMarkInfoBlockPtr, CMarkInfoBlockPtr&>  Active; //elad! initialize?
	enum { Idle, CollectingMarkInfo } State;
	int ThreadsConfirmed, RunningThreads; // # of threads that sent info
	void GC();
	void Mark();
	void Sweep();
	void UI_GC_Mark();
	void UI_GC_Sweep();
	void UI_GC_Done();
	static cell gcrootcont;
	static CONTINUATION Cont;
	friend UINT The_GC_deamon_Main (LPVOID pParam); // Simply calls Main()
};

int The_GC_deamon_status=-1;
BOOL GC_NextGCis4NewCell=FALSE;
CGCdeamon The_GC_deamon(The_GC_deamon_status,GC_NextGCis4NewCell); // Ths single GC deamon object

extern CShellApp theApp;

extern "C" extern void gc_start(char*);
extern "C" extern void gc_sweep();
extern "C" void mark_locations(STACKITEM x[], sizet n); // sys.c
extern "C" CONTINUATION *make_root_continuation(STACKITEM *stack_base); // continue.c
extern "C" long stack_size(STACKITEM *start); // continue.c
extern "C" extern void alloc_some_heap(); // sys.c
extern "C" extern int verbose;

CGCdeamon::CGCdeamon(int& XStatusIndicator, BOOL& Next) :
DoneEvent(FALSE/*InitiallyOwned*/,TRUE/*Manual?*/,"GCd"),
StatusIndicator(XStatusIndicator),
NextGCis4NewCell(Next)
{
	//?DoneEvent.ResetEvent();
	StatusIndicator = GC_STATUS_IDLE;
	NextGCis4NewCell=FALSE;
}


// GCdeamon_main is the main thread control function.
void CGCdeamon::Main ()
{
	State=Idle;
	Thrd=(DWORD)-1;
		
	CMessage msg;
	CMarkInfoBlockPtr lpv;
	SCM thrdobj;
	ThreadsConfirmed=-1;
	for(;;)
	{
		Q.Get(msg);
		thrdobj=(SCM)(msg.msg);
		switch(msg.type)
		{
		case GCD_THREAD_STARTS:
			TRACE0("GCd: Thread Started\n");
			WASSERT (!Active.Lookup(thrdobj, lpv));
			Active[thrdobj]=NULL;
			RunningThreads++;
			break;

		case GCD_THREAD_ENDS:
			TRACE0("GCd: Trhead ended\n");
			WASSERT (Active.Lookup(thrdobj, lpv));
			Active.RemoveKey(thrdobj);
			RunningThreads--;
			break;
			
		case GCD_REQUEST_GC:
			{
				TRACE0("GCd: GC Requested\n");
				if (State==CollectingMarkInfo) break;
				
				// Tell everybody we want their Mark info
				TRACE0("GCd: Sending GC reqs\n");
				SCM thrdobj;
				CMessageQueue* HisQueue;
				POSITION pos=Active.GetStartPosition();
				WASSERT (pos!=NULL); // No running interpreters
				do
				{
					Active.GetNextAssoc(pos, thrdobj, lpv);
					WASSERT(THREADP(thrdobj)); 
					HisQueue=(CMessageQueue*)THRDQ(thrdobj);
					HisQueue->CMsgQx::PostUrgent(CMessage(0, MSGMSG_URGENT_GC, (DWORD)0));
				} while (pos!=NULL);
				State=CollectingMarkInfo;
				ThreadsConfirmed=0;
				break;
			}

		case GCD_MARKINFO:
			WASSERT(Active.Lookup(thrdobj, lpv));
			Active[thrdobj]=(CMarkInfoBlockPtr)(msg.ptr);
			ThreadsConfirmed++;
			break;

		case GCD_DIE: // GCdeamon wanted dead.
			WASSERT(Threads==0); // Only kill GCdeamon after all SCM died.
			return;
			
		default: WASSERT(FALSE); // Unknown msg.type
		}
		
		if (ThreadsConfirmed==RunningThreads)
		{ // All threads are suspended
			WASSERT(State==CollectingMarkInfo);
			WASSERT(RunningThreads==(int)Threads); // Compare with global counter
			State=Idle;
			ThreadsConfirmed=-1;
			TRACE0("GCd: Starting GC\n");
			GC();
			NextGCis4NewCell=FALSE;
			DoneEvent.PulseEvent(); // Wake all threads up
		}
	}
}


CONTINUATION CGCdeamon::Cont;
cell         CGCdeamon::gcrootcont;

void CGCdeamon::GC() // based on igc()
{
	STACKITEM stackplace;

	// First we set a new continuation in case an error occours.
	// We could have used make_root_continuation() from continue.c, but
	// it uses must_malloc() which in may call igc().. So we don't.
	
	Cont.length=0;
	Cont.stkbse=&stackplace;
	Cont.parent=&Cont;
	Cont.other.ThreadID = ThisThreadID;
	Cont.other.dynenv = EOL;
	Cont.other.parent = BOOL_F;
	rootcont=(SCM)(&gcrootcont);
	SETCONT(rootcont, &Cont);
	CAR(rootcont) = tc7_contin;
	stacktrace = EOL;

	if (0 != setjmp(CONT(rootcont)->jmpbuf))  // Handle errors during GC
	{
		AfxMessageBox("Garbage Collection failed");
		return;
	}
	

	int saverbose=verbose;
	verbose=0; // Stay silent because we don't have any way to report anything anyway
	errjmp_bad=2;

	UI_GC_Mark();

	int j = num_protects;
	gc_start("GC deamon");

	// Mark each thread's information

	SCM thrdobj;
	CMarkInfoBlockPtr pMBI;

	POSITION pos=Active.GetStartPosition();
	do
	{
		Active.GetNextAssoc(pos, thrdobj, pMBI);
		
		mark_locations( pMBI->stk,  pMBI->stksz );  // Mark thread's stack
		mark_locations( (STACKITEM*)pMBI->regs, sizeof (jmp_buf) / sizeof (STACKITEM) ); // Mark thread's registers
		int j=num_protects; 
		while (j--) gc_mark(pMBI->sys_protects[j]);   // Mark thread's sys_protects
	} while (pos != NULL);


	// Sweep

	UI_GC_Sweep();

	gc_sweep(); 

	// Logic for allocating an extra hplim, taken from gc_for_newcell()

	gc_end();

	if (NextGCis4NewCell && ((gc_cells_collected < MIN_GC_YIELD) || IMP(freelist)))
	{
		TRACE0("GC Enters alloc_some_heap()");
		errjmp_bad=0;
		alloc_some_heap();
	}
	verbose=saverbose;

	UI_GC_Done();
  
}

void CGCdeamon::UI_GC_Mark()
{
	theApp.BeginWaitCursor();
	StatusIndicator = GC_STATUS_MARK;
	UpdateStatusBar();
}

void CGCdeamon::UI_GC_Sweep()
{
	theApp.BeginWaitCursor();
	StatusIndicator = GC_STATUS_SWEEP;
	UpdateStatusBar();
}

void CGCdeamon::UI_GC_Done()
{
	theApp.EndWaitCursor();
	StatusIndicator = GC_STATUS_IDLE;
	UpdateStatusBar();
}



// igc() used to be the Garbage Collection function in SCM.
// In here we use the same name for the function that asks for GC.
// What it does: It sends the GCdeamon a GC request; Waits for it to confirm it,
// and then passes control to ConsentGC(). In addition, it also buffers all UrgentMessages it
// recieves while waiting for confirmation, and reposts them. 

/* igc() is the main GC function. -elad*/
void ConsentGC();

extern "C" void igc(char *what, STACKITEM *stackbase)
{
 	GCNotifyRequestGC(cur_thread_obj);
	CMessage msg;
	CArray<CMessage, CMessage&> TempMessages; // Used to save UrgentMessages
	for (;;) 
	{ // Collect UrgentMessages 
		TheCombination.pTheInputQueue->CMsgQx::GetByType(msg, MSG_NEVERUSED);
		WASSERT(msg.type==0); 
		if (msg.msg == MSGMSG_URGENT_GC) break; 
		TempMessages.Add(msg);
	}
	
	ConsentGC(/*stackbase*/); // Send GCd the information it needs and wait for it to set us free

	// Resend the collected UrgentMessages. 
	// CMsgQx::PostUrgentAtHead() is used so that the overall order of UrgentMessages is kept
	int j=TempMessages.GetSize();
	while (j--)
		TheCombination.pTheInputQueue->CMsgQx::PostUrgentAtHead(TempMessages[j]);
}

// ConsentGC() is called by a SCM thread whenever a GC is due.
// What it does: ConsentGC() gathers information about the current C-stack, registers,
// and the TLS sys_protects, and sends them to the GC deamon, which is supposed to be
// waiting for them when this function is called. Then it waits for GCd to signal it's
// done GCing.

// Differences from the opriginal SCM igc(): Stack is always scanned from rootcont->stkbase

#ifdef STACK_GROWS_UP
# error Wrong Architecture - ConsentGC() is only for stack-grow-down
#endif
void ConsentGC()
{
	CMarkInfoBlockPtr pMIB = new CMarkInfoBlock;
	++errjmp_bad;
	
	// Fill Mark info block:
	// - Save sys_protects
	pMIB->sys_protects = new SCM[num_protects];
	int j = num_protects;
	while (j--) pMIB->sys_protects[j]=sys_protects[j];
    
	// - Save registers (assuming jmp_buf does the job)
    setjmp(pMIB->regs);
    
	// - Save the stack
	long stack_len = stack_size(CONT(rootcont)->stkbse);
	pMIB->stk = new STACKITEM[stack_len];
	STACKITEM* pSI = CONT(rootcont)->stkbse - stack_len;
	j=stack_len; while (j--) pMIB->stk[j]= *(pSI++);
	pMIB->stksz = stack_len;
	
	// Notify GC deamon about the information we gathered
	
	GCNotifyMarkInfo(cur_thread_obj, pMIB);
	
	// Wait until GC is done
	TRACE1 ("Thrd%d sleeps until GC is done\n", Thrd);
	CSingleLock Wait_gcd(&The_GC_deamon.DoneEvent, FALSE/*InitiallyLocked*/);
	Wait_gcd.Lock();
	TRACE1 ("Thrd%d woke up after GC\n", Thrd);
	
	// Release memory used
	delete pMIB->sys_protects;
	delete pMIB->stk;
	delete pMIB;
	--errjmp_bad;
}


// Outer interface ---------------------------------------------------------------------

// These two functions tie things up.
// You call Start_GC_deamon(), and a thread running The_GC_deamon.Main() starts running.
// It has very little value but keeping the class whole.

UINT The_GC_deamon_Main (LPVOID pParam) // friend of CGCdeamon
{
	The_GC_deamon.Main();
	return 0;
}

void Start_GC_deamon()
{
	AfxBeginThread( The_GC_deamon_Main, NULL );
}


void GCNotifyThreadStarts(SCM thrdobj)
		{ The_GC_deamon.Q.Post(CMessage(GCD_THREAD_STARTS, thrdobj, (DWORD)0)); }

void GCNotifyThreadEnds(SCM thrdobj)
		{ The_GC_deamon.Q.Post(CMessage(GCD_THREAD_ENDS, thrdobj, (DWORD)0)); }

void GCNotifyKillDeamon()				  
		{ The_GC_deamon.Q.Post(CMessage(GCD_DIE, (DWORD)0, (DWORD)0)); }

void GCNotifyRequestGC(SCM thrdobj)				  
		{ The_GC_deamon.Q.Post(CMessage(GCD_REQUEST_GC, thrdobj, (DWORD)0)); }
	
void GCNotifyMarkInfo(SCM thrdobj, CMarkInfoBlockPtr p)
		{ The_GC_deamon.Q.Post(CMessage(GCD_MARKINFO, thrdobj, (DWORD)p)); }


/* NewCellEx is called by NEWCELL whenever freelist is not a pointer.
   It is either EOL (end of heap memory) or UNDEFINED (locked).
   By the time NewCellEx() is read, then freelist is already UNDEFINED, no matter
   what its OldValue was -elad */

extern "C" SCM NewCellEx (SCM OldValue)
{
	TRACE1("Thrd%d enterend NewCellEx()\n", Thrd);
BusyWait:
	if (OldValue == UNDEFINED)
	{	
		Sleep(0); /* Give up CPU slice */
TryAgain:
		if IMP(OldValue=InterlockedExchange(&freelist, UNDEFINED)) goto BusyWait;
		
		cells_allocated++;
		InterlockedExchange(&freelist, CDR(OldValue));
		TRACE1("Thrd%d escaped NewCellEx()\n", Thrd);
		return OldValue;
	}
	/* So OldValue==EOL, meaning a GC is needed */
	InterlockedExchange(&freelist, EOL); 
	GC_NextGCis4NewCell=TRUE; // Make sure next GC gives us free memory
	igc(NULL,NULL); // Parameterss are ignored anyway
	goto TryAgain;
}

