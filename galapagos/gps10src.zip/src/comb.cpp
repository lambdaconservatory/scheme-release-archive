/* COMB.CPP */

#include "stdafx.h"
#include "winbase.h"  /* for GetCurrentThreadId() */
#include "shell.h"
#include "MainFrm.h"
#include "ShellDoc.h"
#include "ShellView.h"
#include "MsgQ.h"

#include "comb.h"
#include "threads.h"

#include "mydebug.h"
#include "scm.h"

#include "ScmThrd.h"
#include "GCd.h"

CShellView *MeanWhile_TheActiveView;
extern CShellApp theApp;
extern "C" {
	THREAD extern SCM sys_protects[];	/* scm.c */
	extern sizet num_protects;		    /* scl.c */
	THREAD extern int dblprec;			/* scl.c */
	THREAD int IsFirstSCMThread,  /* nonzero only for the first SCM (for init) */
		       IsBoundToConsole,
			   IsIdle; /* True in the lread() in repl. Used in HandleUrgentMesage */
	THREAD DWORD parent_env=EOL, startup_form=EOL;
			}

THREAD CString* pTheInputString=NULL;

#define ALLCOMBS_SIZE 20
Combination *AllCombs[ALLCOMBS_SIZE];
THREAD Combination TheCombination;
THREAD DWORD ThisThreadID;
THREAD int Thrd = 0; /*elad!*/
DWORD Threads=0;       /*elad!*/
/*************************************************************** 
   The pointer part of the combination smob is not interesting.
   All the smobs are one! 
**************************************************************/

//	CWinThread* AfxBeginThread
//		( AFX_THREADPROC pfnThreadProc, 
//		  LPVOID pParam, 
//			int nPriority = THREAD_PRIORITY_NORMAL, 
//			UINT nStackSize = 0, DWORD dwCreateFlags = 0, 
//			LPSECURITY_ATTRIBUTES lpSecurityAttrs = NULL )

extern "C" int MainScheme (int argc, char **argv);
extern "C" int SchemeBody ();

void DisposeTheCombination();

SCM __cdecl unbind_console(); // ScmThrd.h
void InitTheCombination1();
// SCM_SubThread() is the control loop (not really a loop)
// for a threa created by (new-thread).
// This thread is initially Windowless.
UINT SCM_SubThread(LPVOID pParam)
{	
	Thrd=++Threads; /*elad!*/
	UpdateStatusBar();
	
	int r;
	
	InitTheCombination1();
		
	IsBoundToConsole=IsFirstSCMThread=0;

	CCombTransfer *xfer = (CCombTransfer*) pParam;
	//Combination * pParentComb = (Combination*)( *(UINT*)pParam );
	for (size_t i=0; i<num_protects; i++)
		sys_protects[i]=xfer->sys_protects[i];
	*(TheCombination.p_dblprec) =xfer->dblprec;  /*dblprec alone won't do */

	startup_form=xfer->form;
	parent_env=xfer->env;
	delete xfer->sys_protects;

	MakeThreadObj();
	xfer->returnQ->Post(CMessage(MSG_NEVERUSED, cur_thread_obj, (DWORD)NULL));
	delete xfer;
	
	GCNotifyThreadStarts(cur_thread_obj);
	r=SchemeBody();
	GCNotifyThreadEnds(cur_thread_obj);	
	unbind_console(); // No intepreterless threads!

	KillThreadObj();
	if (TheCombination.pTheView) TheCombination.pTheView->m_pCombination=NULL;
	DisposeTheCombination();
	
	Threads--; /*elad!*/
	UpdateStatusBar();
	return r;
}

extern "C" UINT SCM_FirstThread(LPVOID pParam)
{	
// DEBUGGING HEAPLEAKS! @@@@
//	  _CrtSetBreakAlloc(116);

	
	Thrd=Threads=1; /*elad*/
	UpdateStatusBar();
	
	Start_GC_deamon();
	
	int r;
	
	InitTheCombination1();
	
	IsBoundToConsole=0;
	IsFirstSCMThread=1;

	LPSTR NewArgv[2];
	NewArgv[0]=strdup(theApp.m_pszExeName);
	NewArgv[1]=NULL;
	
	r=MainScheme(1, NewArgv);
  	GCNotifyThreadEnds(cur_thread_obj);	

	//?if (TheCombination.pTheView) TheCombination.pTheView->m_pCombination=NULL;
	if (IsBoundToConsole && TheCombination.pTheView) 
	{
		CMessageQueue Q;
//		TheCombination.pTheView->GetDocument()->OnCloseDocument();
		TheOutputQueue.Post(CMessage(MSG_CLOSE_CONSOLE, (DWORD)TheCombination.pTheView, &Q));
		CMessage msg;
		Q.Get(msg);
	}
	DisposeTheCombination();
	
	Threads--; /*elad!*/
	//UpdateStatusBar();

	GCNotifyKillDeamon();
	free(NewArgv[0]);; // strdup'ed

	theApp.m_pMainWnd->PostMessage(WM_CLOSE);
	return r;
}


void InitTheCombination1()
{ 
#ifdef _DEBUG
	if (Thrd<ALLCOMBS_SIZE) AllCombs[Thrd]=&TheCombination;
#endif
	TheCombination.pTheView = NULL;
	ThisThreadID = ::GetCurrentThreadId();
	TheCombination.sys_protects = &(sys_protects[0]);
	TheCombination.p_dblprec = (int*)(long)&dblprec;
	TheCombination.pTheInputQueue = new CMessageQueue;
	pTheInputString = new CString("");
}
/*
void InitTheCombination()
{ 
#ifdef _DEBUG
	if (Thrd<ALLCOMBS_SIZE) AllCombs[Thrd]=&TheCombination;
#endif
	TheCombination.pTheView = MeanWhile_TheActiveView;
	MeanWhile_TheActiveView->m_pCombination = &TheCombination;
	ThisThreadID = ::GetCurrentThreadId();
	TheCombination.sys_protects = &(sys_protects[0]);
	TheCombination.p_dblprec = (int*)(long)&dblprec;
	TheCombination.pTheInputQueue = new CMessageQueue;
	pTheInputString = new CString("");
}
*/
void DisposeTheCombination()
{
	delete TheCombination.pTheInputQueue;
	delete pTheInputString;
}


extern "C" {




// Prints where the cursor is, translating ever \n or \r
// to a newline. 


int Comb_fputs (const char *s1, SCM p)
{	
	if (!IsBoundToConsole) return 0;
	CString s(s1), news;
	int i;
				
	while ( -1 != ( i = s.FindOneOf("\n\r") ) )
	{
		news+=s.Left(i)+"\r\n";
		s=s.Mid(i+1);
	}
	news += s;

	TheOutputQueue.Post (CMessage
		( STR_INTERPRETER2WINDOW,
		  (DWORD)new CString(news),
		  (DWORD)(TheCombination.pTheView) ));

	return 0;
}

int Comb_fputc (int c, SCM p)
{
	if (!IsBoundToConsole) return c;
	TheOutputQueue.Post(CMessage(
		STR_INTERPRETER2WINDOW,
		c=='\n'? (DWORD)new CString ("\r\n") : (DWORD)new CString(c),
		(DWORD)(TheCombination.pTheView)	));
	return c;
}

sizet Comb_fwrite (char *s, sizet siz, sizet num, SCM p)
{
	if (!IsBoundToConsole) return num;
	int i;
	char *cp, *S;
    for (cp = S = new char[1+(i=siz*num)]; i; i--, s++)
		if (*s) *(cp++)=*s;
	*cp=0;

	Comb_fputs(S, p);
	delete S;
	return num;
}

int Comb_fgetc (SCM p)
{
	while (pTheInputString->IsEmpty())
	{
		CMessage msg;
		TheCombination.pTheInputQueue->GetByType(msg, STR_WINDOW2INTERPRETER);
		WASSERT ( msg.type == STR_WINDOW2INTERPRETER );
		delete pTheInputString;
		pTheInputString = (CString*)(msg.msg); // This is a CString copy
	}
	int i=(*pTheInputString)[0];
	*pTheInputString=pTheInputString->Mid(1);
	return i;
}


int Comb_PrintPTOB (SCM exp, SCM port, int writing)
{
	prinport(exp, port, "ComboPort");
	return !0;
}

void CombStartGC()
{
	TheCombination.pTheView->BeginWaitCursor();
	theApp.m_bInGC = TRUE;
	UpdateStatusBar();
}

void CombEndGC()
{ 
	TheCombination.pTheView->EndWaitCursor();
	theApp.m_bInGC = FALSE;
	UpdateStatusBar();
}

void TRACE_1(char *s, int d)
{ TRACE1(s,d); }


/*extern "C" */ }

extern void ConsentGC(); // in GCd.cpp
void HandleUrgentMessage(CMessage msg)
{
	switch (msg.msg)
	{
	case MSGMSG_SCMURGENT: // A scheme-level Urgent message
		HandleUrgentMessageSCM((DWORD)(msg.ptr));
		return;
	case MSGMSG_URGENT_GC: // GC is needed
		ConsentGC();
		return;
	case MSGMSG_URGENTSTR: // A string we need to compute
		scm_evstr((char*)(msg.ptr));
		if (IsIdle && !IsBoundToConsole)
			quit(UNDEFINED);
		return;
	default:
		WASSERT(1==2);
	}
}
