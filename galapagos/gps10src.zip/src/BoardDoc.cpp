// BoardDoc.cpp : implementation of the CBoardDoc class
//

#include "stdafx.h"
#include "Board.h"

#include "BoardDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBoardDoc

IMPLEMENT_DYNCREATE(CBoardDoc, CDocument)

BEGIN_MESSAGE_MAP(CBoardDoc, CDocument)
	//{{AFX_MSG_MAP(CBoardDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBoardDoc construction/destruction

CBoardDoc::CBoardDoc()
{
	// TODO: add one-time construction code here

}

CBoardDoc::~CBoardDoc()
{
}

BOOL CBoardDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
 
	m_SizeDoc = CSize (MAX_BOARD_X, MAX_BOARD_Y);   // document size

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBoardDoc serialization

void CBoardDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBoardDoc diagnostics

#ifdef _DEBUG
void CBoardDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBoardDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBoardDoc commands

CSize CBoardDoc::GetDocSize()
{
  return m_SizeDoc;
}
