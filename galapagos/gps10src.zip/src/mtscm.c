/* mtscm.c - MultiThread SCM extensions */

#include "scm.h"

#define SEMAPHP(x) (TYP16(x)==tc16_semaph)
long tc16_semaph;

/*	(make-semaphore name initial maximum)
	(down-semaphore semaphore)
	(up-semaphore semaphore)	*/

SCM make_semaph (SCM initial, SCM name)
{	unsigned long init = num2ulong (initial_s, ARG2, myname),
				  max = num2ulong (maximum)s, ARG3, myname);
	return cons(tc16_semaph, (SCM)num2ulong(initial, ARG1, myname)));
	




#define MUTEXP(x) (TYP16(x)==tc16_MUTEX)

long tc16_mutex;

/*	(make-mutex name)
	(mutex-name mutex)
	(try-mutex mutex)
	(start-mutex mutex)
	(end-mutex mutex) */

#define myname "make-mutex"
SCM make_mutex (SCM name)
{	SCM x;
	NEWCELL(x);
	CAR(x)=tc16_mutex;
	CDR(x)=cons(

/*static smobfuns envw_smob = { markcdr, free0, printenvw, cdr_eq };

static iproc subr0s[] = {
	{"base-environment", base_env},
	{0,0} };

static iproc subr1s[] = {
	{"procedure-environment", proc_env},
	{"environment->list",   env2list},
	{"extend-environment",  ext_env},
	{"pop-environment",  pop_env},
	{"environment?", envp},
	{"set-base-environment", set_base_env},
	{0, 0} };

static iproc subr2os[] = {
	{"clone-environment", clone_env},
	{0,0} };



void init_explicit()
{ 
	tc16_envw = newsmob (&envw_smob);
	init_iprocs(subr0s, tc7_subr_0);
	init_iprocs(subr1s, tc7_subr_1);
	init_iprocs(subr2os, tc7_subr_2o);
	make_synt("current-environment", makacro, m_cur_env);
	cur_base_env=EOL; /* Initial env - toplevel */

}

*/