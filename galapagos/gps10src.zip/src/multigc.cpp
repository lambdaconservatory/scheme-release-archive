/* multigc.cpp - For dealing with Garbage Collection in a multithread universe */

#include "stdafx.h"
#include "ShellDoc.h"
#include "ShellView.h"
#include "msgq.h"
#include "comb.h"
#include "mydebug.h"
#include "scm.h"

#ifdef _TRACE_BARRIER
# define BARRIER_TRACE1 TRACE1
#else
# define BARRIER_TRACE1(x,y) {}
#endif

#define MSG_I_WAIT 0x1234

DWORD NumberOfInterpreters = 0; // Number of running interpreters

CMessageQueue SleepQ; // Used to synchronise all interpreters at first
CEvent WakeEv (TRUE/*InitiallyOwned*/,FALSE/*Automatic*/); // Used to wait them up later on

// StartBarrier()/EndBarrier() creates a special barrier. That is:
// For the "console" (first) SCM thread, StartBarrier() blocks until all other interpreters
//   are blocked and then return 1. Caller should do its business and then call EndBarrier()
// For other interpreters, StartBarrier() returns 0 after the "console" called EndBarrier()
// (Not to be called recursively, of course)


int StartBarrier()
{
	if (IsFirstSCMThread)
	{
		int i=NumberOfInterpreters;
		CMessage msg;
		BARRIER_TRACE1("StartBarrier - waiting for %d SMCs\n", i);
		while (--i) SleepQ.Get(msg);
		// Now all of the other threads are blocked
		return 1;
	}	
	else // All other threads just sit and wait. Sorta
	{
		BARRIER_TRACE1("StartBarrier - Thrd%d going to sleep\n", Thrd);
		SleepQ.Post(CMessage(MSG_I_WAIT, ThisThreadID)); // Tell console I am waiting
		CSingleLock WakeupLock(&WakeEv);
		WakeupLock.Lock(); // Wait until console's done sweeping
		TRACE1("StartBarrier - Thrd%d woke up\n", Thrd);
		return 0;
	}
}

void EndBarrier()
{
	WASSERT(IsFirstSCMThread);
	BARRIER_TRACE1("EndBarrier   - Console continues\n",0);

	WakeEv.PulseEvent();
}


