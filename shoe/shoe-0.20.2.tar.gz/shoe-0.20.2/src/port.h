/* port.c
 *
 * COPYRIGHT (c) 1999 by Fredrik Noring.
 *
 * This module deals with portability issues.
 */

#ifndef __PORT_H__
#define __PORT_H__

#endif /* __PORT_H__ */
