/* version.h
 *
 * COPYRIGHT (c) 1998 by Fredrik Noring.
 */

#define SHOE_MAJOR_VERSION 0
#define SHOE_MINOR_VERSION 2
#define SHOE_BUILD_VERSION 2
