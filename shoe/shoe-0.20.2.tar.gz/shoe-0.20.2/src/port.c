/* port.c
 *
 * COPYRIGHT (c) 1999 by Fredrik Noring.
 *
 * This module deals with portability issues.
 */

#define MODULE_DEBUG 0
#define MODULE_NAME  "port"

#include "types.h"
