/*
 * If we have a sys/select.h, then include it.
 */
#if	defined(HAVE_SYS_SELECT_H)

#include <sys/types.h>
#include <sys/select.h>

#endif
