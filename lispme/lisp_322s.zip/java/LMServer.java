import java.io.*;
import java.net.*;
import java.util.*;


public class LMServer implements Runnable  {
  Thread listener;
  ServerSocket server;

  public static void main(String args[]) {
    new LMServer();
  }
  public LMServer () {
    try {
      server = new ServerSocket(4711);
      listener = new Thread(this);
      listener.start();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void run() {
    try {
      while(true) {
        Socket client = server.accept();
        new EchoClient(client).start();
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}

class EchoClient extends Thread {
  Socket s;
  OutputStream out;
  InputStream in;

  public EchoClient(Socket s) throws IOException {
    System.out.println("New connection received");
    this.s = s;
    out = s.getOutputStream();
    in = s.getInputStream();
  }

  public void run() {
    byte[] buffer = new byte[10];
    int num;
    try {
      while((num = in.read(buffer)) != -1) {
        System.out.println("Copying string " + new String(buffer, 0, num));
        out.write(buffer, 0, num);
      }
    }
    catch(IOException e) {
      e.printStackTrace();
    }
  }
}
