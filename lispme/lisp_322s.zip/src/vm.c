/**********************************************************************/
/*                                                                    */
/* vm.c: LISPME Virtual Machine                                       */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 20.07.1997 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "vm.h"
#include "io.h"
#include "comp.h"
#include "LispMe.h"
#include "fpstuff.h"
#include "cplx.h"
#include "util.h"
#include "builtin.h"
#include "arith.h"

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
int     stepsInSlice;
Boolean evalMacro;

/**********************************************************************/
/* Static data                                                        */
/**********************************************************************/
static eqvType foreignEqv[MAX_FOREIGN_TYPES];

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static Boolean leq(PTR a, PTR b)                                SEC(VM);
static Boolean member(PTR el, PTR l)                            SEC(VM);
static void    transUnary(void (*fn)(double,double*))           SEC(VM);
static void    transCplUnary(PTR (*fn)(double,double))          SEC(VM);
static void    transBinary(void (*fn)(double,double,double*))   SEC(VM);
static void    application(Boolean copyArgs)                    SEC(VM);

/**********************************************************************/
/* compare equivalence (works for all numbers)                        */
/* (It's never necessary to actually compare a big int to a small     */
/* int since their range doesn't overlap)                             */
/**********************************************************************/
Boolean eqv(PTR a, PTR b)
{
  if (a == b)
    return true;
  else if (IS_SMALLINT(a))
  {
    if (IS_REAL(b))
      return eqDouble(longToDouble(INTVAL(a)),getReal(b));
    else
      return false;
  }
  else if (IS_BIGINT(a))
  {
    if (IS_BIGINT(b))
      return compBigint(a,b) == 0;
    else if (IS_REAL(b))
      return eqDouble(bigToDouble(a),getReal(b));
    else
      return false;
  }
  else if (IS_REAL(a))
  {
    if (IS_SMALLINT(b))
      return eqDouble(getReal(a), longToDouble(INTVAL(b)));
    else if (IS_BIGINT(b))
      return eqDouble(getReal(a), bigToDouble(b));
    else if (IS_REAL(b))
      return eqDouble(getReal(a), getReal(b));
    else
      return false;
  }
  else if (IS_COMPLEX(a) && IS_COMPLEX(b))
    return eqDouble(getReal(cadr(a)),getReal(cadr(b))) &&
           eqDouble(getReal(cddr(a)),getReal(cddr(b)));
  else if (IS_FOREIGN(a) && IS_FOREIGN(b) &&
           FOREIGNTYPE(a) == FOREIGNTYPE(b))
  {
    /*----------------------------------------------------------------*/
    /* Call registered comparison function for foreign type           */
    /*----------------------------------------------------------------*/
    static eqvType eqvFct;
    if ((eqvFct = foreignEqv[FOREIGNTYPE(a)]))
      return eqvFct(FOREIGNVAL(a), FOREIGNVAL(b));
    else
      return FOREIGNVAL(a) == FOREIGNVAL(b);
  } 
  else
    return false;
}

/**********************************************************************/
/* compare two arbitrary numbers, chars or strings                    */
/**********************************************************************/
static Boolean leq(PTR a, PTR b)
{
  if (IS_SMALLINT(a))
  {
    if (IS_SMALLINT(b))
      return INTVAL(a) <= INTVAL(b);
    else if (IS_BIGINT(b))
      return !BIGSIGN(b);
    else if (IS_REAL(b))
      return leqDouble(longToDouble(INTVAL(a)), getReal(b));
    else
      ErrThrow(ERR_R14_INVALID_COMP);
  }
  else if (IS_BIGINT(a))
  {
    if (IS_SMALLINT(b))
      return !!BIGSIGN(a);
    else if (IS_BIGINT(b))
      return compBigint(a,b) <= 0;
    else if (IS_REAL(b))
      return leqDouble(bigToDouble(a), getReal(b));
    else
      ErrThrow(ERR_R14_INVALID_COMP);
  }
  else if (IS_REAL(a))
  {
    if (IS_SMALLINT(b))
      return leqDouble(getReal(a), longToDouble(INTVAL(b)));
    else if (IS_BIGINT(b))
      return leqDouble(getReal(a), bigToDouble(b));
    else if (IS_REAL(b))
      return leqDouble(getReal(a), getReal(b));
    else
      ErrThrow(ERR_R14_INVALID_COMP);
  }
  else if (IS_CHAR(a))
  {
    if (IS_CHAR(b))
      return CHARVAL(a) <= CHARVAL(b);
    else
      ErrThrow(ERR_R14_INVALID_COMP);
  }
  else if (IS_STRING(a))
  {
    if (IS_STRING(b))
      return strComp(a,b) <= 0;
    else
      ErrThrow(ERR_R14_INVALID_COMP);
  }
  else
    ErrThrow(ERR_R14_INVALID_COMP);
}

/**********************************************************************/
/* Check, if el is in list l (using eqv?)                             */
/**********************************************************************/
static Boolean member(PTR el, PTR l)
{
  PTR   p = l;
  while (IS_PAIR(p))
  {
    if (eqv(el,car(p))) return true;
    p = cdr(p);
  }
  if (p!=NIL)
    error1(ERR_C6_IMPROPER_ARGS, l);
  return false;
}

/**********************************************************************/
/* Transcendental functions                                           */
/**********************************************************************/
static void transUnary(void (*fn)(double,double*))
{
  /*------------------------------------------------------------------*/
  /* (x.s) e (FKT.c) d --> (fkt(x).s) e c d                           */
  /*------------------------------------------------------------------*/
  double res;

  if (!mathLibOK)
    ErrThrow(ERR_R12_NO_MATHLIB);
  fn(realVal(car(S)),&res);
  S = cons(allocReal(res), cdr(S));
  C = cdr(C);
}

static void transCplUnary(PTR (*fn)(double,double))
{
  /*------------------------------------------------------------------*/
  /* (x.s) e (FKT.c) d --> (fkt(x).s) e c d                           */
  /*------------------------------------------------------------------*/
  W = car(S);
  if (!mathLibOK)
    ErrThrow(ERR_R12_NO_MATHLIB);
  if (IS_SMALLINT(W))
    S = cons(fn(longToDouble(INTVAL(W)),0.0), cdr(S));
  else if (IS_REAL(W))
    S = cons(fn(getReal(W),0), cdr(S));
  else if (IS_BIGINT(W))
    S = cons(fn(bigToDouble(W),0), cdr(S));
  else if (IS_COMPLEX(W))
    S = cons(fn(getReal(cadr(W)),
                 getReal(cddr(W))),
              cdr(S));
  else
    typeError(W,"number");
  C = cdr(C);
}

static void transBinary(void (*fn)(double,double,double*))
{
  /*------------------------------------------------------------------*/
  /* (x y.s) e (FKT.c) d --> (fkt(x,y).s) e c d                       */
  /*------------------------------------------------------------------*/
  double res;

  if (!mathLibOK)
    ErrThrow(ERR_R12_NO_MATHLIB);
  fn(realVal(car(S)),realVal(cadr(S)),&res);
  S = cons(allocReal(res), cddr(S));
  C = cdr(C);
}

/**********************************************************************/
/* Locate a variable in an environment                                */
/**********************************************************************/
PTR locate(PTR loc, LEXADR adr)
{
  int j = adr >> FRAME_SHIFT; 
  while (--j>=0) 
    loc = cdr(loc);
  loc = car(loc);
  if (loc == BLACK_HOLE)
    ErrThrow(ERR_R9_BLACK_HOLE);
  j = adr & SLOT_MASK;
  while (--j>=0)
    loc = cdr(loc);
  return loc;
}

/**********************************************************************/
/* common code for APC and TAPC                                       */
/**********************************************************************/
static void application(Boolean copyArgs)
{
  /*------------------------------------------------------------------*/
  /* apply closure: first check number of arguments                   */
  /*------------------------------------------------------------------*/
  short len = INTVAL(car(cadar(S)));
  short i;

  /*------------------------------------------------------------------*/
  /* have to copy args when applying to avoid destruction of org list */
  /*------------------------------------------------------------------*/
  if (copyArgs)
  {
    W = cadr(S);
    listCopy(&cadr(S),cadr(S),ALL_ELEMENTS);
  }

  /*------------------------------------------------------------------*/
  /* check number of arguments                                        */
  /*------------------------------------------------------------------*/
  if (len >= 0)
  {
    if (len != listLength(cadr(S)))
    {
      expectedLen = len;
      error1(ERR_R3_NUM_ARGS,cadr(S));
    }
  }
  else
  {
    /*----------------------------------------------------------------*/
    /* variable number of args, modify arg list                       */
    /*----------------------------------------------------------------*/
    PTR* ptr;
    if (-len-1 > listLength(cadr(S)))
    {
      expectedLen = len+1;
      error1(ERR_R3_NUM_ARGS,cadr(S));
    }
    for (ptr=&cadr(S),i=0;i<-len-1;i++)
      ptr = &cdr(*ptr);
    *ptr = cons(*ptr,NIL);
  }
}

/**********************************************************************/
/* apply a builtin function                                           */
/**********************************************************************/
static void applyBuiltIn(PTR cont, Boolean copyArgs)
{
  PTR p;
  short n = listLength(cadr(S));

  /*------------------------------------------------------------------*/
  /* Compile the primitive "on the fly" in front of the continuation  */
  /*------------------------------------------------------------------*/
  buildIn(car(S), cadr(S), n, NIL, &cont);
  C = cont;

  if (copyArgs) 
  {
    W = NIL; 
    *listCopy(&W,cadr(S),ALL_ELEMENTS) = cddr(S);
    S = W; 
  }
  else
  {
    /*------------------------------------------------------------------*/
    /* Splice the argument list in front of S                           */
    /*------------------------------------------------------------------*/
    W = p = cadr(S);
    S = cddr(S);
    if (n>0) {
      while(--n>0)
        p=cdr(p);
      cdr(p) = S;
      S = W;
    }
  }
}

/**********************************************************************/
/* Virtual machine (assume code is already loaded into C register)    */
/**********************************************************************/
PTR exec(void)
{
  PTR loc;
  int i,op;

  if (LispMePrefs.noAutoOff)
    EvtResetAutoOffTimer();

  for (stepsInSlice=0; stepsInSlice<STEPS_PER_TIMESLICE; ++stepsInSlice)
  {
    ++numStep;

    op = INTVAL(car(C));
    switch (op > 0 ? MAJOP(op) : op)
    {
      case TRAN:
        /*------------------------------------------------------------*/
        /* (a.s) e (TRAN&n . c) d --> (trans(a,n).s) e c d            */
        /*------------------------------------------------------------*/
        switch (MINOP(op))
        {
          case SQRT: transCplUnary(&cplSqrt);  break;
          case EXP:  transCplUnary(&cplExp);   break;
          case LOG:  transCplUnary(&cplLog);   break;
          case SIN:  transCplUnary(&cplSin);   break;
          case COS:  transCplUnary(&cplCos);   break;
          case TAN:  transCplUnary(&cplTan);   break;
          case SINH: transCplUnary(&cplSinh);  break;
          case COSH: transCplUnary(&cplCosh);  break;
          case TANH: transCplUnary(&cplTanh);  break;
          case ASIN: transCplUnary(&cplAsin);  break;
          case ACOS: transCplUnary(&cplAcos);  break;
          case ASIH: transCplUnary(&cplAsinh); break;
          case ACOH: transCplUnary(&cplAcosh); break;
          case ATAH: transCplUnary(&cplAtanh); break;
          case FLOR: transUnary(&LMfloor);     break;
          case CEIL: transUnary(&LMceil);      break;
          case TRUN: transUnary(&LMtrunc);     break;
          case ROUN: transUnary(&LMround);     break;
        }
        break;

      case ATN2: transBinary(&LMatan2);    break;
      case ATAN: transCplUnary(&cplAtan);  break;

      case MKRA:
        /*------------------------------------------------------------*/
        /* (a b.s) e (MKRA.c) d --> (complex(a,b).s) e c d            */
        /*------------------------------------------------------------*/
        S = cons(storeNum(realVal(car(S)),realVal(cadr(S))), cddr(S));
        goto skip1;

      case MKPO:
        /*------------------------------------------------------------*/
        /* (a b.s) e (MKPO.c) d --> (polar(a,b).s) e c d              */
        /*------------------------------------------------------------*/
        S = cons(makePolar(realVal(car(S)),realVal(cadr(S))), cddr(S));
        goto skip1;

      case ST:
        /*------------------------------------------------------------*/
        /* (a.s) e (ST i.c) d --> (a.s) e' c d                        */
        /* where e' = update e set locate(i) = a                      */
        /*------------------------------------------------------------*/
        loc = locate(E,INTVAL(cadr(C)));
        locVal(loc) = car(S);
      skip2:
        C = cddr(C);
        break;

      case STU:
        /*------------------------------------------------------------*/
        /* (a.s) e (STU i.c) d --> (a.s) e c d                        */
        /* and change STU i to STG (a.r) where (v.r) is locate(i,e)   */
        /*------------------------------------------------------------*/
        cadr(C) = locate(E,INTVAL(cadr(C)));
        car(C)  = MKINT(STG);
        /* fall thru */

      case STG:
        /*------------------------------------------------------------*/
        /* (a.s) e (STG (v.r) .c) d --> (a.s) e c d                   */
        /* and update cell (v.r) to (a.r)                             */
        /*------------------------------------------------------------*/
        locVal(cadr(C)) = car(S);
        goto skip2;

      case LDC:
        /*------------------------------------------------------------*/
        /* s e (LDC x.c) d --> (x.s) e c d                            */
        /*------------------------------------------------------------*/
        S = cons(cadr(C),S);
        goto skip2;

      case LDU:
        /*------------------------------------------------------------*/
        /* s e (LDU i.c) d --> (locate(i,e).s) e c d                  */
        /* and change LDU i to LDG (v.r) where (v.r) is locate(i,e)   */
        /*------------------------------------------------------------*/
        cadr(C) = locate(E,INTVAL(cadr(C)));
        car(C)  = MKINT(LDG);
        /* fall thru */

      case LDG:
        /*------------------------------------------------------------*/
        /* s e (LDG (v.r) . c) d --> (v.s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(locVal(cadr(C)),S);
        goto skip2;

      case LDF:
        /*------------------------------------------------------------*/
        /* s e (LDF c'.c) d --> ((c'.e).s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(cons(cadr(C),E), S);
        goto skip2;
  
      case AP:
        /*------------------------------------------------------------*/
        /* ((c'.e') v.s) e (AP.c) d --> NIL (v.e') c' (s e c.d)       */
        /*------------------------------------------------------------*/
        D = cons(cddr(S), cons(E, cons(cdr(C), D)));
        E = cons(cadr(S), cdar(S));
        C = caar(S); S = NIL;
        break;
  
      case LDFC:
        /*------------------------------------------------------------*/
        /* s e (LDFC n c'.c) d --> ((#clos n c'.e).s) e c d           */
        /*------------------------------------------------------------*/
        S = cons(cons3(CLOS_TAG, cadr(C), caddr(C), E), S);
        C = cdddr(C);
        break;

      case APC:
      case APY:
        /*------------------------------------------------------------*/
        /* (#prim v.s) e (APC.c) d -->                                */
        /*          (append(v,s)) e (compile(#prim, length(v)) . c) d */
        /* ((#clos n c'.e') v.s) e (APC.c) d -->                      */
        /*                              NIL (v.e') c' (s e c.d)       */
        /*  (special rule for variable number of args)                */
        /* ((#cont s e c.d) (v).s') e' (APC.c') d' --> (v.s) e c d    */
        /*------------------------------------------------------------*/
        if (IS_PRIMBIND(car(S)))
        {
          applyBuiltIn(cdr(C), car(C) == MKINT(APY));  
          break;
        }
        if (!IS_CONS(car(S)))
          typeError(car(S),"function");
        if (caar(S) == CLOS_TAG)
        {
          application(INTVAL(car(C)) == APY);
          D = cons(cddr(S),
                    cons(E,
                          cons(cdr(C),D)));
          E = cons(cadr(S), cdddr(car(S)));
          C = caddr(car(S)); S = NIL;
        }
        else if (caar(S) == CONT_TAG)
        {
          /*----------------------------------------------------------*/
          /* apply continuation                                       */
          /*----------------------------------------------------------*/
        applyCont:
          if (listLength(cadr(S)) != 1)
          {
            expectedLen = 1;
            error1(ERR_R3_NUM_ARGS,cadr(S));
          }
          E = cadr(cdar(S));
          C = caddr(cdar(S));
          D = cdddr(cdar(S));
          S = cons(caadr(S), cadar(S));
        }
        else if (caar(S) == CXR_TAG)
        {
          /*----------------------------------------------------------*/
          /* Sequence of car/cdr operations                           */
          /*----------------------------------------------------------*/
          applyBuiltIn(cdr(C), car(C) == MKINT(APY));  
          break;
        }
        else
          typeError(car(S),"function");
        break;

      case TAPC:
      case TAPY:
        /*------------------------------------------------------------*/
        /* (#prim v.s) e (TAPC) d -->                                 */
        /*          (append(v,s)) e (compile(#prim, length(v)) RTN) d */
        /* ((#clos n c'.e') v.s) e (TAPC) d -->  s (v.e') c' d        */
        /*  (special rule for variable number of args)                */
        /* ((#cont s e c.d) (v).s') e' (TAPC) d' --> (v.s) e c d      */
        /*------------------------------------------------------------*/
        if (IS_PRIMBIND(car(S)))
        {
          applyBuiltIn(list1(MKINT(RTN)), car(C) == MKINT(TAPY));  
          break;
        }
        if (!IS_CONS(car(S)))
          typeError(car(S),"function");
        if (caar(S) == CLOS_TAG)
        {
          application(INTVAL(car(C)) == TAPY);
          E = cons(cadr(S), cdddr(car(S)));
          C = caddr(car(S)); S = cddr(S);
        }
        else if (caar(S) == CONT_TAG)
          goto applyCont;
        else if (caar(S) == CXR_TAG)
        {
          applyBuiltIn(list1(MKINT(RTN)), car(C) == MKINT(TAPY));  
          break;
        }  
        else
          typeError(car(S),"function");
        break;

      case TAP:
        /*------------------------------------------------------------*/
        /* ((c'.e') v.s) e (TAP.c) d --> s (v.e') c' d                */
        /*------------------------------------------------------------*/
        E = cons(cadr(S), cdar(S));
        C = caar(S);
        S = cddr(S);
        break;
  
      case RTN:
        /*------------------------------------------------------------*/
        /* (a) e' (RTN) (s e c.d) --> (a.s) e c d                     */
        /*------------------------------------------------------------*/

        /*------------------------------------------------------------*/
        /* Store environment, if we load from file                    */
        /*------------------------------------------------------------*/
        if (pMemGlobal->fileLoad)       
          pMemGlobal->newTopLevelVals = car(E);

        S = cons(car(S), car(D));
        E = cadr(D); C = caddr(D); D = cdddr(D);
        break;

      case CANF:
        /*------------------------------------------------------------*/
        /* (v1... . s) e (CANF #nat.c) d --> (#nat(v1,...) . s) e c d */
        /*------------------------------------------------------------*/
	S = callNative(cadr(C), -1, S);
	goto skip2;

      case CANV:
        /*------------------------------------------------------------*/
        /* (v1... . s) e (CANV&ar #nat.c) d -->                       */
        /*                         (#nat(ar,v1,...) . s) e c d        */
        /*------------------------------------------------------------*/
	S = callNative(cadr(C), MINOP(op), S);
        goto skip2;

      case LDM:
        /*------------------------------------------------------------*/
        /* s e (LDM c'.c) d --> ((#macro #clos 1 c'.e).s) e c d       */
        /*------------------------------------------------------------*/
        S = cons(cons4(MACR_TAG, CLOS_TAG, list1(MKINT(1)), cadr(C), E), S);
        C = cddr(C);
        break;

      case DUM:
        /*------------------------------------------------------------*/
        /* s e (DUM.c) d --> s (?.e) c d                              */
        /*------------------------------------------------------------*/
        E = cons(BLACK_HOLE, E);
      skip1:
        C = cdr(C);
        break;
  
      case RAP:
        /*------------------------------------------------------------*/
        /* ((c'.e') v.s) (?.e) (RAP.c) d -> NIL rpl(e',v) c' (s e c.d)*/
        /*------------------------------------------------------------*/
        D = cons(cddr(S), cons(cdr(E), cons(cdr(C), D)));
        E = cdar(S); car(E) = cadr(S);
        C = caar(S); S = NIL;
        break;

      case RTAP:
        /*------------------------------------------------------------*/
        /* ((c'.e') v.s) (?.e) (RTAP.c) d --> NIL rpl(e',v) c' d      */
        /*------------------------------------------------------------*/
        E = cdar(S); car(E) = cadr(S);
        C = caar(S); S = NIL;
        break;
  
      case SEL:
        /*------------------------------------------------------------*/
        /* (x.s)   e (SEL ct cf.c) d --> s e ct (c.d)                 */
        /* (#f.s)  e (SEL ct cf.c) d --> s e cf (c.d)                 */
        /*------------------------------------------------------------*/
        D = cons(cdddr(C), D);
        /* fall thru! */

      case SELR:
        /*------------------------------------------------------------*/
        /* (x.s)   e (SELR ct cf) d --> s e ct d                      */
        /* (#f.s)  e (SELR ct cf) d --> s e cf d                      */
        /*------------------------------------------------------------*/
        C = (car(S) == FALSE) ? caddr(C) : cadr(C);
        S = cdr(S);
        break;

      case SEO:
      case SEA:
        /*------------------------------------------------------------*/
        /* (x.s)   e (SEO cf.c) d --> (x.s) e c d                     */
        /* (#f.s)  e (SEA ct.c) d --> (#f.s) e c d                    */
        /* (#f.s)  e (SEO cf.c) d --> s e cf (c.d)                    */
        /* (x.s)   e (SEA ct.c) d --> s e ct (c.d)                    */
        /*------------------------------------------------------------*/
        if ((INTVAL(car(C)) == SEO) == (car(S) == FALSE)) {
          D = cons(cddr(C), D);
          S = cdr(S); C = cadr(C);
        }
        else
          goto skip2;
        break;

      case SEOR:
      case SEAR:
        /*------------------------------------------------------------*/
        /* (x.s)   e (SEOR cf.c) d --> (x.s) e c d                    */
        /* (#f.s)  e (SEAR ct.c) d --> (#f.s) e c d                   */
        /* (#f.s)  e (SEOR cf.c) d --> s e cf d                       */
        /* (x.s)   e (SEAR ct.c) d --> s e ct d                       */
        /*------------------------------------------------------------*/
        if ((INTVAL(car(C)) == SEOR) == (car(S) == FALSE)) {
          S = cdr(S); C = cadr(C);
        }
        else
          goto skip2;
        break;

      case MEM:
        /*------------------------------------------------------------*/
        /* (x.s) e (MEM l ct cf.c) d --> s     e ct (c.d) if x in l   */
        /* (x.s) e (MEM l ct cf.c) d --> (x.s) e cf (c.d) else        */
        /*------------------------------------------------------------*/
        D = cons(cdr(cdddr(C)), D);
        /* fall thru! */

      case MEMR:
        /*------------------------------------------------------------*/
        /* (x.s) e (MEMR l ct cf.c) d --> s     e ct d if x in l      */
        /* (x.s) e (MEMR l ct cf.c) d --> (x.s) e cf d else           */
        /*------------------------------------------------------------*/
        if (member(car(S),cadr(C))) {
          S = cdr(S); C = caddr(C);
        }
        else
          C = car(cdddr(C));
        break;

      case JOIN:
        /*------------------------------------------------------------*/
        /* s e (JOIN) (c.d) -> s e c d                                */
        /*------------------------------------------------------------*/
        C = car(D); D = cdr(D);
        break;
  
      case CAR:
        /*------------------------------------------------------------*/
        /* ((a.b).s) e (CAR.c) d --> (a.s) e c d                      */
        /*------------------------------------------------------------*/
        if (!IS_PAIR(car(S)))
          extTypeError("car",0,car(S),"pair");
        S = cons(caar(S),cdr(S));
        goto skip1;
  
      case CDR:
        /*------------------------------------------------------------*/
        /* ((a.b).s) e (CDR.c) d --> (b.s) e c d                      */
        /*------------------------------------------------------------*/
        if (!IS_PAIR(car(S)))
          extTypeError("cdr",0,car(S),"pair");
        S = cons(cdar(S),cdr(S));
        goto skip1;

      case CXR:
        /*------------------------------------------------------------*/
        /* (x.s) e (CXR bs . c) d --> (cxxxr(x) . s) e c d            */
        /* where bs is a bitstring encoding a sequence of car/cdr     */
        /* applications [hal: 15/8-00]                                */
        /*------------------------------------------------------------*/
        if (i = MINOP(op));
        else {
          C = cdr(C);
          i = INTVAL(car(C));
        }
        S = cons(cxr(car(S), i), cdr(S));
        goto skip1;

      case SCAR:
        /*------------------------------------------------------------*/
        /* ((a.b) a' .s) e (SCAR.c) d --> ((a'.b) .s) e c d           */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyPAIR,car(S),"set-car!",0);
        caar(S) = cadr(S);
        cdr(S) = cddr(S);
        goto skip1;

      case SCDR:
        /*------------------------------------------------------------*/
        /* ((a.b) b' .s) e (SCDR.c) d --> ((a.b') .s) e c d           */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyPAIR,car(S),"set-cdr!",0);
        cdar(S) = cadr(S);
        cdr(S) = cddr(S);
        goto skip1;
  
      case NOT:
        /*------------------------------------------------------------*/
        /* (#f .s) e (NOT.c) d --> (#t.s) e c d                       */
        /* (x  .s) e (NOT.c) d --> (#f.s) e c d                       */
        /*------------------------------------------------------------*/
        S = cons((car(S) == FALSE) ? TRUE : FALSE,
                  cdr(S));
        goto skip1;

      case CTYP:
        /*------------------------------------------------------------*/
        /* (x.s) e (CTYP t.c) d --> (hasType(t,x) . s) e c d          */
        /*------------------------------------------------------------*/
        S = cons(hasType(INTVAL(cadr(C)), car(S)) ? TRUE : FALSE,
                 cdr(S));
        goto skip2;

      case CONS:
        /*------------------------------------------------------------*/
        /* (a b.s) e (CONS.c) d --> ((a.b).s) e c d                   */
        /*------------------------------------------------------------*/
        S = cons(cons(car(S),cadr(S)),cddr(S));
        goto skip1;

      case APND:
        /*------------------------------------------------------------*/
        /* (a b.s) e (APND.c) d --> (append(a,b).s) e c d             */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyLIST,car(S),"append",-1);
        W = NIL;
        *listCopy(&W,car(S),ALL_ELEMENTS) = cadr(S);
        S = cons(W, cddr(S));
        goto skip1;
  
      case EQ:
        /*------------------------------------------------------------*/
        /* (a a.s) e (EQ.c) d --> (#t.s) e c d                        */
        /* (a b.s) e (EQ.c) d --> (#f.s) e c d                        */
        /*------------------------------------------------------------*/
        S = cons(car(S) == cadr(S) ? TRUE : FALSE, cddr(S));
        goto skip1;
  
      case EQV:
        /*------------------------------------------------------------*/
        /* (a a.s) e (EQV.c) d --> (#t.s) e c d                       */
        /* (a b.s) e (EQV.c) d --> (#f.s) e c d                       */
        /* additionally compare numbers and foreign types             */
        /*------------------------------------------------------------*/
        S = cons(eqv(car(S),cadr(S)) ? TRUE : FALSE, cddr(S));
        goto skip1;

      case ADD:
        /*------------------------------------------------------------*/
        /* (a b.s) e (ADD.c) d --> (b+a.s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(genBinOp(car(S),cadr(S),ARITHOP_ADD), cddr(S));
        goto skip1;
  
      case SUB:
        /*------------------------------------------------------------*/
        /* (a b.s) e (SUB.c) d --> (b-a.s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(genBinOp(car(S),cadr(S),ARITHOP_SUB), cddr(S));
        goto skip1;
  
      case MUL:
        /*------------------------------------------------------------*/
        /* (a b.s) e (MUL.c) d --> (b*a.s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(genBinOp(car(S),cadr(S),ARITHOP_MUL), cddr(S));
        goto skip1;
  
      case DIV:
        /*------------------------------------------------------------*/
        /* (a b.s) e (DIV.c) d --> (b/a.s) e c d                      */
        /*------------------------------------------------------------*/
        S = cons(div(car(S),cadr(S)), cddr(S));
        goto skip1;

      case LAND:
        /*------------------------------------------------------------*/
        /* (a b.s) e (LAND.c) d --> (b&a . s) e c d                   */
        /*------------------------------------------------------------*/
        S = cons(genBitOp(car(S),cadr(S),BITOP_AND), cddr(S));
        goto skip1;

      case LIOR:
        /*------------------------------------------------------------*/
        /* (a b.s) e (LIOR.c) d --> (b|a . s) e c d                   */
        /*------------------------------------------------------------*/
        S = cons(genBitOp(car(S),cadr(S),BITOP_IOR), cddr(S));
        goto skip1;

      case LXOR:
        /*------------------------------------------------------------*/
        /* (a b.s) e (LXOR.c) d --> (b^a . s) e c d                   */
        /*------------------------------------------------------------*/
        S = cons(genBitOp(car(S),cadr(S),BITOP_XOR), cddr(S));
        goto skip1;

      case LEQ:
        /*------------------------------------------------------------*/
        /* (a b.s) e (LEQ.c) d --> (T.s)   e c d  if b>=a             */
        /* (a b.s) e (LEQ.c) d --> (NIL.s) e c d  if b< a             */
        /*------------------------------------------------------------*/
        S = cons(leq(car(S),cadr(S)) ? TRUE : FALSE, cddr(S));
        goto skip1;
  
      case GEQ:
        /*------------------------------------------------------------*/
        /* (a b.s) e (GEQ.c) d --> (T.s)   e c d  if a>=b             */
        /* (a b.s) e (GEQ.c) d --> (NIL.s) e c d  if a< b             */
        /*------------------------------------------------------------*/
        S = cons(leq(cadr(S),car(S)) ? TRUE : FALSE, cddr(S));
        goto skip1;
  
      case STOP:
        /*------------------------------------------------------------*/
        /* (v.s) e (STOP) d --> stop returning v                      */
        /*------------------------------------------------------------*/
        if (pMemGlobal->fileLoad && !evalMacro)
        {
          /*----------------------------------------------------------*/
          /* Extend top level environment                             */
          /*----------------------------------------------------------*/
          pMemGlobal->tlVals = cons(pMemGlobal->newTopLevelVals,
                                     pMemGlobal->tlVals);
          pMemGlobal->newTopLevelVals = NIL;
        }
        running = false;
        return car(S);

      case LDE:
        /*------------------------------------------------------------*/
        /* s e (LDE c.c') d --> ((#rcpd c.e).s) e c' d                */
        /*------------------------------------------------------------*/
        S = cons(cons(RCPD_TAG, cons(cadr(C), E)), S);
        goto skip2;
  
      case AP0:
        /*------------------------------------------------------------*/
        /* ((#rcpd c.e).s) e' (AP0.c') d -->                          */
        /*                          NIL e c (((#rcpd c.e).s) e' c'.d) */
        /* ((#rcpf.x).s) e (AP0.c) d --> (x.s) e c d                  */
        /*------------------------------------------------------------*/
        if (!IS_CONS(car(S)))
          typeError(car(S),"promise");
        if (caar(S) == RCPD_TAG)
        {
          D = cons(S, cons(E, cons(cdr(C), D)));
          C = cadar(S); E = cddar(S); S = NIL;
        }
        else if (caar(S) == RCPF_TAG)
        {
          S = cons(cdar(S), cdr(S));
          goto skip1;
        }
        else
          typeError(car(S),"promise");
        break;
  
      case UPD:
        /*------------------------------------------------------------*/
        /* (x) e (UPD) (((#rcpd c.e).s) e' c'.d) --> (x.s) e' c' d    */
        /* and replace (#rcpd c.e) by (#rcpf.x)                       */
        /*------------------------------------------------------------*/
        S = cons(car(S), cdar(D));
        E = cadr(D); C = caddr(D);
        caaar(D) = RCPF_TAG; cdaar(D) = car(S);
        D = cdddr(D);
        break;
  
      case LDCT:
        /*------------------------------------------------------------*/
        /* s e (LDCT c'.c) d --> (((#cont s e c'.d)).s) e c d         */
        /*------------------------------------------------------------*/
        S = cons(list1(cons4(CONT_TAG,S,E,cadr(C),D)),S);
        goto skip2;

      case DOLO:
        /*------------------------------------------------------------*/
        /* (#f.s e (DOLO b.c) d --> s e c d                           */
        /* (a.s) e (DOLO b.c) d --> s (b DOLO b.c) d                  */
        /*------------------------------------------------------------*/
        if (car(S) != FALSE) {
          D = cons(C, D);
          S = cdr(S);
          C = cadr(C);
        }
        else
          goto skip2;
        break;

      case MST:
        /*------------------------------------------------------------*/
        /* (a1..aN.s) e (MST (i1..iN).c) d --> (a1..aN.s) e' c d      */
        /* where e' = update e set locate(in) = an                    */
        /*------------------------------------------------------------*/
        W = cadr(C);
        while (true) {
          loc = locate(E,INTVAL(car(W)));
          locVal(loc) = car(S);
          if ((W = cdr(W)) != NIL)
            S = cdr(S);
          else
            break;
        }
        goto skip2;

      case EXEC:
        /*------------------------------------------------------------*/
        /* Exec extension                                             */
        /*------------------------------------------------------------*/
        C = cdr(C); // skip EXEC opcode
        pop(loc, C); // get and skip BUILTIN
        ((nativeCompFct*)(BUILTIN(loc)->fun))(loc, NIL, NULL);
        break;

      case CERR:
        /*------------------------------------------------------------*/
        /* Abort uncondionally                                        */
        /*------------------------------------------------------------*/
        ErrThrow(ERR_R10_COND_CLAUSE);
        break;

      case POP:
        /*------------------------------------------------------------*/
        /* (x.s) e (POP.c) d --> s e c d                              */
        /*------------------------------------------------------------*/
        S = cdr(S);
        goto skip1;

      case LST:
        /*------------------------------------------------------------*/
        /* (v1 ... vn.s) e (LST n.c) d --> ((v1 ... vn).s) e c d      */
        /*------------------------------------------------------------*/
        if (i = MINOP(op));
        else {
          C = cdr(C);
          i = INTVAL(car(C));
        }
        loc = S;
        while (--i>0)
          loc = cdr(loc);
        S = cons(S,cdr(loc));
        cdr(loc) = NIL;
        goto skip1;

      case SLEN:
        /*------------------------------------------------------------*/
        /* ((#STR . l) . s) e (SLEN.c) d --> (length(l).s) e c d      */
        /*------------------------------------------------------------*/
        S = cons(makeNum(stringLength(car(S))), cdr(S));
        goto skip1;

      case SAPP:
        /*------------------------------------------------------------*/
        /* ((#STR.l1) (#STR.l2) . s) e (SAPP.c) d -->                 */
        /*      ((#STR copy(l1) copy(l2)) . s) e c d                  */
        /*------------------------------------------------------------*/
        S = cons(appendStrings(car(S),cadr(S)),cddr(S));
        goto skip1;

      case SREF:
        /*------------------------------------------------------------*/
        /* ((#STR.l) n . s) e (SREF.c) d --> (access(l,n) . s) e c d  */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyINDEX, cadr(S),"string-ref",1);
        stringAcc(&W, car(S), getUInt16(cadr(S)), false);
        S = cons(W, cddr(S));
        goto skip1;

      case SSET:
        /*------------------------------------------------------------*/
        /* ((#STR.l) n ch . s) e (SSET.c) d -->                       */
        /*      ((#STR set(l,n,ch)) . s) e c d                        */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyINDEX,cadr(S),"string-set!",1);
        stringAcc(&caddr(S), car(S), getUInt16(cadr(S)), true);
        S = cons(car(S),cdddr(S));
        goto skip1;

      case C2I:
        /*------------------------------------------------------------*/
        /* (ch . s) e (C2I.c) d --> (asc(ch) . s) e c d               */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyCHAR,car(S),"char->integer",0);
        S = cons(MKINT(CHARVAL(car(S))), cdr(S));
        goto skip1;

      case I2C:
        /*------------------------------------------------------------*/
        /* (n . s) e (C2I.c) d --> (chr(n) . s) e c d                 */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tySMALLINT,car(S),"integer->char",0);
        S = cons(MKCHAR(INTVAL(car(S))&0xff), cdr(S));
        goto skip1;

      case O2S:
        /*------------------------------------------------------------*/
        /* (x.s) e (O2S.c) d --> (format(x).s) e c d                  */
        /*------------------------------------------------------------*/
        printSEXP(car(S), PRT_ESCAPE, &portConv);
        S = cons(str2Lisp(msg), cdr(S));
        goto skip1;

      case S2O:
        /*------------------------------------------------------------*/
        /* (x.s) e (S2O.c) d --> (read(x).s) e c d                    */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tySTRING,car(S),"string->object",0);
        printSEXP(car(S), 0, &portConv);
        S = cons(readNthSEXP(msg,1), cdr(S));
        goto skip1;

      case EVT:
        /*------------------------------------------------------------*/
        /* (#f.s) e (EVT . c) d --> (event.s) e c d                   */
        /* (x.s)  e (EVT . c) d --> (event.s) e c d                   */
        /* Waits for event if arg is true                             */
        /*------------------------------------------------------------*/
        pMemGlobal->waitEvent = car(S) != FALSE;
        pMemGlobal->getEvent  = true;
        C = cdr(C);
        S = cdr(S);
        return NIL;

      case GUI:
        /*------------------------------------------------------------*/
        /* (x . s) e (GUI.c) d --> (x . s) e c d                      */
        /* and owns/disowns GUI event handling                        */
        /*------------------------------------------------------------*/
        enableCtls(!(pMemGlobal->ownGUI = car(S) != FALSE));
        goto skip1;

      case VLEN:
        /*------------------------------------------------------------*/
        /* (vec . s) e (VLEN.c) d --> (length(vec).s) e c d           */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyVECTOR,car(S),"vector-length",0);
        S = cons(makeNum(vectorLength(car(S))), cdr(S));
        goto skip1;

      case VREF:
        /*------------------------------------------------------------*/
        /* (vec n . s) e (VREF.c) d --> (access(vec,n) . s) e c d     */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyINDEX, cadr(S),"vector-ref",1);
        vectorAcc(&W, car(S), getUInt16(cadr(S)), false);
        S = cons(W, cddr(S));
        goto skip1;

      case VSET:
        /*------------------------------------------------------------*/
        /* (vec n x . s) e (VSET.c) d --> (vec'. s) e c d             */
        /* where vec' is vec updated at index n with x                */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tyINDEX, cadr(S),"vector-set!",1);
        vectorAcc(&caddr(S), car(S), getUInt16(cadr(S)), true);
        S = cons(car(S),cdddr(S));
        goto skip1;

      case L2V:
        /*------------------------------------------------------------*/
        /* (l . s) e (L2V.c) d --> (vector(l) . s) e c d              */
        /*------------------------------------------------------------*/
        S = cons(makeVector(listLength(car(S)), car(S), true), cdr(S));
        goto skip1;

      case FRMD:
        /*------------------------------------------------------------*/
        /* (t x h . s) e (FRMD.c) d --> s e c d                       */
        /* Displays the form x and stops running (we're now in event  */
        /* handling mode) and save (s e c d) in context stack         */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tySMALLINT,car(S),"frm-popup",0);
        EXT_TCHECK(tyGUI_ID,cadr(S),"frm-popup",1);
        popupForm(getUInt16(cadr(S)), INTVAL(car(S)), caddr(S));
        return NIL;

      case FRMG:
        /*------------------------------------------------------------*/
        /* (t x h . s) e (FRMG.c) d --> s e c d                       */
        /* Displays the form x and stops running (we're now in event  */
        /* handling mode), use event handler h, timeout t             */
        /*------------------------------------------------------------*/
        EXT_TCHECK(tySMALLINT,car(S),"frm-goto",0);
        EXT_TCHECK(tyGUI_ID,cadr(S),"frm-goto",1);
        gotoForm(getUInt16(cadr(S)), INTVAL(car(S)), caddr(S));
        return NIL;

      case FRMQ:
        /*------------------------------------------------------------*/
        /* (v) e' (FRMQ) d' --> (v . s) e c d                         */
        /* Event handling mode finished, so restore context of FRMD   */
        /* from continuation stack                                    */
        /*------------------------------------------------------------*/
        if (actContext==-1)
          goto skip1;
        quitHandler = true;
        return NIL;

      case LNCH:
        /*------------------------------------------------------------*/
        /* (x.s) e (LNCH.c) d --> quit imm. and launch other app      */
        /*------------------------------------------------------------*/
        if (launchApp(car(S))) {
          running = false;
          return NOPRINT;
        }
        else
          goto skip1; 

      /*==============================================================*/
      /* Some frequent LDC constants                                  */
      /* s e (LC?? . c) d --> (??.s) e c d                            */
      /*==============================================================*/
      case LC0:
        S = cons(MKINT(0),S);
        goto skip1;

      case LC1:
        S = cons(MKINT(1),S);
        goto skip1;

      case LC2:
        S = cons(MKINT(2),S);
        goto skip1;

      case LC3:
        S = cons(MKINT(3),S);
        goto skip1;

      case LC_1:
        S = cons(MKINT(-1),S);
        goto skip1;

      case LC_T:
        S = cons(TRUE,S);
        goto skip1;

      case LC_F:
        S = cons(FALSE,S);
        goto skip1;

      case LC_N:
        S = cons(NIL,S);
        goto skip1;

      case LC_E:
        S = cons(EMPTY_STR,S);
        goto skip1;

      /*==============================================================*/
      /* Some frequent LD lexical addresses are hardcoded below       */
      /*==============================================================*/
      case -0: /* (0 . 0) */
        if ((loc=car(E)) == BLACK_HOLE)
          ErrThrow(ERR_R9_BLACK_HOLE);
        S = cons(car(loc),S);
        goto skip1;

      case -1: /* (0 . 1) */
        if ((loc=car(E)) == BLACK_HOLE)
          ErrThrow(ERR_R9_BLACK_HOLE);
        S = cons(cadr(loc),S);
        goto skip1;

      case -2: /* (0 . 2) */
        if ((loc=car(E)) == BLACK_HOLE)
          ErrThrow(ERR_R9_BLACK_HOLE);
        S = cons(caddr(loc),S);
        goto skip1;

      default:
        if (op < 0) {
          /*----------------------------------------------------------*/
          /* negative opcodes denote LD instructions:                 */
          /* s e (-n . c) d --> (locate(n,e) . s) e c d               */
          /*----------------------------------------------------------*/
          loc = locate(E,-op);
          S = cons(locVal(loc),S);
          goto skip1; 
        }
        else { 
          /*----------------------------------------------------------*/
          /* illegal opcode                                           */
          /*----------------------------------------------------------*/
          error1(ERR_R7_ILLEGAL_OP,car(C));
        }  
        break;
    } /* switch */
  } /* for */
  return NIL;
}

/**********************************************************************/
/* Register a EQV comparison function for foreign types               */
/**********************************************************************/
void registerEQV(UInt8 ftype, eqvType fp)
{
  if (ftype >= MAX_FOREIGN_TYPES)
    error1(ERR_M10_INV_FOR_TYPE,MKINT(ftype));
  foreignEqv[ftype] = fp;
}
