/**********************************************************************/
/*                                                                    */
/* socket.c: LISPME socket support                                    */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 26.05.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "socket.h"
#include "arith.h"
#include "vm.h"
#include "io.h"
#include "util.h"
#include "LispMe.h"
#include "comp.h"
#include "port.h"

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define TIMEOUT MKPRIMSYM(SOCKET_MODULE,1)
#define EMERGENCY_TIMEOUT   (sysTicksPerSecond * 5)

#define CLOSED_SOCKET 0
#define SOCK_BUF_SIZE 256

/**********************************************************************/
/* Local types                                                        */
/**********************************************************************/
typedef struct {
  NetSocketRef sock;
  PTR          inPort;
  PTR          outPort;
} LMSocket;

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/

/**********************************************************************/
/* Local data                                                         */
/**********************************************************************/
static UInt16             netLibRef;
static Boolean            netLibOK = false;
static NetHostInfoBufType hostInfo;
static Err                error;
static PTR                timeOutCell;

typedef enum {HOST_NAME, HOST_ADDR, LOCAL_ADDR, PORT_NUM} SocketInfo;

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void    netError(char* text)                             SEC(IO);
static void    init(ModuleMessage mess)                         SEC(IO); 
static void    socketMemHook(MemMessage mess, PTR ptr)          SEC(IO);
static void    socketPrinter(Boolean machineFormat, void* p)    SEC(IO);
static Boolean lazyOpenNetLib()                                 SEC(IO);
static Err     stringToIPAddr(char* str, UInt32* addr)          SEC(IO);
static Int32   getTimeout()                                     SEC(IO);
static PTR     allocSocket(NetSocketRef sock)                   SEC(IO);
static void    writeSock(WriterCmd cmd, OutPort* outp)          SEC(IO);
static Boolean readSock(ReaderCmd cmd, InPort* inp)             SEC(IO);


static PTR     nativeString2IP(PTR* args)                       SEC(IO);
static PTR     nativeMakeClientSocket(PTR* args)                SEC(IO);
static PTR     socketInfo(PTR s, SocketInfo what)               SEC(IO);
static PTR     nativeSocketHostAddr(PTR* args)                  SEC(IO);
static PTR     nativeSocketHostName(PTR* args)                  SEC(IO);
static PTR     nativeSocketLocalAddr(PTR* args)                 SEC(IO);
static PTR     nativeSocketPortNum(PTR* args)                   SEC(IO);
static PTR     nativeSocketInput(PTR* args)                     SEC(IO);
static PTR     nativeSocketOutput(PTR* args)                    SEC(IO);
static PTR     nativeSocketClose(int argc, PTR* args)           SEC(IO);
static PTR     nativeSocketDown(PTR* args)                      SEC(IO);

/**********************************************************************/
/* build net error object                                             */
/**********************************************************************/
static void netError(char* text) 
{
  GrabMem();
  errInfo = text;
  // don't wrap error in an integer!
  ErrThrow((((UInt32)error) << 16) | ERR_N1_NET_ERROR);
}

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
      /*--------------------------------------------------------------*/
      /* Don't open NetLib now, wait for first call                   */
      /*--------------------------------------------------------------*/
      netLibOK = false;

      /*--------------------------------------------------------------*/
      /* Register hooks for socket datatype                           */
      /*--------------------------------------------------------------*/
      registerMemHook(FT_SOCKET,  socketMemHook);
      registerTypename(FT_SOCKET, "socket");
      registerPrinter(FT_SOCKET, socketPrinter);

      /*--------------------------------------------------------------*/
      /* Register hooks for port layer                                */
      /*--------------------------------------------------------------*/
      registerReadFct(PT_SOCKET, readSock);
      registerWriteFct(PT_SOCKET, writeSock);
      break;

    case APP_STOP:
      /*--------------------------------------------------------------*/
      /* Close NetLib (but give other apps chance to reuse service)   */
      /*--------------------------------------------------------------*/
      if (netLibOK) 
        NetLibClose(netLibRef, false);
      break;

    case INIT_HEAP: 
      /*--------------------------------------------------------------*/ 
      /* Add *net-timeout* to global variable list                    */ 
      /*--------------------------------------------------------------*/ 
      createGlobalVar(TIMEOUT, MKINT(10 * SysTicksPerSecond()));
      /* fall thru */

    case SESS_CONNECT: 
      /*--------------------------------------------------------------*/ 
      /* Cache *net-timeout* variable                                 */ 
      /*--------------------------------------------------------------*/ 
      timeOutCell = symLoc(TIMEOUT);
      break;

    default:
  }
}

/**********************************************************************/
/* Open net library on first access                                   */
/**********************************************************************/
static Boolean lazyOpenNetLib()
{
  UInt16 ifErrs;

  if (!netLibOK) {
    error = SysLibFind("Net.lib", &netLibRef);
    if (!error) {
      /*--------------------------------------------------------------*/
      /* The following call may popup a requester so enable           */
      /* write protection, again.                                     */
      /*--------------------------------------------------------------*/
      ReleaseMem();
      error = NetLibOpen(netLibRef, &ifErrs);
      if (error == netErrAlreadyOpen || error == 0)
        netLibOK = true;
      GrabMem();
    }
  }
  return netLibOK;
}

/**********************************************************************/
/* Read and check *net-timeout* variable                              */
/**********************************************************************/
static Int32 getTimeout()
{
  if (!IS_SMALLINT(locVal(timeOutCell)))
    typeError(TIMEOUT, "small integer");
  return INTVAL(locVal(timeOutCell));
}

/**********************************************************************/
/* The memory hook function for sockets                               */
/**********************************************************************/
static void socketMemHook(MemMessage mess, PTR ptr) 
{
  NetSocketRef sock;

  switch (mess) {
    case MEM_MARK:
      mark(((LMSocket*)FOREIGNVAL(ptr))->inPort);
      mark(((LMSocket*)FOREIGNVAL(ptr))->outPort);
      break;
  
    case MEM_DELETE:
      /*--------------------------------------------------------------*/
      /* Close the socket                                             */
      /*--------------------------------------------------------------*/
      sock = ((LMSocket*)FOREIGNVAL(ptr))->sock;
      if (sock != CLOSED_SOCKET)
        if (lazyOpenNetLib()) {
          ReleaseMem();
          NetLibSocketClose(netLibRef, sock, EMERGENCY_TIMEOUT, &error);
          GrabMem();
        }
      MemPtrFree(FOREIGNVAL(ptr));
      break;

    case MEM_PICKLE:
      standardPickle(ptr);
      break;

    case MEM_UNPICKLE:
      standardUnpickle(ptr);
      break;

    default:
  }
}

/**********************************************************************/
/* Print a socket                                                     */
/**********************************************************************/
static void socketPrinter(Boolean machineFormat, void* p)
{
  NetSocketRef sock = ((LMSocket*)p)->sock;
  if (sock==CLOSED_SOCKET)
    outStr("[\254socket]");
  else {
    outStr("[socket ");
    StrIToA(token, (UInt32)sock);
    outStr(token);
    outStr("]");
  }
}

/**********************************************************************/
/* Converts a host string to an IP address.                           */
/**********************************************************************/
static Err stringToIPAddr(char* str, UInt32* addr)
{
  if (((long)(*addr = NetLibAddrAToIN(netLibRef, str))) == -1)
  {
    NetHostInfoPtr hInfo;
    hInfo = NetLibGetHostByName(netLibRef, str, &hostInfo,
                                getTimeout(), &error);
    if (error)
      return error;

    MemMove(addr, hInfo->addrListP[0], hInfo->addrLen);
  }
  return 0;
}

/**********************************************************************/
/* Allocate a socket                                                  */
/**********************************************************************/
static PTR allocSocket(NetSocketRef sock)
{
  LMSocket* plm = MemPtrNew(sizeof(LMSocket));
  PTR       res = allocForeign(plm, FT_SOCKET);
  PROTECT(res);
  plm->sock     = sock;
  // next line necessary in case of GC triggered by makeXXPort 
  plm->inPort   = plm->outPort = NIL;
  plm->inPort   = makeBufInPort(PT_SOCKET,res,EMPTY_STR);
  plm->outPort  = makeBufOutPort(PT_SOCKET, res,
                                 SOCK_BUF_SIZE, OPF_AUTOFLUSH);
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Create a client socket from hostname and port number               */
/**********************************************************************/
static PTR nativeMakeClientSocket(PTR* args)
{
  NetIPAddr ipAddr;
  NetSocketAddrINType addr;
  NetSocketRef        sock;
  Err                 dummy;
  int one = 1;

  if (lazyOpenNetLib()) {
    Int32 timeOut = getTimeout();
    printString(args[0]); // prints to msg
    ReleaseMem();
    if (stringToIPAddr(msg, &ipAddr) != 0) 
      netError("GetHostByName");
    sock = NetLibSocketOpen(netLibRef, netSocketAddrINET, netSocketTypeStream,
                            0, timeOut, &error);
    if (sock < 0)
      netError("SocketOpen");
 
    addr.family = netSocketAddrINET;
    addr.port   = NetHToNS(getInt16(args[1]));
    addr.addr   = ipAddr;
    if (NetLibSocketConnect(netLibRef, sock, (NetSocketAddrType*)&addr,
                            sizeof(addr), 
                            timeOut, &error) < 0) {
      NetLibSocketClose(netLibRef, sock, timeOut, &dummy);
      netError("SocketConnect");
    }

    if (NetLibSocketOptionSet(netLibRef, sock, netSocketOptLevelTCP,
                              netSocketOptTCPNoDelay,
                              (char*)&one, sizeof(one),
                              timeOut, &error) < 0) {
      NetLibSocketClose(netLibRef, sock, timeOut, &dummy);
      netError("SocketOptionSet");
    }
    GrabMem();
    return allocSocket(sock);
  }
  return FALSE;
}

/**********************************************************************/
/* Lookup host and return its IP addr                                 */
/**********************************************************************/
static PTR nativeString2IP(PTR* args)
{
  NetIPAddr ipAddr;
  PTR res = FALSE;

  if (lazyOpenNetLib()) {
    printString(args[0]);
    ReleaseMem();
    if (stringToIPAddr(msg, &ipAddr) == 0) {
      NetLibAddrINToA(netLibRef, ipAddr, token);
      GrabMem();
      res = str2Lisp(token);     
    }
    else
      GrabMem();
  }
  return res;
}

/**********************************************************************/
/* Close the net library                                              */
/**********************************************************************/
static PTR nativeCloseNetlib(PTR* args)
{
  Boolean closed;
  if (netLibOK) {
    ReleaseMem();
    closed = NetLibClose(netLibRef, args[0] != FALSE) != netErrStillOpen;
    GrabMem();
    netLibOK = !closed;
  }
  return closed ? TRUE : FALSE;
}

/**********************************************************************/
/* Retrieve various info for a socket                                 */
/**********************************************************************/
static PTR socketInfo(PTR s, SocketInfo what)
{
  NetSocketRef sock = ((LMSocket*)FOREIGNVAL(s))->sock;
  NetSocketAddrINType locAddr, remAddr;
  Int16               locLen,  remLen;
  NetHostInfoPtr      hInfo;

  if (lazyOpenNetLib() && sock != CLOSED_SOCKET) {
    ReleaseMem();
    if (NetLibSocketAddr(netLibRef, sock,
                         (NetSocketAddrType*)&locAddr, &locLen,
                         (NetSocketAddrType*)&remAddr, &remLen,
                         getTimeout(), &error) < 0) 
      netError("SocketAddr");
    switch (what) {
      case HOST_NAME:
        if ((hInfo = NetLibGetHostByAddr(netLibRef, (UInt8*)&remAddr.addr,
                                sizeof(remAddr.addr), netSocketAddrINET, 
                                &hostInfo, getTimeout(), &error)) == NULL)
          netError("GetHostByAddr");
        GrabMem();
        return str2Lisp(hInfo->nameP); 

      case HOST_ADDR:
        NetLibAddrINToA(netLibRef, remAddr.addr, token);
        GrabMem();
        return str2Lisp(token); 

      case LOCAL_ADDR:
        NetLibAddrINToA(netLibRef, locAddr.addr, token);
        GrabMem();
        return str2Lisp(token); 

      case PORT_NUM:
        GrabMem();
        return MKINT(locAddr.port);
    }
  }
  return FALSE;
}

/**********************************************************************/
/* Native interface for retrieving various socket info                */
/**********************************************************************/
static PTR nativeSocketHostAddr(PTR* args)
{
  return socketInfo(args[0], HOST_ADDR);
}

static PTR nativeSocketHostName(PTR* args)
{
  return socketInfo(args[0], HOST_NAME);
}

static PTR nativeSocketLocalAddr(PTR* args)
{
  return socketInfo(args[0], LOCAL_ADDR);
}

static PTR nativeSocketPortNum(PTR* args)
{
  return socketInfo(args[0], PORT_NUM);
}

/**********************************************************************/
/* Retrieve input port from a socket                                  */
/**********************************************************************/
static PTR nativeSocketInput(PTR* args)
{
  return ((LMSocket*)FOREIGNVAL(args[0]))->inPort;
}

/**********************************************************************/
/* Retrieve output port from a socket                                 */
/**********************************************************************/
static PTR nativeSocketOutput(PTR* args)
{
  return ((LMSocket*)FOREIGNVAL(args[0]))->outPort;
}

/**********************************************************************/
/* Shutdonw/close a socket                                            */
/**********************************************************************/
static PTR nativeSocketClose(int argc, PTR* args)
{
  LMSocket* plm = FOREIGNVAL(args[0]);
  NetSocketRef sock = plm->sock;
  OutPort* outp = FOREIGNVAL(plm->outPort);
  InPort* inp   = FOREIGNVAL(plm->inPort);

  switch (argc)
  {

    case 2:
      if (car(args[1]) == FALSE) 
        if (lazyOpenNetLib() && sock != CLOSED_SOCKET) 
          NetLibSocketShutdown(netLibRef, plm->sock, netSocketDirBoth,
                               getTimeout(), &error);

      /* fall thru */
    case 1:
      if (lazyOpenNetLib() && sock != CLOSED_SOCKET) 
        NetLibSocketClose(netLibRef, plm->sock, getTimeout(), &error);
      break;

    default:
      arityError("socket-shutdown",argc); 
  }
  plm->sock   = CLOSED_SOCKET;
  inp->status = INP_STATUS_CLOSED;
  inp->buf    = NIL;
  outp->flags |= OPF_CLOSED;
  outp->buf   = NIL;
  return args[0];
}

/**********************************************************************/
/* Is the socket down?                                                */
/**********************************************************************/
static PTR nativeSocketDown(PTR* args)
{
  NetSocketRef sock = ((LMSocket*)FOREIGNVAL(args[0]))->sock;
  return sock == CLOSED_SOCKET ? TRUE : FALSE;
}

/**********************************************************************/
/* Read from a socket                                                 */
/**********************************************************************/
static Boolean readSock(ReaderCmd cmd, InPort* inp)
{
  Int16 blk;
  NetSocketRef sock = ((LMSocket*)FOREIGNVAL(inp->impl))->sock;

  switch (cmd) {
    case RC_READ:
      /*--------------------------------------------------------------*/ 
      /* Read next data block                                         */ 
      /*--------------------------------------------------------------*/ 
      if (lazyOpenNetLib() && sock != CLOSED_SOCKET) {
        ReleaseMem();
        blk = NetLibReceive(netLibRef, sock, token, SOCK_BUF_SIZE, 0, 0, 0,
                            getTimeout(), &error);
        GrabMem();
        if (blk == 0)
          return false; // socket shutdown
        else if (blk < 0)
          netError("Receive");
        inp->buf    = copyString(blk, token);
        inp->bufLen = blk;
        inp->pos    = 0;
        return true;
      }
      return false; 

    case RC_CLOSE: 
      /*--------------------------------------------------------------*/ 
      /* Shutdown socket input stream                                 */ 
      /*--------------------------------------------------------------*/ 
      if (lazyOpenNetLib() && sock != CLOSED_SOCKET) {
        ReleaseMem();
        if (NetLibSocketShutdown(netLibRef, sock, netSocketDirInput,
                                 getTimeout(), &error))
          netError("SocketShutdown");    
        GrabMem(); 
      } 
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL;
      return true;
  }
}

/**********************************************************************/
/* Write to a socket                                                  */
/**********************************************************************/
static void writeSock(WriterCmd cmd, OutPort* outp)
{
  NetSocketRef sock = ((LMSocket*)FOREIGNVAL(outp->impl))->sock;
  Int16 sent=0, blk;

  switch (cmd) {
    case WC_WRITE:
      if (lazyOpenNetLib() && sock != CLOSED_SOCKET) {
        while (sent < outp->pos) {
          ReleaseMem();
          blk = NetLibSend(netLibRef, sock, outp->mem+sent,
                           outp->pos-sent, 0, 0, 0,
                           getTimeout(), &error);
          GrabMem();
          if (blk == 0)
            return; // socket shutdown
          else if (blk < 0) 
            netError("Send");
          else
            sent += blk;
        }
        outp->pos = 0;
      }
      break;
 
    case WC_CLOSE:
      /*--------------------------------------------------------------*/ 
      /* Shutdown socket output stream                                */ 
      /*--------------------------------------------------------------*/ 
      if (lazyOpenNetLib() && sock != CLOSED_SOCKET) {
        ReleaseMem(); 
        if (NetLibSocketShutdown(netLibRef, sock, netSocketDirOutput,
                                 getTimeout(), &error))
          netError("SocketShutdown");    
        GrabMem();
      } 
      outp->flags |= OPF_CLOSED;
      break;
  }
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule socketBuiltins = 
{
  MODULE_FUNC(init),
  BUILTINSYMBOL_H("*net-timeout*","timeout in ticks until net call fails"),
  {"socket-shutdown",      NATIVEV1(nativeSocketClose,   FOREIGN(FT_SOCKET))},
  {"make-client-socket",   NATIVE2(nativeMakeClientSocket, tySTRING, tyINT)},
  {"lookup-host",          NATIVE1(nativeString2IP, tySTRING)},
  {"socket-hostname",      NATIVE1(nativeSocketHostName, FOREIGN(FT_SOCKET))},
  {"socket-host-address",  NATIVE1(nativeSocketHostAddr, FOREIGN(FT_SOCKET))},
  {"socket-local-address", NATIVE1(nativeSocketLocalAddr,FOREIGN(FT_SOCKET))},
  {"socket-port-number",   NATIVE1(nativeSocketPortNum,  FOREIGN(FT_SOCKET))},
  {"socket-input",         NATIVE1(nativeSocketInput,    FOREIGN(FT_SOCKET))},
  {"socket-output",        NATIVE1(nativeSocketOutput,   FOREIGN(FT_SOCKET))},
  {"socket?",              PRIMTYPE(FOREIGN(FT_SOCKET))}, 
  {"socket-down?",         NATIVE1(nativeSocketDown,   FOREIGN(FT_SOCKET))},
  {"close-netlib",         NATIVE1(nativeCloseNetlib,   tyBOOL)},

  {NULL}
};
