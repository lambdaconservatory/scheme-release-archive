/**********************************************************************/
/*                                                                    */
/* builtin.c:   LISPME primitives                                     */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 05.09.2000 New                                                Hal  */
/* 03.01.2001 Integrated into 3.0                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"
#include "vm.h"
#include "comp.h"
#include "util.h"
#include "io.h"
#include "LispMe.h"
#include "arith.h"

/*****************************************************************/
/* Global variables                                              */
/*****************************************************************/
BuiltIn* builtins[MAX_MODULES_COUNT];
PTR      histCell;

/*****************************************************************/
/* Static variables                                              */
/*****************************************************************/
static char* foreignNames[MAX_FOREIGN_TYPES];
static int   numMod = 0;
static PTR*  builtindex;
static int   numBuiltins;
static PTR   nativeArgs[5];

/*****************************************************************/
/* Iterate over all built-in entries                             */
/* (Start index 1 since 0 is reserved for module control func.)  */
/* Note static vars to minimize stack usage                      */
/* DOBUILTINS_N allows skipping the first frame(s)               */
/*****************************************************************/
static int       iDOB;
static BuiltIn** bsDOB;
static BuiltIn*  bDOB;

#define DOBUILTINS_N(n,body) \
{\
  for (bsDOB=builtins+(n); *bsDOB != NULL; bsDOB++)\
    for (iDOB=1; (bDOB = ((*bsDOB)+iDOB))->name != NULL; iDOB++)\
      body;\
}

#define DOBUILTINS(body) DOBUILTINS_N(0,body)

/*****************************************************************/
/* Retrieve builtin function                                     */
/*****************************************************************/
BuiltIn* getBuiltin(PTR p)
{
  if (!IS_PRIM(p))
    typeError(p, "primitive");
  return builtins[PRIMVAL1(p)] + PRIMVAL2(p);
}

/*****************************************************************/
/* Retrieve name of builtin function                             */
/*****************************************************************/
char* getName(PTR p)
{
  return getBuiltin(p)->name;
}

/*****************************************************************/
/* Search for given name first in built-in tables, after that    */
/* in the atom table                                             */
/*****************************************************************/
static Int16 compareBuiltins(void *b1, void *b2, Int32 ignore)
{
  char *s1 = (builtins[PRIMVAL1(*(PTR*)b1)] + PRIMVAL2(*(PTR*)b1))->name;
  char *s2 = (builtins[PRIMVAL1(*(PTR*)b2)] + PRIMVAL2(*(PTR*)b2))->name;
  return StrCompare(s1, s2);
}

static Int16 searchBuiltins(void const *s1, void const *b, Int32 ignore)
{
  char *s2 = (builtins[PRIMVAL1(*(PTR*)b)] + PRIMVAL2(*(PTR*)b))->name;
  return StrCompare(s1, s2);
}

static void buildIndex()
{
  numBuiltins = 0;
  DOBUILTINS({numBuiltins++;});
  builtindex = MemPtrNew(numBuiltins*sizeof(PTR));
  numBuiltins = 0;
  DOBUILTINS({
    builtindex[numBuiltins++] = MKPRIMSYM((bsDOB-builtins),iDOB);
  });
  SysQSort(builtindex, numBuiltins, sizeof(PTR), compareBuiltins, 0L);
}

PTR findName(char* s, Boolean create)
{
  Int32 res = -1;

  if (SysBinarySearch(builtindex, numBuiltins, sizeof(PTR),
                      searchBuiltins, s, 0L, &res, true))
    return builtindex[res];
  else
    return findAtom(s, create);
}

/*****************************************************************/
/* Add all completing strings to current completion vector       */
/*****************************************************************/
char* completeBuiltins(char* prefix, UInt16 len, Boolean force)
{
  char* c = NULL;
  DOBUILTINS_N(1,c=completeString1(prefix, len, bDOB->name, force));
  return c;
}

/*****************************************************************/
/* Add all completing strings to symbol list                     */
/*****************************************************************/
void prefixBuiltins(char* prefix, UInt16 len, UInt16* num, char** res)
{
  DOBUILTINS_N(1, {
    if (!prefixOf(prefix, len, bDOB->name, -1));
    else if (num != NULL)
      ++*num;
    else if (res != NULL)
      *(res++) = bDOB->name;
  });
}

/*****************************************************************/
/* Is expression a symbol for a primitive builtin?               */
/*****************************************************************/
Boolean isPrimitiveBuiltin(PTR p)
{
  return IS_PRIM(p) && BUILTIN(p)->kind != KIND_KEYWORD;
}

/*****************************************************************/
/* Typecheck a value                                             */
/*****************************************************************/
Boolean hasType(UInt8 type, PTR val)
{
  switch (type) {
    case tyANY:      return true;
    case tyNUMBER:   if (IS_COMPLEX(val)) return true; /* fall thru */
    case tyREAL:     if (IS_REAL(val)) return true;    /* fall thru */
    case tyINT:      if (IS_BIGINT(val)) return true;  /* fall thru */
    case tySMALLINT: return IS_SMALLINT(val);
    case tyCHAR:     return IS_CHAR(val);
    case tySTRING:   return IS_STRING(val);
    case tyVECTOR:   return IS_VEC(val);
    case tySYMBOL:   return IS_SYM(val) && !IS_FRAME0(val);
    case tyINDEX:    return isIndex(val);
    case tyCOL_IDX:  return IS_SMALLINT(val) && INTVAL(val) >= 0 &&
                            INTVAL(val) < 256;
    case tyGUI_ID:   return IS_INT(val); // && checkedPtr...  
    case tyLIST:     return val==NIL || IS_PAIR(val);
    case tyPROPLIST: return !improperListP(val, true);
    case tyEOFOBJ:   return val==END_OF_FILE;
    case tyBOOL:     return val==TRUE || val==FALSE;
    case tyPAIR:     return IS_PAIR(val);
    case tyNIL:      return val==NIL;
    case tyNONE:     return val==NOPRINT;
    case tyPROC:     return IS_PRIMBIND(val) || 
                            IS_CONS(val) &&
                              (car(val) == CLOS_TAG ||
                               car(val) == CONT_TAG ||
                               car(val) == CXR_TAG);
    case tyCONT:     return IS_CONS(val) && car(val) == CONT_TAG;
    case tyPROMISE:  return IS_CONS(val) &&
                              (car(val) == RCPD_TAG ||
                               car(val) == RCPF_TAG);
    case tyMACRO:    return IS_MACRO(val);
    default:
      if (type >= tyFOREIGN)
        return IS_FOREIGN(val) &&
               FOREIGNTYPE(val) == type-tyFOREIGN;
  }
  return false;
}

/*****************************************************************/
/* Register a foreign type name to be printed in error messages  */
/*****************************************************************/
void registerTypename(UInt8 ftype, char* name)
{
  if (ftype >= MAX_FOREIGN_TYPES)
    error1(ERR_M10_INV_FOR_TYPE,MKINT(ftype));
  foreignNames[ftype] = name;
}

/*****************************************************************/
/* Format a type name for printing                               */
/*****************************************************************/
char* formatType(UInt8 type)
{
  switch (type) {
    case tyINT:      return "integer";
    case tySMALLINT: return "small integer";
    case tyREAL:     return "real";
    case tyNUMBER:   return "number";
    case tyPAIR:     return "pair";
    case tyCHAR:     return "char";
    case tySTRING:   return "string";
    case tyVECTOR:   return "vector";
    case tySYMBOL:   return "symbol";
    case tyINDEX:    return "index";
    case tyLIST:     return "list";
    case tyPROPLIST: return "proper list";
    case tyCOL_IDX:  return "color index";
    case tyGUI_ID:   return "id" ; // "gui id";
    case tyBOOL:     return "boolean";
    case tyANY:      return "any";
    default:
      if (type < tyFOREIGN)
        return "*unprintable*";
      else if (foreignNames[type-tyFOREIGN])
        return foreignNames[type-tyFOREIGN];
      else {
        static char buf[30];
        StrCopy(buf,"foreign type ");
        StrIToA(buf+13,type-tyFOREIGN);
        return buf;     
      }
  }
}

/**********************************************************************/
/* Call a native function                                             */
/* argc == -1 means fixed arity, argc >= 0 var arity indicating       */
/* actual number of args                                              */
/**********************************************************************/
PTR callNative(PTR nat, int argc, PTR args)
{
  BuiltIn* b = BUILTIN(nat);
  int len = b->kind-(argc==-1 ? KIND_NATIVE : KIND_NATIVE_VAR);
  UInt8* types;
  PTR p;
  PTR *currArg;

  /*------------------------------------------------------------------*/
  /* Typecheck all arguments upto declared length of parameter list   */
  /*------------------------------------------------------------------*/
  for (p=args, types = b->stypes, currArg=nativeArgs;
       len--;
       p=cdr(p), types++, currArg++) {
    *currArg = car(p);
    if (!hasType(*types, *currArg))
      extTypeError(b->name, types-b->stypes,
                   *currArg, formatType(*types));
  }

  if (argc == -1)
  {
    W   = (b->fun)(nativeArgs);
    len = b->kind-KIND_NATIVE;
  }
  else
  {
    *currArg = p;
    W   = ((nativeVarFct*)(b->fun))(argc, nativeArgs);
    len = argc;
  }

  /*------------------------------------------------------------------*/
  /* Pop arguments from stack and push result onto stack              */
  /*------------------------------------------------------------------*/
  while (len--)
    args = cdr(args);
  return cons(W, args);
}

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static int init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START:
      /*--------------------------------------------------------------*/ 
      /* Init sorted index of builtin names                           */ 
      /*--------------------------------------------------------------*/ 
      buildIndex();
      break;

    case APP_STOP:
      /*--------------------------------------------------------------*/ 
      /* Release resources                                            */ 
      /*--------------------------------------------------------------*/ 
      MemPtrFree(builtindex);
      break;

    case INIT_HEAP: 
      /*--------------------------------------------------------------*/ 
      /* Create environment frame for global variables, IT and *HIST* */ 
      /*--------------------------------------------------------------*/ 
      pMemGlobal->tlNames = list1(NIL);
      pMemGlobal->tlVals  = list1(NIL);
      createGlobalVar(IT, FALSE);
      createGlobalVar(HIST, NIL);
      goto cacheVars;

    case SESS_CONNECT: 
      /*--------------------------------------------------------------*/ 
      /* Unpickle heap                                                */ 
      /*--------------------------------------------------------------*/ 
      if (pMemGlobal->pickled)
        unpickle();

      /*--------------------------------------------------------------*/ 
      /* Cache *hist* variable                                        */ 
      /*--------------------------------------------------------------*/ 
    cacheVars:
      histCell = symLoc(HIST);
      break;

    case SESS_DISCONNECT: 
      /*--------------------------------------------------------------*/ 
      /* Pickle heap                                                  */ 
      /*--------------------------------------------------------------*/ 
      if (!pMemGlobal->pickled)
        pickle();
      break;

    default:
  }
}

/**********************************************************************/
/* Special immediate values (had reserved pointer bit pattern earlier)*/
/**********************************************************************/
BuiltInModule specialBuiltins =
{
  MODULE_FUNC(NULL),

  BUILTINKEYWORD("[hole]"),
  BUILTINKEYWORD("()"),
  BUILTINKEYWORD("#f"),
  BUILTINKEYWORD("#t"),
  BUILTINKEYWORD("#n"),
  BUILTINKEYWORD("[eof]"),
  BUILTINKEYWORD("#()"),
  BUILTINKEYWORD("\"\""),
  BUILTINKEYWORD("#let"),

  BUILTINKEYWORD("#mlambda"), // separates special values and special tags

  BUILTINKEYWORD("#clos"),
  BUILTINKEYWORD("#dprom"),
  BUILTINKEYWORD("#fprom"),
  BUILTINKEYWORD("#cont"),
  BUILTINKEYWORD("#cplx"),
  BUILTINKEYWORD("#macro"),
  BUILTINKEYWORD("#cxr"),

  {0}
};


/**********************************************************************/
/* Keywords and kernel symbols                                        */
/**********************************************************************/
BuiltInModule keywordBuiltins = 
{
  MODULE_FUNC(NULL),
  /* these four macro characters must be first and */
  /* in an order matching macroChars constant in io.c */
  BUILTINKEYWORDQ_H(quote,      "datum"),
  BUILTINKEYWORDQ_H(quasiquote, "template"),
  BUILTINKEYWORDQ(unquote),
  BUILTINKEYWORD("unquote-splicing"),

  BUILTINKEYWORDQ_H(define,  "var exp"),
  BUILTINKEYWORDQ_H(letrec,  "((var exp)* ) exp'+"),
  BUILTINKEYWORDQ_H(lambda,  "(var* ) exp+"),
  BUILTINKEYWORDQ_H(begin,   "exp+"),
  BUILTINKEYWORDQ(else),
  BUILTINKEYWORDQ_H(cond,    "(test exp+)* [(else exp')]"),
  BUILTINKEYWORDQ_H(if,      "test exp [exp']"),
  BUILTINKEYWORDQ_H(and,     "exp*"),
  BUILTINKEYWORDQ_H(or,      "exp*"),
  BUILTINKEYWORD_H("set!",   "var exp"),
  BUILTINKEYWORDQ_H(delay,   "exp"),
  BUILTINSYMBOL_H("call/cc", "<proc>"),
  BUILTINSYMBOLQ_H(apply,    "<proc> <list>"),
  BUILTINSYMBOLQ_H(it,       "result of last evaluation"),
  BUILTINKEYWORDQ_H(case,    "(list exp+)* [(else exp')]"),
  BUILTINKEYWORDQ_H(macro,   "var exp"),
  BUILTINSYMBOL_H("*hist*",  "expressions evaluated recently"),

  {0}
};

/**********************************************************************/
/* Kernel primitives, type predicates                                 */
/**********************************************************************/
BuiltInModule primitiveBuiltins = 
{
  MODULE_FUNC(init),
  {"not",              PRIM1(1, NOT, "<any>")},
  {"boolean?",         PRIMTYPE(tyBOOL)},
  {"pair?",            PRIMTYPE(tyPAIR)},
  {"null?",            PRIMTYPE(tyNIL)},
  {"number?",          PRIMTYPE(tyNUMBER)},
  {"complex?",         PRIMTYPE(tyNUMBER)},
  {"real?",            PRIMTYPE(tyREAL)},
  {"integer?",         PRIMTYPE(tyINT)},
  {"char?",            PRIMTYPE(tyCHAR)},
  {"string?",          PRIMTYPE(tySTRING)},
  {"vector?",          PRIMTYPE(tyVECTOR)},
  {"symbol?",          PRIMTYPE(tySYMBOL)},
  {"none?",            PRIMTYPE(tyNONE)},
  {"procedure?",       PRIMTYPE(tyPROC)},
  {"continuation?",    PRIMTYPE(tyCONT)},
  {"promise?",         PRIMTYPE(tyPROMISE)},
  {"macro?",           PRIMTYPE(tyMACRO)},
  {"eq?",              PRIM1(2, EQ,  "<any> <any>")},
  {"eqv?",             PRIM1(2, EQV, "<any> <any>")},

  {"force",            PRIM1(1, AP0, "<promise>")},
  {"char->integer",    PRIM1(1, C2I, "<char>")},
  {"integer->char",    PRIM1(1, I2C, "<integer>")},

  {0}
};

/*****************************************************************/
/* Initialize built-in tables and call init fct for each module  */
/*****************************************************************/
void initBuiltins()
{
  ADD_ALL_MODULES;
  builtins[numMod] = NULL;
  forAllModules(APP_START, false);
}

/*****************************************************************/
/* Exit fct for each module                                      */
/*****************************************************************/
void forAllModules(ModuleMessage msg, Boolean reverse)
{
  int i;
  for (i = reverse ? numMod-1 : 0;
           reverse ? i>=0 : i<numMod;
           reverse ? --i  : ++i)
    if (builtins[i][0].fun)
         ((moduleFct*)(builtins[i][0].fun))(msg);
}

