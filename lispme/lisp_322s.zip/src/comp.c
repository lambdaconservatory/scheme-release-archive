/**********************************************************************/
/*                                                                    */
/* comp.c:  LISP to SECD compiler                                     */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 20.07.1997 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include "builtin.h"
#include "comp.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"

/**********************************************************************/
/* Heuristic: More than n macro calls per compile indicate an error   */
/**********************************************************************/
#define MAX_MACRO_PER_COMPILE 200

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static void    compaccum(PTR exlist, PTR names, PTR* code,
                         PTR init, int opc)                   SEC(COMP);
static void    checkUnique(PTR vars)                          SEC(COMP);
static PTR     vars(PTR body)                                 SEC(COMP);
static PTR     exprs(PTR body)                                SEC(COMP);
static short   lambdaNames(PTR orgArgs, PTR* newArgs)         SEC(COMP);
static int     resolveDefineList(PTR expr, PTR* newExpr)      SEC(COMP);
static int     resolveInnerDefine(PTR expr, PTR* newExpr)     SEC(COMP);
static PTR     makeDefaultArg(UInt8 opcode)                   SEC(COMP);  
static int     checkCxr(PTR at)                               SEC(COMP);
static void    addDefine(PTR* let, PTR body, Boolean isMacro) SEC(COMP);
static Boolean shadowingDefine(PTR expr)                      SEC(COMP);

/**********************************************************************/
/* local data                                                         */
/**********************************************************************/
static int   qqNest;
static int   macroCalls;

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
PTR joinCont;
PTR rtnCont;

/**********************************************************************/
/* local definitions                                                  */
/**********************************************************************/
#define FAIL_IF_KEYWORD(ptr) if (IS_KEYWORD(ptr)) \
  error1(ERR_C12_KEYWORD,(ptr))

/**********************************************************************/
/* find a variable in an environment                                  */
/* a lexical address is a single 14 bit integer                       */
/* additionally indicate if the variable has been found in the global */
/* env., in the top-most frame of the global env. or in local env     */
/**********************************************************************/
LEXADR location(PTR var, PTR env, Boolean throwErr, VARLOC* where)
{
  short depth = 0;
  short ord   = 0;
  PTR   frame;
  PTR   name;
  
  if (where != NULL)
    *where = LOCAL;
  for (depth = 0, frame = env;
       frame != NIL;
       ++depth, frame = cdr(frame))
  {
    if (frame == pMemGlobal->tlNames && where != NULL) {
      *where = GLOBAL;
      depth = 0;
    } 
    for (ord = 0, name = car(frame);
         name != NIL;
         ++ord, name = cdr(name))
      if (var == car(name)) {
        if (depth >= MAX_FRAMES ||
            ord   >= MAX_VARS_IN_FRAME)
          error1(ERR_C17_TOO_MANY_VARS,var);
        else {
          if (car(frame) == pMemGlobal->newTopLevelNames &&
              where != NULL && *where==LOCAL)
            *where = RGLOBAL;
          return (depth << FRAME_SHIFT) | ord;
        }  
      }    
  }
  if (throwErr)
    error1(ERR_C1_UNDEF,var);
  else
    return VAR_NOT_FOUND;
}

/**********************************************************************/
/* Create code for pushing constant onto stack                        */
/**********************************************************************/
void compConst(PTR con, PTR* code)
{
  switch (con) 
  {
    case MKINT(0):  *code = cons(MKINT(LC0),*code);  break;
    case MKINT(1):  *code = cons(MKINT(LC1),*code);  break;
    case MKINT(2):  *code = cons(MKINT(LC2),*code);  break;
    case MKINT(3):  *code = cons(MKINT(LC3),*code);  break;
    case MKINT(-1): *code = cons(MKINT(LC_1),*code); break;
    case TRUE:      *code = cons(MKINT(LC_T),*code); break;
    case FALSE:     *code = cons(MKINT(LC_F),*code); break;
    case NIL:       *code = cons(MKINT(LC_N),*code); break;
    case EMPTY_STR: *code = cons(MKINT(LC_E),*code); break;
    default:        *code = cons2(MKINT(LDC),con,*code); break;
  }
}

/**********************************************************************/
/* Create code for variable access                                    */
/**********************************************************************/
void compVar(Boolean store, LEXADR la, VARLOC where, PTR* code)
{
  switch (where) {
    case GLOBAL:
      *code = cons2(MKINT(store ? STG : LDG),
                    locate(pMemGlobal->tlVals,la),*code);
      break; 
    
    case LOCAL:
      if (store)
        *code = cons2(MKINT(ST), MKINT(la), *code);
      else 
        *code = cons(MKINT(-la), *code);
      break;

    case RGLOBAL:
      *code = cons2(MKINT(store ? STU : LDU), MKINT(la), *code);
      break;
  }
}

/**********************************************************************/
/* compile an expression list                                         */
/* using init as neutral element and opc as combiner                  */
/* always use neutral element when building a list or string!         */
/**********************************************************************/
static void compaccum(PTR exlist, PTR names, PTR* code, 
                      PTR init,   int opc)
{
  PTR e;
  CHECKSTACK(e)
  for (e=exlist; e != NIL; e=cdr(e))
  {
    if (!IS_PAIR(e))
      error1(ERR_C6_IMPROPER_ARGS,exlist);
    if (cdr(e) != NIL || opc == CONS ||
        (init == EMPTY_STR && cdr(exlist) == NIL))
      *code = cons(MKINT(opc),*code);
    if (names != NIL)
      comp(car(e), names, code);
  }
  if (exlist == NIL || opc == CONS ||
      (init == EMPTY_STR && cdr(exlist) == NIL))
    compConst(init, code);
}

/**********************************************************************/
/* compile an expression list using the new optimized LST n inst.     */
/**********************************************************************/
void complist(PTR exlist, PTR names, PTR* code)
{
  PTR e;
  PTR patch;
  int n = 0;
  CHECKSTACK(e)

  if (exlist == NIL) {
    /* replace LST 0 with LC_N */
    *code = cons(MKINT(LC_N),*code);
  }
  else {
    /* store length cell to patch later after counting expressions */
    *code = (patch=cons(MKINT(LST),*code));

    for (e=exlist; e != NIL; e=cdr(e))
      {
        if (!IS_PAIR(e))
          error1(ERR_C6_IMPROPER_ARGS,exlist);
        ++n;
        if (names != NIL)
          comp(car(e), names, code);
      }
    if (FITSMINOP(n))
      car(patch) = MKINT(MKMINOP(LST,n));
    else
      cdr(patch) = cons(MKINT(n), cdr(patch));
  }
}

/**********************************************************************/
/* create a default argument from its compressed (8bit) representa.   */
/**********************************************************************/
static PTR makeDefaultArg(UInt8 opcode)
{
  switch (opcode)
  {
    case EMPTY_LIST:   return NIL;
    case EMPTY_STRING: return EMPTY_STR;
    default:           return MKINT((signed char)opcode);
  }
}

/**********************************************************************/
/* Check a symbol for c[ad]+r and build its encoding sequence         */
/**********************************************************************/
static int checkCxr(PTR at)
{
  char* p=getAtom(at);
  if (*p++ == 'c') 
  {
    int enc = 1;
    while (*p == 'a' || *p == 'd') /* only [ad] allowed before an r*/
      enc = (enc << 1) | (*p++ == 'd');

    if (enc > 1 && enc < (1<<(PTR_BITLEN-3)) &&
        p[0] == 'r' && p[1] == '\0') /* atom is c[ad]+r */
      return enc;
  }
  return 0;
}

/**********************************************************************/
/* Is the expression a definition to be rewritten to (set! ...) for   */
/* redefinition?                                                      */
/**********************************************************************/
static Boolean shadowingDefine(PTR expr)
{
  if (IS_PAIR(expr) && car(expr) == DEFINE) {
    W = cadr(expr);
    if (IS_PAIR(W))
      W = car(W);
    return location(W, pMemGlobal->tlNames, false, NULL) != VAR_NOT_FOUND;
  }
  return false;
}

/**********************************************************************/
/* build code for built-in function                                   */
/* names == NIL means compiling on the fly for applying a builtin     */
/* function. Don't compile args in this case                          */
/**********************************************************************/
Boolean buildIn(PTR func, PTR args, Int16 argl, PTR names, PTR* code)
{
  UInt16          kind, j;
  PTR             temp;
  static unsigned char* p;
  static int enc;

  CHECKSTACK(temp);
  /*------------------------------------------------------------------*/
  /* First check c[ad]+r functions  [hal: 15/8-00]                    */
  /*------------------------------------------------------------------*/
  if (IS_ATOM(func))
  {
    if ((enc = checkCxr(func)) != 0)
    {
      if (argl != 1)
        error1(ERR_C2_NUM_ARGS,func);

      if (FITSMINOP(enc))
        *code = cons(MKINT(MKMINOP(CXR,enc)), *code);
      else
        *code = cons2(MKINT(CXR), MKINT(enc), *code);
      if (names != NIL)
        comp(car(args), names, code);
      return true;
    }
    else
      return false;
  }
  else if (IS_CONS(func) && car(func) == CXR_TAG)
  {
    /*----------------------------------------------------------------*/
    /* A c[ad]+r function already converted is now being applied      */
    /*----------------------------------------------------------------*/
    if (argl != 1)
      error1(ERR_C2_NUM_ARGS,func);
    *code = cons2(MKINT(CXR), cdr(func), *code);
    if (names != NIL)
      comp(car(args), names, code);
    return true;
  }
  else if (!isPrimitiveBuiltin(func))
    return false;

  /*------------------------------------------------------------------*/
  /* It's a builtin function                                          */
  /*------------------------------------------------------------------*/
  kind = BUILTIN(func)->kind;
  p    = BUILTIN(func)->stypes; 

  if (kind == KIND_PRIM12_OP)
  {
    /*----------------------------------------------------------------*/
    /* 1 or 2 args, different opcodes                                 */
    /*----------------------------------------------------------------*/
    switch (argl) {
      case 1:
      case 2:
        *code = cons(MKINT(p[argl-1]), *code);
        break;

      default:
        error1(ERR_C2_NUM_ARGS,func);
    }
  }
  else if (kind == KIND_PRIM_LIST)
  {
    /*----------------------------------------------------------------*/
    /* Gather arguments into a list                                   */
    /*----------------------------------------------------------------*/
    if (p[0] != NOP)
      *code = cons(MKINT(p[0]), *code);
    complist(args, names, code);
    return true;
  }
  else if (kind == KIND_PRIM_TRANS)
  {
    /*----------------------------------------------------------------*/
    /* Unary transcendental primitive encoded in minor opcode         */
    /*----------------------------------------------------------------*/
    if (argl != 1)
      error1(ERR_C2_NUM_ARGS,func);
    *code = cons(MKINT(MKMINOP(TRAN,p[0])), *code);
  }
  else if (kind >= KIND_NATIVE)
  {
    /*----------------------------------------------------------------*/
    /* Call native C function (fixed arity)                           */
    /*----------------------------------------------------------------*/
    if (argl != kind-KIND_NATIVE)
      error1(ERR_C2_NUM_ARGS,func);
    *code = cons2(MKINT(CANF), MKPRIMBIND(func), *code);
  }
  else if (kind >= KIND_NATIVE_VAR)
  {
    /*----------------------------------------------------------------*/
    /* Call native C function (var arity)                             */
    /* Assume argl<64, so it always fits in minor opcode              */
    /*----------------------------------------------------------------*/
    if (argl < kind-KIND_NATIVE_VAR)
      error1(ERR_C2_NUM_ARGS,func);
    *code = cons2(MKINT(MKMINOP(CANV,argl)), MKPRIMBIND(func), *code);
  }
  else if (kind >= KIND_PRIM_DEF)
  {
    /*----------------------------------------------------------------*/
    /* n or n+1 args, default value for first arg                     */
    /*----------------------------------------------------------------*/
    *code = cons(MKINT(p[0]), *code);
    switch (argl-(kind-KIND_PRIM_DEF)) {
      case 0:
        compConst(makeDefaultArg(p[1]), code);
      case 1:
        break;

      default:
        error1(ERR_C2_NUM_ARGS,func);
    }
  }
  else if (kind >= KIND_PRIM_FOLD)
  {
    /*----------------------------------------------------------------*/
    /* any number of args, use accumulating pattern                   */
    /*----------------------------------------------------------------*/
    if (argl < kind-KIND_PRIM_FOLD)
      error1(ERR_C2_NUM_ARGS,func);
    compaccum(args, names, code, makeDefaultArg(p[1]), p[0]);
    return true;
  }
  else
  {
    /*----------------------------------------------------------------*/
    /* Fixed number of args                                           */
    /*----------------------------------------------------------------*/
    if (argl != kind)
      error1(ERR_C2_NUM_ARGS,func);

    /*----------------------------------------------------------------*/
    /* Build opcode list from table (reversed!)                       */
    /*----------------------------------------------------------------*/  
    for (j=0; p[j] != NOP; j++) 
      *code = cons(MKINT(p[j]),*code);
  }

  /*------------------------------------------------------------------*/
  /* Build code for subexpressions                                    */
  /*------------------------------------------------------------------*/
  if (names != NIL)
    for (; argl-- && args != NIL; args = cdr(args))
      comp(car(args), names, code);
  return true;
}

/**********************************************************************/
/* check, if name list is unique                                      */
/**********************************************************************/
static void checkUnique(PTR vars)
{
  PTR p1,p2;
  for (p1=vars; p1 != NIL; p1=cdr(p1))
    for (p2=cdr(p1); p2 != NIL; p2=cdr(p2))
      if (car(p1) == car(p2))
        error1(ERR_C7_DUPLICATE_NAME,car(p1));
}

/**********************************************************************/
/* check let-list and  extract variable names from                    */
/* a LET or LETREC-block                                              */
/**********************************************************************/
static PTR vars(PTR body)
{
  PTR e;
  PTR res = NIL;

  PROTECT(res)
  for (e=body; e != NIL; e=cdr(e))
  {
    if (!IS_PAIR(e))
      error1(ERR_C8_INV_LET_LIST,e);
    if (listLength(car(e)) != 2)
      error1(ERR_C4_INVALID_BIND,car(e));
    if (!IS_SYM(caar(e)))
      error1(ERR_C3_NOT_SYMBOL,caar(e));
    FAIL_IF_KEYWORD(caar(e));
    res = cons(caar(e),res);
  }
  checkUnique(res);
  UNPROTECT(res)
  return res;
}

/**********************************************************************/
/* extract expressions from a LET or LETREC-block                     */
/**********************************************************************/
static PTR exprs(PTR body)
{
  PTR e;
  PTR res = NIL;
  PROTECT(res)
  for (e=body; e != NIL; e=cdr(e))
    res = cons(cadar(e),res);
  UNPROTECT(res)
  return res;
}

/**********************************************************************/
/* build name list for lambda expression                              */
/**********************************************************************/
static short lambdaNames(PTR orgArgs, PTR* newArgs)
{
  short len = 0;
  PTR   oldP=NIL;

  if (IS_CONS(orgArgs) || orgArgs == NIL)
  {
    PTR p = orgArgs;
    while (IS_CONS(p))
    {
      if (!IS_SYM(car(p)))
        error1(ERR_C5_INVALID_LAMBDA,orgArgs);
      FAIL_IF_KEYWORD(car(p));
      oldP = p;
      p = cdr(p);
      ++len;
    }
    if (p==NIL)
    {
      *newArgs = orgArgs;
      checkUnique(*newArgs);
      return len;
    }
    else if (IS_SYM(p))
    {
      FAIL_IF_KEYWORD(p);
      cdr(oldP) = cons(p,NIL);
      *newArgs = orgArgs;
      checkUnique(*newArgs);
      return -1-len;
    }
    else
      error1(ERR_C5_INVALID_LAMBDA,orgArgs);
  }
  else if (IS_SYM(orgArgs))
  {
    FAIL_IF_KEYWORD(orgArgs);
    *newArgs = cons(orgArgs,NIL);
    return -1;
  }
  else
    error1(ERR_C5_INVALID_LAMBDA,orgArgs);
}

/**********************************************************************/
/* compile an expression sequence                                     */
/**********************************************************************/
void compseq(PTR exlist, PTR names, PTR* code)
{
  PTR e = NIL;

  CHECKSTACK(e)

  if (exlist == NIL)
    ErrThrow(ERR_C10_EMPTY_SEQUENCE);

  PROTECT(e)
  for (e=reverse(exlist); e != NIL; e=cdr(e))
  {
    comp(car(e), names, code);
    if (cdr(e) != NIL) {
      *code = cons(MKINT(POP),*code);
    }
  }
  UNPROTECT(e)
}

/**********************************************************************/
/* add a single definition to a letrec binding list                   */
/**********************************************************************/
static void addDefine(PTR* let, PTR body, Boolean isMacro)
{
  if (!IS_CONS(body) || !IS_CONS(cdr(body)))
    error1(ERR_C2_NUM_ARGS, DEFINE);

  if (IS_CONS(car(body)))
  {
    /*----------------------------------------------------------------*/
    /* function definition:                                           */
    /* ((var . args) expr ...) -> (var (lambda args expr ...))        */
    /*----------------------------------------------------------------*/
    *let = cons(cons(caar(body),
                     cons(cons(isMacro ? MLAMBDA : LAMBDA,
                               cons(cdar(body),cdr(body))),
                          NIL)),
           *let);
  }
  else
  {
    if (isMacro)
      error1(ERR_C15_INVALID_DEFINE, body);
    /*----------------------------------------------------------------*/
    /* simple definition:                                             */
    /* (var expr) -> (var expr)                                       */
    /*----------------------------------------------------------------*/
    *let = cons(body,*let);
  }
}

/**********************************************************************/
/* resolve a definition (define ...) or definition list              */
/* (begin (define ...) ...) to equivalent letrec                     */
/**********************************************************************/
static int resolveDefineList(PTR expr, PTR* newExpr)
{
  PTR temp, def;
  int res;

  *newExpr = expr;
  if (IS_CONS(expr))
  {
    temp = cons2(LETREC, NIL, list1(NOPRINT));
    PROTECT(temp)

    if (car(expr) == DEFINE || car(expr) == MACRO)
    {
      /*--------------------------------------------------------------*/
      /* single definition                                            */
      /*--------------------------------------------------------------*/
      addDefine(&cadr(temp), cdr(expr), car(expr) == MACRO);
      *newExpr = temp;
      res = 1;
    }
    else if (car(expr) == BEGIN && IS_CONS(cadr(expr)) &&
             (caadr(expr) == DEFINE || caadr(expr) == MACRO))
    {
      /*--------------------------------------------------------------*/
      /* (possible) list of definitions                               */
      /*--------------------------------------------------------------*/
      for (def = cdr(expr); def != NIL; def = cdr(def))
      {
        if (!IS_PAIR(def))
          error1(ERR_C15_INVALID_DEFINE, def);
        if (!IS_CONS(car(def)) ||
              (caar(def) != DEFINE && caar(def) != MACRO))
          error1(ERR_C15_INVALID_DEFINE, car(def));
        addDefine(&cadr(temp), cdar(def), caar(def) == MACRO);
      }
      *newExpr = temp;
      res = 1;
    }
    else
      res = 0;
    UNPROTECT(temp)
    return res;
  }
  else
    return 0;
}

/**********************************************************************/
/* resolve a inner definition ((define1 ...) (define2 ...) exp1 exp2) */
/* to equivalent letrec                                               */
/**********************************************************************/
static int resolveInnerDefine(PTR expr, PTR* newExpr)
{
  PTR temp, def, seq;

  *newExpr = expr;
  if (IS_CONS(expr) && IS_CONS(car(expr)) && caar(expr) == DEFINE)
  {
    /*----------------------------------------------------------------*/
    /* OK, list starts with DEFINE, now find first non-DEFINE         */
    /*----------------------------------------------------------------*/
    for (seq = cdr(expr);
         IS_CONS(seq) && IS_CONS(car(seq)) && caar(seq) == DEFINE;
         seq = cdr(seq))
      ;

    if (seq == NIL)
      ErrThrow(ERR_C10_EMPTY_SEQUENCE);

    /*----------------------------------------------------------------*/
    /* Check that no subsequent expression is a define                */
    /*----------------------------------------------------------------*/
    for (temp=seq; temp != NIL; temp = cdr(temp))
      if (IS_CONS(def) && IS_CONS(car(def)) && caar(def) == DEFINE)
        error1(ERR_C9_WRONG_DEFINE, car(def));

    /*----------------------------------------------------------------*/
    /* Build LETREC with first non-DEFINE as body                     */
    /*----------------------------------------------------------------*/
    temp = cons2(LETREC, NIL, seq);
    PROTECT(temp)

    /*----------------------------------------------------------------*/
    /* Add each definition to binding part of LETREC                  */
    /*----------------------------------------------------------------*/
    for (def = expr; def != seq; def = cdr(def))
      addDefine(&cadr(temp), cdar(def), false);
    *newExpr = temp;
    UNPROTECT(temp)
    return 1;
  }
  else
    return 0;
}

/**********************************************************************/
/* compile an expression, accumulating the resulted code              */
/**********************************************************************/
void comp(PTR expr, PTR names, PTR* code)
{
  static LEXADR la;
  static VARLOC where;
  PTR temp;
  PTR temp1;
  PTR temp2;
  PTR temp3;
  PTR temp4;
  short opc;

  CHECKSTACK(opc)

tailCall:
  if (IS_SMALLINT(expr)  || IS_REAL(expr)    || IS_SPECIAL(expr) ||
      IS_CHAR(expr)      || IS_STRING(expr)  || IS_BIGINT(expr)  ||
      IS_PRIMBIND(expr)  ||
      (IS_CONS(expr) && IS_STAG(car(expr))))
  {
    /*----------------------------------------------------------------*/
    /* Self-evaluating                                                */
    /*----------------------------------------------------------------*/
  selfEval:
    compConst(expr, code);
  }
  else if (IS_VEC(expr))
  {
    if (qqNest)
    {
      /*--------------------------------------------------------------*/
      /* Handle vector template for quasiquote:                       */
      /*--------------------------------------------------------------*/
      *code = cons(MKINT(L2V),*code);
      expr  = vector2List(expr);
      goto tailCall;
    }
    else
      goto selfEval;
  }
  else if (IS_PRIMSYM(expr))
  {
    if (qqNest)
      goto selfEval;

    if (BUILTIN(expr)->kind == KIND_KEYWORD)
      error1(ERR_C12_KEYWORD,expr);

    /*----------------------------------------------------------------*/
    /* Allow predefined names to be redefined by user!                */
    /*----------------------------------------------------------------*/
    la = location(expr,names,false,&where);
    if (la == VAR_NOT_FOUND) {
      if (BUILTIN(expr)->kind == KIND_SYMBOL)
        error1(ERR_C1_UNDEF,expr);
      else
        *code = cons2(MKINT(LDC),MKPRIMBIND(expr),*code);
    }
    else
      compVar(false, la, where, code); 
  }
  else if (IS_ATOM(expr))
  {
    static int cxrcode;

    if (qqNest)
      goto selfEval;

    /*----------------------------------------------------------------*/
    /* Variable access                                                */
    /* Don't use LD opcode anymore, instead negative encoded adr as   */
    /* opcode directly                                                */
    /*----------------------------------------------------------------*/
    la = location(expr,names,false,&where);
    if (la == VAR_NOT_FOUND) {
      if ((cxrcode = checkCxr(expr)) != 0)
        *code = cons2(MKINT(LDC),cons(CXR_TAG,MKINT(cxrcode)),*code);
      else
        error1(ERR_C1_UNDEF,expr);
    }
    else
      compVar(false, la, where, code); 
  }
  else 
  {
    PTR   fn   = car(expr);
    PTR   args = cdr(expr);
    Int16 argl = listLength(args);

    if (qqNest)
    {
      /*--------------------------------------------------------------*/
      /* We're inside a quasiquote template                           */
      /*--------------------------------------------------------------*/
      if (fn == QUASIQUOTE)
      {
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        *code = cons(MKINT(CONS),*code);
        ++qqNest;
        comp(fn, names, code);
        compaccum(args,names,code,NIL,CONS);
        --qqNest;
      }
      else if (fn == UNQUOTE)
      {
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        if (qqNest == 1)
        {
          --qqNest;
          comp(car(args), names, code);
          ++qqNest;
        }
        else
        {
        compUnquote:
          *code = cons(MKINT(CONS),*code);
          --qqNest;
          comp(fn, names, code);
          compaccum(args,names,code,NIL,CONS);
          ++qqNest;
        }
      }
      else if (fn == UNQUOTESPLICING)
      {
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        if (qqNest == 1)
        {
          if (car(*code) != MKINT(CONS))
            ErrThrow(ERR_C14_SPLICE_NONLIST);
          /*----------------------------------------------------------*/
          /* Replace latest CONS in continuation by APND              */
          /*----------------------------------------------------------*/
          *code = cons(MKINT(APND), cdr(*code));
          --qqNest;
          comp(car(args), names, code);
          ++qqNest;
        }
        else
          goto compUnquote;
      }
      else
      {
        *code = cons(MKINT(CONS),*code);
        comp(fn,names,code);
        compaccum(args,names,code,NIL,CONS);
      }
    }
    else
    {
      /*--------------------------------------------------------------*/
      /* normal expression                                            */
      /*--------------------------------------------------------------*/
      if (fn == QUOTE)
      {
        /*------------------------------------------------------------*/
        /* quoted expression                                          */
        /*------------------------------------------------------------*/
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        compConst(car(args), code);
      }
      else if (fn == QUASIQUOTE)
      {
        /*------------------------------------------------------------*/
        /* quasiquote expression                                      */
        /*------------------------------------------------------------*/
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        ++qqNest;
        comp(car(args), names, code);
        --qqNest;
      }
      else if (fn == UNQUOTE || fn == UNQUOTESPLICING)
        error1(ERR_C13_INV_UNQUOTE,fn);
      else if (fn == COND)
      {
        /*------------------------------------------------------------*/
        /* conditional: if cont = (RET) dont use join, but propagate  */
        /* (RET) to subcontrols and use non-pushing SEL (=SELR)       */
        /*------------------------------------------------------------*/
        temp = temp4 = cons(MKINT(CERR),NIL);
        PROTECT(temp)
        PROTECT(temp4)
        temp3 = reverse(args);
        PROTECT(temp3)
        while (temp3 != NIL)
        {
          if (!IS_PAIR(car(temp3)))
            error1(ERR_C11_INVALID_COND,car(temp3));
   
          /*----------------------------------------------------------*/
          /* Continuation after selection                             */
          /*----------------------------------------------------------*/
          if (*code == rtnCont) {
            temp1 = rtnCont;
            opc = SELR;
          } else {
            temp1 = joinCont;
            opc = SEL;
          }
          PROTECT(temp1)
          temp2 = NIL; PROTECT(temp2)
          if (resolveInnerDefine(cdar(temp3), &temp2))
            comp(temp2, names, &temp1);
          else
            compseq(temp2, names, &temp1);
          UNPROTECT(temp2)
          /*----------------------------------------------------------*/
          /* Omit test, if condition is 'else'                        */
          /*----------------------------------------------------------*/
          if (caar(temp3) == ELSE)
            temp = temp4 = temp1;
          else
          {
            temp4 = list3(MKINT(opc), temp1, temp);
            if (opc == SEL)
            {
              if (cdr(temp3) == NIL)
                cdddr(temp4) = *code;
              else
                cdddr(temp4) = joinCont;
            }  

            comp(caar(temp3),names,&temp4);
            temp = temp4;
          }
          UNPROTECT(temp1)
          temp3 = cdr(temp3);
        }
        UNPROTECT(temp3)
        UNPROTECT(temp4)
        UNPROTECT(temp)
        *code = temp4;
      }
      else if (fn == CASE)
      {
        /*------------------------------------------------------------*/
        /* conditional: if cont = (RET) dont use join, but propagate  */
        /* (RET) to subcontrols and use non-pushing SEL (=SELR)       */
        /*------------------------------------------------------------*/
        if (argl < 1)
          error1(ERR_C2_NUM_ARGS,fn);
        temp = temp4 = list1(MKINT(CERR));
        PROTECT(temp)
        PROTECT(temp4)
        temp3 = reverse(cdr(args));
        PROTECT(temp3)
        while (temp3 != NIL)
        {
          if (!IS_PAIR(car(temp3)))
            error1(ERR_C11_INVALID_COND,car(temp3));
   
          /*----------------------------------------------------------*/
          /* Continuation after selection                             */
          /*----------------------------------------------------------*/
          if (*code == rtnCont) {
            temp1 = rtnCont;
            opc = MEMR;
          } else {
            temp1 = joinCont;
            opc = MEM;
          }
          PROTECT(temp1)
          temp2 = NIL; PROTECT(temp2)
          if (resolveInnerDefine(cdar(temp3), &temp2))
            comp(temp2, names, &temp1);
          else
            compseq(temp2, names, &temp1);
          UNPROTECT(temp2)
          /*----------------------------------------------------------*/
          /* Omit test, if condition is 'else', but have to POP test  */
          /*----------------------------------------------------------*/
          if (caar(temp3) == ELSE)
            temp = temp4 = cons(MKINT(POP),temp1);
          else
          {
            temp4 = cons(MKINT(opc),
                          cons(caar(temp3),
                                cons(temp1,
                                      cons(temp,NIL))));
            if (opc == MEM)
            {
              if (cdr(temp3) == NIL)
                cdr(cdddr(temp4)) = *code;
              else
                cdr(cdddr(temp4)) = joinCont;
            }
            temp = temp4;
          }
          UNPROTECT(temp1)
          temp3 = cdr(temp3);
        }
        UNPROTECT(temp3)
        UNPROTECT(temp4)
        UNPROTECT(temp)
        *code = temp4;
        expr=car(args);
        goto tailCall;
      }
      else if (fn == IF)
      {
        /*------------------------------------------------------------*/
        /* [e1] SEL{R} ([e2] JOIN/RTN) ([e3] JOIN/RTN)                */
        /*------------------------------------------------------------*/
        if (argl != 3 && argl != 2)
          error1(ERR_C2_NUM_ARGS,fn);
   
        if (*code == rtnCont) {
          temp2 = temp1 = rtnCont;
          opc = SELR;
        } else {
          temp2 = temp1 = joinCont;
          opc = SEL;
        }
        PROTECT(temp1)
        PROTECT(temp2)
        comp(cadr(args),names,&temp1);
        if (argl==3)
          comp(caddr(args),names,&temp2);
        else
          compConst(FALSE,&temp2);
        *code = cons3(MKINT(opc), temp1, temp2, opc==SEL?*code:NIL);
        UNPROTECT(temp2)
        UNPROTECT(temp1)
        expr = car(args);
        goto tailCall;
      }
      else if (fn == OR || fn == AND)
      {
        /*------------------------------------------------------------*/
        /* 0 arg: LDC #f/#t                                           */
        /* 1 arg: comp(e)                                             */
        /* n arg: comp(e1) SE(O/A){R} (comp(e2) ... JOIN/RTN)         */
        /*------------------------------------------------------------*/
        if (argl == 0) {
          expr = fn == OR ? FALSE : TRUE;
          goto selfEval;
        }
        temp = reverse(args); temp2 = NIL;
        PROTECT(temp)
        PROTECT(temp2)
        if (*code == rtnCont)
          opc = fn == OR ? SEOR : SEAR;
        else
          opc = fn == OR ? SEO : SEA;
        while (argl--)
        {
          if (*code == rtnCont)
            temp1 = rtnCont;
          else
            temp1 = (argl==0) ? *code : joinCont;
          if (temp2 == NIL)
            temp2 = temp1;
          else
            temp2 = cons2(MKINT(opc), temp2, temp1);
          comp(car(temp),names,&temp2);
          temp = cdr(temp);
        }
        UNPROTECT(temp2)
        UNPROTECT(temp)
        *code = temp2;
      }
      else if (fn == LAMBDA)
      {
        /*------------------------------------------------------------*/
        /* lambda expression                                          */
        /*------------------------------------------------------------*/
        short len;
        if (argl < 1)
          error1(ERR_C2_NUM_ARGS,fn);
        temp = rtnCont;
        PROTECT(temp)
        temp1 = cons(NIL,names);
        PROTECT(temp1)
        len = lambdaNames(car(args), &car(temp1));
        temp2 = NIL; PROTECT(temp2)
        if (resolveInnerDefine(cdr(args), &temp2))
          comp(temp2, temp1, &temp);
        else
          compseq(temp2, temp1, &temp);
        UNPROTECT(temp2)
        UNPROTECT(temp1)
        *code = cons3(MKINT(LDFC), cons(MKINT(len),car(args)), temp, *code);
        UNPROTECT(temp)
      }
      else if (fn == MLAMBDA)
      {
        /*------------------------------------------------------------*/
        /* lambda expression generated by macro                       */
        /*------------------------------------------------------------*/
        short len;
        if (argl < 1)
          error1(ERR_C2_NUM_ARGS,MACRO);
        temp = rtnCont;
        PROTECT(temp)
        temp1 = cons(NIL,names);
        PROTECT(temp1)
        len = lambdaNames(car(args), &car(temp1));
        if (len != 1)
          error1(ERR_C2_NUM_ARGS,MACRO);
        temp2 = NIL; PROTECT(temp2)
        if (resolveInnerDefine(cdr(args), &temp2))
          comp(temp2, temp1, &temp);
        else
          compseq(temp2, temp1, &temp);
        UNPROTECT(temp2)
        UNPROTECT(temp1)
        *code = cons2(MKINT(LDM), temp, *code);
        UNPROTECT(temp)
      }
      else if (fn == LET_TAG)
      {
        /*------------------------------------------------------------*/
        /* local block                                                */
        /*------------------------------------------------------------*/
        if (argl < 2)
          error1(ERR_C2_NUM_ARGS,LET);
        temp  = rtnCont;                     PROTECT(temp)
        temp1 = cons(vars(car(args)),names); PROTECT(temp1)
        temp2 = NIL;                         PROTECT(temp2)
         if (resolveInnerDefine(cdr(args), &temp2))
          comp(temp2, temp1, &temp);
        else
          compseq(temp2, temp1, &temp);
        UNPROTECT(temp2)
        UNPROTECT(temp1)
        if (*code == rtnCont)
          *code = list3(MKINT(LDF), temp, MKINT(TAP));
        else
          *code = cons3(MKINT(LDF), temp, MKINT(AP), *code);
        temp = exprs(car(args));
        complist(temp, names, code);
        UNPROTECT(temp)
      }
      else if (fn == LETREC)
      {
        /*------------------------------------------------------------*/
        /* local recursive block                                      */
        /*------------------------------------------------------------*/
        if (argl < 2)
          error1(ERR_C2_NUM_ARGS,fn);

        temp1 = cons(vars(car(args)),names);  PROTECT(temp1)
        /*------------------------------------------------------------*/
        /* the outermost LETREC block establishes names in top env    */
        /*------------------------------------------------------------*/
        if (pMemGlobal->newTopLevelNames == BLACK_HOLE)
          pMemGlobal->newTopLevelNames = car(temp1); 

        temp  = rtnCont;                      PROTECT(temp)
        temp2 = NIL;                          PROTECT(temp2)
        if (resolveInnerDefine(cdr(args), &temp2))
          comp(temp2, temp1, &temp);
        else
          compseq(temp2, temp1, &temp);
        UNPROTECT(temp2)
        if (*code == rtnCont)
          *code = list3(MKINT(LDF), temp, MKINT(RTAP));
        else
          *code = cons3(MKINT(LDF), temp, MKINT(RAP), *code);
        temp = exprs(car(args));
        complist(temp, temp1, code);
        UNPROTECT(temp)
        UNPROTECT(temp1)
        *code = cons(MKINT(DUM),*code);
      }
      else if (fn == BEGIN)
      {
        temp = NIL;
        PROTECT(temp)
        if (resolveInnerDefine(args, &temp))
          comp(temp, names, code);
        else
          compseq(temp, names, code);
        UNPROTECT(temp)
      }
      else if (fn == SET)
      {
        /*------------------------------------------------------------*/
        /* modify variable                                            */
        /*------------------------------------------------------------*/
        if (argl != 2)
          error1(ERR_C2_NUM_ARGS,fn);
        if (!IS_SYM(car(args)))
          error1(ERR_C3_NOT_SYMBOL,car(args));
        else if (IS_PRIMSYM(car(args)) &&
                 BUILTIN(car(args))->kind != KIND_SYMBOL)
          error1(ERR_C12_KEYWORD,car(args));

        la = location(car(args),names,true,&where);
        compVar(true, la, where, code); 
        expr = cadr(args);
        goto tailCall;
      }
      else if (fn == DELAY)
      {
        /*------------------------------------------------------------*/
        /* build recipe                                               */
        /*------------------------------------------------------------*/
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        temp = list1(MKINT(UPD));
        PROTECT(temp)
        comp(car(args), names, &temp);
        *code = cons2(MKINT(LDE), temp, *code);
        UNPROTECT(temp)
      }
      else if (fn == CALLCC)
      {
        /*------------------------------------------------------------*/
        /* call with current continuation                             */
        /*------------------------------------------------------------*/
        if (argl != 1)
          error1(ERR_C2_NUM_ARGS,fn);
        if (*code == rtnCont)
          temp = list1(MKINT(TAPC));
        else
          temp = cons(MKINT(APC),*code);
        PROTECT(temp)
        comp(car(args), names, &temp);
        *code = cons2(MKINT(LDCT), *code, temp);
        UNPROTECT(temp)
      }
      else if (fn == DEFINE)
        error1(ERR_C9_WRONG_DEFINE, expr);
      else if (fn == APPLY)
      {
        /*------------------------------------------------------------*/
        /* function application to list                               */
        /*------------------------------------------------------------*/
        if (argl != 2)
          error1(ERR_C2_NUM_ARGS,fn);
        if (*code == rtnCont)
          *code = list1(MKINT(TAPY));
        else
          *code = cons(MKINT(APY),*code);
        comp(car(args),names,code);
        expr = cadr(args);
        goto tailCall;
      }
      else if (IS_PRIMSYM(fn) && location(fn,names,false,&where)
               != VAR_NOT_FOUND)
      {
        /*------------------------------------------------------------*/
        /* A primitive has been re-defined                            */
        /*------------------------------------------------------------*/
        goto appl;
      }
      else if (IS_KEYWORD(fn)) {
        if (BUILTIN(fn)->fun == NULL)
          error1(ERR_C12_KEYWORD, fn);
        else {
          /*------------------------------------------------------------*/
          /* Compiler extension                                         */
          /*------------------------------------------------------------*/
          expr = ((nativeCompFct*)(BUILTIN(fn)->fun))(expr, names, code);
          if (expr != BLACK_HOLE)
            goto tailCall;
        }
      }
      else if (buildIn(fn, args, argl, names, code))
      {
      }
      else if (IS_ATOM(fn))
      {
        if ((la = location(fn,pMemGlobal->tlNames,false,&where))
             != VAR_NOT_FOUND)
        {
          temp4 = locVal(locate(pMemGlobal->tlVals,la));
          if (IS_MACRO(temp4))
          {
            /*--------------------------------------------------------*/
            /* macro application                                      */
            /*--------------------------------------------------------*/
            PROTECT(temp4)
            D = cons3(S,E,C,D);
            S = cons(cdr(temp4),list1(list1(expr)));
            E = pMemGlobal->tlVals;
            C = list2(MKINT(APC), MKINT(STOP));
            PROTECT(temp)
            /*--------------------------------------------------------*/
            /* don't allow macro expansion to be yielded by GC or     */
            /* output; instead abort on exceeding a maximum number    */
            /* of macro calls during a single compilation             */
            /*--------------------------------------------------------*/
            if (++macroCalls >= MAX_MACRO_PER_COMPILE)
              error1(ERR_C16_COMPLEX_MACRO,fn);
            evalMacro = true;
            temp = exec();
            evalMacro = false;
            if (stepsInSlice >= STEPS_PER_TIMESLICE)
              error1(ERR_C16_COMPLEX_MACRO,fn);
            S = car(D); E = cadr(D); C = caddr(D); D = cdddr(D);
            UNPROTECT(temp)
            UNPROTECT(temp4)
            expr = temp;
            goto tailCall;
          }
        }
        goto appl;
      }
      else
      {
        /*------------------------------------------------------------*/
        /* function application                                       */
        /*------------------------------------------------------------*/
      appl:
        if (*code == rtnCont)
          *code = list1(MKINT(TAPC));
        else
          *code = cons(MKINT(APC),*code);
        comp(fn,names,code);
        complist(args,names,code);
      }
    }
  }
}

/**********************************************************************/
/* Compile an SEXPR                                                   */
/**********************************************************************/
PTR compile(PTR expr, PTR names)
{
  PTR res = NIL;
  PTR src = NIL;
  Boolean eval = names != NIL;

  /*------------------------------------------------------------------*/
  /* Protect working registers                                        */
  /*------------------------------------------------------------------*/
  PROTECT(res)
  PROTECT(src)
  joinCont = list1(MKINT(JOIN));
  PROTECT(joinCont)
  rtnCont  = list1(MKINT(RTN));
  PROTECT(rtnCont)

  if (eval)
  {
    res = rtnCont;
    src = expr;
  }
  else
  {
    /*----------------------------------------------------------------*/
    /* Check for shadowing define and rewrite to set!                 */
    /*----------------------------------------------------------------*/
    if (LispMePrefs.rewriteDef && shadowingDefine(expr)) {
      W = NIL;
      addDefine(&W, cdr(expr), false);
      expr = cons(SET, car(W));
    }

    if (pMemGlobal->fileLoad)
    {
      if (!resolveDefineList(expr, &src))
        ErrThrow(ERR_L3_NOT_DEFINE);
    }
    else
    {
      if (resolveDefineList(expr, &src))
      {  
        /*------------------------------------------------------------*/
        /* an interactive definition is compiled, forget last memo    */
        /*------------------------------------------------------------*/
        pMemGlobal->fileLoad  = true;
        pMemGlobal->loadState = LS_INIT;
      }
      else
      {
        /*------------------------------------------------------------*/
        /* add (set! it) before expr. to be able to refer to last res.*/
        /*------------------------------------------------------------*/
        src = cons(SET,cons(IT,cons(expr,NIL)));
      }
    }
    res = cons(MKINT(STOP),NIL);
    names = pMemGlobal->tlNames;
  }
  qqNest     = 0;
  macroCalls = 0;
  if (pMemGlobal->fileLoad && !eval)
    pMemGlobal->newTopLevelNames = BLACK_HOLE; 
  comp(src, names, &res);
  if (pMemGlobal->fileLoad && !eval)
  {
    /*----------------------------------------------------------------*/
    /* We loaded a file, so cons the definitions from outermost       */
    /* letrec block in file to current top level environment          */
    /*----------------------------------------------------------------*/
    pMemGlobal->tlNames = cons(pMemGlobal->newTopLevelNames,
                               pMemGlobal->tlNames);
  }
  UNPROTECT(joinCont)
  UNPROTECT(rtnCont)
  UNPROTECT(src)
  UNPROTECT(res)
  return res;
}
