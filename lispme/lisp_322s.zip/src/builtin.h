/**********************************************************************/
/*                                                                    */
/* builtin.h: LISPME builtin                                          */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 12.08.2000 New                                                Hal  */
/* 03.01.2001 Integrated in 3.0                                  FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_BUILTIN_H
#define INC_BUILTIN_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "store.h"

/**********************************************************************/
/* Pointer to native LispMe function                                  */
/**********************************************************************/
typedef PTR (nativeFct)(PTR*);
typedef PTR (nativeVarFct)(int,PTR*);

/**********************************************************************/
/* Pointer to compiler function: (expr, names, code)                  */
/**********************************************************************/
typedef PTR (nativeCompFct)(PTR,PTR,PTR*);

/**********************************************************************/
/* Pointer to module init/exit function                               */
/**********************************************************************/
typedef void (moduleFct)(ModuleMessage);

/**********************************************************************/
/* Structure describing primitive LispMe functions or variables       */
/* - name: the name as a string, not store in symbol table!           */
/* - kind: the kind of the primitive                                  */
/* - stypes:                                                          */
/*    for functions, this is a string of stypes, length is arity      */
/*    for primitives this contains arity followed by the opcodes      */
/* - fun: pointer to function, NULL for primitives                    */
/* - doc: a documentation string                                      */
/*                                                                    */
/**********************************************************************/
typedef struct 
{
  char*      name;
  UInt8      kind;
  UInt8      stypes[5];
  nativeFct* fun;
  char*      doc;
} BuiltIn;

/**********************************************************************/
/* Hacks to fit variable arity and constant into opcode table         */
/* Normally, constants in the opcode table are integers and the MKINT */
/* macro will always be used. However, sometimes other constant are   */
/* needed ( '(), "" etc) which don't fit nicely into the 8 bit int    */
/* array used for the opcodes, so funny values are used to guide the  */
/* compiler into creating those constants                             */ 
/**********************************************************************/
#define EMPTY_LIST        57
#define EMPTY_STRING      69

/**********************************************************************/
/* Primitive operations                                               */
/**********************************************************************/
#define KIND_MODULE      255 /* module control function */
#define KIND_KEYWORD     254 /* may not be used as a variable */
#define KIND_SYMBOL      253 /* may be used as a variable */
#define KIND_PRIM12_OP   252 /* primitive with 1 or 2 args, different opcodes */
#define KIND_PRIM_LIST   251 /* primitive accumulating args in list */ 
#define KIND_PRIM_TRANS  250 /* primitive unary transcendental with minor opcode */ 

#define KIND_NATIVE      200 /* fixed nr. of args implemented by native C function */
#define KIND_NATIVE_VAR  150 /* var nr. of args implemented by native C function */
#define KIND_PRIM_DEF    100 /* primitive, var arity, default for last arg */
#define KIND_PRIM_FOLD    50 /* primitive, folding */ 
#define KIND_PRIMBASE      0 /* primitive, fixed arity */

/**********************************************************************/
/* Use the following macros to define primitives in your extension mod*/
/**********************************************************************/
/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), fixed arity                               */
/*--------------------------------------------------------------------*/
#define PRIM1(arity,op1,h)        KIND_PRIMBASE+arity, {op1,NOP}, NULL, h
#define PRIM2(arity,op1,op2,h)    KIND_PRIMBASE+arity, {op1,op2,NOP}, NULL, h
#define PRIM3(arity,op1,op2,op3,h)KIND_PRIMBASE+arity, {op1,op2,op3,NOP}, NULL, h

/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), one or two parameters with different opc  */
/*--------------------------------------------------------------------*/
#define PRIM12OP(op1,op2,h)       KIND_PRIM12_OP,      {op1,op2}, NULL, h

/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), all arguments in a list                   */
/*--------------------------------------------------------------------*/
#define PRIMLIST(op1,h)           KIND_PRIM_LIST,      {op1}, NULL, h

/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), folding operator                          */
/*--------------------------------------------------------------------*/
#define PRIMFOLD(arity,op,neutr,h)KIND_PRIM_FOLD+arity,{op,neutr}, NULL, h

/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), fixed arity, default for first parameter  */
/*--------------------------------------------------------------------*/
#define PRIMDEF(arity,op,def,h)   KIND_PRIM_DEF+arity, {op,def}, NULL, h

/*--------------------------------------------------------------------*/
/* Primitives (VM opcodes), transcendental functions                  */
/*--------------------------------------------------------------------*/
#define PRIMTRANS(minop,h)        KIND_PRIM_TRANS, {minop}, NULL, h

/*--------------------------------------------------------------------*/
/* A general type predicate                                           */
/*--------------------------------------------------------------------*/
#define PRIMTYPE(type) PRIM2(1, type, CTYP, "<any>")

/*--------------------------------------------------------------------*/
/* Native (C) functions, fixed arity, default help text               */
/*--------------------------------------------------------------------*/
#define NATIVE0(fn)               NATIVE0_H(fn,NULL)
#define NATIVE1(fn,t1)            NATIVE1_H(fn,t1,NULL)
#define NATIVE2(fn,t1,t2)         NATIVE2_H(fn,t1,t2,NULL)
#define NATIVE3(fn,t1,t2,t3)      NATIVE3_H(fn,t1,t2,t3,NULL)
#define NATIVE4(fn,t1,t2,t3,t4)   NATIVE4_H(fn,t1,t2,t3,t4,NULL)

/*--------------------------------------------------------------------*/
/* Native (C) functions, fixed arity, help text overrides default     */
/*--------------------------------------------------------------------*/
#define NATIVE0_H(fn,h)               KIND_NATIVE,   {},            fn, h
#define NATIVE1_H(fn,t1,h)            KIND_NATIVE+1, {t1},          fn, h
#define NATIVE2_H(fn,t1,t2,h)         KIND_NATIVE+2, {t1,t2},       fn, h
#define NATIVE3_H(fn,t1,t2,t3,h)      KIND_NATIVE+3, {t1,t2,t3},    fn, h
#define NATIVE4_H(fn,t1,t2,t3,t4,h)   KIND_NATIVE+4, {t1,t2,t3,t4}, fn, h

/*--------------------------------------------------------------------*/
/* Native (C) functions, variable arity, default help text            */
/*--------------------------------------------------------------------*/
#define NATIVEV0(fn)              NATIVEV0_H(fn,NULL)
#define NATIVEV1(fn,t1)           NATIVEV1_H(fn,t1,NULL)
#define NATIVEV2(fn,t1,t2)        NATIVEV2_H(fn,t1,t2,NULL)
#define NATIVEV3(fn,t1,t2,t3)     NATIVEV3_H(fn,t1,t2,t3,NULL)
#define NATIVEV4(fn,t1,t2,t3,t4)  NATIVEV4_H(fn,t1,t2,t3,t4,NULL)

/*--------------------------------------------------------------------*/
/* Native (C) functions, variable arity, help text overrides default  */
/*--------------------------------------------------------------------*/
#define NATIVEV0_H(fn,h)              KIND_NATIVE_VAR,   {},            (nativeFct*)fn, h
#define NATIVEV1_H(fn,t1,h)           KIND_NATIVE_VAR+1, {t1},          (nativeFct*)fn, h
#define NATIVEV2_H(fn,t1,t2,h)        KIND_NATIVE_VAR+2, {t1,t2},       (nativeFct*)fn, h
#define NATIVEV3_H(fn,t1,t2,t3,h)     KIND_NATIVE_VAR+3, {t1,t2,t3},    (nativeFct*)fn, h
#define NATIVEV4_H(fn,t1,t2,t3,t4,h)  KIND_NATIVE_VAR+4, {t1,t2,t3,t4}, (nativeFct*)fn, h

#define IS_NATIVE(kind) ((kind)>=KIND_NATIVE_VAR && (kind)<KIND_PRIM_TRANS)
#define IS_NATIVE_VAR(kind) ((kind)<KIND_NATIVE)
#define NATIVE_ARITY(kind) (kind-(IS_NATIVE_VAR(kind)?KIND_NATIVE_VAR:KIND_NATIVE))

/**********************************************************************/
/* For declaration of keywords and variables                          */
/**********************************************************************/
/*--------------------------------------------------------------------*/
/* Compiler extension for this keyword                                */
/*--------------------------------------------------------------------*/
#define BUILTINCOMPKEY(key,fun,h) {key, KIND_KEYWORD, {}, (nativeFct*)(fun), h}

/*--------------------------------------------------------------------*/
/* Keyword or symbol, no help text                                    */
/*--------------------------------------------------------------------*/
#define BUILTINKEYWORD(key)  BUILTINCOMPKEY(key,NULL,NULL)
#define BUILTINKEYWORDQ(key) BUILTINKEYWORD(#key)
#define BUILTINSYMBOL(sym)   {sym, KIND_SYMBOL, {}, NULL, NULL}
#define BUILTINSYMBOLQ(sym)  BUILTINSYMBOL(#sym)

/*--------------------------------------------------------------------*/
/* Keyword or symbol, with help text                                  */
/*--------------------------------------------------------------------*/
#define BUILTINSYMBOL_H(sym,h)   {sym, KIND_SYMBOL, {}, NULL, h}
#define BUILTINSYMBOLQ_H(sym,h)  BUILTINSYMBOL_H(#sym,h)
#define BUILTINKEYWORD_H(key,h)  BUILTINCOMPKEY(key,NULL,h)
#define BUILTINKEYWORDQ_H(key,h) BUILTINKEYWORD_H(#key,h)

/*--------------------------------------------------------------------*/
/* The module control functions (must be first entry in module table!)*/
/*--------------------------------------------------------------------*/
#define MODULE_FUNC(fn) {NULL,KIND_MODULE,{},(nativeFct*)(fn), NULL}

typedef BuiltIn BuiltInModule[];

#define MODULE(ptr)     (PRIMVAL1(ptr))
#define MODULEITEM(ptr) (PRIMVAL2(ptr))
#define BUILTIN(ptr)    ((builtins[MODULE(ptr)])+MODULEITEM(ptr))
#define IS_KEYWORD(ptr) (IS_PRIMSYM(ptr) && BUILTIN(ptr)->kind==KIND_KEYWORD)

extern BuiltIn *builtins[];

#define ADD_MOD(idx,bi) {builtins[idx]=bi; ++numMod;}

/**********************************************************************/
/* Creating and accessing global variables                            */
/**********************************************************************/
#define createGlobalVar(sym,val) \
      push(sym, car(pMemGlobal->tlNames));\
      push(val, car(pMemGlobal->tlVals))

#define symLoc(sym) \
      locate(pMemGlobal->tlVals,location(sym,pMemGlobal->tlNames,true,NULL))

#define locVal(loc) car(loc)


/**********************************************************************/
/* Types for primitive functions @@ty                                 */
/**********************************************************************/
#define tyINT       0 // any integer (small or big)
#define tyREAL      1 // a real number
#define tyNUMBER    2 // any number (including complex)
#define tyPAIR      3 // a pair (cons cell)
#define tyCHAR      4 // a character
#define tySTRING    5 // a string
#define tyVECTOR    6 // a vector
#define tySYMBOL    7 // a symbol (or primitive symbol)
#define tyINDEX     8 // a valid string or vector index 0 <= n < 2^14
#define tyLIST      9 // a pair or the empty list
#define tyCOL_IDX  10 // a color index 0 <= n < 256
#define tyBOOL     11 // a boolean #t or #f
#define tyPROPLIST 12 // a proper list (no cycles, ending with (), test expensive)
#define tySMALLINT 13 // a small integer
#define tyGUI_ID   14 // id of UI element

#define tyEOFOBJ   15 // the unique end-of-file object
#define tyNIL      16 // the empty list
#define tyNONE     17 // the non-printing object
#define tyPROC     18 // any callable object
#define tyCONT     19 // a continuation
#define tyPROMISE  20 // a recipe (promise)
#define tyMACRO    21 // a macro
#define tyANY      22 // any object

#define tyFOREIGN 32
#define FOREIGN(ftype) (tyFOREIGN+ftype)

/**********************************************************************/
/* typecheck macro                                                    */
/**********************************************************************/
#define TCHECK(ty,p) if(!hasType((ty),(p))) typeError((p),formatType(ty))
#define EXT_TCHECK(ty,p,fun,arg) \
  if(!hasType((ty),(p))) extTypeError((fun),(arg),(p),formatType(ty))

/**********************************************************************/
/* Exported variables                                                 */
/**********************************************************************/
extern PTR histCell;

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
void     initBuiltins()                                        SEC(MOD);
void     forAllModules(ModuleMessage msg, Boolean reverse)     SEC(MOD);
BuiltIn* getBuiltin(PTR p)                                     SEC(MOD);
char*    getName(PTR p)                                        SEC(MOD);
PTR      findName(char* s, Boolean create)                     SEC(MOD);
void     prefixBuiltins(char* prefix, UInt16 len,
                        UInt16* num, char** res)               SEC(MOD);
char*    completeBuiltins(char* prefix, UInt16 len,
                          Boolean forcep)                      SEC(MOD);
Boolean  hasType(UInt8 type, PTR val)                          SEC(VM); 
Boolean  isPrimitiveBuiltin(PTR p)                             SEC(VM);
PTR      callNative(PTR nat, int argc, PTR args)               SEC(VM);
char*    formatType(UInt8 type)                                SEC(MOD);
void     registerTypename(UInt8 ftype, char* name)             SEC(MOD);


/**********************************************************************/
/* Extensions                                                         */
/**********************************************************************/
#include "extend.h"
#endif
