/**********************************************************************/
/*                                                                    */
/* util.c:  LISPME utility functions needed everywhere                */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.01.1999 New                                                FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "util.h"
#include "LispMe.h"
#include "gui.h"
#include "io.h"

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
char* errInfo;
Int16 expectedLen;
extern Boolean launchedExternally;

/**********************************************************************/
/* Static data                                                        */
/**********************************************************************/
static char* errFunc;
static int   errArgNr;

/**********************************************************************/
/* ptr from ID                                                        */
/**********************************************************************/
void* ptrFromObjID(UInt16 obj)
{
  return FrmGetObjectPtr(FrmGetActiveForm(),
           FrmGetObjectIndex(FrmGetActiveForm(),obj));
}

static Boolean grabbed = false;

/**********************************************************************/
/* Convert a C string into LispMe string                              */
/**********************************************************************/
PTR str2Lisp(const char* cp)
{
  return copyString(StrLen(cp),cp);
}

/**********************************************************************/
/* build type error object                                            */
/**********************************************************************/
void typeError(PTR p, char* type) 
{
  errInfo = type;
  ErrThrow((((UInt32)p) << 16) | ERR_R1_WRONG_TYPE);
}

/**********************************************************************/
/* build type error object                                            */
/**********************************************************************/
void arityError(char* func, int arity) 
{
  errInfo = func;
  ErrThrow((((UInt32)(MKINT(arity))) << 16) | ERR_R11_WRONG_ARITY);
}

/**********************************************************************/
/* build extended type error object                                   */
/**********************************************************************/
void extTypeError(char* func, int argNr, PTR p, char* type) 
{
  errInfo = type;
  errFunc = func;
  errArgNr= argNr;
  ErrThrow((((UInt32)p) << 16) | ERR_R4_EXT_TYPE_ERROR);
}

/**********************************************************************/
/* build parm error object                                            */
/**********************************************************************/
void parmError(PTR p, char* func)
{
  errInfo = func;
  ErrThrow((((UInt32)p) << 16) | ERR_R15_INVALID_PARM);
}

/**********************************************************************/
/* length of a list                                                   */
/**********************************************************************/
short listLength(PTR l)
{
  short len = 0;
  PTR   p = l;
  while (IS_PAIR(p))
  {
    p = cdr(p);
    ++len;
  }
  if (p!=NIL)
    error1(ERR_C6_IMPROPER_ARGS, l);
  return len;
}

/**********************************************************************/
/* reverse a list                                                     */
/**********************************************************************/
PTR reverse(PTR list)
{
  PTR acc = NIL;
  PROTECT(acc)
  while (list != NIL) {
    if (!IS_PAIR(list))
      error1(ERR_C6_IMPROPER_ARGS,list);
    acc = cons(car(list),acc);
    list = cdr(list);
  }
  UNPROTECT(acc)
  return acc;
}

/**********************************************************************/
/* build error object include error resource and object               */
/**********************************************************************/
void error1(UInt16 err, PTR p)
{
  ErrThrow((((UInt32)p) << 16) | err);
}

/**********************************************************************/
/* Make a filename                                                    */
/**********************************************************************/
UInt16 makeFileName(PTR fileName)
{
  UInt16 nameLen;

  if (!IS_STRING(fileName))
    typeError(fileName,"string");
  printString(fileName);
  nameLen = StrLen(msg) + 1;
  if (nameLen > MAX_FILENAME_LEN)
  {
    msg[MAX_FILENAME_LEN]   = '\n';
    msg[MAX_FILENAME_LEN+1] = '\0';
    nameLen = MAX_FILENAME_LEN+2;
  }
  else
  {
    StrCat(msg,"\n");
    ++nameLen;
  }
  return nameLen;
}

/**********************************************************************/
/* Grab memory                                                        */
/**********************************************************************/
void GrabMem(void)
{
  if (useMSR && !grabbed)
  {
    MemSemaphoreReserve(true);
    grabbed = true;
  }
}

/**********************************************************************/
/* Release memory                                                     */
/**********************************************************************/
void ReleaseMem(void)
{
  if (useMSR && grabbed)
  {
    MemSemaphoreRelease(true);
    grabbed = false;
  }
}

/**********************************************************************/
/* Disable/enable command buttons during execution                    */
/**********************************************************************/
void enable(UInt16 id)
{
  CtlShowControl((ControlPtr)FrmGetObjectPtr(mainForm,
                 FrmGetObjectIndex(mainForm,id)));
}

void disable(UInt16 id)
{
  CtlHideControl((ControlPtr)FrmGetObjectPtr(mainForm,
                 FrmGetObjectIndex(mainForm,id)));
}

/**********************************************************************/
/* Disable/enable command buttons during execution                    */
/**********************************************************************/
void disableButtons(void)
{
  disable(IDC_PB_POP);
  disable(IDC_PB_LOAD);
  disable(IDC_PB_RELOAD);
  disable(IDC_PB_NAMES);
  disable(IDC_PB_ARGLIST);
  disable(IDC_PT_HIST);
  disable(IDC_PB_EVAL);
  if (!launchedExternally) 
    enable(IDC_PB_BREAK);
}

void enableButtons(void)
{
  disable(IDC_PB_BREAK);
  if (!launchedExternally) {
    enable(IDC_PB_POP);
    enable(IDC_PB_LOAD);
    enable(IDC_PB_RELOAD);
    enable(IDC_PB_NAMES);
    enable(IDC_PB_ARGLIST);
    enable(IDC_PT_HIST);
    enable(IDC_PB_EVAL);
  }
}

/**********************************************************************/
/* display error message                                              */
/**********************************************************************/
void displayError(UInt32 err)
{
  UInt16 resId = err & 0Xffff;
  PTR  obj     = err >> 16;
  static char msg1[64];
  static char msg2[7];

  /*------------------------------------------------------------------*/
  /* 1. Format message info string according to type                  */
  /*------------------------------------------------------------------*/
  if (resId == ERR_M2_INVALID_PTR ||
      resId == ERR_N1_NET_ERROR) 
  {
    StrIToH(msg,obj);
  }
  else if (resId == ERR_S1_INVALID_CHAR ||
           resId == ERR_S5_INVALID_DIGIT)
  {
    msg[0] = CHARVAL(obj);
    msg[1] = '\0';
  }
  else if (obj)
  {
    GrabMem();
    printSEXP(obj,
              resId == ERR_USER_ERROR ? 0 : PRT_ESCAPE,
              &portMsg);
  }
  else
    msg[0] = '\0';

  /*------------------------------------------------------------------*/
  /* MUST do this before calling UI functions!                        */
  /*------------------------------------------------------------------*/
  ReleaseMem();

  /*------------------------------------------------------------------*/
  /* 2. Display message according to type                             */
  /*------------------------------------------------------------------*/
  if (resId == ERR_R3_NUM_ARGS)
  {
    /*----------------------------------------------------------------*/
    /* Provide full parameter info in message                         */
    /*----------------------------------------------------------------*/
    if (expectedLen >= 0)
      StrIToA(msg1,expectedLen);
    else
    {
      StrCopy(msg1,"at least ");
      StrIToA(msg2,-expectedLen);
      StrCat(msg1,msg2);
    }
    StrIToA(msg2, listLength(obj));
    FrmCustomAlert(resId, msg1, msg2, msg);
  }
  else if (resId == ERR_R1_WRONG_TYPE    ||
           resId == ERR_R11_WRONG_ARITY  ||
           resId == ERR_R15_INVALID_PARM ||
           resId == ERR_U5_INVALID_KIND  ||
           resId == ERR_N1_NET_ERROR)
  {
    /*----------------------------------------------------------------*/
    /* Additonal error info has already been put in errInfo           */
    /*----------------------------------------------------------------*/
    FrmCustomAlert(resId, msg, errInfo, "");
  }
  else if (resId == ERR_R4_EXT_TYPE_ERROR)
  {
    /*----------------------------------------------------------------*/
    /* Extended type error, build complete message                    */
    /*----------------------------------------------------------------*/
    if (errArgNr == -1)
      StrCopy(msg1, "An argument");
    else {
      StrCopy(msg1, "Argument ");
      StrIToA(msg1+9, errArgNr+1);
    }
    StrCat(msg1, " of ");
    StrCat(msg1, errFunc);
    FrmCustomAlert(resId, msg1, errInfo, msg);
  }
  else if (resId >= ERR_S1_INVALID_CHAR && resId < ERR_C1_UNDEF)
  {
    /*----------------------------------------------------------------*/
    /* For syntax errors, add line number to message                  */
    /*----------------------------------------------------------------*/
    StrIToA(msg1, lineNr);
    FrmCustomAlert(resId, msg1, msg, "");
  }
  else
    FrmCustomAlert(resId, msg, "", "");
}

/**********************************************************************/
/* Disable/enable main form controls for GUI                          */
/**********************************************************************/
void enableCtls(Boolean enable)
{
  FldSetUsable(outField, enable);
  FldSetUsable(inField, enable);
  CtlSetUsable((ControlPtr)
    FrmGetObjectPtr(mainForm,
                    FrmGetObjectIndex(mainForm,IDC_PT_SYMS)),
    enable);
  CtlSetUsable((ControlPtr)
    FrmGetObjectPtr(mainForm,
                    FrmGetObjectIndex(mainForm,IDC_ST_SESSION)),
    enable);
  if (enable)
  {
    FrmEraseForm(mainForm);
    updateScrollBar();
    FrmUpdateForm(IDD_MainFrame, frmRedrawUpdateCode);
  }
  else
  {
    SclSetScrollBar(scrollBar, 0, 0, 0, 1);
    FldReleaseFocus(outField);
    FldReleaseFocus(inField);
  }
}

/**********************************************************************/
/* Update the scroll bar associated with a field                      */
/**********************************************************************/
void updateScrollBar(void)
{
  FieldPtr     field = ptrFromObjID(IDC_EF_OUTPUT);
  ScrollBarPtr sbar  = ptrFromObjID(IDC_SB_OUTPUT);
  UInt16       scrollPos;
  UInt16       textHeight;
  UInt16       fieldHeight;

  FldGetScrollValues(field, &scrollPos, &textHeight, &fieldHeight);
  if (textHeight > fieldHeight)
    SclSetScrollBar(sbar, scrollPos, 0,textHeight-fieldHeight, fieldHeight);
  else
    SclSetScrollBar(sbar, scrollPos,0, 0, fieldHeight);
}

/**********************************************************************/
/* Clean up after evaluation                                          */
/**********************************************************************/
void cleanUpEval(Boolean buttons)
{
  tickStop  = TimGetTicks();
  running   = false;
  GrabMem();
  pMemGlobal->waitEvent = false;
  pMemGlobal->getEvent  = false;

  /*------------------------------------------------------------------*/
  /* Cleanup in case name and value lists are out of sync             */
  /*------------------------------------------------------------------*/
  if (listLength(pMemGlobal->tlNames) > listLength(pMemGlobal->tlVals))
      pMemGlobal->tlNames = cdr(pMemGlobal->tlNames);
  ReleaseMem();
  if (buttons)
    enableButtons();
  actContext = -1;
}

/**********************************************************************/
/* prefix test                                                        */
/**********************************************************************/
Boolean prefixOf(char *prefix, UInt16 plen, char *s, UInt16 slen)
{
  int i;
  for (i=0;;i++) {
    if (i == plen || (! *prefix))
      return true;
    if (i == slen || (! *s))
      return false;
    if (caseSens) {
      if (prefix[i] != s[i])
        return false;
    }
    else
      if (StrNCaselessCompare(prefix+i, s+i, 1))
        return false;
  }
  return true;
}

/**********************************************************************/
/* Completion: resetCompletion, completeString1 and finishCompletion  */
/**********************************************************************/
static char* completion;
static int completed;

void resetCompletion()
{
  completion = NULL;
  completed = 0;
}

char* finishCompletion(UInt16 *res)
{
  *res = (completion != NULL ? completed : 0);
  return completion;
}

/**********************************************************************/
/* complete current completion against new string                     */
/**********************************************************************/
char* completeString1(char *prefix, UInt16 len, char *s, Boolean forcep)
{
  UInt16 n = StrLen(s), i;

  /* skip if input is not a prefix of current symbol */
  if (!prefixOf(prefix, len, s, n))
    return completion;

  /* if no current completion, set completion to current symbol */
  if (completion == NULL)
    i = n;
  /* test for empty completion, discard if forcep */
  else if (n == len && forcep)
    return completion;
  else
    /* find first non-matching character */
    for (i=len; i<min(completed, n); i++)
      if (completion[i] != s[i])
        break;
  /* note new (and smaller) completion */
  completed = i;
  return (completion = s);
}

/**********************************************************************/
/* Standard object pickling:                                          */
/* 1) Copy contents to DB record                                      */
/* 2) Delete obj from dynamic heap                                    */
/* 3) Replace pointer by record number                                */
/**********************************************************************/
void standardPickle(PTR ptr)
{
  UInt16 recNr = dmMaxRecordIndex; // important: create record at end of database
  UInt16 size  = MemPtrSize(FOREIGNVAL(ptr));
  MemHandle hd = DmNewRecord(dbRef, &recNr, size);

  DmWrite(MemHandleLock(hd), 0, FOREIGNVAL(ptr), size);
  MemPtrFree(FOREIGNVAL(ptr));
  MemHandleUnlock(hd);
  DmReleaseRecord(dbRef, recNr, true);
  SETFOREIGNVAL(ptr, recNr);
}

/**********************************************************************/
/* Standard object unpickling:                                        */
/* 1) Allocate dynamic heap                                           */
/* 2) Remove DB record                                                */
/* 3) Replace record number by pointer                                */
/**********************************************************************/
void standardUnpickle(PTR ptr)
{
  UInt16 recNr = (UInt32)FOREIGNVAL(ptr);
  MemHandle hd = DmQueryRecord(dbRef, recNr); 
  UInt16  size = MemHandleSize(hd);
  void*   mem  = MemPtrNew(size);

  SETFOREIGNVAL(ptr, mem);
  MemMove(mem, MemHandleLock(hd), size);
  MemHandleUnlock(hd);
  DmRemoveRecord(dbRef, recNr);
}
