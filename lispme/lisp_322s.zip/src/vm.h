/**********************************************************************/
/*                                                                    */
/* vm.h: LISPME Virtual Machine interface and opcode definitions      */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 14.06.1997 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_VM_H
#define INC_VM_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "store.h"

/**********************************************************************/
/* VM opcodes                                                         */
/**********************************************************************/
#define LDC    1 /* load constant                                     */
#define LDF    2 /* load function                                     */
#define AP     3 /* apply function                                    */
#define RTN    4 /* return from function                              */
#define DUM    5 /* create dummy environment                          */
#define RAP    6 /* recursively apply (letrec-block)                  */
#define SEL    7 /* select subcontrol list                            */
#define JOIN   8 /* join to main control list                         */
#define CAR    9 /* CAR of TOS object                                 */
#define CDR   10 /* CDR of TOS object                                 */
#define CONS  11 /* CONS of 2 TOS objects                             */
#define EQ    12 /* EQ of 2 TOS objects                               */
#define ADD   13 /* add 2 TOS objects                                 */
#define SUB   14 /* subtract 2 TOS objects                            */
#define MUL   15 /* multiply 2 TOS objects                            */
#define DIV   16 /* divide 2 TOS objects                              */
#define LEQ   17 /* <= of 2 TOS objects                               */
#define GEQ   18 /* >= of 2 TOS objects                               */
#define STOP  19 /* stop execution of VM                              */
#define NOT   20 /* not of TOS object                                 */
#define ST    21 /* store TOS to variable                             */
#define LDE   22 /* load expression (build recipe)                    */
#define AP0   23 /* apply parameterless function                      */
#define UPD   24 /* update recipe and return                          */
#define LDFC  25 /* load closure including number of args             */
#define APC   26 /* apply closure and check for number of args        */
#define LDCT  27 /* load continuation                                 */
#define SELR  28 /* select subcontrol without pushing rest            */
#define TAPC  29 /* tail-apply closure and check for number of args   */
#define POP   30 /* pop topmost stack object                          */
#define CERR  31 /* cond error, no true clause found                  */
#define SCAR  32 /* set CAR of TOS object                             */
#define SCDR  33 /* set CDR of TOS object                             */
#define EQV   34 /* EQV of 2 TOS objects                              */
#define TRAN  35 /* transcendental function of TOS, in minor opcode   */
#define ATAN  36 /* atan of TOS object                                */
#define ATN2  37 /* atan2 of 2 TOS objects                            */
#define SLEN  38 /* string-length                                     */
#define SREF  39 /* string-ref                                        */
#define SAPP  40 /* string-append                                     */
#define SSET  41 /* string-set!                                       */
#define C2I   42 /* char->integer                                     */
#define I2C   43 /* integer->char                                     */
#define O2S   44 /* object->string                                    */
#define S2O   45 /* string->object                                    */
#define EVT   46 /* event                                             */
#define VSET  47 /* vector-set!                                       */
#define VREF  48 /* vector-ref                                        */
#define VLEN  49 /* vector-length                                     */
#define L2V   50 /* list->vector                                      */
#define SEO   51 /* select subcontrol, don't pop if #t                */
#define SEOR  52 /* select subcontrol, don't pop if #t, don't push cdr*/
#define SEA   53 /* select subcontrol, don't pop if #f                */
#define SEAR  54 /* select subcontrol, don't pop if #f, don't push cdr*/
#define MEM   55 /* select subcontrol if TOS is in set                */
#define MEMR  56 /* select subcontrol if TOS is in set, don't push cdr*/
#define MKRA  57 /* make-rectangular                                  */
#define MKPO  58 /* make-polar                                        */
#define APY   59 /* apply closure and check for number of args,copy   */
#define TAPY  60 /* tail apply clos. and check for number of args,copy*/
#define APND  61 /* append 2 TOS items                                */
#define TAP   62 /* tail-apply let bindings                           */
#define RTAP  63 /* tail-apply letrec bindings                        */
#define LDM   64 /* load macro                                        */
#define GUI   65 /* own-gui                                           */
#define FRMD  66 /* frm-popup                                         */
#define FRMQ  67 /* frm-return                                        */
#define FRMG  68 /* frm-goto                                          */
#define LAND  69 /* bit-and                                           */
#define LIOR  70 /* bit-or                                            */
#define LXOR  71 /* bit-xor                                           */
#define LST   72 /* make a list out of n TOS values                   */
#define CXR   73 /* generalized c[ad]+r                               */
#define LNCH  74 /* launch                                            */
#define LC0   75 /* LDC 0                                             */
#define LC1   76 /* LDC 1                                             */
#define LC2   77 /* LDC 2                                             */
#define LC3   78 /* LDC 3                                             */
#define LC_1  79 /* LDC -1                                            */
#define LC_T  80 /* LDC #t                                            */
#define LC_F  81 /* LDC #f                                            */
#define LC_N  82 /* LDC NIL                                           */
#define LC_E  83 /* LDC ""                                            */
#define CANF  84 /* Call native function                              */
#define CANV  85 /* Call native function with variable arity          */
#define CTYP  86 /* generic type predicate                            */
#define LDG   87 /* load global                                       */
#define STG   88 /* store global                                      */
#define LDU   89 /* load global and update LEXADR by reference        */
#define STU   90 /* store global and update LEXADR by reference       */
#define DOLO  91 /* do loop                                           */
#define MST   92 /* multivariable set                                 */
#define EXEC  93 /* Call compiler extension to interpret              */

#define NOP 0xff /* marks end of code list in compiler tables         */

/**********************************************************************/
/* Minor opcodes for transcendental functions                         */
/**********************************************************************/
#define SQRT   1 /* sqrt of TOS object                                */
#define SIN    2 /* sin  of TOS object                                */
#define COS    3 /* cos  of TOS object                                */
#define TAN    4 /* tan  of TOS object                                */
#define ASIN   5 /* asin of TOS object                                */
#define ACOS   6 /* acos of TOS object                                */
#define EXP    7 /* exp  of TOS object                                */
#define LOG    8 /* log  of TOS object                                */
#define SINH   9 /* sinh  of TOS object                               */
#define COSH  10 /* cosh  of TOS object                               */
#define TANH  11 /* tanh  of TOS object                               */
#define ASIH  12 /* asinh of TOS object                               */
#define ACOH  13 /* acosh of TOS object                               */
#define ATAH  14 /* atanh of TOS object                               */
#define FLOR  15 /* floor of TOS object                               */
#define CEIL  16 /* ceil of TOS object                                */
#define TRUN  17 /* trunc of TOS object                               */
#define ROUN  18 /* round of TOS object                               */

/**********************************************************************/
/* VM opcode structure                                                */
/**********************************************************************/
#define OPBITS  7   /* number of bits used for opcode */
#define MINOPBITS 6 /* number of bits available for minor opcode */
#define OPMASK ((1 << (OPBITS)) - 1)
#define MKMINOP(major,minor) ((major) | ((minor) << OPBITS))
#define MAJOP(op) ((op) & OPMASK)
#define MINOP(op) ((op) >> (OPBITS))
#define FITSMINOP(v) (v < (1 << (MINOPBITS)))

/**********************************************************************/
/* cxr codes                                                          */
/**********************************************************************/
#define CXXR  1 
#define CXAR  2
#define CXDR  3
#define CXAAR 4
#define CXADR 5
#define CXDAR 6
#define CXDDR 7

/**********************************************************************/
/* Defines                                                            */
/**********************************************************************/
#define STEPS_PER_TIMESLICE   1600
#define YIELD() if (!evalMacro) stepsInSlice = STEPS_PER_TIMESLICE

/**********************************************************************/
/* EQV comparison for foreign types                                   */
/**********************************************************************/
typedef Boolean (*eqvType)(void*, void*);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern int     stepsInSlice;
extern Boolean evalMacro;

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
PTR     exec(void)                                              SEC(VM);
PTR     locate(PTR loc, LEXADR adr)                             SEC(VM);
Boolean eqv(PTR a, PTR b)                                       SEC(VM);
void    registerEQV(UInt8 ftype, eqvType fp)                    SEC(VM);

#endif
