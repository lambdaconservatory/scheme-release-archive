/**********************************************************************/
/*                                                                    */
/* lists.c: LISPME list handling functions                            */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 05.05.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "lists.h"
#include "vm.h"
#include "util.h"
#include "arith.h"
#include "LispMe.h"

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static Boolean eq(PTR a, PTR b)                                 SEC(VM);
static Boolean vecEqual(PTR a, PTR b)                           SEC(VM);
static PTR     nativeLength(PTR* args)                          SEC(VM);
static PTR     nativeEqual(PTR* args)                           SEC(VM);
static PTR     nativeListRef(PTR* args)                         SEC(VM);
static PTR     nativeListTail(PTR* args)                        SEC(VM);
static PTR     nativeListAsterix(int argc, PTR* args)           SEC(VM);
static PTR     nativeReverse(PTR* args)                         SEC(VM);

static PTR     nativeMember(PTR* args)                          SEC(VM);
static PTR     nativeMemV(PTR* args)                            SEC(VM);
static PTR     nativeMemQ(PTR* args)                            SEC(VM);
static PTR     nativeAssoc(PTR* args)                           SEC(VM);
static PTR     nativeAssV(PTR* args)                            SEC(VM);
static PTR     nativeAssQ(PTR* args)                            SEC(VM);
static PTR     nativeRassoc(PTR* args)                          SEC(VM);
static PTR     nativeRassV(PTR* args)                           SEC(VM);
static PTR     nativeRassQ(PTR* args)                           SEC(VM);
static PTR     nativePosition(PTR* args)                        SEC(VM);
static PTR     nativePosV(PTR* args)                            SEC(VM);
static PTR     nativePosQ(PTR* args)                            SEC(VM);

static PTR     nativeMakeString(PTR* args)                      SEC(VM);
static PTR     nativeMakeVector(PTR* args)                      SEC(VM);
static PTR     nativeVector2List(PTR* args)                     SEC(VM); 
static PTR     nativeString2List(PTR* args)                     SEC(VM); 
static PTR     nativeList2String(PTR* args)                     SEC(VM); 

static PTR     nativeStringTok(PTR* args)                       SEC(VM);
static PTR     nativeSubstring(PTR* args)                       SEC(VM);

/**********************************************************************/
/* Generalised car/cdr sequence encoded as bits                       */
/**********************************************************************/
PTR cxr(PTR l, UInt16 bits)
{
  PTR p = l;
  while (bits > 1) {
    if (!IS_PAIR(p))
      extTypeError("cxr",0,l,"tree");
    p = (bits & 1 ? cdr(p) : car(p));
    bits >>= 1;
  }
  return p;
}

/**********************************************************************/
/* Has the list a circle or is the last cdr not the empty list?       */
/**********************************************************************/
Boolean improperListP(PTR l, Boolean nilEnding)
{
  PTR aux = l;
  while (IS_PAIR(l)) {
    l = cdr(l);
    if (IS_PAIR(aux)) {
      aux = cdr(aux);
      if (IS_PAIR(aux)) {
        aux = cdr(aux);
        if (aux==l)
          return true;
      }
    }   
  }
  return nilEnding && l!=NIL;
}

/**********************************************************************/
/* nth: step n times, return val                                      */
/**********************************************************************/
static PTR nth(PTR l, int nc, Int16 val)
{
  while (--nc >= 0)
    if (IS_PAIR(l))
      l = cdr(l);
    else
      extTypeError("nth", 0, l, "pair");
  return cxr(l, val);
}

/**********************************************************************/
/* Generalised find, which supports circular lists                    */
/* The trick is to take double steps with an aux variable,            */
/* e.g. by the cddr, and see if you catch up with the                 */
/* normal iteration variable                                          */
/**********************************************************************/
PTR find(PTR l, PTR p, Int16 step, Int16 from, Int16 to, PTR def,
         Boolean (*comp)(PTR, PTR))
{
  PTR orig = l, aux = l;
  UInt16 n = 0;
  for (; IS_PAIR(l); l = cxr(l, step)) {
    if (comp(cxr(l, from), p))
      // when to == from return position
      return(to == from ? MKINT(n) : cxr(l, to));
    if (IS_PAIR(aux)) {
      aux = cxr(aux, step);
      if (IS_PAIR(aux))
        if ((aux = cxr(aux, step)) == l)
          extTypeError("general find", 0, orig, "proper list");
    }
    n++;
  }
  if (l != NIL)
    extTypeError("general find", 0, orig, "proper list");
  return def;
}

/**********************************************************************/
/* Identity                                                           */
/**********************************************************************/
static Boolean eq(PTR a, PTR b)
{
  return a==b;
}

/**********************************************************************/
/* Generalised equal?, which supports circular lists                  */
/* The trick is to take double steps with an aux variable,            */
/* e.g. by the cddr, and see if you catch up with the                 */
/* normal iteration variable                                          */
/**********************************************************************/
Boolean equal(PTR a, PTR b)
{
  CHECKSTACK(a);

  if (eqv(a,b)) return true;
  else if (IS_STRING(a) && IS_STRING(b)) return strComp(a,b) == 0;
  else if (IS_PAIR(a) && IS_PAIR(b)) {
    if (improperListP(a,false))
      error1(ERR_R20_IMPROPER_TREE, a);
    if (improperListP(b,false))
      error1(ERR_R20_IMPROPER_TREE, b);
    while (IS_PAIR(a) && IS_PAIR(b)) {
      if (!equal(car(a),car(b))) return false;
      a=cdr(a); b=cdr(b); 
    }
    return equal(a,b);
  }
  else if (IS_VEC(a) && IS_VEC(b)) {
    /* both a and b #() already handled in eqv() */
    if (a==EMPTY_VEC || b==EMPTY_VEC) return false;
    else return vecEqual(a,b); 
  }
  else return false;
}

static Boolean vecEqual(PTR a, PTR b)
{
  /*------------------------------------------------------------------*/
  /* Problem: When a vector contains itself (vector-set! v n v), the  */
  /* memory handle gets locked more than 16 times (maximum lock count)*/
  /* which is less than the recursion depth limit allows. There seems */
  /* to be no legal way to query the lock count of a handle???        */
  /*------------------------------------------------------------------*/
  MemHandle h1, h2;
  UInt16    l;
  PTR       *pel1, *pel2;
  Boolean   res = true;
  CHECKSTACK(h1);

  h1 = DmQueryRecord(dbRef,ARR_INDEX(a));
  h2 = DmQueryRecord(dbRef,ARR_INDEX(b));
  if ((l=ArrayHandleSize(h1)) != ArrayHandleSize(h2))
    return false;
  pel1 = (PTR*)ArrayHandleLock(h1); 
  pel2 = (PTR*)ArrayHandleLock(h2);
  l >>= 1;
  while (l--)
    if (!equal(pel1[l], pel2[l])) {
      res = false;
      break;
    }
  ArrayHandleUnlock(h1);
  ArrayHandleUnlock(h2);
  return res;
}

/**********************************************************************/
/* list*: copy n-1 args, using nth arg as tail                        */
/**********************************************************************/
static PTR nativeListAsterix(int argc, PTR* args)
{
  PTR  res = NIL;
  PTR* d   = &res;
  while (--argc > 0) {
    *d = cons(car(args[0]), NIL);
    d = &cdr(*d);
    args[0] = cdr(args[0]);
  }
  *d = car(args[0]);
  return res;
}

/**********************************************************************/
/* Reverse a list                                                     */
/**********************************************************************/
static PTR nativeReverse(PTR* args)
{
  return reverse(args[0]);
}

/**********************************************************************/
/* Length of a list                                                   */
/**********************************************************************/
static PTR nativeLength(PTR* args)
{
  return makeNum(listLength(args[0]));
}

static PTR nativeCircular(PTR* args)
{ return improperListP(args[0],false) ? TRUE : FALSE;}

static PTR nativeEqual(PTR* args)
{ return equal(args[0], args[1]) ? TRUE : FALSE;}

/**********************************************************************/
/* List access                                                        */
/**********************************************************************/
static PTR nativeListRef(PTR* args)
{ return nth(args[0], getInt16(args[1]), CXAR);}

static PTR nativeListTail(PTR* args)
{ return nth(args[0], getInt16(args[1]), CXXR);}

/**********************************************************************/
/* Association lists                                                  */
/**********************************************************************/
static PTR nativeMember(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXXR, FALSE, equal);}
static PTR nativeMemV(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXXR, FALSE, eqv);}
static PTR nativeMemQ(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXXR, FALSE, eq);}

static PTR nativeAssoc(PTR* args)
{ return find(args[1], args[0], CXDR, CXAAR, CXAR, FALSE, equal);}
static PTR nativeAssV(PTR* args)
{ return find(args[1], args[0], CXDR, CXAAR, CXAR, FALSE, eqv);}
static PTR nativeAssQ(PTR* args)
{ return find(args[1], args[0], CXDR, CXAAR, CXAR, FALSE, eq);}

static PTR nativeRassoc(PTR* args)
{ return find(args[1], args[0], CXDR, CXDAR, CXAR, FALSE, equal);}
static PTR nativeRassV(PTR* args)
{ return find(args[1], args[0], CXDR, CXDAR, CXAR, FALSE, eqv);}
static PTR nativeRassQ(PTR* args)
{ return find(args[1], args[0], CXDR, CXDAR, CXAR, FALSE, eq);}

static PTR nativePosition(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXAR, FALSE, equal);}
static PTR nativePosV(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXAR, FALSE, eqv);}
static PTR nativePosQ(PTR* args)
{ return find(args[1], args[0], CXDR, CXAR, CXAR, FALSE, eq);}

/**********************************************************************/
/* Create a string                                                    */
/**********************************************************************/
static PTR nativeMakeString(PTR* args)
{
  return makeString(getUInt16(args[0]), NULL, 0, (char*)1, args[1]);
}

/**********************************************************************/
/* Create a vector                                                    */
/**********************************************************************/
static PTR nativeMakeVector(PTR* args)
{
  return makeVector(getUInt16(args[0]), args[1], false);
}

/**********************************************************************/
/* Convert a string to list of characters                             */
/**********************************************************************/
static PTR nativeString2List(PTR* args)
{
  return string2List(args[0]);
}

/**********************************************************************/
/* Convert a list of characters to a string                           */
/**********************************************************************/
static PTR nativeList2String(PTR* args)
{
  return makeString(listLength(args[0]), NULL, 0, NULL, args[0]);
}

/**********************************************************************/
/* Convert a vector to a list                                         */
/**********************************************************************/
static PTR nativeVector2List(PTR* args)
{
  return vector2List(args[0]);
}

/**********************************************************************/
/* Tokenize string                                                    */
/**********************************************************************/
static PTR nativeStringTok(PTR* args)
{
  PTR  res = NIL;
  PTR* d = &res;
  static MemHandle h1,h2;
  static char      *p1,*p2;
  static UInt16    i,j,l=0,n1,n2;
  static Boolean   skip = true;

  if (args[0] == EMPTY_STR)
    return NIL;
  if (args[1] == EMPTY_STR)
    return list1(args[0]);
  
  PROTECT(res);
  h1 = DmQueryRecord(dbRef, ARR_INDEX(args[0]));
  h2 = DmQueryRecord(dbRef, ARR_INDEX(args[1]));
  p1 = ArrayHandleLock(h1);
  p2 = ArrayHandleLock(h2);
  n1 = ArrayHandleSize(h1);
  n2 = ArrayHandleSize(h2);
  for (i=0;i<=n1;++i) {
    for (j=0;j<n2;++j)
      if (p1[i] == p2[j])
        break;
    if (j<n2 || i==n1) /* delimiter found or end of first string */ {
      if (!skip) {
        *d = list1(copyString(i-l,p1+l));
        d = &cdr(*d);
        skip = true;
      }   
    }
    else {
      if (skip)
        l = i; 
      skip = false;
    }  
  } 
  ArrayHandleUnlock(h2);
  ArrayHandleUnlock(h1);
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Convert string to lower case (there's no upper case fun. in SDK??) */
/**********************************************************************/
static PTR nativeStringLower(PTR* args)
{
  PTR  res = NIL;
  char nul = '\0';
  static MemHandle h;
  static char *p;
  PTR  cs  = appendStrings(args[0],copyString(1,&nul));
  h = DmQueryRecord(dbRef, ARR_INDEX(cs));
  p = ArrayHandleLock(h);
  StrToLower(p,p);
  res = str2Lisp(p);
  ArrayHandleUnlock(h);
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Extract substring                                                  */
/**********************************************************************/
static PTR nativeSubstring(PTR* args)
{
  return substring(args[0], getUInt16(args[1]), getUInt16(args[2]));
}

/**********************************************************************/
/* Are strings equal?                                                 */
/**********************************************************************/
static PTR nativeStringEq(PTR* args)
{
  return strComp(args[0], args[1]) == 0 ? TRUE : FALSE;
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule listBuiltins = 
{
  MODULE_FUNC(NULL),
  {"append",           PRIMFOLD(0, APND, EMPTY_LIST, "<list>*")},
  {"car",              PRIM1(1, CAR,                 "<pair>")},
  {"cdr",              PRIM1(1, CDR,                 "<pair>")},
  {"cons",             PRIM1(2, CONS,                "<any> <any>")},
  {"set-car!",         PRIM1(2, SCAR,                "<pair> <any>" )},
  {"set-cdr!",         PRIM1(2, SCDR,                "<pair> <any>")},
  {"list",             PRIMLIST(NOP,                 "<any>*")},
  {"list-ref",         NATIVE2(nativeListRef, tyLIST, tyINT)},
  {"list-tail",        NATIVE2(nativeListTail, tyLIST, tyINT)},
  {"list*",            NATIVEV0(nativeListAsterix)},
  {"list?",            PRIM2(1, tyPROPLIST, CTYP,    "<any>")}, 

  {"reverse",          NATIVE1(nativeReverse, tyPROPLIST)},
  {"length",           NATIVE1(nativeLength,  tyPROPLIST)},
  {"circular?",        NATIVE1(nativeCircular,tyANY)},
  {"equal?",           NATIVE2(nativeEqual,   tyANY, tyANY)},
  {"member",           NATIVE2(nativeMember,  tyANY, tyLIST)},
  {"memv",             NATIVE2(nativeMemV,    tyANY, tyLIST)},
  {"memq",             NATIVE2(nativeMemQ,    tyANY, tyLIST)},
  {"assoc",            NATIVE2(nativeAssoc,   tyANY, tyLIST)},
  {"assv",             NATIVE2(nativeAssV,    tyANY, tyLIST)},
  {"assq",             NATIVE2(nativeAssQ,    tyANY, tyLIST)},
  {"rassoc",           NATIVE2(nativeRassoc,  tyANY, tyLIST)},
  {"rassv",            NATIVE2(nativeRassV,   tyANY, tyLIST)},
  {"rassq",            NATIVE2(nativeRassQ,   tyANY, tyLIST)},
  {"position",         NATIVE2(nativePosition,tyANY, tyLIST)},
  {"posv",             NATIVE2(nativePosV,    tyANY, tyLIST)},
  {"posq",             NATIVE2(nativePosQ,    tyANY, tyLIST)},

  {NULL}
};

BuiltInModule vecStrBuiltins = 
{
  MODULE_FUNC(NULL),
  {"vector",           PRIMLIST(L2V,                   "<any>*")},
  {"string-append",    PRIMFOLD(0, SAPP, EMPTY_STRING, "<string>*")},
  {"string-length",    PRIM1(1, SLEN,                  "<string>")},
  {"string->list",     NATIVE1(nativeString2List, tySTRING)},
  {"list->string",     NATIVE1(nativeList2String, tyPROPLIST)},
  {"vector->list",     NATIVE1(nativeVector2List, tyVECTOR)},
  {"list->vector",     PRIM1(1, L2V,  "<proper list>")},
  {"vector-length",    PRIM1(1, VLEN, "<vector>")},
  {"string-ref",       PRIM1(2, SREF, "<string> <index>")},
  {"string=?",         NATIVE2(nativeStringEq, tySTRING, tySTRING)},
  {"vector-ref",       PRIM1(2, VREF, "<vector> <index>")},
  {"make-vector",      NATIVE2(nativeMakeVector, tyINDEX, tyANY)},
  {"make-string",      NATIVE2(nativeMakeString, tyINDEX, tyCHAR)},
  {"string-set!",      PRIM1(3, SSET, "<string> <index> <char>")},
  {"vector-set!",      PRIM1(3, VSET, "<vector> <index> <any>")},
  {"substring",        NATIVE3(nativeSubstring, tySTRING, tyINDEX, tyINDEX)},
  {"object->string",   PRIM1(1, O2S,  "<any>")},
  {"string->object",   PRIM1(1, S2O,  "<string>")},
  {"string-tokenize",  NATIVE2(nativeStringTok, tySTRING, tySTRING)},
  {"string-lower",     NATIVE1(nativeStringLower, tySTRING)},

  {NULL}
};

