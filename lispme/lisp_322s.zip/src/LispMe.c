/**********************************************************************/
/*                                                                    */
/* LispMe.c: Entire program                                           */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 27.07.1997 New                                                FBI  */
/* 02.08.1997 Combined all sorce modules, as linker fucks up!!   FBI  */
/* 09.10.1997 PalmOS2 only version                               FBI  */
/* 01.03.1998 Use DB mem as heap via MemSemaphoreReserve()       FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 21.11.1999 'Reload' button added                              FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include "LispMe.h"
#include "io.h"
#include "vm.h"
#include "comp.h"
#include "util.h"
#include "sess.h"
#include "setup.h"
#include "builtin.h"
#include "lists.h"
#include "ParHack.h"
#include "callback.h"

/**********************************************************************/
/* local defines                                                      */
/**********************************************************************/
#define MAX_LINE_LEN 32
#define OUTPUT_LINES  8
#define AUTOSELREL    1 // 1 = next file , 0 = current file

/*--------------------------------------------------------------------*/
/* Size of the internal editor                                        */
/*--------------------------------------------------------------------*/
#define BIG_EDIT 32768 
#define STD_EDIT  4096

/**********************************************************************/
/* predeclare static functions                                        */
/**********************************************************************/
static Boolean appHandleEvent(EventType*);
static Boolean MainFrameHandleEvent(EventType*);
static Boolean LoadHandleEvent(EventType*);
static Boolean EditFrameHandleEvent(EventType*);
static Boolean ParHackHandleEvent(EventType* e);
static Boolean StartApp(char*);
static void    StopApp(void);
static void    showArgList(FieldPtr field, Boolean clearp)     SEC(GUI);
static void    makeStandalone(void);
static void    cleanUpEditFrame(DmOpenRef srcRef, UInt16 recNr);

/**********************************************************************/
/* predeclare global functions                                        */
/**********************************************************************/
void    handleScrollEvents(EventType* e);

/**********************************************************************/
/* External   global functions                                        */
/**********************************************************************/
extern Boolean internFldHandleEvent(FieldPtr field, EventPtr event);

/**********************************************************************/
/* global data                                                        */
/**********************************************************************/
DmOpenRef dbRef;
struct MemGlobal* pMemGlobal;
PTR       S,E,C,D,W;
PTR       firstFree;
char*     carHeap;
char*     cdrHeap;
char*     strStore;

Int32     heapSize;
Int32     heapLimit;
Int32     atomSize;
char*     markBit;
MemHandle realHandle;
Int32     realSize;
char*     reals;
char*     markRealBit;
PTR       firstFreeReal;

Int32  numGC;
Int32  numStep;
UInt32 tickStart;
UInt32 tickStop;

short    depth;              /* stack depth for printing or GC */
Boolean  running;
Boolean  quitHandler;
Boolean  changeHandler;
Boolean  launchedExternally = true;
Boolean  palmOS5; 
Boolean  parHackActive;
Boolean  useMSR; 


MemHandle    outHandle;
MemHandle    inHandle;
FieldPtr     inField;
FieldPtr     outField;
FormPtr      mainForm;
ScrollBarPtr scrollBar;

struct LispMeGlobPrefs LispMePrefs;

/**********************************************************************/
/* static data                                                        */
/**********************************************************************/
static UInt16    selMemo;

static LocalID   memoPadID = NULL;
static LocalID   peditID   = NULL;
static LocalID   pedit32ID = NULL;

/**********************************************************************/
/* Add expression to history list                                     */
/**********************************************************************/
static void addHistory(PTR form)
{
  int i;
  PTR p;

  /*------------------------------------------------------------------*/
  /* Check for equal? entry already in history list                   */
  /*------------------------------------------------------------------*/
  p = locVal(histCell);
  for (i=0; i<HIST_SIZE; ++i) {
    if (IS_PAIR(p)) {
      ErrTry {
        if (equal(car(p),form))
          return;
      } ErrCatch(err) {
        // ignore errors in equal?
      } ErrEndCatch;
      p = cdr(p);
    }  
  }

  /*------------------------------------------------------------------*/
  /* Add it to the front and shift out earliest entry                 */
  /*------------------------------------------------------------------*/
  push(form, locVal(histCell));
  p = locVal(histCell);
  for (i=1; i<HIST_SIZE; ++i)
    if (IS_PAIR(p))
      p = cdr(p);
    else
      return;
  if (IS_PAIR(p))
    cdr(p) = NIL;
}

/**********************************************************************/
/* Get expression from history list                                   */
/**********************************************************************/
static PTR getHistory(int n)
{
  int i;
  PTR p;

  for (i=0, p=locVal(histCell); i<HIST_SIZE; ++i)
    if (IS_PAIR(p))
      if (i==n)
        return car(p);
      else
        p=cdr(p);
    else
      break;
  return NOPRINT;   
}

/**********************************************************************/
/* Get expression as string from history list                         */
/**********************************************************************/
static Boolean getHistoryStr(int n)
{
  int i;
  PTR p;

  for (i=0, p=locVal(histCell); i<HIST_SIZE; ++i)
    if (IS_PAIR(p))
      if (i==n) {
        printSEXP(car(p), PRT_ESCAPE, &portMsg);
        return true;
      }
      else
        p=cdr(p);
    else
      break;
  return false;
}

/**********************************************************************/
/* Check for an application with given creator                        */
/**********************************************************************/
static LocalID findApp(UInt32 creator)
{
  DmSearchStateType sState;
  UInt16            card;
  LocalID           dbID;
  return DmGetNextDatabaseByTypeCreator(true, &sState, sysFileTApplication,
           creator, true, &card, &dbID) == errNone
         ? dbID : NULL;              
}

/**********************************************************************/
/* Switch to MemoPad or pedit to edit record (on error position)      */
/**********************************************************************/
static void startMemoPad(UInt16 recNum, Boolean usePedit, Boolean memo32)
{
  GoToParamsPtr     goPtr;

  goPtr = MemPtrNew(sizeof(GoToParamsType));
  MemPtrSetOwner(goPtr, 0);
  goPtr->searchStrLen  = !usePedit && startPtr ? 1 : 0;
  goPtr->dbCardNo      = 0;
  goPtr->dbID          = memo32 ? memo32Id : memoId;
  goPtr->recordNum     = recNum;
  goPtr->matchPos      = startPtr ? currPtr-startPtr-1 : 0;
  goPtr->matchFieldNum = 0;
  goPtr->matchCustom   = startPtr ? 1 : 0;

  if (usePedit)
    goPtr->matchCustom |= memo32 ? 0x20680000L : 0x19480000L;

  SysUIAppSwitch(0, usePedit ? (memo32 ? pedit32ID : peditID) : memoPadID,
                 sysAppLaunchCmdGoTo, (MemPtr)goPtr);
}

/**********************************************************************/
/* Main entry                                                         */
/**********************************************************************/
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
  EventType e;
  short err;

  switch (cmd)
  {
    case sysAppLaunchCmdNormalLaunch:
      cmdPBP = NULL;
      launchedExternally = false;

    case sysAppLaunchCmdCustomBase:
      if (!StartApp((char*)cmdPBP))
        return 0;

      /*--------------------------------------------------------------*/
      /* Determine stack limit                                        */
      /*--------------------------------------------------------------*/
      stackLimit = (char*)&e - OS3_STACK_AVAIL;
      FrmGotoForm(startPanel);

      /*--------------------------------------------------------------*/
      /* Main event handling loop                                     */
      /*--------------------------------------------------------------*/
      do {
        EvtGetEvent(&e, actContext>=0 ? contexts[actContext].timeout :
                        running       ? 0 : -1);
        if (actContext>=0 && e.eType == nilEvent) {
          /*----------------------------------------------------------*/
          /* Let LispMe UI handler see nilEvents (e.g. for animations)*/
          /*----------------------------------------------------------*/
          FrmDispatchEvent(&e);
          continue;
        }
        /*------------------------------------------------------------*/
        /* Must check ParHack events BEFORE the system event handler  */
        /*------------------------------------------------------------*/
        if (!ParHackHandleEvent(&e))
          if (!SysHandleEvent(&e))
            if (!MenuHandleEvent(0, &e, &err))
              if (!appHandleEvent(&e))
                FrmDispatchEvent(&e);
      } while (e.eType != appStopEvent);
      StopApp();
  }
  return 0;
}

/**********************************************************************/
/* Parentheses Hack event handling                                    */
/**********************************************************************/
static Boolean ParHackHandleEvent(EventType* e)
{
  FormPtr form;
  UInt16  idx;
  if (!parHackActive &&
      LispMePrefs.matchParens &&
      e->eType == keyDownEvent &&
      (idx=FrmGetFocus(form=FrmGetActiveForm())) != noFocus &&
      FrmGetObjectType(form,idx) == frmFieldObj)
        return internFldHandleEvent(FrmGetObjectPtr(form,idx),e);
  return false;
}

/**********************************************************************/
/* Application event handling                                         */
/**********************************************************************/
static Boolean appHandleEvent(EventType* e)
{
  if (e->eType == frmLoadEvent)
  {
    Int16   formId = e->data.frmLoad.formID;
    FormPtr form   = FrmInitForm(formId);
    FrmSetActiveForm(form);

    switch(formId)
    {
      case IDD_MainFrame:
        FrmSetEventHandler(form, MainFrameHandleEvent);
        break;

      case IDD_Edit:
        FrmSetEventHandler(form, EditFrameHandleEvent);
        break;

      case IDD_SetupGlob:
        FrmSetEventHandler(form, SetupGlobHandleEvent);
        break;

      case IDD_SetupSess:
        FrmSetEventHandler(form, SetupSessHandleEvent);
        break;

      case IDD_Load:
        FrmSetEventHandler(form, LoadHandleEvent);
        break;

      case IDD_Sess:
        FrmSetEventHandler(form, SessHandleEvent);
        break;

      case IDD_NewSess:
        FrmSetEventHandler(form, NewSessHandleEvent);
        break;

      default:
        /*------------------------------------------------------------*/
        /* This is an ext.form, use special handler for Lisp callback */
        /* The LispMe handler function has already been installed     */
        /*------------------------------------------------------------*/
        returning = false;
        FrmSetEventHandler(form, LispHandleEvent);
        break;
    }
    return true;
  }
  return false;
}

/**********************************************************************/
/* Handle all events dealing with scrollbar/entryfield sync           */
/**********************************************************************/
void handleScrollEvents(EventType* e)
{
  FieldPtr fld;
  Int16    lines;
  switch (e->eType)
  {
    case keyDownEvent:
    {
      fld   = ptrFromObjID(IDC_EF_OUTPUT);
      lines = FldGetVisibleLines(fld)-1;
      switch (e->data.keyDown.chr)
      {
        case pageUpChr:
          if (FldScrollable(fld, winUp))
            FldScrollField(fld, lines, winUp);
          break;

        case pageDownChr:
          if (FldScrollable(fld, winDown))
            FldScrollField(fld, lines, winDown);
          break;
      }
      updateScrollBar();
      break;
    }
    case sclRepeatEvent:
    {
      fld   = ptrFromObjID(IDC_EF_OUTPUT);
      lines = e->data.sclRepeat.newValue-e->data.sclRepeat.value;
      if (lines > 0)
        FldScrollField(fld, lines, winDown);
      else
        FldScrollField(fld, -lines, winUp);
      break;
    }

    case fldChangedEvent:
      updateScrollBar();
      break;
    default:
  }
}

/**********************************************************************/
/* Set all up for an evaluation                                       */
/* n == 0: wrap (BEGIN ...) around expressions                        */
/* n > 0:  evaluate nth expression in buffer input                    */
/* n < 0:  evaluate (-n-1)th expression in history                    */
/**********************************************************************/
static void setUpEval(char* input, int n)
{
  PTR res;
  tickStart = TimGetTicks();
  GrabMem();
  if (pMemGlobal->pickled)
    unpickle();
  S = E = C = D = W = NIL;
  pMemGlobal->fileLoad = n==0;
  protIdx = 0;
  if (n==0)
    res = loadMemo(input);
  else if (n>0) {
    res = readNthSEXP(input,n);
  }
  else
    res = getHistory(-n-1);
  C = compile(res,NIL);
  if (n > 0)
    addHistory(res);
  S = D = W = NIL;
  E = pMemGlobal->tlVals;
  numGC = numStep = 0L;
  portOutField->pos = 0;
  running = true;
  evalMacro = false;
  actContext = -1;
}


static void PopEnvFrame(void)
{
  if (IS_CONS(pMemGlobal->tlNames) &&
      IS_CONS(cdr(pMemGlobal->tlNames)))
  {
    GrabMem();
    pMemGlobal->tlNames   = cdr(pMemGlobal->tlNames);
    pMemGlobal->tlVals    = cdr(pMemGlobal->tlVals);
    pMemGlobal->loadState = LS_INIT;
    ReleaseMem();
  }
  else
    displayError(ERR_O1_STACK_EMPTY);
}

/**********************************************************************/
/* Symbol start                                                       */
/**********************************************************************/
static char* startOfSymbol(FieldPtr field, UInt16 *len)
{
   UInt16 pos1 = 0, pos2 = -1;
   char *s = FldGetTextPtr(field);
   FldGetSelection(field, &pos1, &pos2);
   *len = 0;
   if (pos1 == pos2) {
     for (; pos1 >= 0; pos1--)
       if (pos1 == 0 || !isSymbolChar(s[pos1-1])) {
         *len = pos2 - pos1;
         return s+pos1;
       }
   }
   else {
     *len = pos2 - pos1;
     return s+pos1;
   }
   return NULL;
}

/**********************************************************************/
/* Length of string to be replaced when pasting from symbol popup     */
/**********************************************************************/
static UInt16 replaceLen(FieldPtr field)
{
   UInt16 len, pos1, pos2;
   FldGetSelection(field, &pos1, &pos2);
   if (pos1 == pos2) 
     startOfSymbol(field, &len);
   else
     len = 0;
   return len;
}

/**********************************************************************/
/* Complete symbol                                                    */
/**********************************************************************/
static void completeSymbol(FieldPtr field)
{
  UInt16 len = 0, newLen;
  char *s = startOfSymbol(field, &len), *completion;
  if (len <= 0)
    return;
  resetCompletion();
  completeAtoms(s, len, true);
  completeBuiltins(s, len, true);
  completion = finishCompletion(&newLen);
  if (newLen > len)
    FldInsert(field, completion+len, newLen - len);
  showArgList(field, false);
}

/**********************************************************************/
/* Build list of known symbols                                        */
/**********************************************************************/
static void fillSymbolList(FieldPtr field)
{
   static char* empty[]     = {"*** No match ***"};
   static char* emergency[] = {"*** Not enough memory ***"};
   UInt16 num, len = 0;
   ListPtr list = (ListPtr)ptrFromObjID(IDC_PL_SYMS);
   char *s = startOfSymbol(field, &len);
   if (symbols)
     MemPtrFree(symbols);
   if ((symbols = prefixSymbols(s, len, &num)))
     LstSetListChoices(list, symbols, num);
   else
     LstSetListChoices(list, num ? emergency : empty,1);

   /*-----------------------------------------------------------------*/
   /* Inc. search is an inofficial feature, no more available in OS5  */
   /*-----------------------------------------------------------------*/
   if (!palmOS5)
     list->attr.search = true;
}

/**********************************************************************/
/* Show arglist                                                       */
/**********************************************************************/
static void showArgList(FieldPtr field, Boolean clearp)
{
  if (LispMePrefs.showParms || clearp) {
    UInt16 len = 0;
    char *s = startOfSymbol(field, &len);
    PTR sym, val;
    LEXADR l;

    GrabMem();
    if (s == NULL)
      goto noArgs;
    StrNCopy(msg, s, len);
    msg[len] = '\0';
    sym = findName(msg, false);
    StrCopy(msg, "*not available*");
    currPtr = msg;
    if (sym == FALSE)
      goto noArgs;

    l = location(sym, pMemGlobal->tlNames, false, NULL);
    if (l != VAR_NOT_FOUND) {
      val = car(locate(pMemGlobal->tlVals,l));
      if (IS_CONS(val) && car(val) == CLOS_TAG)
        printSEXP(cons(sym,cdadr(val)), 0, &portMsg);
      else if (IS_PRIMSYM(sym)) {
        /*------------------------------------------------------------*/
        /* Build help string for builtin variable                     */
        /*------------------------------------------------------------*/
        BuiltIn* b = BUILTIN(sym);
        if (b->doc)
          StrCopy(currPtr, b->doc);
        else
          goto noArgs;
      }
      else
        goto noArgs;
    }
    else if (IS_PRIMSYM(sym)) {
      BuiltIn* b = BUILTIN(sym);
      UInt8* types = b->stypes;
      int ar;

      if (b->doc) {
        /*------------------------------------------------------------*/
        /* Build help string from name and builtin text               */
        /*------------------------------------------------------------*/
        *currPtr++ = '(';
        StrCopy(currPtr, b->name);
        currPtr += StrLen(b->name);
        *currPtr++ = ' '; 
        StrCopy(currPtr, b->doc);
        currPtr += StrLen(b->doc);
        *currPtr++ = ')';
      }
      else if (IS_NATIVE(b->kind)) {
        /*------------------------------------------------------------*/
        /* Build help string from name and parameter types            */
        /*------------------------------------------------------------*/
        *currPtr++ = '(';
        StrCopy(currPtr, b->name);
        currPtr += StrLen(b->name);

        ar = NATIVE_ARITY(b->kind);
        while (ar--) {
          *currPtr++ = ' '; 
          *currPtr++ = '<'; 
          s = formatType(*types);
          StrCopy(currPtr, s);
          currPtr += StrLen(s);
          *currPtr++ = '>'; 
          types++;
        }
        if (IS_NATIVE_VAR(b->kind)) {
          *currPtr++ = ' '; 
          *currPtr++ = charEllipsis; 
        }
        *currPtr++ = ')';
      }
      else 
        goto noArgs;
    
      *currPtr = '\0';
    }
    clearp = true;

   noArgs:
    if (clearp) {
      currPtr = (char*)MemHandleLock(outHandle);
      StrCopy(currPtr, msg);
      MemHandleUnlock(outHandle);
    }
    ReleaseMem(); 
    if (clearp) {
      FldSetTextHandle(outField, outHandle);
      FldDrawField(outField);
      updateScrollBar();
    }
  }
}

/**********************************************************************/
/* Build list of history entries                                      */
/**********************************************************************/
static void fillHistoryList()
{
  int i;
  PTR p;

  for (i=HIST_SIZE-1, p=locVal(histCell); i>=0; --i) 
    if (IS_PAIR(p)) {
      printSEXP(car(p), PRT_ESCAPE, &portMsg);
      StrNCopy(historyStr[i], msg, HIST_STRLEN);
      historyStr[i][HIST_STRLEN] = '\0'; 
      p=cdr(p);
    }
    else {
      /*--------------------------------------------------------------*/   
      /* EOL or improper list, leave entries empty                    */   
      /*--------------------------------------------------------------*/   
      StrCopy(historyStr[i], "");
    }
  LstSetListChoices((ListPtr)ptrFromObjID(IDC_PL_HIST),
                    historyStr, HIST_SIZE);
}

/**********************************************************************/
/* Evaluate entered expr: Parse, compile and set state to running     */
/**********************************************************************/
static Boolean doEval(int n)
{
  UInt16 s=0, e=0;
  ErrTry {
    disableButtons();
    FldDrawField(inField); 
    if (n>0) 
      FldGetSelection(inField, &s, &e);
    if (e>s)
      FldGrabFocus(inField);
    setUpEval(FldGetTextPtr(inField) + (e>s ? s : 0), n);
  }
  ErrCatch(err) {
    cleanUpEval(true);
    displayError(err);
  } ErrEndCatch
  ReleaseMem();
  return true;
}

/**********************************************************************/
/* Modify main frame for standalone apps:                             */
/* a: disable all controls                                            */
/* b: change form title to session name                               */
/* c: change menu                                                     */
/* d: resize output field                                             */
/**********************************************************************/
static void makeStandalone(void)
{
  UInt16 index;
  RectangleType rect;

  disable(IDC_PT_SYMS);
  disable(IDC_ST_SESSION);
  disable(IDC_PB_POP);
  disable(IDC_PB_LOAD);
  disable(IDC_PB_RELOAD);
  disable(IDC_PB_NAMES);
  disable(IDC_PB_ARGLIST);
  disable(IDC_PB_EVAL);
  disable(IDC_PB_BREAK);
  disable(IDC_PT_HIST);
  FldSetUsable(inField, false);
  GsiEnable(false);

  FrmSetTitle(mainForm, LispMePrefs.sessDB);
  
  FrmSetMenu(mainForm, IDD_MainFrame2);
  
  index = FrmGetObjectIndex(mainForm, IDC_SB_OUTPUT);
  FrmGetObjectBounds(mainForm, index, &rect);
  rect.extent.y = 159 - rect.topLeft.y;
  FrmSetObjectBounds(mainForm, index, &rect);
  index = FrmGetObjectIndex(mainForm, IDC_EF_OUTPUT);
  FrmGetObjectBounds(mainForm, index, &rect);
  rect.extent.y = 159 - rect.topLeft.y;
  FrmSetObjectBounds(mainForm, index, &rect);
  FrmSetFocus(mainForm, index);
  updateScrollBar();
  FrmUpdateForm(IDD_MainFrame, frmRedrawUpdateCode);
}

/**********************************************************************/
/* Event handler for main form                                        */
/**********************************************************************/
static Boolean MainFrameHandleEvent(EventType *e)
{
  PTR           res;
  static Char   buf[100];
  static Char   buf1[12];
  static Char   buf2[12];
  static Char   buf3[12];
  Boolean handled = false;
  CALLBACK_PROLOGUE

  DoLMEvent(e);
  handleScrollEvents(e);

  switch (e->eType)
  {
    case nilEvent:
      if (running && !pMemGlobal->waitEvent)
      {
        /*------------------------------------------------------------*/
        /* Run machine some steps                                     */
        /*------------------------------------------------------------*/
        ErrTry {
          GrabMem();
          res = exec();
          if (!running)
          {
            cleanUpEval(true);
            GrabMem();
            printSEXP(res, PRT_ESCAPE | PRT_AUTOLF, portOutField);
          }
        }
        ErrCatch(err) {
          cleanUpEval(true);
          displayError(err);
        } ErrEndCatch
        ReleaseMem();
      }
      handled = true;
      break;

    case menuEvent:
      switch (e->data.menu.itemID)
      {
        case IDM_ViewStat:
        {
          /*----------------------------------------------------------*/
          /* Execution statistics                                     */
          /*----------------------------------------------------------*/
          UInt16 len;
          if (tickStop <= tickStart)
            StrCopy(buf1,"0.00");
          else
          {
            StrIToA(buf,tickStop-tickStart);
            switch (len = StrLen(buf))
            {
              case 1:
                StrCopy(buf1,"0.0"); StrCat(buf1,buf);
                break;

              case 2:
                StrCopy(buf1,"0."); StrCat(buf1,buf);
                break;

              default:
                StrCopy(buf1,buf); MemMove(buf1+len-1,buf1+len-2,3);
                buf1[len-2] = '.';
                break;
            }
          }
          StrIToA(buf2,numStep);
          StrIToA(buf3,numGC);
          FrmCustomAlert(IDA_STAT_EXE,buf1,buf2,buf3);
          handled = true;
        }
        break;

        case IDM_ViewMemory:
        {
          /*----------------------------------------------------------*/
          /* Memory statistics                                        */
          /*----------------------------------------------------------*/
          Int32 heapUse, atomUse, realUse;
          Int32 vecSize, strSize, bigSize;
          ErrTry {  
            memStat(&heapUse, &realUse, &atomUse,
                    &vecSize, &strSize, &bigSize);
            formatMemStat(buf, heapUse, heapSize);
            StrCat(buf,"\nAtoms:\t");
            formatMemStat(buf1, atomUse, atomSize);
            StrCat(buf,buf1);
            StrCat(buf,"\nReals:\t");
            formatMemStat(buf1, realUse, realSize);
            StrCat(buf,buf1);
            StrCat(buf,"\nBigints:\t");
            formatRight(buf1,bigSize,13);
            StrCat(buf,buf1);
            formatRight(buf2,strSize,13);
            formatRight(buf3,vecSize,13);
            FrmCustomAlert(IDA_STAT_MEM,buf,buf2,buf3);
          }
          ErrCatch(err) {
            displayError(err);
          } ErrEndCatch
          handled = true;
        }
        break;

        case IDM_ViewGUI:
          /*----------------------------------------------------------*/
          /* View standard LispMe GUI elements                        */
          /*----------------------------------------------------------*/
          GrabMem();
          pMemGlobal->ownGUI = false;
          ReleaseMem();
          enableCtls(true);
          handled = true;
          break;

        case IDM_EditClrIn:
          /*----------------------------------------------------------*/
          /* Clear input field                                        */
          /*----------------------------------------------------------*/
          FldDelete(inField, 0, FldGetTextLength(inField));
          handled = true;
          break;

        case IDM_EditClrOut:
          /*----------------------------------------------------------*/
          /* Clear output field                                       */
          /*----------------------------------------------------------*/
          FldDelete(outField, 0, FldGetTextLength(outField));
          handled = true;
          break;

        case IDM_Complete:
          /*----------------------------------------------------------*/
          /* Complete symbol                                          */
          /*----------------------------------------------------------*/
          completeSymbol(inField);
          handled = true;
          break;

        case IDM_OptGlob:
          /*----------------------------------------------------------*/
          /* Display global setup dialog                              */
          /*----------------------------------------------------------*/
          FrmPopupForm(IDD_SetupGlob);
          handled = true;
          break;

        case IDM_OptSess:
          /*----------------------------------------------------------*/
          /* Display session setup dialog                             */
          /*----------------------------------------------------------*/
          if (running)
          {
            cleanUpEval(true);
            displayError(ERR_O2_INTERRUPT);
          }
          FrmPopupForm(IDD_SetupSess);
          handled = true;
          break;

        case IDM_OptReset:
          /*----------------------------------------------------------*/
          /* Reset memory                                             */
          /*----------------------------------------------------------*/
          if (FrmAlert(ERR_O6_CONFIRM) == 0)
          {
            if (running)
            {
              cleanUpEval(true);
              displayError(ERR_O2_INTERRUPT);
            }
            destroyHeap();
            initHeap();
            FldSetTextHandle(outField, outHandle);
            FldDrawField(outField);
            FldSetTextHandle(inField, inHandle);
            FldDrawField(inField);
            updateScrollBar();
          }
          handled = true;
          break;

        case IDM_OptClrHist:
          /*----------------------------------------------------------*/
          /* Clear history list                                       */
          /*----------------------------------------------------------*/
          if (running)
          {
            cleanUpEval(true);
            displayError(ERR_O2_INTERRUPT);
          }
          GrabMem();
          locVal(histCell) = NIL;
          ReleaseMem();
          handled = true;
          break;

        case IDC_PB_LOAD:
        case IDC_PB_RELOAD:
        case IDC_PB_POP:
        case IDC_PB_NAMES:
        case IDC_PB_EVAL:
        case IDC_PB_ARGLIST:
        case IDC_PB_BREAK:
        {
          /*----------------------------------------------------------*/
          /* Map these commands to corresponding buttons              */
          /*----------------------------------------------------------*/
          EventType ev; 
          ev.eType = ctlSelectEvent; 
          ev.data.ctlSelect.controlID = e->data.menu.itemID;
          EvtAddEventToQueue(&ev);
          handled = true;
          break;
        }  

        case IDC_PB_EVAL2:
          /*----------------------------------------------------------*/
          /* Mapping these menu events to buttons no more works in    */
          /* OS5. Apparently, controls must actually exist when we    */
          /* simulate pressing them.                                  */
          /*----------------------------------------------------------*/
          handled = doEval(2);
          break;

        case IDC_PB_EVAL3:
          handled = doEval(3);
          break;

        case IDM_HelpAbout:
          /*----------------------------------------------------------*/
          /* Show About screen                                        */
          /*----------------------------------------------------------*/
          FrmAlert(IDA_ABOUT);
          handled = true;
          break;

        case IDM_HelpAbout2:
          /*----------------------------------------------------------*/
          /* Show About screen for standalone apps                    */
          /*----------------------------------------------------------*/
          FrmAlert(IDA_ABOUT2);
          handled = true;
          break;
        
        case IDM_HelpFunc:
          /*----------------------------------------------------------*/
          /* Function help                                            */
          /*----------------------------------------------------------*/
          FrmHelp(HLP_FUNC);
          handled = true;
          break;

        case IDM_HelpGeneral:
          /*----------------------------------------------------------*/
          /* General help                                             */
          /*----------------------------------------------------------*/
          FrmHelp(HLP_GENERAL);
          handled = true;
          break;
      }
      break;

    case frmOpenEvent:
    {
      MemHandle oldHandle;
      startPanel = IDD_MainFrame;
      mainForm   = FrmGetActiveForm();
      inField    = ptrFromObjID(IDC_EF_INPUT);
      outField   = ptrFromObjID(IDC_EF_OUTPUT);
      scrollBar  = ptrFromObjID(IDC_SB_OUTPUT);

      /*--------------------------------------------------------------*/
      /* Init handle for input field                                  */
      /*--------------------------------------------------------------*/
      oldHandle = FldGetTextHandle(inField);
      FldSetTextHandle(inField, inHandle);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Init handle for output field                                 */
      /*--------------------------------------------------------------*/
      oldHandle = FldGetTextHandle(outField);
      FldSetTextHandle(outField, outHandle);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Init other controls                                          */
      /*--------------------------------------------------------------*/
      CtlSetLabel(ptrFromObjID(IDC_ST_SESSION), LispMePrefs.sessDB);
      handleLefty(mainForm);

      if (launchedExternally) {
        /*------------------------------------------------------------*/
        /* Disable unnecessary controls and tap EVAL                  */
        /*------------------------------------------------------------*/
        makeStandalone();
        if (!running)
          CtlHitControl(ptrFromObjID(IDC_PB_EVAL));
      }
      else {
        if (running)
          disableButtons();
        enableCtls(!pMemGlobal->ownGUI);
        if(!pMemGlobal->ownGUI)
          FrmSetFocus(mainForm, FrmGetObjectIndex(mainForm,IDC_EF_INPUT));
      }
      handled = true;
      break;
    }

    case frmCloseEvent:
      FldCompactText(inField); 
      FldSetTextHandle(inField, NULL);
      FldSetTextHandle(outField, NULL);
      break;
 
    case ctlSelectEvent:
      switch (e->data.ctlSelect.controlID)
      {
        case IDC_PB_EVAL:
          handled = doEval(1);
          break;

        case IDC_PB_ARGLIST:
          /*----------------------------------------------------------*/
          /* Show arglist                                             */
          /*----------------------------------------------------------*/
          { 
            FieldAttrType attr;
            FldGetAttributes(inField, &attr);
            showArgList(attr.hasFocus ? inField : outField, true);
            handled = true;
            break;
          }  

        case IDC_PB_RELOAD:
          /*----------------------------------------------------------*/
          /* Pop current and reload last loaded memo                  */
          /*----------------------------------------------------------*/
          if (pMemGlobal->loadState != LS_INIT)
          {
            if (pMemGlobal->loadState == LS_LOADED)
              PopEnvFrame();
            startPtr = 0;
            GrabMem(); 
            pMemGlobal->loadState = LS_LOADED;
            ReleaseMem();
            disableButtons();
            ErrTry {
              setUpEval(openSrcFile(pMemGlobal->sourceFmt,
                                    &pMemGlobal->lastSrc),0);
            }
            ErrCatch(err) {
              pMemGlobal->loadState = LS_ERROR;
              cleanUpEval(true);
              displayError(err);
              closeSrcFile();
              handled = true;
              break;
            } ErrEndCatch
            ReleaseMem();
            closeSrcFile();
          }
          else
            displayError(ERR_L5_LAST_NOT_MEMO);
          handled = true;
          break;

        case IDC_PB_BREAK:
          /*----------------------------------------------------------*/
          /* Break excution                                           */
          /*----------------------------------------------------------*/
          cleanUpEval(true);
          displayError(ERR_O2_INTERRUPT);
          handled = true;
          break;

        case IDC_PB_LOAD:
          /*----------------------------------------------------------*/
          /* Load a source memo                                       */
          /*----------------------------------------------------------*/
          FrmPopupForm(IDD_Load);
          handled = true;
          break;

        case IDC_PB_POP:
          /*----------------------------------------------------------*/
          /* Pop last loaded source from stack                        */
          /*----------------------------------------------------------*/
          PopEnvFrame();
          handled = true;
          break;

        case IDC_PB_NAMES:
          /*----------------------------------------------------------*/
          /* Display all available names                              */
          /*----------------------------------------------------------*/
          portOutField->pos = 0;
          GrabMem();
          printSEXP(pMemGlobal->tlNames, 0, portOutField);
          ReleaseMem();
          handled = true;
          break;

        case IDC_PT_SYMS:
          /*----------------------------------------------------------*/
          /* Build list of known symbols                              */
          /*----------------------------------------------------------*/
          fillSymbolList(inField);
          break;

        case IDC_PT_HIST:
          /*----------------------------------------------------------*/
          /* Build list of history entries                            */
          /*----------------------------------------------------------*/
          fillHistoryList();
          break;

        case IDC_ST_SESSION:
          /*----------------------------------------------------------*/
          /* Display session form                                     */
          /*----------------------------------------------------------*/
          FrmGotoForm(IDD_Sess);
          handled = true;
          break;

        default:
      }
      break;

    case popSelectEvent:
      switch (e->data.popSelect.listID) {
        case IDC_PL_SYMS:
          /*----------------------------------------------------------*/
          /* Insert selected symbol into input field                  */
          /*----------------------------------------------------------*/
          if (symbols)
          {
            UInt16 sel = e->data.popSelect.selection, len;
            char*  sym = LstGetSelectionText(
              (ListPtr)e->data.popSelect.listP,sel);
            len = replaceLen(inField); 
            FldInsert(inField, sym+len, StrLen(sym) - len);
            showArgList(inField, false);
          }
          handled = true;
          break;

        case IDC_PL_HIST:
        {
          static Int16 tapX, tapY;
          static Boolean down;
          EvtGetPen(&tapX, &tapY, &down);
          if (tapX < 80) {
            /*--------------------------------------------------------*/
            /* Eval selected history entry                            */
            /*--------------------------------------------------------*/
            handled = doEval(e->data.popSelect.selection - HIST_SIZE);
          }
          else if (getHistoryStr(HIST_SIZE - 1 - e->data.popSelect.selection)) {
            /*--------------------------------------------------------*/
            /* Copy selected history entry to input field             */
            /*--------------------------------------------------------*/
            FldInsert(inField, msg, StrLen(msg)); 
            handled = true;  
          } 
          else
            handled = true;  
          break;
        }
      }
      break;

    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Globals dealing with source memo lists                             */
/**********************************************************************/
static char**     ppSrc;
static SourceRef* srcArr;
static UInt16     numSrc;

/**********************************************************************/
/* Fill list box with memos/memos32/DOCs                              */
/**********************************************************************/
static void fillMemoList(UInt16 format)
{
  static DmOpenRef  srcRef;
  static char* noCategory[] = {"*** Category 'LispMe' not found ***"};
  static char* noMemo[]     = {"*** No memo in 'LispMe' found ***"};
  static char* noDoc[]      = {"*** No DOC files found ***"};
  ListPtr    srcList  = ptrFromObjID(IDC_LIST_SOURCE);
  ControlPtr memoBut  = ptrFromObjID(IDC_PB_LOAD_MEMO);
  ControlPtr peditBut = ptrFromObjID(IDC_PB_LOAD_PEDIT);
  LocalID    srcId;
  Int16      i;
  Boolean    listOK = true;

  if (format == IDC_RB_DOC) {
    /*----------------------------------------------------------------*/
    /* Go thru all databases with type/creator DOC                    */
    /*----------------------------------------------------------------*/
    DmSearchStateType state;
    UInt16 card;

    for (numSrc=0;;++numSrc)
      if (DmGetNextDatabaseByTypeCreator(numSrc==0, &state,
                                         DOC_TYPE, DOC_CREATOR,false,
                                         &card, &srcId) != errNone)
        break;
    if (numSrc == 0) {
      listOK = false;
      LstSetListChoices(srcList, noDoc, 1);
    }
    else {
      ppSrc  = MemPtrNew(numSrc * sizeof(char*));
      srcArr = MemPtrNew(numSrc * sizeof(SourceRef));
      for (i=0;;++i)
        if (DmGetNextDatabaseByTypeCreator(i==0, &state,
                                           DOC_TYPE, DOC_CREATOR,false,
                                           &card, &srcId) != errNone)
          break;
        else {
          srcArr[i].dbId  = srcId;
          srcArr[i].recNr = 1;
          ppSrc[i] = MemPtrNew(dmDBNameLength);
          DmDatabaseInfo(card, srcId, ppSrc[i], NULL, NULL, NULL, NULL,
                         NULL, NULL, NULL, NULL, NULL, NULL);  
        }
      LstSetListChoices(srcList, ppSrc, numSrc);
    } // DOC found
  } // DOC format
  else {
    /*----------------------------------------------------------------*/
    /* Memo[32], go thru all records of category 'LispMe'             */
    /*----------------------------------------------------------------*/
    UInt16     lispCat;
    UInt16     recId   = 0;
    MemHandle  recHand;

    srcId    = format == IDC_RB_MEMO ? memoId : memo32Id;
    srcRef   = format == IDC_RB_MEMO ? memoRef : memo32Ref;
    startPtr = 0;
    lispCat  = CategoryFind(srcRef, "LispMe");
    numSrc   = 0;

    if (lispCat == dmAllCategories) {
      listOK = false;
      LstSetListChoices(srcList, noCategory, 1);
    }
    else if ((numSrc = DmNumRecordsInCategory(srcRef, lispCat)) == 0) {
      listOK = false;
      LstSetListChoices(srcList, noMemo, 1);
    }
    else
    {
      ppSrc  = MemPtrNew(numSrc * sizeof(char*));
      srcArr = MemPtrNew(numSrc * sizeof(SourceRef));
      for (i=0; i<numSrc; ++i)
      {
        char  *recPtr, *s, *d;
        recHand         = DmQueryNextInCategory(srcRef, &recId, lispCat);
        recPtr          = MemHandleLock(recHand);
        ppSrc[i]        = MemPtrNew(MAX_LINE_LEN+2);
        srcArr[i].dbId  = srcId;
        srcArr[i].recNr = recId;

        /*------------------------------------------------------------*/
        /* Copy beginning of memo text upto first \n or MAX_LINE_LEN  */
        /*------------------------------------------------------------*/
        for (s = recPtr, d = ppSrc[i];
             s-recPtr < MAX_LINE_LEN && *s && *s != '\n';
             ++s, ++d)
          *d = *s;
        if (s-recPtr == MAX_LINE_LEN)
          *d++ = charEllipsis;
        *d = '\0';
        MemHandleUnlock(recHand);
        recId++;
      }
      LstSetListChoices(srcList, ppSrc, numSrc);
    } // memos found 
  } // memo list

  if (listOK) {
    /*----------------------------------------------------------------*/
    /* Autoselect file following last loaded one                      */
    /*----------------------------------------------------------------*/
    for (i=AUTOSELREL; i<numSrc; i++)
      if (!MemCmp(&(srcArr[i-AUTOSELREL]), &(pMemGlobal->lastSrc),
                   sizeof(SourceRef))) {
        LstSetSelection(srcList, i);
        LstMakeItemVisible(srcList, i);
        break;
      }
  }

  /*------------------------------------------------------------------*/
  /* Select buttons according to sensible actions                     */
  /*------------------------------------------------------------------*/
  CtlSetUsable(memoBut,listOK && format == IDC_RB_MEMO);
  CtlSetUsable(peditBut,listOK && ((format == IDC_RB_MEMO && peditID) ||
                                   (format == IDC_RB_MEMO32 && pedit32ID)));
  CtlSetUsable((ControlPtr)ptrFromObjID(IDC_PB_LOAD_OK), listOK);
  CtlSetUsable((ControlPtr)ptrFromObjID(IDC_PB_LOAD_EDIT),
               listOK && format != IDC_RB_DOC);
}

/**********************************************************************/
/* Deallocate memo list structures                                    */
/**********************************************************************/
static void freeMemoList(void)
{
  Int16 i;
  for (i=0; i<numSrc; ++i)
    MemPtrFree(ppSrc[i]);
  if (numSrc) {
    MemPtrFree(ppSrc);
    MemPtrFree(srcArr);
    numSrc = 0;
  }
}

/**********************************************************************/
/* Event handler for load form                                        */
/**********************************************************************/
static Boolean LoadHandleEvent(EventType *e)
{
  Boolean handled = false;
  ListPtr srcList = ptrFromObjID(IDC_LIST_SOURCE);
  CALLBACK_PROLOGUE

  switch (e->eType)
  {
    case lstSelectEvent:
      startPtr = 0;
      break;

    case frmOpenEvent:
    {
      /*--------------------------------------------------------------*/
      /* Disable Memo32 selection if no DB (yet) created              */
      /*--------------------------------------------------------------*/
      if (memo32Id == 0) {
        GrabMem();
        if (pMemGlobal->sourceFmt == IDC_RB_MEMO32)
          pMemGlobal->sourceFmt = IDC_RB_MEMO;
        ReleaseMem();
        CtlHideControl((ControlPtr)ptrFromObjID(IDC_RB_MEMO32));
      }

      /*--------------------------------------------------------------*/
      /* Fill list from Memo DB                                       */
      /*--------------------------------------------------------------*/
      CtlSetValue(ptrFromObjID(pMemGlobal->sourceFmt), true);
      fillMemoList(pMemGlobal->sourceFmt); 
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;
    }

    case frmCloseEvent:
    {
      freeMemoList();
      handled = true;
      break;
    }

    case frmUpdateEvent:
    {
      /*--------------------------------------------------------------*/
      /* Erase button area only before redrawing                      */
      /*--------------------------------------------------------------*/
      RectangleType bottom = {{0,146},{160,14}};
      WinEraseRectangle(&bottom, 0);
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;
    }  

    case keyDownEvent:
    {
      int lines = LstGetVisibleItems(srcList)-1; 
      int num   = LstGetNumberOfItems(srcList);
      int sel   = LstGetSelection(srcList);

      switch (e->data.keyDown.chr)
      {
        case upArrowChr: 
          LstSetSelection(srcList, (sel > 0 ? sel - 1 : num - 1));
          break;

        case downArrowChr: 
          LstSetSelection(srcList, (sel + 1) % num);
          break;

        case pageUpChr:
          LstScrollList(srcList, winUp, lines);
          handled = true;
          break;

        case pageDownChr:
          LstScrollList(srcList, winDown, lines);
          handled = true;
          break;
      }
      break;
    }  

    case ctlSelectEvent:
    {
      UInt16 sel = LstGetSelection(srcList);
      UInt16 id  = e->data.ctlSelect.controlID;
      switch (id)
      {
        case IDC_RB_MEMO:  
        case IDC_RB_MEMO32:  
        case IDC_RB_DOC:  
          if (id != pMemGlobal->sourceFmt) {
            /*--------------------------------------------------------*/
            /* Reload memo list, enable editor buttons and remember it*/
            /*--------------------------------------------------------*/
            GrabMem();
            pMemGlobal->sourceFmt = id;
            ReleaseMem();
            freeMemoList();
            fillMemoList(id);
            FrmUpdateForm(IDD_Load, 0);
          }  
          handled = true;
          break; 

        case IDC_PB_LOAD_OK:
        {
          /*----------------------------------------------------------*/
          /* Load selected memo                                       */
          /*----------------------------------------------------------*/
          if (sel != -1)
          {
            GrabMem();
            pMemGlobal->lastSrc   = srcArr[sel];
            pMemGlobal->loadState = LS_LOADED;
            
            ErrTry {
              setUpEval(openSrcFile(pMemGlobal->sourceFmt,
                                    &pMemGlobal->lastSrc),0);
            }
            ErrCatch(err) {
              pMemGlobal->loadState = LS_ERROR;
              cleanUpEval(false);
              displayError(err);
              closeSrcFile(); 
              handled = true;
              break;
            } ErrEndCatch
            ReleaseMem();
            closeSrcFile();
          } // anything selected
        } // case PB_OK
        disableButtons();

        /*------------------------------------------------------------*/
        /* Load was OK, now clean up dialog (=fall thru to cancel)    */
        /*------------------------------------------------------------*/
        case IDC_PB_LOAD_CANCEL:
        {
          freeMemoList(); 
          FrmReturnToForm(IDD_MainFrame);
          // Eval selection may have changed the input field, so redraw
          FrmUpdateForm(IDD_MainFrame, 0); 
          handled = true;
          break;
        }

        case IDC_PB_LOAD_MEMO:
          /*----------------------------------------------------------*/
          /* Call MemoPad with selected memo, jump to error position, */
          /* if known                                                 */
          /*----------------------------------------------------------*/
          if (sel != -1)
            startMemoPad(srcArr[sel].recNr, false, false);
          handled = true;
          break;

        case IDC_PB_LOAD_PEDIT:
          /*----------------------------------------------------------*/
          /* Call PEDIT with selected memo, jump to error position,   */
          /* if known                                                 */
          /*----------------------------------------------------------*/
          if (sel != -1)
            startMemoPad(srcArr[sel].recNr, true,
                         pMemGlobal->sourceFmt == IDC_RB_MEMO32);
          handled = true;
          break;

        case IDC_PB_LOAD_EDIT:
          /*----------------------------------------------------------*/
          /* Call internal editor with selected memo                  */
          /*----------------------------------------------------------*/
          if (sel != -1)
          {
            selMemo = sel; 
            FrmPopupForm(IDD_Edit);
          }
          handled = true;
          break;
      }
    }
    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Cleanup field and update DB after editing                          */
/**********************************************************************/
static void cleanUpEditFrame(DmOpenRef srcRef, UInt16 recNr)
{
  FieldPtr editField = ptrFromObjID(IDC_EF_OUTPUT);
  Boolean dirty = FldDirty(editField);
  FldSetTextHandle(editField, NULL);
  DmReleaseRecord(srcRef, recNr, dirty);
}

/**********************************************************************/
/* Event handler for edit form                                        */
/**********************************************************************/
static Boolean EditFrameHandleEvent(EventType *e)
{
  static FieldPtr  editField;
  static DmOpenRef srcRef;
  static UInt16    recNr;
  Boolean handled = false;
  CALLBACK_PROLOGUE

  handleScrollEvents(e);
  switch (e->eType)
  {
    case frmOpenEvent:
    {
      /*--------------------------------------------------------------*/
      /* Set field handle to memo DB record                           */
      /*--------------------------------------------------------------*/
      MemHandle oldHandle, recHand;
      FormPtr frm = FrmGetActiveForm();
      if (srcArr[selMemo].dbId == memoId) 
        srcRef = memoRef;
      else
        srcRef = memo32Ref;
      recHand = DmGetRecord(srcRef, recNr=srcArr[selMemo].recNr);
      handleLefty(frm);
      editField = ptrFromObjID(IDC_EF_OUTPUT);

      /*--------------------------------------------------------------*/
      /* Set field size according to preferences                      */
      /*--------------------------------------------------------------*/
      FldSetMaxChars(editField,
                     LispMePrefs.bigMemo ? BIG_EDIT : STD_EDIT);

      oldHandle = FldGetTextHandle(editField);
      FldSetTextHandle(editField, recHand);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Scroll to error position if known                            */
      /*--------------------------------------------------------------*/
      if (startPtr)
      {
        FldSetSelection(editField, currPtr-startPtr-1, currPtr-startPtr);
        FldSetInsPtPosition(editField, currPtr-startPtr-1);
      }  
      else 
        FldSetInsPtPosition(editField, 0);
      updateScrollBar();
      FrmDrawForm(frm);
      FrmSetFocus(frm, FrmGetObjectIndex(frm,IDC_EF_OUTPUT));
      handled = true;
      break;
    }

    case frmCloseEvent:
      cleanUpEditFrame(srcRef, recNr);
      handled = true;
      break;

    case ctlSelectEvent:
      switch (e->data.ctlSelect.controlID)
      {
        case IDC_PB_EDIT_DONE:
          cleanUpEditFrame(srcRef, recNr);
          FrmReturnToForm(IDD_Load);
          handled = true;
          break;

        case IDC_PB_EDIT_EVAL:
        {
          /*----------------------------------------------------------*/
          /* Copy selection to input field and press EVAL             */
          /*----------------------------------------------------------*/
          UInt16 start, end;
          FldGetSelection(editField, &start, &end);
          FldSetSelection(inField, 0, 0); // remove selection
          FldSetInsertionPoint(inField, 0); // set insertion point to beginning
          FldInsert(inField, FldGetTextPtr(editField)+start, end-start);
          FldSetSelection(inField, 0, end-start); // set selection to newly inserted text

          cleanUpEditFrame(srcRef, recNr);
          FrmReturnToForm(IDD_Load);
          CtlHitControl(ptrFromObjID(IDC_PB_LOAD_CANCEL));
          CtlHitControl(FrmGetObjectPtr(mainForm,
                          FrmGetObjectIndex(mainForm, IDC_PB_EVAL)));
          handled = true;
          break;
        }  

        case IDC_PT_SYMS:
          /*----------------------------------------------------------*/
          /* Build list of known symbols                              */
          /*----------------------------------------------------------*/
          fillSymbolList(editField);
          break;
      }
      break; 

    case popSelectEvent:
      /*--------------------------------------------------------------*/
      /* Insert selected symbol into field                            */
      /*--------------------------------------------------------------*/
      if (symbols)
      {
        UInt16 sel = e->data.popSelect.selection, len;
        char*  sym = LstGetSelectionText((ListPtr)e->data.popSelect.listP,sel);
        len = replaceLen(editField); 
        FldInsert(editField, sym+len, StrLen(sym) - len);
      }
      handled = true;
      break;

    case menuEvent:
      switch (e->data.menu.itemID)
      {
        case IDM_Complete:
          /*----------------------------------------------------------*/
          /* Complete symbol                                          */
          /*----------------------------------------------------------*/
          completeSymbol(editField);
          handled = true;
          break;
      }

    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* init all subsystems                                                */
/**********************************************************************/
static Boolean StartApp(char* startSess)
{
  Err     error;
  UInt32  ver;

  /*------------------------------------------------------------------*/
  /* Check for PalmOS3                                                */
  /*------------------------------------------------------------------*/
  error = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &ver);
  if (error || ver < 0x03000000)
  {
    FrmAlert(ERR_O4_OS_VERSION);
    return false;
  }

  /*------------------------------------------------------------------*/
  /* Version-specific settings                                        */
  /*------------------------------------------------------------------*/
  charEllipsis = ver >= 0x03100000 ? 0x18 : 0x85;
  charNumSpace = ver >= 0x03100000 ? 0x19 : 0x80;
  newTimeDlg   = ver >= 0x03103000;
  newGraphic   = ver >= 0x03500000;
  palmOS5      = ver >= 0x05000000;

  /*------------------------------------------------------------------*/
  /* Do we have to use MemSemaphoreReserve() calls to access DB?      */
  /*------------------------------------------------------------------*/
  useMSR = true;
  if (palmOS5)
  {
    UInt32 procId;

    // Make it work on the simulator, using an Intel x86 CPU
    // sysFtrNumProcessorx86 == 0x01000000, in the OS5 SDK
    error = FtrGet(sysFtrCreator, sysFtrNumProcessorID, &procId);
    if (!error && ((procId & sysFtrNumProcessorMask) == 0x01000000))
      useMSR = false;
  }

  /*------------------------------------------------------------------*/
  /* Open DB and init memory                                          */
  /*------------------------------------------------------------------*/
  initBuiltins();
  startPanel = InitDB(startSess) ? IDD_MainFrame : IDD_Sess;
  if (startSess && startPanel == IDD_Sess)
  {
    FrmCustomAlert(ERR_OX_SESSION_MISS,startSess,0,0);
    return false;
  }

  /*------------------------------------------------------------------*/
  /* Check for Parentheses Hack                                       */
  /*------------------------------------------------------------------*/
  parHackActive = FtrGet(PARHACK_APPID, PARHACK_RESID, &ver) == 0;

  /*------------------------------------------------------------------*/
  /* Check for different flavours of pedit.                           */
  /*------------------------------------------------------------------*/
  memoPadID  = findApp(sysFileCMemo);
  (peditID   = pedit32ID = findApp('pnPr')) ||
  (pedit32ID = findApp('pn32')              ,
   (peditID  = findApp('pn10'))             ||
   (peditID  = findApp('pnLi')));
    
  return true;
}

/**********************************************************************/
/* shutdown all subsystems                                            */
/**********************************************************************/
static void StopApp(void)
{
  FrmCloseAllForms();
  DisconnectSession();
  forAllModules(APP_STOP,true);
  FreeDynMem();
}

