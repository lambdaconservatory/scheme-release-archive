/**********************************************************************/
/*                                                                    */
/* gui.c:   LISPME user interface functions                           */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.01.1999 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include <limits.h>

#include "gui.h"
#include "io.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"
#include "graphic.h"
#include "date.h"
#include "arith.h"
#include "callback.h"

/**********************************************************************/
/* Aliases for event symbol PTRs                                      */
/**********************************************************************/
/* the events without a ID comes first */
#define TIMEOUT         MKPRIMSYM(EVENT_MODULE,1)
#define PENDOWN         MKPRIMSYM(EVENT_MODULE,2)
#define PENMOVE         MKPRIMSYM(EVENT_MODULE,3)
#define PENUP           MKPRIMSYM(EVENT_MODULE,4)
#define KEYDOWN         MKPRIMSYM(EVENT_MODULE,5)
#define CTLENTER        MKPRIMSYM(EVENT_MODULE,6)
#define CTLSELECT       MKPRIMSYM(EVENT_MODULE,7)
#define CTLREPEAT       MKPRIMSYM(EVENT_MODULE,8)
#define LSTENTER        MKPRIMSYM(EVENT_MODULE,9)
#define LSTSELECT       MKPRIMSYM(EVENT_MODULE,10)
#define POPSELECT       MKPRIMSYM(EVENT_MODULE,11)
#define FLDENTER        MKPRIMSYM(EVENT_MODULE,12)
#define FLDCHANGED      MKPRIMSYM(EVENT_MODULE,13)
#define MENU            MKPRIMSYM(EVENT_MODULE,14)
#define FRMOPEN         MKPRIMSYM(EVENT_MODULE,15)
#define FRMUPDATE       MKPRIMSYM(EVENT_MODULE,16)
#define FRMCLOSE        MKPRIMSYM(EVENT_MODULE,17)
#define SCLENTER        MKPRIMSYM(EVENT_MODULE,18)
#define SCLREPEAT       MKPRIMSYM(EVENT_MODULE,19)
#define SCLEXIT         MKPRIMSYM(EVENT_MODULE,20)
#define FRMTTLENTER     MKPRIMSYM(EVENT_MODULE,21)
#define FRMTTLSELECT    MKPRIMSYM(EVENT_MODULE,22)

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static PTR      MakeLispEvent(EventType *e)                    SEC(GUI);
static void*    checkedPtrFromObjID(UInt16 obj,
                                    FormObjectKind kind,
                                    char* msg)                 SEC(GUI);
static UInt16   checkedIndexFromObjID(UInt16 obj)              SEC(GUI);
static FieldPtr accField(PTR* args)                            SEC(GUI);
static void     setIdAssoc(PTR id, PTR temps)                  SEC(GUI);

static PTR nativeFrmShow(PTR* args)                            SEC(GUI);
static PTR nativeFrmGetFocus(PTR* args)                        SEC(GUI);
static PTR nativeFrmSetFocus(PTR* args)                        SEC(GUI);
static PTR nativeFrmHelp(PTR* args)                            SEC(GUI);
static PTR nativeFrmGetProp(PTR* args)                         SEC(GUI);

static PTR nativeCtlGetVal(PTR* args)                          SEC(GUI);
static PTR nativeCtlSetVal(PTR* args)                          SEC(GUI);
static PTR nativeCtlHit(PTR* args)                             SEC(GUI);
static PTR nativeCtlSetLabel(PTR* args)                        SEC(GUI);
static PTR nativeCtlGetLabel(PTR* args)                        SEC(GUI);

static PTR nativeSclGetVal(PTR* args)                          SEC(GUI);
static PTR nativeSclSetVal(PTR* args)                          SEC(GUI);

static PTR nativeLstGetSel(PTR* args)                          SEC(GUI);
static PTR nativeLstSetSel(PTR* args)                          SEC(GUI);
static PTR nativeLstGetTxt(PTR* args)                          SEC(GUI);
static PTR nativeLstSetLst(PTR* args)                          SEC(GUI);

static PTR nativeFldGetTxt(PTR* args)                          SEC(GUI);
static PTR nativeFldSetTxt(PTR* args)                          SEC(GUI);
static PTR nativeFldGetScl(PTR* args)                          SEC(GUI);
static PTR nativeFldScroll(PTR* args)                          SEC(GUI);
static PTR nativeFldDirty(PTR* args)                           SEC(GUI);
static PTR nativeFldSetDirty(PTR* args)                        SEC(GUI);

static PTR nativeFldCut(PTR* args)                             SEC(GUI);
static PTR nativeFldCopy(PTR* args)                            SEC(GUI);
static PTR nativeFldPaste(PTR* args)                           SEC(GUI);
static PTR nativeFldUndo(PTR* args)                            SEC(GUI);

static PTR nativeSelectDate(PTR* args)                         SEC(GUI);
static PTR nativeSelectTime(PTR* args)                         SEC(GUI);
static PTR nativeSelectTimeRange(int argc, PTR* args)          SEC(GUI);
static PTR nativeSelectCol(PTR* args)                          SEC(GUI);

static PTR nativeFrmAlert(int argc, PTR* args)                 SEC(GUI);

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
Boolean          returning;
Boolean          newTimeDlg;
struct UIContext contexts[MAX_GUI_NEST];
int              actContext = -1;

/**********************************************************************/
/* Convert PalmOS events to LispMe events                             */
/**********************************************************************/
static PTR MakeLispEvent(EventType *e)
{
  PTR res;
  PROTECT(res)

  switch (e->eType)
  {
    case nilEvent:
      res = list1(TIMEOUT);
      break;
 
    case penDownEvent:
      res = PENDOWN; goto PenEvent;
    case penUpEvent:
      res = PENUP; goto PenEvent;
    case penMoveEvent:
      res = PENMOVE;
    PenEvent:
      res = list3(res, MKINT(e->screenX), MKINT(e->screenY));
      break;
  
    case keyDownEvent: {
      UInt16 c = e->data.keyDown.chr;
      res = list2(KEYDOWN,c > 0xFF ? MKINT(c) : MKCHAR(c));
      break;
    }

    case ctlEnterEvent:
      res = list2(CTLENTER, makeUNum(e->data.ctlEnter.controlID));
      break;

    case ctlSelectEvent:
      res = list3(CTLSELECT, makeUNum(e->data.ctlSelect.controlID),
                  e->data.ctlSelect.on ? TRUE : FALSE);
      break;

    case ctlRepeatEvent:
      res = list2(CTLREPEAT, makeUNum(e->data.ctlRepeat.controlID));
      break;

    case lstEnterEvent:
      res = list3(LSTENTER, makeUNum(e->data.lstEnter.listID),
                            makeNum(e->data.lstEnter.selection));
      break;

    case lstSelectEvent:
      res = list3(LSTSELECT, makeUNum(e->data.lstSelect.listID),
                             makeNum(e->data.lstSelect.selection));
      break;

    case popSelectEvent:
      res = list5(POPSELECT, makeUNum(e->data.popSelect.controlID),
                  makeUNum(e->data.popSelect.listID),
                  makeNum(e->data.popSelect.selection),
                  makeNum(e->data.popSelect.priorSelection));
      break;

    case fldEnterEvent:
      res = list2(FLDENTER, makeUNum(e->data.fldEnter.fieldID));
      break;

    case fldChangedEvent:
      res = list2(FLDCHANGED, makeUNum(e->data.fldChanged.fieldID));
      break;

    case sclEnterEvent:
      res = list2(SCLENTER, makeUNum(e->data.sclEnter.scrollBarID));
      break;

    case sclRepeatEvent:
      res = list4(SCLREPEAT, makeUNum(e->data.sclExit.scrollBarID),
                  makeNum(e->data.sclExit.newValue),        
                  makeNum(e->data.sclExit.value));
      break;

    case sclExitEvent:
      res = list3(SCLEXIT, makeUNum(e->data.sclRepeat.scrollBarID),
                  makeNum(e->data.sclRepeat.newValue));
      break;

    case menuEvent:
      res = list2(MENU, makeUNum(e->data.menu.itemID));
      break;

    case frmOpenEvent:
      res = list2(FRMOPEN, makeUNum(e->data.frmOpen.formID));
      break;

    case frmUpdateEvent:
      res = list3(FRMUPDATE,makeUNum(e->data.frmUpdate.formID),
                            makeUNum(e->data.frmUpdate.updateCode));
      break;

    case frmCloseEvent:
      res = list2(FRMCLOSE, makeUNum(e->data.frmClose.formID));
      break;

    case frmTitleEnterEvent:
      res = list2(FRMTTLENTER, makeUNum(e->data.frmTitleEnter.formID));
      break;

    case frmTitleSelectEvent:
      res = list2(FRMTTLSELECT, makeUNum(e->data.frmTitleSelect.formID));
      break;

    default:
      res = cons(FALSE,NIL);
  }

  UNPROTECT(res)
  return res;
}

/**********************************************************************/
/* Retrieve GUI id                                                    */
/**********************************************************************/
static UInt16 guiId(PTR p)
{
  return getUInt16(p);
}

/**********************************************************************/
/* Low level LispMe hook to event handler                             */
/**********************************************************************/
void DoLMEvent(EventType *e)
{
  if (running && pMemGlobal->getEvent)
    if (e->eType != nilEvent || !pMemGlobal->waitEvent)
    {
      GrabMem();
      S = cons(MakeLispEvent(e), S);
      pMemGlobal->getEvent = false;
      pMemGlobal->waitEvent = false;
      ReleaseMem();
    }
}

/**********************************************************************/
/* Stub for Scheme event handler                                      */
/**********************************************************************/
Boolean LispHandleEvent(EventType *e)
{
  static  UInt32 wdog[] = {1000ul,3000ul,6000ul,30000ul};
  Boolean handled = true;
  UInt32  timeLimit;

  CALLBACK_PROLOGUE

  if (LispMePrefs.watchDogSel == 4)
    timeLimit = ULONG_MAX;
  else
    timeLimit = TimGetTicks()+wdog[LispMePrefs.watchDogSel];

  if (e->eType == frmUpdateEvent) {
    FormPtr frm = FrmGetActiveForm();
    FrmEraseForm(frm);
    FrmDrawForm(frm);
  }
  else if (e->eType == frmOpenEvent)
    FrmDrawForm(FrmGetActiveForm());

  GrabMem();
  if (!returning)
  {
    S = cons(contexts[actContext].handler,cons(MakeLispEvent(e),NIL));
    C = cons(MKINT(APC),cons(MKINT(STOP),NIL));
    E = pMemGlobal->tlVals;
    W = NIL;
  }

  running = true;
again:
  ErrTry {
    quitHandler = changeHandler = false;
    evalMacro = true;
    handled = exec() != FALSE;
    evalMacro = false;
    ReleaseMem();
  }
  ErrCatch(err) {
    displayError(err);
    goto cleanup;
  } ErrEndCatch

  returning = false;
  if (quitHandler)
  {
    /*----------------------------------------------------------------*/
    /* frm-return was called, restore context as before frm-popup     */
    /*----------------------------------------------------------------*/
    GrabMem();
    W = contexts[actContext--].prevCont;
    S = cons(car(S),car(W));
    E = cadr(W);
    C = caddr(W);
    D = cdddr(W);
    returning = true;
    ReleaseMem();
    FrmReturnToForm(0);
  }
  else if (changeHandler)
  {
    /*----------------------------------------------------------------*/
    /* frm-goto was called, leave this handler but don't change stack */
    /*----------------------------------------------------------------*/
  }
  else if (running)
  {
    if (TimGetTicks() <= timeLimit)
    {
      GrabMem();
      goto again;
    }
    /*----------------------------------------------------------------*/
    /* Too many steps !                                               */
    /*----------------------------------------------------------------*/
    displayError(ERR_U3_WATCHDOG);
  cleanup:
    FrmReturnToForm(IDD_MainFrame);
    cleanUpEval(true);
    enableCtls(true);
    quitHandler = true;
  }

  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Replace current LispMe form by another one                         */
/**********************************************************************/
void gotoForm(UInt16 resId, int timeout, PTR handler)
{
  MemHandle frmHand = DmGetResource('tFRM',resId);
  if (frmHand)
  {
    DmReleaseResource(frmHand);
    if (actContext < 0)
      ErrThrow(ERR_U6_INVALID_GOTO);
    running = false;
    contexts[actContext].handler = handler;
    contexts[actContext].timeout = timeout;
    contexts[actContext].data    = NIL;
    ReleaseMem();
    FrmGotoForm(resId);
    GrabMem();
    changeHandler = true;
    return;
  }
  error1(ERR_U1_INVALID_FORM, makeUNum(resId));
}
/**********************************************************************/
/* Popup a nested LispMe form                                         */
/**********************************************************************/
void popupForm(UInt16 resId, int timeout, PTR handler)
{
  MemHandle frmHand = DmGetResource('tFRM',resId);
  if (frmHand)
  {
    DmReleaseResource(frmHand);
    running = !++actContext;
    if (actContext >= MAX_GUI_NEST-1)
      ErrThrow(ERR_U7_FORM_NEST);
    contexts[actContext].prevCont = cons(cddr(S),cons(E,cons(cdr(C),D)));
    contexts[actContext].handler  = handler;
    contexts[actContext].data     = NIL;
    contexts[actContext].timeout  = timeout;
    ReleaseMem();
    FrmPopupForm(resId);
    GrabMem();
    changeHandler = false;
    return;
  }
  error1(ERR_U1_INVALID_FORM, makeUNum(resId));
}

/**********************************************************************/
/* index from ID (check for valid ID)                                 */
/**********************************************************************/
static UInt16 checkedIndexFromObjID(UInt16 obj)
{
  FormPtr frm = FrmGetActiveForm();
  int i;
  for (i=FrmGetNumberOfObjects(frm)-1;i>=0;--i)
    if (FrmGetObjectId(frm,i) == obj)
      return i;
  error1(ERR_U2_INVALID_OBJ, makeUNum(obj));
}

/**********************************************************************/
/* Get the field whose index is the first element in args             */
/**********************************************************************/
static FieldPtr accField(PTR* args)
{
  return checkedPtrFromObjID(guiId(args[0]), frmFieldObj, "field");
}

/**********************************************************************/
/* Get field text                                                     */
/**********************************************************************/
static PTR nativeFldGetTxt(PTR* args)
{
  char* p;
  p = FldGetTextPtr(accField(args));
  return p ? str2Lisp(p) : EMPTY_STR;
}

/**********************************************************************/
/* Get field scroll parameters                                        */
/**********************************************************************/
static PTR nativeFldGetScl(PTR* args)
{
  UInt16 scrPos, totLines, visLines;
  FldGetScrollValues(accField(args), &scrPos, &totLines, &visLines);
  return list3(MKINT(scrPos), MKINT(totLines), MKINT(visLines));
}

/**********************************************************************/
/* Get list text                                                      */
/**********************************************************************/
static PTR nativeLstGetTxt(PTR* args)
{
  char* p;
  p = LstGetSelectionText(checkedPtrFromObjID(guiId(args[0]),
                                              frmListObj,"list"),
                           INTVAL(args[1]));
  return p ? str2Lisp(p) : EMPTY_STR;
}

/**********************************************************************/
/* Add/modify (list id . string array) assoc to form data             */
/**********************************************************************/
static void setIdAssoc(PTR id, PTR temps)
{
  PTR   l;

  if (actContext < 0)
    return;

  for (l = contexts[actContext].data; l != NIL; l = cdr(l))
    if (caar(l) == id)
      break;

  if (l == NIL)
    push(cons(id,temps), contexts[actContext].data);
  else
    cdar(l) = temps;
}

/**********************************************************************/
/* Set list choices                                                   */
/* Uses the new string array foreign type                             */
/**********************************************************************/
static PTR nativeLstSetLst(PTR* args)
{
  ListPtr lst = checkedPtrFromObjID(guiId(args[0]),
                                    frmListObj,"list");
  PTR items;
  char **ss;

  if (hasType(tyPROPLIST,args[1]))
    items = makeStrArr(args[1]);
  else if (hasType(FOREIGN(FT_STR_ARR),args[1]))
    items = args[1];
  else
    extTypeError("lst-set-list", 1, args[1], "list/strarr");
  
  ss = FOREIGNVAL(items);
  setIdAssoc(args[0], items);
  LstSetListChoices(lst, ss+1, (Int32)ss[0]);
  LstDrawList(lst);
  return args[1]; 
}

/**********************************************************************/
/* ptr from ID (check for valid ID and kind)                          */
/**********************************************************************/
static void* checkedPtrFromObjID(UInt16 obj,
                                 FormObjectKind kind, char* msg)
{
  FormPtr frm = FrmGetActiveForm();
  UInt16  n   = checkedIndexFromObjID(obj);

  if (FrmGetObjectType(frm,n) != kind)
  {
    errInfo = msg;
    error1(ERR_U5_INVALID_KIND, makeUNum(obj));
  }
  return FrmGetObjectPtr(frm,n);
}

/**********************************************************************/
/* Set field text                                                     */
/**********************************************************************/
static PTR nativeFldSetTxt(PTR* args)
{
  FieldPtr  fld;
  MemHandle oldH, newH;

  printSEXP(args[1], 0, &portMsg);
  fld  = accField(args);
  oldH = FldGetTextHandle(fld);
  newH = MemHandleNew(StrLen(msg)+1);
  StrCopy(MemHandleLock(newH),msg);
  MemHandleUnlock(newH);
  FldSetTextHandle(fld, newH);
  FldDrawField(fld);
  if (oldH)
    MemHandleFree(oldH);
  return args[1];
}

/**********************************************************************/
/* Scroll field text                                                  */
/**********************************************************************/
static PTR nativeFldScroll(PTR* args)
{
  FieldPtr fld;
  Int16    delta;

  delta = INTVAL(args[1]);
  fld  = accField(args);
  if (delta > 0) {
    if (FldScrollable(fld, winDown))
      FldScrollField(fld, delta, winDown);
  } else if (delta < 0) {
    if (FldScrollable(fld, winUp))
      FldScrollField(fld, -delta, winUp);
  }  
  return args[1];
}

/**********************************************************************/
/* Is field dirty?                                                    */
/**********************************************************************/
static PTR nativeFldDirty(PTR* args)
{
  return FldDirty(accField(args)) ? TRUE : FALSE;
}

/**********************************************************************/
/* Set field dirty                                                    */
/**********************************************************************/
static PTR nativeFldSetDirty(PTR* args)
{
  FldSetDirty(accField(args), args[1] != FALSE);
  return args[1];
}

/**********************************************************************/
/* Do a clipboard operation with the field                            */
/**********************************************************************/
static PTR nativeFldCut(PTR* args)
{
  FldCut(accField(args));
  return args[0];
}

static PTR nativeFldCopy(PTR* args)
{
  FldCopy(accField(args));
  return args[0];
}

static PTR nativeFldPaste(PTR* args)
{
  FldPaste(accField(args));
  return args[0];
}

static PTR nativeFldUndo(PTR* args)
{
  FldUndo(accField(args));
  return args[0];
}

/**********************************************************************/
/* Display form help text                                             */
/**********************************************************************/
static PTR nativeFrmHelp(PTR* args)
{
  UInt16 id = guiId(args[0]);
  if (DmGetResource('tSTR',id) == NULL) {
    errInfo = "help string";
    error1(ERR_U5_INVALID_KIND, args[0]);
  }
  ReleaseMem();
  FrmHelp(id);
  GrabMem();
  return NOPRINT;
}

/**********************************************************************/
/* Get control value                                                  */
/**********************************************************************/
static PTR nativeCtlGetVal(PTR* args)
{
  return CtlGetValue(
           checkedPtrFromObjID(guiId(args[0]),
                               frmControlObj,"control"))
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Set control value                                                  */
/**********************************************************************/
static PTR nativeCtlSetVal(PTR* args)
{
  CtlSetValue(checkedPtrFromObjID(guiId(args[0]),
                                  frmControlObj,"control"),
              args[1] != FALSE);
  return args[1];
}

/**********************************************************************/
/* Hit a control                                                      */
/**********************************************************************/
static PTR nativeCtlHit(PTR* args)
{
  CtlHitControl(checkedPtrFromObjID(guiId(args[0]),
                                    frmControlObj,"control"));
  return NOPRINT;
}

/**********************************************************************/
/* Set control label                                                  */
/**********************************************************************/
static PTR nativeCtlSetLabel(PTR* args)
{
  PTR items = makeStrArr(list1(args[1]));
  char **ss = FOREIGNVAL(items);
  setIdAssoc(args[0], items);
  CtlSetLabel(checkedPtrFromObjID(guiId(args[0]),
                                  frmControlObj,"control"),
              ss[1]);
  return args[1];
}

/**********************************************************************/
/* Get control label                                                  */
/**********************************************************************/
static PTR nativeCtlGetLabel(PTR* args)
{
  return str2Lisp(
           CtlGetLabel(checkedPtrFromObjID(guiId(args[0]),
                                           frmControlObj,"control")));
}

/**********************************************************************/
/* Get scrollbar values                                               */
/**********************************************************************/
static PTR nativeSclGetVal(PTR* args)
{
  Int16 curr, minP, maxP, pageSize;

  SclGetScrollBar(checkedPtrFromObjID(guiId(args[0]),
                                      frmScrollBarObj,"scrollbar"),
                  &curr, &minP, &maxP, &pageSize);
  return cons(MKINT(curr), 
           list3(MKINT(minP), MKINT(maxP), MKINT(pageSize)));
}

/**********************************************************************/
/* Set scrollbar values                                               */
/**********************************************************************/
static PTR nativeSclSetVal(PTR* args)
{
  PTR obj = args[1];

  if (listLength(obj) != 4 || 
      !IS_SMALLINT(car(obj)) ||
      !IS_SMALLINT(cadr(obj)) ||
      !IS_SMALLINT(caddr(obj)) ||
      !IS_SMALLINT(cadddr(obj)) ||
      INTVAL(cadr(obj)) > INTVAL(caddr(obj)))
    parmError(obj,"scl-set-val");

  SclSetScrollBar(checkedPtrFromObjID(guiId(args[0]),
                                      frmScrollBarObj,"scrollbar"),
                  INTVAL(car(obj)),
                  INTVAL(cadr(obj)),
                  INTVAL(caddr(obj)),
                  INTVAL(cadddr(obj)));
  return obj; 
}

/**********************************************************************/
/* Get list selection                                                 */
/**********************************************************************/
static PTR nativeLstGetSel(PTR* args)
{
  UInt16 n = LstGetSelection(checkedPtrFromObjID(guiId(args[0]),
                                                 frmListObj,"list"));
  return n==-1 ? FALSE : MKINT(n);
}

/**********************************************************************/
/* Set list selection                                                 */
/**********************************************************************/
static PTR nativeLstSetSel(PTR* args)
{
  PTR obj = args[1];
  if (obj==FALSE)
    obj=MKINT(-1);
  EXT_TCHECK(tySMALLINT,obj,"lst-set-sel",1);
  LstSetSelection(checkedPtrFromObjID(guiId(args[0]),
                                      frmListObj,"list"),
                  INTVAL(obj));
  return obj;
}

/**********************************************************************/
/* Set focus                                                          */
/**********************************************************************/
static PTR nativeFrmSetFocus(PTR* args)
{
  FrmSetFocus(FrmGetActiveForm(),
              checkedIndexFromObjID(guiId(args[0])));
  return args[0];
}

/**********************************************************************/
/* Get focus                                                          */
/**********************************************************************/
static PTR nativeFrmGetFocus(PTR* args)
{
  FormPtr frm = FrmGetActiveForm();
  UInt16  n   = FrmGetFocus(frm);
  return n==-1 ? FALSE : makeUNum(FrmGetObjectId(frm,n));
}

/**********************************************************************/
/* Get form properties                                                */
/**********************************************************************/
static PTR nativeFrmGetProp(PTR* args)
{
  return actContext < 0 ? NIL : contexts[actContext].data;
}

/**********************************************************************/
/* Show/hide a form object                                            */
/**********************************************************************/
static PTR nativeFrmShow(PTR* args)
{
  FormPtr frm = FrmGetActiveForm();

  if (args[1] == FALSE)
    FrmHideObject(frm,checkedIndexFromObjID(guiId(args[0])));
  else
    FrmShowObject(frm,checkedIndexFromObjID(guiId(args[0])));
  return args[1];
}

/**********************************************************************/
/* Display date selection dialog                                      */
/**********************************************************************/
static PTR nativeSelectDate(PTR* args)
{
  Int16 year;
  Int16 month;
  Int16 day;
  DateType d = GETDATE(args[1]);
  Boolean res;

  year  = d.year+1904;
  month = d.month;
  day   = d.day;
  printString(args[0]);
  ReleaseMem();
  res = SelectDay(selectDayByDay, &month, &day, &year, msg);
  GrabMem();
  return res ? allocDate(year, month, day) : FALSE;
}

/**********************************************************************/
/* Display time selection dialog                                      */
/**********************************************************************/
static PTR nativeSelectTime(PTR* args)
{
  Int16 hour;
  Int16 minute;
  TimeType t = GETTIME(args[1]);
  Boolean res;

  hour   = t.hours;
  minute = t.minutes;
  printString(args[0]);
  if (newTimeDlg)
  {
    /*----------------------------------------------------------------*/
    /* The simple 'select one time' dialog is only available from     */
    /* PalmOS versions >=3.1 :-(                                      */
    /*----------------------------------------------------------------*/
    ReleaseMem();
    res = SelectOneTime(&hour, &minute, msg);
    GrabMem();
    return res ? allocTime(hour, minute) : FALSE;
  }
  else
  {
    /*----------------------------------------------------------------*/
    /* Use the over-sophisticated time interval selection dialog      */
    /* available in all PalmOS versions                               */
    /*----------------------------------------------------------------*/
    TimeType start, end;
    start.minutes = end.minutes = minute;
    start.hours   = end.hours   = hour; 
    ReleaseMem();
    res = SelectTimeV33(&start, &end, false, msg, 8);
    GrabMem();
    return res ? allocTime(start.hours, start.minutes) : FALSE;
  }
}

/**********************************************************************/
/* Display time range selection dialog                                */
/**********************************************************************/
static PTR nativeSelectTimeRange(int argc, PTR* args)
{
  TimeType start = GETTIME(args[1]);
  TimeType end;
  Boolean res;

  printString(args[0]);

  switch (argc) {
    case 2: end = start; break;

    case 3:
      EXT_TCHECK(FOREIGN(FT_TIME),car(args[2]),"pick-time-range",2);
      end = GETTIME(args[2]);
      break;

    default:
      arityError("pick-time-range", argc);
  }
  ReleaseMem();
  res = SelectTimeV33(&start, &end, false, msg, 8);
  GrabMem();
  if (res)
    return (start.hours==255) ? TRUE :
      list2(allocTime(start.hours, start.minutes),
            allocTime(end.hours, end.minutes));
  else
    return FALSE;
}

/**********************************************************************/
/* Display color selection dialog                                     */
/**********************************************************************/
static PTR nativeSelectCol(PTR* args)
{
  if (newGraphic)
  {
    IndexedColorType idx = INTVAL(args[1]);
    RGBColorType rgb;
    Boolean res;

    printString(args[0]);
    ReleaseMem();
    res = UIPickColor(&idx, &rgb, UIPickColorStartPalette, msg, NULL);
    GrabMem();
    return res ? MKINT(idx) : FALSE;
  }
  else
    return MKINT(0);
}

/**********************************************************************/
/* Display arbitrary PalmOS alert with parameter substitution         */
/**********************************************************************/
static PTR nativeFrmAlert(int argc, PTR* args)
{
  char* s1 = "";
  char* s2 = "";
  char* s3 = "";
  PTR res;
  UInt16 altId = guiId(args[0]);

  MemHandle alertH = DmGetResource('Talt',altId);
  if (alertH)
  {
    DmReleaseResource(alertH);

    // All fall-thrus intentional!
    switch (argc) {
      default:
        arityError("frm-alert",argc);

      case 4:
        printSEXP(caddr(args[1]),0,&portConv);
        s3 = MemPtrNew(StrLen(msg)+1);
        StrCopy(s3, msg);
      case 3:
        printSEXP(cadr(args[1]),0,&portConv);
        s2 = MemPtrNew(StrLen(msg)+1);
        StrCopy(s2, msg);
      case 2:
        printSEXP(car(args[1]),0,&portConv);
        s1 = MemPtrNew(StrLen(msg)+1);
        StrCopy(s1, msg);
      case 1:
    }

    ReleaseMem();
    res = MKINT(FrmCustomAlert(altId,s1,s2,s3));
    GrabMem();

    switch (argc) {
      case 4: MemPtrFree(s3);
      case 3: MemPtrFree(s2);
      case 2: MemPtrFree(s1);
    }

    return res;
  }
  error1(ERR_U1_INVALID_FORM, makeUNum(altId));
}


/**********************************************************************/
/* Create a symbolic name for each PalmOS event supported             */
/**********************************************************************/
BuiltInModule eventBuiltins = 
{
  MODULE_FUNC(NULL),
  BUILTINSYMBOLQ_H(timeout,          ""),
  BUILTINSYMBOLQ_H(pen-down,         "x y"),
  BUILTINSYMBOLQ_H(pen-move,         "x y"),
  BUILTINSYMBOLQ_H(pen-up,           "x y"),
  BUILTINSYMBOLQ_H(key-down,         "key/code"),
  BUILTINSYMBOLQ_H(ctl-enter,        "id"),
  BUILTINSYMBOLQ_H(ctl-select,       "id on?"),
  BUILTINSYMBOLQ_H(ctl-repeat,       "id"),
  BUILTINSYMBOLQ_H(lst-enter,        "id sel"),
  BUILTINSYMBOLQ_H(lst-select,       "id sel"),
  BUILTINSYMBOLQ_H(pop-select,       "id list-id sel last-sel"),
  BUILTINSYMBOLQ_H(fld-enter,        "id"),
  BUILTINSYMBOLQ_H(fld-changed,      "id"),
  BUILTINSYMBOLQ_H(menu,             "id"),
  BUILTINSYMBOLQ_H(frm-open,         "id"),
  BUILTINSYMBOLQ_H(frm-update,       "id code"),
  BUILTINSYMBOLQ_H(frm-close,        "id"),
  BUILTINSYMBOLQ_H(scl-enter,        "id"),
  BUILTINSYMBOLQ_H(scl-repeat,       "id new old"),
  BUILTINSYMBOLQ_H(scl-exit,         "id new"),
  BUILTINSYMBOLQ_H(frm-title-enter,  "id"),
  BUILTINSYMBOLQ_H(frm-title-select, "id"),

  {NULL}
};

/**********************************************************************/
/* Bundle all functions from the module                               */
/* (Split in two frames to fit them all :-)                           */
/**********************************************************************/
BuiltInModule guiBuiltins = 
{
  MODULE_FUNC(NULL),
  {"frm-show",       NATIVE2(nativeFrmShow, tyGUI_ID, tyANY)},
  {"frm-get-focus",  NATIVE0(nativeFrmGetFocus)},
  {"frm-set-focus",  NATIVE1(nativeFrmSetFocus, tyGUI_ID)},
  {"frm-popup",      PRIMDEF(2, FRMD, -1, "[timeout] <id> <proc>")},
  {"frm-goto",       PRIMDEF(2, FRMG, -1, "[timeout] <id> <proc>")},
  {"frm-return",     PRIM1(1, FRMQ, "<any>")},
  {"frm-help",       NATIVE1(nativeFrmHelp, tyGUI_ID)},
  {"frm-get-prop",   NATIVE0(nativeFrmGetProp)},

  {"ctl-get-val",    NATIVE1(nativeCtlGetVal,   tyGUI_ID)},
  {"ctl-set-val",    NATIVE2(nativeCtlSetVal,   tyGUI_ID, tyANY)},
  {"ctl-hit",        NATIVE1(nativeCtlHit,      tyGUI_ID)},
  {"ctl-set-label",  NATIVE2(nativeCtlSetLabel, tyGUI_ID, tyANY)},
  {"ctl-get-label",  NATIVE1(nativeCtlGetLabel, tyGUI_ID)},

  {"scl-get-val",    NATIVE1(nativeSclGetVal, tyGUI_ID)},
  {"scl-set-val",    NATIVE2_H(nativeSclSetVal, tyGUI_ID, tyLIST, 
                               "<id> (curr min max page)")}, 

  {"lst-get-sel",    NATIVE1(nativeLstGetSel,   tyGUI_ID)},
  {"lst-set-sel",    NATIVE2(nativeLstSetSel,   tyGUI_ID, tySMALLINT)},
  {"lst-get-text",   NATIVE2(nativeLstGetTxt,   tyGUI_ID, tySMALLINT)},
  {"lst-set-list",   NATIVE2_H(nativeLstSetLst, tyGUI_ID, tyANY,
                              "<id> <list/strarr>")},

  {"fld-get-text",   NATIVE1(nativeFldGetTxt,   tyGUI_ID)},
  {"fld-set-text",   NATIVE2(nativeFldSetTxt,   tyGUI_ID, tyANY)},
  {"fld-get-scroll", NATIVE1(nativeFldGetScl,   tyGUI_ID)},
  {"fld-scroll",     NATIVE2(nativeFldScroll,   tyGUI_ID, tySMALLINT)},
  {"fld-dirty?",     NATIVE1(nativeFldDirty,    tyGUI_ID)},
  {"fld-set-dirty",  NATIVE2(nativeFldSetDirty, tyGUI_ID, tyANY)},
 
  {"fld-cut",        NATIVE1(nativeFldCut,   tyGUI_ID)},
  {"fld-copy",       NATIVE1(nativeFldCopy,  tyGUI_ID)},
  {"fld-paste",      NATIVE1(nativeFldPaste, tyGUI_ID)},
  {"fld-undo",       NATIVE1(nativeFldUndo,  tyGUI_ID)},

  {NULL}
};

BuiltInModule guiBuiltins2 = 
{
  MODULE_FUNC(NULL),
  {"pick-date",      NATIVE2(nativeSelectDate, tySTRING, FOREIGN(FT_DATE))},
  {"pick-time",      NATIVE2(nativeSelectTime, tySTRING, FOREIGN(FT_TIME))},
  {"pick-time-range",NATIVEV2_H(nativeSelectTimeRange, tySTRING, FOREIGN(FT_TIME),
                                "<string> <time> [<time>]")},
  {"pick-color",     NATIVE2(nativeSelectCol,  tySTRING, tyCOL_IDX)},

  {"own-gui",        PRIM1(1, GUI, "<boolean>")},
  {"event",          PRIM1(1, EVT, "<boolean>")},
  {"frm-alert",      NATIVEV1(nativeFrmAlert, tyGUI_ID)},

  {NULL}
};
