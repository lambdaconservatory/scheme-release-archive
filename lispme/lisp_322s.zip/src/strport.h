/**********************************************************************/
/*                                                                    */
/* strport.h: LISPME string port support                              */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 03.06.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_STRPORT_H
#define INC_STRPORT_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule strPortBuiltins; 

#endif
