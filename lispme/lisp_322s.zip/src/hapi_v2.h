/**********************************************************************/
/*                                                                    */
/* hapi_v2.h: Header for HandBase API version 2                       */
/*                                                                    */
/* Copied from original DDH hapi.h and renamed due to incompatible    */
/* changes in data structures from HBase V2 -> V3 :-(                 */
/*                                                                    */
/**********************************************************************/

#ifndef __HAPI_V2_H__
#define __HAPI_V2_H__

#if 0
// Use definition in hapi_v3.h
typedef enum {
                HapiGetDBNames = sysAppLaunchCmdCustomBase,
                HapiGetDBInfo,
                HapiGetFieldValue,
                HapiGetLinkInfo,
                HapiFindNextLinkedRecord,
                HapiSetFieldValue,
                HapiSetRecordValue,
                HapiAddRecord
} HapiCustomActionCodes;
#endif

#define HAPI_MAX_FIELDS_V2 30
#define HAPI_MAX_DBS_V2    60

// #define HAPI_MIN_VERSION 199

#if 0
// Use definition in hapi_v3.h
enum HAPIFIELDTYPES {
  HB_FIELD_NOT_USED,
  HB_STRING_FIELD,
  HB_DECIMAL_FIELD,
  HB_FLOAT_FIELD,
  HB_POPUP_FIELD,
  HB_CHECKBOX_FIELD,
  HB_UNIQUE_FIELD,
  HB_IMAGE_FIELD,
  HB_DATE_FIELD,
  HB_TIME_FIELD,
  HB_LINK_FIELD,
  HB_LINKED_FIELD,
  HB_NOTE_FIELD,
  HB_HEADING_FIELD,
  HB_LINKLIST_FIELD,
  HB_CALCULATED_FIELD
};
#endif

// For use with HapiGetDBInfo
typedef struct {
  int fieldtype;   // use HAPIFIELDTYPES enum
  unsigned char exportable;   // Whether to export and print this field (renamed FBI)
  unsigned char visible;  // Whether field is visible in Edit Record screen.
  int maxsize;            // Maximum size of this field in bytes.
  char fieldname[20];     // Name given to field
} HapiFieldDefType;

typedef struct {
  // input fields
  char dbname[20];   // name of db to look at.
  // output fields
  HapiFieldDefType fields[HAPI_MAX_FIELDS_V2];   // field definition information
  UInt16 numrecs;      // number of records in database.
} HapiFieldsDefTypeV2;


// For use with HapiGetDBNames
typedef struct {
  // output type
  char dbnames[HAPI_MAX_DBS_V2][20];  // Names of databases
  int numdbs;                      // Number of databases.
} HapiDBListTypeV2;


// For use with HapiGetFieldValue and HapiSetFieldValue
typedef struct {
  // input variables
  char dbname[20];   // name of db to look at
  UInt16 recnum;       // number of record to retrieve.
  int maxsizeofvalue;    // maximum size defined of the outvalue pointer below.
  int fieldnum;      // field number to retrieve
  // output variables for Get and input for Set routine.
  char *outvalue;  // For HapiGetFieldValue - returned value of record.  You must make sure to allocate at least maxsizeofvalue before calling HanDBase!
} HapiFieldValueTypeV2;

//(For use with HapiSetRecord and HapiAddRecord
typedef struct {
  // input variables
  char dbname[20];   // name of db to look at
  UInt16 recnum;       // number of record to set (N/A for Add Record)
  char *fieldvalues[HAPI_MAX_FIELDS_V2];
} HapiRecordValueTypeV2;

// For use with HapiGetLinkInfo
typedef struct {
  // input variables
  char dbname[20];   // name of db to look at
  UInt16 recnum;       // number of record to retrieve.
  int fieldnum;      // field number to retrieve
  // output variables
  char linkeddatabasename[20];  // returns the name of the database that is linked to
  int linkedfieldnum;  // returns the field number of the linked field
  unsigned char outvalue[24];  // returned value of link field.
} HapiLinkInfoTypeV2;

// For use with HapiFindNextLinkedRecord
typedef struct {
  // input variables
  char dbname[20];   // name of db to look at
  int fieldnum;      // field number of linked field
  int maxsizeofvalue;    // maximum size defined of the outvalue pointer below.
  int newsearch;        // set to 1 if this is a new search- HanDBase will start from the beginning if true.
  unsigned char linkvalue[24];  // returned value of link field.  You must make sure to allocate at least 24 bytes for this.
  // input and output
  UInt16 recnum;       // number of record to start looking from. And record that has the match.
  // output variables
  char *outvalue;  // returned value of linked record.  You must make sure to allocate at least maxsizeofvalue bytes for this.
} HapiLinkedRecordInfoTypeV2;

#endif
