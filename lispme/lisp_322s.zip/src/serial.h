/**********************************************************************/
/*                                                                    */
/* serial.h: LISPME serial port support                               */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 31.01.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_SERIAL_H
#define INC_SERIAL_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule serialBuiltins; 

#endif
