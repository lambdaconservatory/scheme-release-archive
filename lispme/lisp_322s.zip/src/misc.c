/**********************************************************************/
/*                                                                    */
/* misc.c: LISPME miscellaneous native functions                      */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "misc.h"
#include "vm.h"
#include "io.h"
#include "util.h"
#include "LispMe.h"
#include "comp.h"
#include "fpstuff.h"
#include "arith.h"
#include <DLServer.h>

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
/* #define LET  MKPRIMSYM(MISC_MODULE, 1) defined in store.h */
#define LET_AST MKPRIMSYM(MISC_MODULE, 2)
#define WHILE   MKPRIMSYM(MISC_MODULE, 4)
#define PSET    MKPRIMSYM(MISC_MODULE, 5)

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void init(ModuleMessage mess)                           SEC(MOD); 
static void strArrPrinter(Boolean machineFormat, void* p)      SEC(MOD);
static void strArrMemHook(MemMessage mess, PTR obj)            SEC(MOD);

static PTR  nativeGC(PTR* args)                                SEC(MOD);
static PTR  nativeGenSym(PTR* args)                            SEC(MOD);
static PTR  nativeSound(PTR* args)                             SEC(MOD);
static PTR  nativeWait(PTR* args)                              SEC(MOD);
static PTR  nativeMessage(PTR* args)                           SEC(MOD);
static PTR  nativeError(PTR* args)                             SEC(MOD);
static PTR  nativeCrash(PTR* args)                             SEC(MOD);
static PTR  nativeBatteryInfo(PTR* args)                       SEC(MOD);
static PTR  nativeHotsyncInfo(PTR* args)                       SEC(MOD);
static PTR  nativeROMVersion(PTR* args)                        SEC(MOD);
static PTR  nativeSerialNumber(PTR* args)                      SEC(MOD);
static PTR  nativeGetClipboardText(PTR* args)                  SEC(MOD);
static PTR  nativeSetClipboardText(PTR* args)                  SEC(MOD);
static PTR  nativeMakeStrArr(PTR* args)                        SEC(MOD);
static PTR  nativeStrArrRef(PTR* args)                         SEC(MOD);
static PTR  nativeStrArrLength(PTR* args)                      SEC(MOD);
static PTR  nativeGetPreference(PTR* args)                     SEC(MOD);
static PTR  nativeSetPreference(PTR* args)                     SEC(MOD);
static PTR  nativeClearOutfield(PTR* args)                     SEC(MOD);

static PTR  compExecEval(PTR expr, PTR names, PTR* code)      SEC(COMP);
static PTR  compileWhile(PTR expr, PTR names, PTR* code)      SEC(COMP);
static PTR  compileParSet(PTR expr, PTR names, PTR* code)     SEC(COMP);
static PTR  compileLetAsterix(PTR expr, PTR names, PTR* code) SEC(COMP);
static PTR  compileDo(PTR expr, PTR names, PTR* code)         SEC(COMP);

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START:
      registerTypename(FT_STR_ARR, "string array");
      registerPrinter (FT_STR_ARR, strArrPrinter);
      registerMemHook (FT_STR_ARR, strArrMemHook);
      break;

    case INIT_HEAP: 
      /*--------------------------------------------------------------*/ 
      /* Reset gensym counter                                         */ 
      /*--------------------------------------------------------------*/ 
      pMemGlobal->symCnt = 0;
      break;

    default:
  }
}

/**********************************************************************/
/* String array foreign type                                          */
/**********************************************************************/
static void strArrPrinter(Boolean machineFormat, void* p)
{
  Int32 *ss = (Int32*)p;
  outStr("[strarr ");
  StrIToA(token, ss[0]);
  outStr(token);
  outStr("]");
}

static void strArrMemHook(MemMessage mess, PTR obj)
{
  UInt16 i, n;
  char **ss;
  
  switch (mess) {
    case MEM_MARK:
      break;

    case MEM_DELETE:
      MemPtrFree(FOREIGNVAL(obj));
      break;

    case MEM_UNPICKLE:
      /*--------------------------------------------------------------*/
      /* Replace string offsets by pointers                           */
      /*--------------------------------------------------------------*/ 
      standardUnpickle(obj);
      ss = FOREIGNVAL(obj);
      n  = (Int32)ss[0];
      for (i=0; i<n; i++)
        ss[i+1] = (char*)ss + (Int32)ss[i+1];
      break;

    case MEM_PICKLE:
      /*--------------------------------------------------------------*/
      /* Replace string pointers by offsets                           */
      /*--------------------------------------------------------------*/ 
      ss = FOREIGNVAL(obj);
      n  = (Int32)ss[0];
      for (i=0; i<n; i++)
        ss[i+1] = (char*)(ss[i+1] - (char*)ss);
      standardPickle(obj);
      break;
  }
}

/**********************************************************************/
/* Create string array                                                */
/**********************************************************************/
PTR makeStrArr(PTR items)
{
  PTR    l;
  UInt16 i, len;
  char   **ss, *s;
  UInt32 n; // to force long arithmetic and recognize alloc failures

  /*------------------------------------------------------------------*/ 
  /* count total size, so all strings can be allocated together       */
  /*------------------------------------------------------------------*/ 
  for (i=0, n=0, len=0, l=items; l!=NIL; ++n, l=cdr(l)) {
    printSEXP(car(l), 0, &portConv);
    len += StrLen(msg);
  }

  if ((ss=MemPtrNew((n+1)*sizeof(void*) + len + n)) == 0)
    ErrThrow(ERR_M7_NO_RECORD_MEM);

  ss[0] = (char*)(Int32)n;
  s = (char*)(ss + (n+1));

  for (i=0, l=items; l!=NIL; ++i, l=cdr(l)) {
    printSEXP(car(l), 0, &portConv);
    StrCopy(s, msg);
    ss[i+1] = s;
    s += StrLen(msg) + 1;
  }
  return allocForeign(ss, FT_STR_ARR);
}

static PTR nativeMakeStrArr(PTR* args)
{
  return makeStrArr(args[0]);
}

/**********************************************************************/
/* Retrieve a string from a string array                              */
/**********************************************************************/
static PTR nativeStrArrRef(PTR* args)
{
  char **ss = (char**)FOREIGNVAL(args[0]);
  UInt16 i  = getUInt16(args[1]);
  UInt16 n  = (Int32)(ss[0]);
  
  if (i >= n)
    error1(ERR_R2_INVALID_INDEX, args[1]);

  return str2Lisp(ss[i+1]);
}

/**********************************************************************/
/* Determine length of a string array                                 */
/**********************************************************************/
static PTR nativeStrArrLength(PTR* args)
{
  char **ss = (char**)FOREIGNVAL(args[0]);
  return makeNum((Int32)ss[0]);
}

/**********************************************************************/
/* Expicitly invoke garbage collection                                */
/**********************************************************************/
static PTR nativeGC(PTR* args)
{
  gc(NIL, NIL); 
  return NOPRINT;
}

/**********************************************************************/
/* create a new unique symbol                                         */
/**********************************************************************/
static PTR nativeGenSym(PTR* args)
{
  msg[0] = '#';
  msg[1] = 'g';
  StrIToA(msg+2,pMemGlobal->symCnt++);
  return findAtom(msg,true);
}

/**********************************************************************/
/* Disassemble a closure or macro                                     */
/**********************************************************************/
static PTR nativeDisasm(PTR* args)
{
  if (!IS_CONS(args[0]) || car(args[0]) != CLOS_TAG)
    if (!IS_CONS(args[0]) || car(args[0]) != MACR_TAG)
      typeError(args[0],"procedure");
    else
      return cadddr(args[0]);
  else
    return caddr(args[0]);
}
 
/**********************************************************************/
/* Play a sound                                                       */
/**********************************************************************/
static PTR nativeSound(PTR* args)
{
  Int16 freq = getInt16(args[0]);
  Int16 dur  = getInt16(args[1]);
  struct SndCommandType cmd;

  if (dur < 0)
    parmError(args[1],"sound");
  if (freq < 1)
    parmError(args[0],"sound");
  cmd.cmd    = sndCmdFreqDurationAmp;
  cmd.param1 = freq;
  cmd.param2 = dur;
  cmd.param3 = sndMaxAmp;
  SndDoCmd((void*)0, &cmd, false);
  YIELD();
  return NOPRINT;
}

/**********************************************************************/
/* Wait for some time                                                 */
/**********************************************************************/
static PTR nativeWait(PTR* args)
{
  Int32 ticks = getInt32(args[0])*sysTicksPerSecond/1000L;
  if (ticks>0) {
    ReleaseMem();
    SysTaskDelay(ticks);
    GrabMem();
  }
  YIELD();
  return args[0];
}

/**********************************************************************/
/* Display a user message                                             */
/**********************************************************************/
static PTR nativeMessage(PTR* args)
{
  printSEXP(args[0], 0, &portMsg);
  ReleaseMem();
  FrmCustomAlert(ERR_USER_INFO, msg, "", "");
  GrabMem();
  return args[0];
}

/**********************************************************************/
/* Display a user error                                               */
/**********************************************************************/
static PTR nativeError(PTR* args)
{
  error1(ERR_USER_ERROR, args[0]);
  return NOPRINT; /* not reached */
}

/**********************************************************************/
/* Crash the device (by accessing an odd address, just for debugging) */
/**********************************************************************/
static PTR nativeCrash(PTR* args)
{
  return *((int*)1);
}

/**********************************************************************/
/* Retrieve battery info                                              */
/**********************************************************************/
static PTR nativeBatteryInfo(PTR* args)
{ 
  UInt16 curr, warn, crit, tick;
  SysBatteryKind kind;
  Boolean plug;
  UInt8 perc;
  PTR res = NIL;

  curr = SysBatteryInfo(false, &warn, &crit, &tick, &kind, &plug, &perc);

  PROTECT(res);
  res = cons(MKINT(perc), res);
  res = cons(plug ? TRUE : FALSE, res);
  res = cons(MKINT(kind), res);
  res = cons(makeUNum(tick), res);
  res = cons(allocReal(divDouble(longToDouble(crit), 100.0)), res);
  res = cons(allocReal(divDouble(longToDouble(warn), 100.0)), res);
  res = cons(allocReal(divDouble(longToDouble(curr), 100.0)), res);
  UNPROTECT(res); 
  return res;
}

/**********************************************************************/
/* Retrieve hotsync info                                              */
/**********************************************************************/
static PTR nativeHotsyncInfo(PTR* args)
{ 
  UInt32 succ, last;
  DlkSyncStateType state;
  PTR res = NIL;

  DlkGetSyncInfo(&succ, &last, &state, token, NULL, NULL); 
  PROTECT(res);
  res = cons(MKINT(state), res);
  res = cons(allocForeign((void*)last, FT_TIMESTAMP), res);
  res = cons(allocForeign((void*)succ, FT_TIMESTAMP), res);
  res = cons(str2Lisp(token), res);
  UNPROTECT(res); 
  return res;
}

/**********************************************************************/
/* Retrieve ROM version                                               */
/**********************************************************************/
static PTR nativeROMVersion(PTR* args)
{
  UInt32 ver;
  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &ver);
  StrIToH(token, ver);
  return str2Lisp(token);
}

/**********************************************************************/
/* Retrieve serial number                                             */
/**********************************************************************/
static PTR nativeSerialNumber(PTR* args)
{
  UInt8* buf;
  UInt16 len;
  if (!SysGetROMToken(0, sysROMTokenSnum, &buf, &len) &&
      buf && *buf != 0xff) 
    return copyString(len,buf);
  else
    return FALSE;  
}

/**********************************************************************/
/* Get system preference                                              */
/**********************************************************************/
static PTR nativeGetPreference(PTR* args)
{
  return makeUNum(PrefGetPreference(INTVAL(args[0])));
}

/**********************************************************************/
/* Set system preference                                              */
/**********************************************************************/
static PTR nativeSetPreference(PTR* args)
{
  PrefSetPreference(INTVAL(args[0]),getUInt32(args[1]));
  return args[0];
}

/**********************************************************************/
/* Clear output field                                                 */
/**********************************************************************/
static PTR nativeClearOutfield(PTR* args)
{
  portOutField->pos=0;
  printSEXP(EMPTY_STR, 0, portOutField);
  return NOPRINT;
}


/**********************************************************************/
/* Get clipboard text                                                 */
/**********************************************************************/
static PTR nativeGetClipboardText(PTR* args)
{
  UInt16 len = 0;
  MemHandle handle = ClipboardGetItem(clipboardText, &len);
  char *s;
  PTR res;
  if (handle == NULL)
    return FALSE;
  s = MemHandleLock(handle);
  res = copyString(len, s);
  MemHandleUnlock(handle);
  return res;
}

/**********************************************************************/
/* Set clipboard text                                                 */
/**********************************************************************/
static PTR nativeSetClipboardText(PTR* args)
{
  UInt16 len;
  printSEXP(args[0], 0, &portConv);
  len = StrLen(msg);
  if (args[1] != FALSE)
    ClipboardAppendItem(clipboardText, msg, len);
  else
    ClipboardAddItem(clipboardText, msg, len);
  return args[0];
}

/**********************************************************************/
/* Launch an application                                              */
/**********************************************************************/
Boolean launchApp(PTR appId)
{
  if (appId == MKINT(0)) {
    /* Start system application launcher */
    EventType ev;
    ev.eType = keyDownEvent;
    ev.data.keyDown.chr = launchChr;
    ev.data.keyDown.modifiers = commandKeyMask;
    EvtAddEventToQueue(&ev);
    return true;
  }
  else {
    DmSearchStateType state;
    UInt16            card;
    LocalID           app;

    EXT_TCHECK(tySTRING, appId, "launch", 0);
    printSEXP(appId, 0, &portMsg);

    ReleaseMem();
    if (DmGetNextDatabaseByTypeCreator(true, &state, sysFileTApplication,
                                       *((UInt32*)msg), true, &card, &app))
      error1(ERR_R17_OPEN_FILE, appId);
    SysUIAppSwitch(card, app, sysAppLaunchCmdNormalLaunch, 0);
    return false;
  }
}

/**********************************************************************/
/* Compiler extension: eval                                           */
/**********************************************************************/
static PTR compExecEval(PTR expr, PTR names, PTR* code)
{
  if (IS_PRIMSYM(expr)) {
    /*----------------------------------------------------------------*/
    /* We are called from exec() (EXEC and EVAL already have been     */
    /* removed from the code list)                                    */
    /* (ex.s) e (na.c) d --> NIL e compile(ex,na) (s e c.d)           */
    /*----------------------------------------------------------------*/
    D = cons3(cdr(S), E, cdr(C), D);
    C = compile(car(S), car(C));
    S = NIL;
    return NIL;
  }
  else {
    /*----------------------------------------------------------------*/
    /* We are called from compile()                                   */
    /* (eval ex) ==> [ex] EXEC EVAL names                             */
    /*----------------------------------------------------------------*/
    if (listLength(expr) != 2)
      error1(ERR_C2_NUM_ARGS, car(expr));
    *code = cons3(MKINT(EXEC), car(expr), names, *code);
    return cadr(expr);
  }
}

/**********************************************************************/
/* Compiler extension: while                                          */
/**********************************************************************/
static PTR compileWhile(PTR expr, PTR names, PTR* code)
{
  PTR temp1, temp2;
  /*------------------------------------------------------------------*/
  /* (while e1 e2 ...) ==> [e1] DOLO ([e2] ... [e1] JOIN)             */
  /*------------------------------------------------------------------*/
  if (listLength(expr) < 2)
    error1(ERR_C2_NUM_ARGS, car(expr));
  temp1 = joinCont;                                       PROTECT(temp1)
  *listCopy(&temp2,cddr(expr),ALL_ELEMENTS) = list1(cadr(expr)); PROTECT(temp2)
  compseq(temp2,names,&temp1);
  *code = cons2(MKINT(DOLO),temp1,*code);
  UNPROTECT(temp2)
  UNPROTECT(temp1)
  return cadr(expr);
}

/**********************************************************************/
/* Compiler extension: parallel set!                                  */
/**********************************************************************/
static PTR compileParSet(PTR expr, PTR names, PTR* code)
{
  PTR args = cdr(expr);
  int argl = listLength(args);
  PTR temp;
  static LEXADR la;

  /*------------------------------------------------------------------*/
  /* (pset! (v1 ...) e1 ...) ==> [e1] ... MSET (addr(v1) ...)         */
  /*------------------------------------------------------------------*/
  if (argl < 1 || argl-1 != listLength(car(args)))
    error1(ERR_C2_NUM_ARGS, car(expr));
  *code = cons(NIL, *code);
  for (temp = reverse(car(args)); temp != NIL; temp = cdr(temp)) {
    if (!IS_SYM(car(temp)))
      error1(ERR_C3_NOT_SYMBOL, car(temp));
    else if (IS_PRIMSYM(car(temp)) &&
             BUILTIN(car(temp))->kind != KIND_SYMBOL)
      error1(ERR_C12_KEYWORD,car(temp));
    la = location(car(temp),names,true,NULL);
    car(*code) = cons(MKINT(la), car(*code));
  }
  *code = cons(MKINT(MST),*code);
  for (args = cdr(args); args != NIL; args = cdr(args))
    comp(car(args), names, code);
      
  return BLACK_HOLE;
}

/**********************************************************************/
/* Compiler extension: let*                                           */
/**********************************************************************/
static PTR compileLetAsterix(PTR expr, PTR names, PTR* code)
{
  PTR args = cdr(expr);
  PTR newExpr;

  /*------------------------------------------------------------------*/
  /* (let* ((v1 e1) (v2 e2) ...) e1' ...) ==>                         */
  /*   (let ((v1 e1)) (let* ((v2 e2) ...) e1'...)                     */
  /*------------------------------------------------------------------*/
  if (listLength(args) < 2)
    error1(ERR_C2_NUM_ARGS, car(expr));
  if (!hasType(tyPROPLIST, car(args)))
    error1(ERR_C8_INV_LET_LIST, car(args));
  if (listLength(car(args)) <= 1)
    newExpr = cons(LET,args);
  else
    newExpr = list3(LET, list1(caar(args)),
                cons2(LET_AST, cdar(args), cdr(args)));
  PROTECT(newExpr);
  comp(newExpr, names, code);
  UNPROTECT(newExpr);
  return BLACK_HOLE;
}

/**********************************************************************/
/* Compiler extension: do                                             */
/**********************************************************************/
static PTR compileDo(PTR expr, PTR names, PTR* code)
{
  PTR args = cdr(expr);
  PTR temp = NIL, bind, vars, steps, init, rets, newExpr;
  PTR loop = nativeGenSym(NULL);    

  /*------------------------------------------------------------------*/
  /* (do ((v1 e1 s1) ...) (c r ...) e1' ...) ==>                      */
  /*>> This is WRONG: RxRS states that the variables have to be       */
  /*>> rebound, not assigned to!                                      */
  /* (let ((v1 e1) ...) (while (not c) e1' ...                        */
  /*                           (pset! (v1 ...) s1 ...)) r ...)        */
  /*>> The correct translation is                                     */
  /* (letrec ((loop (lambda (v1 ...)                                  */
  /*           (if c (begin r ...)                                    */
  /*                 (begin e1' ... (loop s1 ...)))))) (loop e1 ...)) */
  /*------------------------------------------------------------------*/
  if (listLength(args) < 2)
    error1(ERR_C2_NUM_ARGS, car(expr));
  if (!hasType(tyPROPLIST, car(args)))
    error1(ERR_C8_INV_LET_LIST, car(args));
  if (!IS_CONS(cadr(args)))
    ErrThrow(ERR_C10_EMPTY_SEQUENCE);

  /*------------------------------------------------------------------*/
  /* lists are constructed in reverse order, but this doesn't matter! */
  /*------------------------------------------------------------------*/
  steps = vars = init = NIL;
  PROTECT(steps);
  PROTECT(vars);
  PROTECT(init);
  PROTECT(rets);
  for (bind = car(args); bind != NIL; bind = cdr(bind)) {
    PTR v = car(bind);
    switch (listLength(v)) {
      case 3:
        steps = cons(caddr(v),steps);
        break;
 
      case 2:
        steps = cons(car(v),steps);
        break;
      
      default:
        error1(ERR_C4_INVALID_BIND, v);
    }
    vars  = cons(car(v),vars);
    init  = cons(cadr(v),init);
  }
  PROTECT(temp);
  *listCopy(&temp, cddr(args), ALL_ELEMENTS) = list1(cons(loop, steps));
  // empty (begin) creates error, so use #n here
  rets = cdadr(args) == NIL ? NOPRINT : cons(BEGIN, cdadr(args));
  newExpr = list3(LETREC,
                  list1(list2(loop, 
                              list3(LAMBDA, 
                                    vars,
                                    list4(IF, caadr(args),
                                          rets,
                                          cons(BEGIN, temp))))),
                  cons(loop, init));
  PROTECT(newExpr);
  /*------------------------------------------------------------------*/
  /* To view the macro expansion, simply replace the next statement by*/
  /* compConst(newExpr, code);                                        */
  /*------------------------------------------------------------------*/
  comp(newExpr, names, code);

  UNPROTECT(temp);
  UNPROTECT(newExpr);
  UNPROTECT(rets);
  UNPROTECT(init);
  UNPROTECT(vars);
  UNPROTECT(steps);
  return BLACK_HOLE;
}

/**********************************************************************/
/* Compiler extension: named let                                      */
/**********************************************************************/
static PTR compileNamedLet(PTR expr, PTR names, PTR* code)
{
  PTR args = cdr(expr);
  PTR bind, vars = NIL, init = NIL;
  PTR newExpr;

  /*------------------------------------------------------------------*/
  /* (let tag ((v1 e1) ...) e1' ...) ==>                              */
  /*   ((letrec ((tag (lambda (v1 ...) e1' ...))) tag) e1 ...)        */
  /*------------------------------------------------------------------*/
  if (listLength(args) < 2 ||
      !IS_SYM(car(args)) ||
      !hasType(tyPROPLIST, cadr(args)))
    return W = cons(LET_TAG, args); // try the internal LET
  else {
    for (bind = cadr(args); bind != NIL; bind = cdr(bind)) {
      PTR v = car(bind);
      if (listLength(v) != 2)
        error1(ERR_C4_INVALID_BIND, v);
      vars  = cons(car(v),vars);
      init  = cons(cadr(v),init);
    }

    // Now here is variable order important, as user calls the loop
    newExpr = cons(list3(LETREC,
                         list1(list2(car(args), 
                                     cons2(LAMBDA, 
                                           reverse(vars),
                                           cddr(args)))),
                         car(args)),
                   reverse(init));
    PROTECT(newExpr);
    /*------------------------------------------------------------------*/
    /* To view the macro expansion, simply replace the next statement by*/
    /* compConst(newExpr, code);                                        */
    /*------------------------------------------------------------------*/
    // compConst(newExpr, code);                                    
    comp(newExpr, names, code);

    UNPROTECT(newExpr);
  }
  return BLACK_HOLE;
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule miscBuiltins = 
{
  MODULE_FUNC(init),
  BUILTINCOMPKEY("let",   compileNamedLet,   "[tag] ((var exp)* ) exp+"),
  BUILTINCOMPKEY("let*",  compileLetAsterix, "((var exp)* ) exp+"),
  BUILTINCOMPKEY("eval",  compExecEval,      "exp"),
  BUILTINCOMPKEY("while", compileWhile,      "test exp*"),
  BUILTINCOMPKEY("pset!", compileParSet,     "(var*) exp*"),
  BUILTINCOMPKEY("do",    compileDo,         "((var init [step])* ) (test exp*) exp'*"),
  {"gc",                 NATIVE0(nativeGC)},
  {"gensym",             NATIVE0(nativeGenSym)},
  {"disasm",             NATIVE1(nativeDisasm,  tyANY)},
  {"sound",              NATIVE2(nativeSound,   tyINT, tyINT)},
  {"wait",               NATIVE1(nativeWait,    tyINT)},
  {"message",            NATIVE1(nativeMessage, tyANY)},
  {"error",              NATIVE1(nativeError,   tyANY)},
  {"launch",             PRIMDEF(0, LNCH, 0, "[<string>]")},
  {"crash",              NATIVE0(nativeCrash)},
  {"battery-info",       NATIVE0(nativeBatteryInfo)},
  {"hotsync-info",       NATIVE0(nativeHotsyncInfo)},
  {"rom-version",        NATIVE0(nativeROMVersion)},
  {"serial-number",      NATIVE0(nativeSerialNumber)},
  {"get-clipboard-text", NATIVE0(nativeGetClipboardText)},
  {"set-clipboard-text", NATIVE2(nativeSetClipboardText, tyANY, tyBOOL)},
  {"make-strarr",        NATIVE1(nativeMakeStrArr,  tyPROPLIST)},
  {"strarr-ref",         NATIVE2(nativeStrArrRef, FOREIGN(FT_STR_ARR), tyINDEX)},
  {"strarr-length",      NATIVE1(nativeStrArrLength, FOREIGN(FT_STR_ARR))},
  {"get-sys-pref",       NATIVE1(nativeGetPreference, tySMALLINT)},
  {"set-sys-pref",       NATIVE2(nativeSetPreference, tySMALLINT, tyINT)},
  {"clear-output-field", NATIVE0(nativeClearOutfield)},
  {NULL}
};
