/**********************************************************************/
/*                                                                    */
/* vfs.c: LISPME virtual file system support                          */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 23.11.2003 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "vfs.h"
#include "util.h"
#include "arith.h"
#include "io.h"
#include "vm.h"
#include "LispMe.h"
#include <VFSMgr.h>

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define VFS_BUF_SIZE 4096

/**********************************************************************/
/* Local types                                                        */
/**********************************************************************/
typedef struct {
  FileRef fp;
  UInt16  vol;
  UInt16  mode;
  PTR     name;
  UInt32  pos;
} VirtFile;

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/

/**********************************************************************/
/* Local data                                                         */
/**********************************************************************/
static Boolean vfsOK;

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void    init(ModuleMessage mess)                       SEC(MISC); 
static void    vfsMemHook(MemMessage mess, PTR ptr)           SEC(MISC);
static void    vfsPrinter(Boolean machineFormat, void* p)     SEC(MISC);
static void    writeVfs(WriterCmd cmd, OutPort* outp)         SEC(MISC);
static Boolean readVfs(ReaderCmd cmd, InPort* inp)            SEC(MISC);
static VirtFile* openFile(UInt16 vol, PTR fName, UInt16 mode) SEC(MISC);
static Err     readIntoString(FileRef fref, PTR str,
                              UInt32* nReadP)                 SEC(MISC);
static PTR     nativeOK(PTR* args)                            SEC(MISC);
static PTR     nativeVolumes(PTR* args)                       SEC(MISC);
static PTR     nativeVolSize(PTR* args)                       SEC(MISC);
static PTR     nativeVolGetLabel(PTR* args)                   SEC(MISC);
static PTR     nativeVolSetLabel(PTR* args)                   SEC(MISC);
static PTR     nativeVolInfo(PTR* args)                       SEC(MISC);
static PTR     nativeDir(PTR* args)                           SEC(MISC);
static PTR     nativeGetAttr(PTR* args)                       SEC(MISC);
static PTR     nativeSetAttr(PTR* args)                       SEC(MISC);
static PTR     nativeGetTS(PTR* args)                         SEC(MISC);
static PTR     nativeSetTS(PTR* args)                         SEC(MISC);
static PTR     nativeTell(PTR* args)                          SEC(MISC);
static PTR     nativeSeek(PTR* args)                          SEC(MISC);
static PTR     nativeSize(PTR* args)                          SEC(MISC);
static PTR     nativeEOF(PTR* args)                           SEC(MISC);
static PTR     nativeRename(PTR* args)                        SEC(MISC);
static PTR     nativeFOpen(PTR* args)                         SEC(MISC);
static PTR     nativeFClose(PTR* args)                        SEC(MISC);
static PTR     nativeFRead(PTR* args)                         SEC(MISC);
static PTR     nativeFWrite(PTR* args)                        SEC(MISC);
static PTR     nativeCreDir(PTR* args)                        SEC(MISC);
static PTR     nativeOpenInput(PTR* args)                     SEC(MISC);
static PTR     nativeOpenOutput(PTR* args)                    SEC(MISC);

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  UInt32 vfsMgrVersion;

  switch (mess)
  {
    case APP_START: 
      /*--------------------------------------------------------------*/
      /* Check for availability of routines                           */
      /*--------------------------------------------------------------*/
      vfsOK = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &vfsMgrVersion) == 0;

      /*--------------------------------------------------------------*/
      /* Register hooks for VFS file ref datatype                     */
      /*--------------------------------------------------------------*/
      registerMemHook(FT_VFS_FILE,  vfsMemHook);
      registerTypename(FT_VFS_FILE, "vfs ref");
      registerPrinter(FT_VFS_FILE, vfsPrinter);

      /*--------------------------------------------------------------*/
      /* Register hooks for port layer                                */
      /*--------------------------------------------------------------*/
      registerReadFct(PT_VFS, readVfs);
      registerWriteFct(PT_VFS, writeVfs);
      break;

    case APP_STOP:
      break;

    case INIT_HEAP: 

    case SESS_CONNECT: 
      break;

    default:
  }
}

/**********************************************************************/
/* The memory hook function VFS file references                       */
/**********************************************************************/
static void vfsMemHook(MemMessage mess, PTR ptr) 
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(ptr);

  switch (mess) {
    case MEM_MARK:
      mark(vf->name);
      break;

    case MEM_DELETE: 
      if (vf->fp != vfsInvalidFileRef) {
        VFSFileClose(vf->fp);
        vf->fp = vfsInvalidFileRef;
      }
      break;

    case MEM_PICKLE:
      /*--------------------------------------------------------------*/
      /* Close file and pickle                                        */
      /*--------------------------------------------------------------*/
      if (vfsOK && vf->fp != vfsInvalidFileRef) {
        VFSFileTell(vf->fp, &vf->pos);
        VFSFileClose(vf->fp);
      } 
      else
        vf->name = FALSE;
      vf->fp = vfsInvalidFileRef;
      standardPickle(ptr);
      break;

    case MEM_UNPICKLE:
      /*--------------------------------------------------------------*/
      /* Unpickle and re-open                                         */
      /*--------------------------------------------------------------*/
      standardUnpickle(ptr);
      vf = (VirtFile*)FOREIGNVAL(ptr);
      if (vfsOK && vf->name != FALSE) {
        printString(vf->name);
        VFSFileOpen(vf->vol, msg, vf->mode, &vf->fp);
        VFSFileSeek(vf->fp, vfsOriginBeginning, vf->pos);
      }
      break;

    default:
  }
}

/**********************************************************************/
/* Print VFS reference                                                */
/**********************************************************************/
static void vfsPrinter(Boolean machineFormat, void* p)
{
  VirtFile* vf = (VirtFile*)p;
  if (vf->fp == vfsInvalidFileRef)
    outStr("[\254file]");
  else {
    outStr("[file ");
    writeSEXP(vf->name);
    outStr("]");
  }
}

/**********************************************************************/
/* Read a block of data into an existing string                       */
/**********************************************************************/
static Err readIntoString(FileRef fref, PTR str, UInt32* nReadP)
{
  UInt16    index   = ARR_INDEX(str);
  MemHandle recHand = DmGetRecord(dbRef, index);
  char*     mem     = ArrayHandleLock(recHand);
  Err       rc      = VFSFileRead(fref, ArrayHandleSize(recHand),
                                  mem, nReadP);
  ArrayHandleUnlock(recHand);
  DmReleaseRecord(dbRef, index, true);
  return rc;
}

/**********************************************************************/
/* Read from a VFS file                                               */
/**********************************************************************/
static Boolean readVfs(ReaderCmd cmd, InPort* inp)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(inp->impl);
  UInt32    nRead;
  Err       rc;

  switch (cmd) {
    case RC_READ: 
      rc = readIntoString(vf->fp, inp->buf, &nRead); 
      inp->bufLen = nRead;
      return (rc==errNone || rc==vfsErrFileEOF) && nRead != 0; 

    case RC_CLOSE: 
      VFSFileClose(vf->fp);
      vf->fp      = vfsInvalidFileRef;
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL;
      inp->impl   = NIL;
      return true;
  }
}

/**********************************************************************/
/* Write to a VFS file                                                */
/**********************************************************************/
static void writeVfs(WriterCmd cmd, OutPort* outp)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(outp->impl);
  switch (cmd) {
    case WC_WRITE:
      VFSFileWrite(vf->fp, outp->pos, outp->mem, NULL);
      outp->pos = 0;
      break;
    
    case WC_CLOSE:
      VFSFileClose(vf->fp);
      vf->fp = vfsInvalidFileRef;
      outp->flags |= OPF_CLOSED;
      break;
  }
}

/**********************************************************************/
/* Do VFS routines exist?                                             */
/**********************************************************************/
static PTR nativeOK(PTR* args)
{
  return vfsOK ? TRUE : FALSE;
}

/**********************************************************************/
/* Retrieve list of all mounted volumes                               */
/**********************************************************************/
static PTR nativeVolumes(PTR* args)
{
  UInt16 volume  = vfsInvalidVolRef;
  UInt32 volIter = vfsIteratorStart;
  PTR    res = NIL;
  PTR*   d   = &res;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  PROTECT(res);
  while (volIter != vfsIteratorStop) {
    if (VFSVolumeEnumerate(&volume, &volIter))
      break;
    *d = cons(MKINT(volume), NIL);
    d = &cdr(*d);
  }
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Retrieve volume sizes                                              */
/**********************************************************************/
static PTR nativeVolSize(PTR* args)
{
  UInt32 used, total;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSVolumeSize(INTVAL(args[0]), &used, &total) == errNone ?
         list2(W=makeUNum(used), W=makeUNum(total)) : FALSE;
}

/**********************************************************************/
/* Retrieve volume label                                              */
/**********************************************************************/
static PTR nativeVolGetLabel(PTR* args)
{
  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSVolumeGetLabel(INTVAL(args[0]), msg,
                           MEMO_OUTPUT_SIZE) == errNone ?
         str2Lisp(msg) : FALSE;
}

/**********************************************************************/
/* Set volume label                                                   */
/**********************************************************************/
static PTR nativeVolSetLabel(PTR* args)
{
  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  printString(args[1]);
  return VFSVolumeSetLabel(INTVAL(args[0]), msg) == errNone ?
         TRUE : FALSE;
}

/**********************************************************************/
/* Retrieve volume info                                               */
/**********************************************************************/
static PTR nativeVolInfo(PTR* args)
{
  VolumeInfoType  vInfo;
  PTR             res = NIL;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  if (VFSVolumeInfo(INTVAL(args[0]), &vInfo) != 0)
    return FALSE;
  else {
    PROTECT(res);
    res = cons(make4Byte(vInfo.mediaType), res);
    res = cons(makeUNum(vInfo.slotRefNum), res);
    res = cons(makeUNum(vInfo.slotLibRefNum), res);
    res = cons(make4Byte(vInfo.mountClass), res);
    res = cons(make4Byte(vInfo.fsCreator), res);
    res = cons(make4Byte(vInfo.fsType), res);
    res = cons(makeUNum(vInfo.attributes), res);
    UNPROTECT(res); 
    return res;
  }
}

/**********************************************************************/
/* Retrieve list of all entries in a directory                        */
/**********************************************************************/
static PTR nativeDir(PTR* args)
{
  FileRef      dirRef;
  UInt32       dirIter = vfsIteratorStart;
  FileInfoType info;
  PTR          res = NIL;
  PTR*         d   = &res;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  info.nameP = token;
  info.nameBufLen = MAX_TOKEN_LEN;

  printString(args[1]);
  if (VFSFileOpen(INTVAL(args[0]), msg, vfsModeRead, &dirRef))
    return FALSE;

  PROTECT(res);
  while (dirIter != vfsIteratorStop) {
    if (VFSDirEntryEnumerate(dirRef, &dirIter, &info))
      break;
    *d = cons(str2Lisp(info.nameP), NIL);
    d = &cdr(*d);
  }
  UNPROTECT(res);
  VFSFileClose(dirRef);
  return res;
}

/**********************************************************************/
/* Retrieve file/directory attributes                                 */
/**********************************************************************/
static PTR nativeGetAttr(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    attr;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileGetAttributes(vf->fp, &attr) == errNone 
         ? MKINT(attr) : FALSE;
}

/**********************************************************************/
/* Set file/directory attributes                                      */
/**********************************************************************/
static PTR nativeSetAttr(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileSetAttributes(vf->fp, getUInt32(args[1])) == errNone
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Retrieve file/directory timestamp                                  */
/**********************************************************************/
static PTR nativeGetTS(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    ts;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileGetDate(vf->fp, INTVAL(args[1]), &ts) == errNone
         ? allocForeign((void*)ts, FT_TIMESTAMP) : FALSE;
}

/**********************************************************************/
/* Set file/directory timestamp                                       */
/* !!! Bug in PalmOS4 doc: pass ts by value, not by ref !!!           */
/**********************************************************************/
static PTR nativeSetTS(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    ts = (UInt32)FOREIGNVAL(args[2]);

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileSetDate(vf->fp, INTVAL(args[1]), ts) == errNone
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Tell file position                                                 */
/**********************************************************************/
static PTR nativeTell(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    pos;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileTell(vf->fp, &pos) == errNone 
         ? makeUNum(pos) : FALSE;
}

/**********************************************************************/
/* Seek file position                                                 */
/**********************************************************************/
static PTR nativeSeek(PTR* args)
{
  Err rc;
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  rc = VFSFileSeek(vf->fp, INTVAL(args[1]), getInt32(args[2]));
  return rc==errNone || rc==vfsErrFileEOF
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Get file size                                                      */
/**********************************************************************/
static PTR nativeSize(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    size;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileSize(vf->fp, &size) == errNone
         ? makeUNum(size) : FALSE;
}

/**********************************************************************/
/* Is file at EOF?                                                    */
/**********************************************************************/
static PTR nativeEOF(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  return VFSFileEOF(vf->fp) == vfsErrFileEOF
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Delete a file or directory                                         */
/**********************************************************************/
static PTR nativeDelete(PTR* args)
{
  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  printString(args[1]);
  return VFSFileDelete(INTVAL(args[0]), msg) == errNone
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Rename a file or directory                                         */
/**********************************************************************/
static PTR nativeRename(PTR* args)
{
  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  printString(args[1]);
  StrCopy(token, msg);
  printString(args[2]);
  return VFSFileRename(INTVAL(args[0]), token, msg) == errNone
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Open a file                                                        */
/**********************************************************************/
static PTR nativeFOpen(PTR* args)
{
  VirtFile* vf;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  if (vf = openFile(INTVAL(args[0]), args[1], INTVAL(args[2])))
    return allocForeign(vf, FT_VFS_FILE);
  else
    return FALSE;
}

/**********************************************************************/
/* Close a file                                                       */
/**********************************************************************/
static PTR nativeFClose(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  if (VFSFileClose(vf->fp))
    return FALSE;
  vf->fp = vfsInvalidFileRef;
  return TRUE;
}

/**********************************************************************/
/* Read a block from a file                                           */
/**********************************************************************/
static PTR nativeFRead(PTR* args)
{
  VirtFile* vf  = (VirtFile*)FOREIGNVAL(args[0]);
  UInt16    len = getUInt16(args[1]);
  UInt32    nRead;
  PTR       res = FALSE;
  Err       rc;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  PROTECT(res);
  res = createString(len);
  rc  = readIntoString(vf->fp, res, &nRead);
  if (rc==errNone || rc==vfsErrFileEOF) {
    if (nRead < len)
      res = substring(res, 0, nRead);  
  }
  else
    res = FALSE;
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Write a block to a file                                            */
/**********************************************************************/
static PTR nativeFWrite(PTR* args)
{
  VirtFile* vf = (VirtFile*)FOREIGNVAL(args[0]);
  UInt32    nWritten;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  printString(args[1]);
  if (VFSFileWrite(vf->fp, stringLength(args[1]), msg, &nWritten))
    return FALSE;
  return makeUNum(nWritten);
}

/**********************************************************************/
/* Create a directory                                                 */
/**********************************************************************/
static PTR nativeCreDir(PTR* args)
{
  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  printString(args[1]);
  return VFSDirCreate(INTVAL(args[0]), msg) == errNone
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Allocate fiel structure                                            */
/**********************************************************************/
static VirtFile* openFile(UInt16 vol, PTR fName, UInt16 mode)
{
  VirtFile* vf = MemPtrNew(sizeof(VirtFile));

  // Can't leave file open after quitting
  mode &= ~vfsModeLeaveOpen;  
   
  vf->name = fName; 
  // Files has already been created/truncated, don't do it on
  // reopening again! 
  vf->mode = mode & ~vfsModeTruncate & ~vfsModeCreate;
  vf->pos  = 0;
  vf->vol  = vol;
  printString(fName);
  return VFSFileOpen(vol, msg, mode, &vf->fp) == errNone
         ? vf : NULL;
}

/**********************************************************************/
/* Open as input port                                                 */
/**********************************************************************/
static PTR nativeOpenInput(PTR* args)
{
  VirtFile* vf;
  PTR buffer, impl, res;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  if (!(vf = openFile(INTVAL(args[0]), args[1], vfsModeRead)))
    return FALSE;
  impl = allocForeign(vf, FT_VFS_FILE);
  PROTECT(impl);
  buffer = createString(VFS_BUF_SIZE);
  PROTECT(buffer);
  res = makeBufInPort(PT_VFS, impl, buffer);
  PROTECT(res);
  readVfs(RC_READ, (InPort*)FOREIGNVAL(res));
  UNPROTECT(res);
  UNPROTECT(buffer);
  UNPROTECT(impl);
  return res;
}

/**********************************************************************/
/* Open as input port                                                 */
/**********************************************************************/
static PTR nativeOpenOutput(PTR* args)
{
  VirtFile* vf;
  PTR       impl;

  if (!vfsOK)
    ErrThrow(ERR_V1_NO_VFS);

  if (!(vf = openFile(INTVAL(args[0]), args[1],
                      vfsModeWrite | vfsModeCreate | vfsModeTruncate)))
    return FALSE;
  impl = allocForeign(vf, FT_VFS_FILE);

  return makeBufOutPort(PT_VFS, impl, VFS_BUF_SIZE, OPF_NORMAL);
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule vfsBuiltins = 
{
  MODULE_FUNC(init),
  {"vfs-supported?",      NATIVE0(nativeOK)},

  {"vfs-volumes",         NATIVE0(nativeVolumes)},
  {"vfs-vol-size",        NATIVE1(nativeVolSize, tySMALLINT)},
  {"vfs-vol-get-label",   NATIVE1(nativeVolGetLabel, tySMALLINT)},
  {"vfs-vol-set-label",   NATIVE2(nativeVolSetLabel, tySMALLINT, tySTRING)},
  {"vfs-vol-info",        NATIVE1(nativeVolInfo, tySMALLINT)},

  {"vfs-dir",             NATIVE2(nativeDir, tySMALLINT, tySTRING)},
  {"vfs-delete",          NATIVE2(nativeDelete, tySMALLINT, tySTRING)},
  {"vfs-rename",          NATIVE3(nativeRename, tySMALLINT, tySTRING, tySTRING)},
  {"vfs-create-dir",      NATIVE2(nativeCreDir, tySMALLINT, tySTRING)},

  {"vfs-open",            NATIVE3(nativeFOpen, tySMALLINT, tySTRING, tySMALLINT)},
  {"vfs-close",           NATIVE1(nativeFClose, FOREIGN(FT_VFS_FILE))},
  {"vfs-read",            NATIVE2(nativeFRead, FOREIGN(FT_VFS_FILE), tyINT)},
  {"vfs-write",           NATIVE2(nativeFWrite, FOREIGN(FT_VFS_FILE), tySTRING)},
  {"vfs-get-attr",        NATIVE1(nativeGetAttr, FOREIGN(FT_VFS_FILE))},
  {"vfs-set-attr",        NATIVE2(nativeSetAttr, FOREIGN(FT_VFS_FILE), tySMALLINT)},
  {"vfs-get-ts",          NATIVE2(nativeGetTS, FOREIGN(FT_VFS_FILE), tySMALLINT)},
  {"vfs-set-ts",          NATIVE3(nativeSetTS, FOREIGN(FT_VFS_FILE), tySMALLINT, FOREIGN(FT_TIMESTAMP))},
  {"vfs-tell",            NATIVE1(nativeTell, FOREIGN(FT_VFS_FILE))},
  {"vfs-seek",            NATIVE3(nativeSeek, FOREIGN(FT_VFS_FILE), tySMALLINT, tyINT)},
  {"vfs-size",            NATIVE1(nativeSize, FOREIGN(FT_VFS_FILE))},
  {"vfs-eof?",            NATIVE1(nativeEOF, FOREIGN(FT_VFS_FILE))},
  {"vfs-ref?",            PRIMTYPE(FOREIGN(FT_VFS_FILE))},

  {"vfs-open-input",      NATIVE2(nativeOpenInput,  tySMALLINT, tySTRING)},
  {"vfs-open-output",     NATIVE2(nativeOpenOutput, tySMALLINT, tySTRING)},

  {NULL}
};
