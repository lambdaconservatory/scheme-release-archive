/**********************************************************************/
/*                                                                    */
/* dm.c: LISPME Palm database management                              */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.03.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "dm.h"
#include "io.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"
#include "arith.h"

/**********************************************************************/
/* Local typedefs                                                     */
/**********************************************************************/
typedef struct {
  UInt16 dbMode;
  char   dbName[dmDBNameLength];
} PickledDB;

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define RESDB MKPRIMSYM(DM_MODULE,1)

/**********************************************************************/
/* Module local data                                                  */
/**********************************************************************/
static DmOpenRef locDBRef;
static UInt16    recNr;
static LocalID   localId;
static UInt16    cardNr;
static PickledDB pbuf;
static MemHandle recHand;
static MemHandle newHand;
static MemHandle srcHand;
static UInt16    strLen;
static UInt32    creator;
static UInt32    type;

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static PTR     nativeOpenDB(PTR* args)                          SEC(IO);
static PTR     nativeCloseDB(PTR* args)                         SEC(IO);
static PTR     nativeCreateDB(PTR* args)                        SEC(IO);
static PTR     nativeDeleteDB(PTR* args)                        SEC(IO);
static PTR     nativeDBInfo(PTR* args)                          SEC(IO);
static PTR     nativeDBSize(PTR* args)                          SEC(IO);
static PTR     nativeNumRecords(PTR* args)                      SEC(IO);
static PTR     nativeReadRecord(PTR* args)                      SEC(IO);
static PTR     nativeInsertRecord(PTR* args)                    SEC(IO);
static PTR     nativeUpdateRecord(PTR* args)                    SEC(IO);
static PTR     nativeRemoveRecord(PTR* args)                    SEC(IO);
static PTR     nativeArchiveRecord(PTR* args)                   SEC(IO);
static PTR     nativeDeleteRecord(PTR* args)                    SEC(IO);
static PTR     nativeSetAttr(PTR* args)                         SEC(IO);
static PTR     nativeGetAttr(PTR* args)                         SEC(IO);
static PTR     nativeReadResource(PTR* args)                    SEC(IO);
static PTR     nativeInsertResource(PTR* args)                  SEC(IO);
static PTR     nativeUpdateResource(PTR* args)                  SEC(IO);
static PTR     nativeRemoveResource(PTR* args)                  SEC(IO);
static PTR     nativeIsResourceDB(PTR* args)                    SEC(IO); 
static PTR     nativeListDB(PTR* args)                          SEC(IO);
static PTR     nativeCatGetName(PTR* args)                      SEC(IO);
static void    initModule(ModuleMessage mess)                   SEC(IO);
static void    dmMemHook(MemMessage mess, PTR ptr)              SEC(IO);
static void    dmPrinter(Boolean machineFormat, void* p)        SEC(IO);
static void    getDBInfo(PickledDB* pdb)                        SEC(IO);
static UInt16  findRsrcRecord(PTR* args)                        SEC(IO);
static Boolean isResourceDB()                                   SEC(IO);

/**********************************************************************/
/* Module control function                                            */
/**********************************************************************/
static void initModule(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
      registerMemHook(FT_DBREF,  dmMemHook);
      registerTypename(FT_DBREF, "dbref");
      registerPrinter(FT_DBREF,  dmPrinter);
      break;

    case INIT_HEAP:
      /*--------------------------------------------------------------*/
      /* Create *resdb* global variable. Note: There's no need to     */
      /* access this variable from the dm.c extension module, since   */
      /* PalmOS keeps track of open resource databases itself, so     */
      /* *resdb* serves only as a handy place to store the current    */
      /* resource database from LispMe code.                          */
      /*--------------------------------------------------------------*/
      createGlobalVar(RESDB, FALSE);
      break;

    default:
  }
}

/**********************************************************************/
/* The memory hook function                                           */
/**********************************************************************/
static void dmMemHook(MemMessage mess, PTR ptr) 
{
  MemHandle  hd;
  PickledDB* p;

  switch (mess) {
    case MEM_MARK:
      break;

    case MEM_DELETE:
      if ((locDBRef = FOREIGNVAL(ptr)))
        DmCloseDatabase(locDBRef);
      break;

    case MEM_PICKLE:
      if ((locDBRef = FOREIGNVAL(ptr))) {
        /*------------------------------------------------------------*/
        /* Create a new session rec. with all info to reopen database */
        /*------------------------------------------------------------*/
        recNr = dmMaxRecordIndex; 
        hd = DmNewRecord(dbRef, &recNr, sizeof(PickledDB));
        getDBInfo(MemHandleLock(hd));
        DmCloseDatabase(locDBRef);
        MemHandleUnlock(hd);
        DmReleaseRecord(dbRef, recNr, false);
        SETFOREIGNVAL(ptr,recNr);
      }
      break;

    case MEM_UNPICKLE:
      if ((recNr = (UInt32)FOREIGNVAL(ptr))) {
        /*------------------------------------------------------------*/
        /* Reopen database                                            */
        /*------------------------------------------------------------*/
        hd = DmQueryRecord(dbRef, recNr); 
        p = MemHandleLock(hd);
        if ((localId = DmFindDatabase(0, p->dbName))) {
          locDBRef = DmOpenDatabase(0, localId, p->dbMode);
          SETFOREIGNVAL(ptr,locDBRef)
        }
        else
          SETFOREIGNVAL(ptr,0)
        MemHandleUnlock(hd);
        DmRemoveRecord(dbRef, recNr);
      }
      break;
  }
}

/**********************************************************************/
/* Print a database reference                                         */
/**********************************************************************/
static void dmPrinter(Boolean machineFormat, void* p)
{
  if ((locDBRef = p)) { 
    getDBInfo(&pbuf);
    outStr("[dbref 0x");
    StrIToH(token,pbuf.dbMode);
    outStr(token+4); // omit 4 hi nibbles
    outStr(" ");
    outStr(pbuf.dbName);
    outStr("]");
  }
  else
    outStr("[\254dbref]");
}

/**********************************************************************/
/* Retrieve general information from an open database                 */
/**********************************************************************/
static void getDBInfo(PickledDB* pdb)
{
  DmOpenDatabaseInfo(locDBRef, &localId, 0, &(pdb->dbMode), &cardNr, 0);
  DmDatabaseInfo(cardNr, localId, pdb->dbName, 0,0,0,0,0,0,0,0,0,0);
}

/**********************************************************************/
/* Is the current database a resource DB?                             */
/**********************************************************************/
static Boolean isResourceDB()
{
  Boolean isResDB;
  DmOpenDatabaseInfo(locDBRef, 0, 0, 0, 0, &isResDB);
  return isResDB;
}

/**********************************************************************/
/* Open a database                                                    */
/* We don't support the dmModeLeaveOpen flag (since it causes trouble */
/* on reopening                                                       */
/**********************************************************************/
static PTR nativeOpenDB(PTR* args)
{
  locDBRef = 0;

  if ((localId = DmFindDatabase(0, printString(args[0]))))
    locDBRef = DmOpenDatabase(0, localId,
                              getUInt16(args[1]) & ~dmModeLeaveOpen);
  return allocForeign(locDBRef, FT_DBREF);
}

/**********************************************************************/
/* Close a database                                                   */
/**********************************************************************/
static PTR nativeCloseDB(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !DmCloseDatabase(locDBRef)) {
    SETFOREIGNVAL(args[0],0);
    return TRUE;
  }
  else
    return FALSE;
}

/**********************************************************************/
/* Create a new database                                              */
/**********************************************************************/
static PTR nativeCreateDB(PTR* args)
{
  creator = *((UInt32*)printString(args[1]));
  type = *((UInt32*)printString(args[2]));
  if (DmCreateDatabase(0, printString(args[0]),
                       creator, type, args[3] != FALSE))
    return FALSE;
  else
    return TRUE;
}

/**********************************************************************/
/* Delete a database                                                  */
/**********************************************************************/
static PTR nativeDeleteDB(PTR* args)
{
  if ((localId = DmFindDatabase(0, printString(args[0]))) &&
      DmDeleteDatabase(0, localId) == 0)
    return TRUE;
  else
    return FALSE;
}

/**********************************************************************/
/* List all databases with type and creator                           */
/**********************************************************************/
static PTR nativeListDB(PTR* args)
{
  Boolean first = true;
  PTR     res = NIL;
  PTR*    pp  = &res; 
  DmSearchStateType state;

  if (args[0] == EMPTY_STR) // wildcard
    type = 0;
  else 
    type = *((UInt32*)printString(args[0]));
  
  if (args[1] == EMPTY_STR) // wildcard
    creator = 0;
  else 
    creator = *((UInt32*)printString(args[1]));

  PROTECT(res);
  while (!DmGetNextDatabaseByTypeCreator(first,&state,type,creator,
                                         false,&cardNr,&localId)) {
    DmDatabaseInfo(cardNr,localId,msg,0,0,0,0,0,0,0,0,0,0);
    *pp = cons(str2Lisp(msg),NIL);
    pp = &cdr(*pp);
    first = false;
  }
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Get database info block                                            */
/**********************************************************************/
static PTR nativeDBInfo(PTR* args)
{
  static UInt16 attr;
  static UInt32 modNr, creTS, modTS, bckTS;
  static Boolean isRes;
  PTR res = NIL;

  if ((locDBRef=FOREIGNVAL(args[0])) &&
      !DmOpenDatabaseInfo(locDBRef, &localId, 0,
                          &pbuf.dbMode, &cardNr, &isRes) &&
      !DmDatabaseInfo(cardNr, localId, pbuf.dbName, &attr, 0,     
                      &creTS, &modTS, &bckTS, &modNr, 0, 0,
                      &type, &creator)) {
    PROTECT(res);
    res = cons(allocForeign((void*)bckTS, FT_TIMESTAMP), res);
    res = cons(allocForeign((void*)modTS, FT_TIMESTAMP), res);
    res = cons(allocForeign((void*)creTS, FT_TIMESTAMP), res);
    res = cons(makeUNum(modNr), res);
    res = cons(make4Byte(creator), res);
    res = cons(make4Byte(type), res);
    res = cons(isRes ? TRUE : FALSE, res);
    res = cons(MKINT(attr), res);
    res = cons(MKINT(pbuf.dbMode), res);
    res = cons(str2Lisp(pbuf.dbName), res);
    UNPROTECT(res);
    return res;
  }
  else
    return FALSE;
}

/**********************************************************************/
/* Get database size information                                      */
/**********************************************************************/
static PTR nativeDBSize(PTR* args)
{
  static UInt32 numRec, totByte, dataByte;
  PTR res = NIL;

  if ((locDBRef=FOREIGNVAL(args[0])) &&
      !DmOpenDatabaseInfo(locDBRef, &localId, 0, 0, 0, 0) &&
      !DmDatabaseSize(0, localId, &numRec, &totByte, &dataByte)) {
    PROTECT(res);
    res = cons(makeUNum(dataByte), res);
    res = cons(makeUNum(totByte), res);
    res = cons(makeUNum(numRec), res);
    UNPROTECT(res);
    return res;
  }
  else
    return FALSE;
}


/**********************************************************************/
/* Count records in a database                                        */
/**********************************************************************/
static PTR nativeNumRecords(PTR* args)
{
  if ((locDBRef=FOREIGNVAL(args[0])))
    return makeUNum(DmNumRecords(locDBRef));
  else
    return FALSE;
}

/**********************************************************************/
/* Read a record from database                                        */
/**********************************************************************/
static PTR nativeReadRecord(PTR* args)
{
  PTR res;
  
  if ((locDBRef=FOREIGNVAL(args[0])) && !isResourceDB()) {
    MemHandle recHand = DmQueryRecord(locDBRef, getUInt16(args[1]));
    if (recHand) {
      ErrTry {
        res = copyString(MemHandleSize(recHand), MemHandleLock(recHand));
      } ErrCatch(err) {
        MemHandleUnlock(recHand);
        ErrThrow(err);
      } ErrEndCatch
      MemHandleUnlock(recHand);
      return res;
    }  
  }
  return FALSE;
}

/**********************************************************************/
/* Insert new record into a database                                  */
/**********************************************************************/
static PTR nativeInsertRecord(PTR* args)
{
  if ((locDBRef=FOREIGNVAL(args[0])) && !isResourceDB()) {
    recNr = getUInt16(args[1]);
    if ((strLen = stringLength(args[2]))) {
      recHand = DmNewRecord(locDBRef, &recNr, strLen);
      if (recHand) {
        srcHand = DmQueryRecord(dbRef,ARR_INDEX(args[2]));
        DmWrite(MemHandleLock(recHand), 0,
                ArrayHandleLock(srcHand), strLen);
        MemHandleUnlock(recHand);
        ArrayHandleUnlock(srcHand);
        DmReleaseRecord(locDBRef,recNr,true);
        return makeUNum(recNr);
      }
    }
  }
  return FALSE;
}

/**********************************************************************/
/* Update a record in a database                                      */
/**********************************************************************/
static PTR nativeUpdateRecord(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() && 
      (strLen = stringLength(args[2])) &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      (recHand = DmGetRecord(locDBRef, recNr))) {
    if ((newHand = DmResizeRecord(locDBRef, recNr, strLen))) {
      srcHand = DmQueryRecord(dbRef,ARR_INDEX(args[2]));
      DmWrite(MemHandleLock(newHand), 0,
              ArrayHandleLock(srcHand), strLen);
      MemHandleUnlock(newHand);
      ArrayHandleUnlock(srcHand);
      DmReleaseRecord(locDBRef,recNr,true);
      return makeUNum(recNr);
    }
    DmReleaseRecord(locDBRef,recNr,false);
  }
  return FALSE;
}

/**********************************************************************/
/* Remove a record from a database                                    */
/**********************************************************************/
static PTR nativeRemoveRecord(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      !DmRemoveRecord(locDBRef, recNr))
    return TRUE;
  else
    return FALSE;
}

/**********************************************************************/
/* Archive a record (mark it as deleted, but preserve it for hotsync  */
/**********************************************************************/
static PTR nativeArchiveRecord(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      !DmArchiveRecord(locDBRef, recNr))
    return TRUE;
  else
    return FALSE;
}

/**********************************************************************/
/* Delete a record from a database (and inform HotSync about it)      */
/**********************************************************************/
static PTR nativeDeleteRecord(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      !DmDeleteRecord(locDBRef, recNr))
    return TRUE;
  else
    return FALSE;
}


/**********************************************************************/
/* Get attributes of a database record                                */
/**********************************************************************/
static PTR nativeGetAttr(PTR* args)
{
  UInt16 attr;

  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      !DmRecordInfo(locDBRef, recNr, &attr, 0, 0))
    return MKINT(attr);

  return FALSE;
}

/**********************************************************************/
/* Set attributes of a database record                                */
/**********************************************************************/
static PTR nativeSetAttr(PTR* args)
{
  UInt16 attr = getUInt16(args[2]);

  if ((locDBRef = FOREIGNVAL(args[0])) && 
      !isResourceDB() &&
      DmQueryRecord(locDBRef, recNr = getUInt16(args[1])) &&
      !DmSetRecordInfo(locDBRef, recNr, &attr, 0))
    return TRUE;

  return FALSE;
}

/**********************************************************************/
/* Get a category name from DB info block                             */
/**********************************************************************/
static PTR nativeCatGetName(PTR* args)
{
  UInt16 attr;
  Int16  cat = INTVAL(args[1]);

  if ((locDBRef = FOREIGNVAL(args[0])) &&
      !isResourceDB() && 0<=cat && cat<dmRecNumCategories) {
    CategoryGetName(locDBRef, cat, msg);
    return str2Lisp(msg);
  }
  return FALSE;
}

/**********************************************************************/
/* Read a resource from all open resource databases                   */
/**********************************************************************/
static PTR nativeReadResource(PTR* args)
{
  PTR res;

  if ((recHand = DmGetResource(*((UInt32*)printString(args[0])),
                               getUInt16(args[1])))) {
    ErrTry {
      res = copyString(MemHandleSize(recHand), MemHandleLock(recHand));
    } ErrCatch(err) {
      MemHandleUnlock(recHand);
      DmReleaseResource(recHand);
      ErrThrow(err);
    } ErrEndCatch
    MemHandleUnlock(recHand);
    DmReleaseResource(recHand);
    return res;
  }
  return FALSE;
}

/**********************************************************************/
/* Retrieve record number for a resource                              */
/**********************************************************************/
static UInt16 findRsrcRecord(PTR* args)
{
  DmResType resType;
  DmResID   resID; 

  resType = *((DmResType*)printString(args[1]));  
  resID   = getUInt16(args[2]);
  return DmFindResource(locDBRef, resType, resID, NULL);
}

/**********************************************************************/
/* Insert new record into a database                                  */
/**********************************************************************/
static PTR nativeInsertResource(PTR* args)
{
  DmResType resType;
  DmResID   resID; 

  if ((locDBRef = FOREIGNVAL(args[0])) &&
      isResourceDB() &&
      (strLen = stringLength(args[3])))
  {
    resType = *((DmResType*)printString(args[1]));  
    resID   = getUInt16(args[2]);
    recHand = DmNewResource(locDBRef, resType, resID, strLen);

    if (recHand)
    {
      srcHand = DmQueryRecord(dbRef,ARR_INDEX(args[3]));
      DmWrite(MemHandleLock(recHand), 0,
              ArrayHandleLock(srcHand), strLen);
      MemHandleUnlock(recHand);
      ArrayHandleUnlock(srcHand);
      DmReleaseResource(recHand);
      return TRUE;
    }
  }
  return FALSE;
}

/**********************************************************************/
/* Update a resource in a database                                    */
/**********************************************************************/
static PTR nativeUpdateResource(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      isResourceDB() &&
      (strLen = stringLength(args[3])) &&
      (recNr = findRsrcRecord(args)) != -1)
  {
    recHand = DmGetResourceIndex(locDBRef, recNr);
    if ((newHand = DmResizeResource(recHand, strLen)))
    {
      srcHand = DmQueryRecord(dbRef,ARR_INDEX(args[3]));
      DmWrite(MemHandleLock(newHand), 0,
              ArrayHandleLock(srcHand),strLen);
      MemHandleUnlock(newHand);
      ArrayHandleUnlock(srcHand);
      DmReleaseResource(newHand);
      return TRUE;
    }
  }
  return FALSE;
}

/**********************************************************************/
/* Remove a resource from a database                                  */
/**********************************************************************/
static PTR nativeRemoveResource(PTR* args)
{
  if ((locDBRef = FOREIGNVAL(args[0])) &&
      isResourceDB() &&   
      (recNr = findRsrcRecord(args)) != -1 &&
      !DmRemoveResource(locDBRef, recNr))
    return TRUE;
  else
    return FALSE;
}

/**********************************************************************/
/* Is it a resource database?                                         */
/**********************************************************************/
static PTR nativeIsResourceDB(PTR* args)
{
  locDBRef = FOREIGNVAL(args[0]);
  return isResourceDB() ? TRUE : FALSE;
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule dmBuiltins = 
{
  MODULE_FUNC(initModule),
  BUILTINSYMBOL_H("*resdb*","active resource database"),
  {"dm-open-db",        NATIVE2(nativeOpenDB,         tySTRING, tyINT)},
  {"dm-close-db",       NATIVE1(nativeCloseDB,        FOREIGN(FT_DBREF))},
  {"dm-create-db",      NATIVE4(nativeCreateDB,       tySTRING, tySTRING, tySTRING, tyBOOL)},
  {"dm-delete-db",      NATIVE1(nativeDeleteDB,       tySTRING)},
  {"dm-num-recs",       NATIVE1(nativeNumRecords,     FOREIGN(FT_DBREF))},
  {"dm-read-rec",       NATIVE2(nativeReadRecord,     FOREIGN(FT_DBREF), tyINT)},
  {"dm-insert-rec",     NATIVE3(nativeInsertRecord,   FOREIGN(FT_DBREF), tyINT, tySTRING)},
  {"dm-update-rec",     NATIVE3(nativeUpdateRecord,   FOREIGN(FT_DBREF), tyINT, tySTRING)},
  {"dm-remove-rec",     NATIVE2(nativeRemoveRecord,   FOREIGN(FT_DBREF), tyINT)},
  {"dm-archive-rec",    NATIVE2(nativeArchiveRecord,  FOREIGN(FT_DBREF), tyINT)},
  {"dm-delete-rec",     NATIVE2(nativeDeleteRecord,   FOREIGN(FT_DBREF), tyINT)},
  {"dm-get-rec-attr",   NATIVE2(nativeGetAttr,        FOREIGN(FT_DBREF), tyINT)},
  {"dm-set-rec-attr",   NATIVE3(nativeSetAttr,        FOREIGN(FT_DBREF), tyINT, tyINT)},
  {"dm-db-info",        NATIVE1(nativeDBInfo,         FOREIGN(FT_DBREF))},
  {"dm-db-size",        NATIVE1(nativeDBSize,         FOREIGN(FT_DBREF))},
  {"dm-read-rsrc",      NATIVE2(nativeReadResource,   tySTRING, tyINT)},
  {"dm-insert-rsrc",    NATIVE4(nativeInsertResource, FOREIGN(FT_DBREF), tySTRING, tyINT, tySTRING)},
  {"dm-update-rsrc",    NATIVE4(nativeUpdateResource, FOREIGN(FT_DBREF), tySTRING, tyINT, tySTRING)},
  {"dm-remove-rsrc",    NATIVE3(nativeRemoveResource, FOREIGN(FT_DBREF), tySTRING, tyINT)},
  {"dbref?",            PRIMTYPE(FOREIGN(FT_DBREF))},
  {"dm-rsrc-db?",       NATIVE1(nativeIsResourceDB,   FOREIGN(FT_DBREF))},
  {"dm-db-list",        NATIVE2(nativeListDB,         tySTRING, tySTRING)},
  {"cat-get-name",      NATIVE2(nativeCatGetName,     FOREIGN(FT_DBREF), tySMALLINT)},

  {NULL}
};
