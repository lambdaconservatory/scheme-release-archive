/**********************************************************************/
/*                                                                    */
/* graphic.c: LISPME graphic functions                                */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 08.04.2000 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "graphic.h"
#include "util.h"
#include "io.h"
#include "comp.h"
#include "vm.h"
#include "LispMe.h"

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
Boolean newGraphic;

/**********************************************************************/
/* Local data                                                         */
/**********************************************************************/
static PTR    gstateCell;
static UInt32 screenDepth;

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void init(ModuleMessage mess)                           SEC(MOD); 
static void checkGState(void)                                  SEC(MOD);
static void setPattern(void)                                   SEC(MOD);
static void setColors(void)                                    SEC(MOD);

static PTR  nativeMove(PTR* args)                              SEC(MOD);
static PTR  nativeDrawLine(PTR* args)                          SEC(MOD);
static PTR  nativeDrawRect(PTR* args)                          SEC(MOD);
static PTR  nativeDrawText(PTR* args)                          SEC(MOD);
static PTR  nativeDrawBitmap(PTR* args)                        SEC(MOD);
static PTR  nativeRGB2Index(PTR* args)                         SEC(MOD);
static PTR  nativeIndex2RGB(PTR* args)                         SEC(MOD);
static PTR  nativeSetPalette(PTR* args)                        SEC(MOD);

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define GSTATE     MKPRIMSYM(GRAPHIC_MODULE,1)
#define GSVAR      locVal(gstateCell)
#define GS_COORD   car(GSVAR)
#define GS_FONT    cadr(GSVAR)
#define GS_PATTERN caddr(GSVAR)
#define GS_MODE    cadr(cddr(GSVAR))
#define GS_FORE    caddr(cddr(GSVAR))
#define GS_BACK    caddr(cdddr(GSVAR))
#define GS_TEXT    car(cdddr(cdddr(GSVAR)))

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START:
      /*--------------------------------------------------------------*/ 
      /* Determine screen depth                                       */ 
      /*--------------------------------------------------------------*/ 
      if (newGraphic) 
        WinScreenMode(winScreenModeGet, NULL, NULL, &screenDepth, NULL);
      break;

    case INIT_HEAP: 
      /*--------------------------------------------------------------*/ 
      /* Add *gstate* to global variable list                         */ 
      /*--------------------------------------------------------------*/ 
      W = cons(cons(MKINT(0),MKINT(0)), // point
          cons(MKINT(0),                // font    
          cons(TRUE,                    // pattern 
          cons(MKINT(0),                // mode    
          cons(MKINT(255),              // foreground color
          cons(MKINT(0),                // background color
          cons(MKINT(255), NIL)))))));  // text color
      createGlobalVar(GSTATE, W);
      /* fall thru */

    case SESS_CONNECT: 
      /*--------------------------------------------------------------*/ 
      /* Cache *gstate* variable                                      */ 
      /*--------------------------------------------------------------*/ 
      gstateCell = symLoc(GSTATE);
      break;

    default:
  }
}

/**********************************************************************/
/* Set fill pattern                                                   */
/**********************************************************************/
static void setPattern(void)
{
  PTR pat = GS_PATTERN;
  if (IS_STRING(pat))
  {
    if (stringLength(pat) != 8)
      goto patError;
    WinSetPattern((UInt8*)printString(pat));
  }
  else 
    patError:
      typeError(pat, "valid pattern");
}

/**********************************************************************/
/* Check gstate consistency                                           */
/**********************************************************************/
static void checkGState(void)
{
  PTR p = GSVAR;

  if (!IS_PAIR(p) || !IS_PAIR(car(p)) ||
      !IS_SMALLINT(caar(p)) || !IS_SMALLINT(cdar(p)) ||
      (p=cdr(p), false) || !IS_SMALLINT(car(p)) ||
      (p=cdr(p), false) || // check pattern later
      (p=cdr(p), false) || !IS_SMALLINT(car(p)) ||    
      (p=cdr(p), false) || !IS_SMALLINT(car(p)) ||    
      (p=cdr(p), false) || !IS_SMALLINT(car(p)) ||    
      (p=cdr(p), false) || !IS_SMALLINT(car(p)))
    typeError(car(gstateCell), "valid graphic state");
}

/**********************************************************************/
/* Set colors and mode                                                */
/**********************************************************************/
static void setColors(void)
{
#define COLINDEX(ptr) ((INTVAL(ptr)) & ((1<<screenDepth)-1))

  WinPushDrawState();
  WinSetForeColor(COLINDEX(GS_FORE));
  WinSetBackColor(COLINDEX(GS_BACK));
  WinSetTextColor(COLINDEX(GS_TEXT));
  WinSetDrawMode(INTVAL(GS_MODE));
  WinSetPatternType(blackPattern);
  switch (GS_PATTERN)
  {
    case FALSE:   // deprecated, only for backward compatibility
      WinSetForeColor(COLINDEX(GS_BACK));
      WinSetBackColor(COLINDEX(GS_FORE));
      WinSetTextColor(COLINDEX(GS_BACK));
      break;

    case NOPRINT: // deprecated, only for backward compatibility
      WinSetDrawMode(winInvert);
      break;

    case TRUE:
      break;
  
    default:
      WinSetPatternType(customPattern); 
      setPattern();
      break;
  }
#undef COLINDEX
}

/**********************************************************************/
/* Move current position                                              */
/**********************************************************************/
static PTR nativeMove(PTR* args)
{
  checkGState();
  car(GS_COORD) = args[0];
  cdr(GS_COORD) = args[1];
  return NOPRINT;
}

/**********************************************************************/
/* Draw a line                                                        */
/**********************************************************************/
static PTR nativeDrawLine(PTR* args)
{
  Int16 x1, y1;
  Int16 x2 = INTVAL(args[0]);
  Int16 y2 = INTVAL(args[1]);

  checkGState();
  x1 = INTVAL(car(GS_COORD));
  y1 = INTVAL(cdr(GS_COORD));

  if (newGraphic) 
  {
    setColors();
    WinPaintLine(x1,y1,x2,y2);
    WinPopDrawState();
  }
  else
  {
    switch (GS_PATTERN)
    {
      case TRUE:
        WinDrawLine(x1,y1,x2,y2);
        break;

      case FALSE:
        WinEraseLine(x1,y1,x2,y2);
        break;

      case NOPRINT:
        WinInvertLine(x1,y1,x2,y2);
        break;

      default:
        setPattern();
        WinFillLine(x1,y1,x2,y2);
        break;
    }
  }
  car(GS_COORD) = MKINT(x2);
  cdr(GS_COORD) = MKINT(y2);
  return NOPRINT;
}

/**********************************************************************/
/* Draw a text                                                        */
/**********************************************************************/
static PTR nativeDrawText(PTR* args)
{
  Int16 x,y;
  int   font;
  int   len;
  FontID oldFont;

  checkGState();
  x    = INTVAL(car(GS_COORD));
  y    = INTVAL(cdr(GS_COORD));
  font = INTVAL(GS_FONT);

  if (newGraphic) 
    setColors();

  printSEXP(args[0], 0, &portMsg);
  oldFont = FntGetFont();
  FntSetFont(stdFont <= font && font <= largeBoldFont
             ? font : stdFont);
  len = StrLen(msg);  

  if (newGraphic) 
  {
    WinPaintChars(msg,len,x,y);
    WinPopDrawState();
  }
  else 
  {
    switch (GS_PATTERN)
    {
      case FALSE:
        WinDrawInvertedChars(msg,len,x,y);
        break;

      case NOPRINT:
        WinInvertChars(msg,len,x,y);
        break;

      default:
        WinDrawChars(msg,len,x,y);
        break;
    }
  }
  FntSetFont(oldFont);
  return NOPRINT;
}

/**********************************************************************/
/* Draw a bitmap                                                      */
/**********************************************************************/
static PTR nativeDrawBitmap(PTR* args)
{
  Int16     x,y;
  BitmapPtr bitmap;

  checkGState();
  x = INTVAL(car(GS_COORD));
  y = INTVAL(cdr(GS_COORD));

  if (args[0] == EMPTY_STR)
    typeError(args[0], "bitmap");
  bitmap = ArrayHandleLock(DmQueryRecord(dbRef, ARR_INDEX(args[0])));  

  /*------------------------------------------------------------------*/
  /* Some sanity checks to avoid a fatal exception - more necessary?  */
  /*------------------------------------------------------------------*/
  if (bitmap->rowBytes & 1) {
    ArrayPtrUnlock(bitmap);
    typeError(args[0], "bitmap");
  }

  if (newGraphic)
  {
    setColors();
    WinPaintBitmap(bitmap, x, y);
    WinPopDrawState();
  }
  else
    WinDrawBitmap(bitmap, x, y);
  ArrayPtrUnlock(bitmap);
  return NOPRINT;
}

/**********************************************************************/
/* Draw a filled rectangle                                            */
/**********************************************************************/
static PTR nativeDrawRect(PTR* args)
{
  RectangleType rect;
  Int16 x1, y1;
  Int16 x2 = INTVAL(args[0]);
  Int16 y2 = INTVAL(args[1]);
  Int16 corner = INTVAL(args[2]);

  checkGState();
  x1 = INTVAL(car(GS_COORD));
  y1 = INTVAL(cdr(GS_COORD));

  rect.topLeft.x = min(x1,x2);
  rect.topLeft.y = min(y1,y2);
  rect.extent.x  = abs(x1-x2);
  rect.extent.y  = abs(y1-y2);

  if (newGraphic) 
  {
    setColors();
    WinPaintRectangle(&rect, corner);
    WinPopDrawState();
  }
  else
  {
    switch (GS_PATTERN)
    {
      case TRUE:
        WinDrawRectangle(&rect, corner);
        break;

      case FALSE:
        WinEraseRectangle(&rect, corner);
        break;

      case NOPRINT:
        WinInvertRectangle(&rect, corner);
        break;

      default:
        setPattern();
        WinFillRectangle(&rect, corner);
        break;
    }
  }

  car(GS_COORD) = MKINT(x2);
  cdr(GS_COORD) = MKINT(y2);
  return NOPRINT;
}

/**********************************************************************/
/* Find nearest color index for RGB values                            */
/**********************************************************************/
static PTR nativeRGB2Index(PTR* args)
{
  RGBColorType col;

  if (newGraphic)
  {
    col.r = INTVAL(args[0]);
    col.g = INTVAL(args[1]);
    col.b = INTVAL(args[2]);
    return MKINT(WinRGBToIndex(&col)); 
  }
  else
    return MKINT(0);
}

/**********************************************************************/
/* Find nearest color index for RGB values                            */
/**********************************************************************/
static PTR nativeIndex2RGB(PTR* args)
{
  RGBColorType col;

  col.r = col.g = col.b = 0;
  if (newGraphic)
    WinIndexToRGB(INTVAL(args[0]), &col); 
  return list3(MKINT(col.r), MKINT(col.g), MKINT(col.b));
}

/**********************************************************************/
/* Set palette entry                                                  */
/**********************************************************************/
static PTR nativeSetPalette(PTR* args)
{
  RGBColorType col;

  if (newGraphic)
  {
    col.r = INTVAL(args[1]); 
    col.g = INTVAL(args[2]);
    col.b = INTVAL(args[3]);
    WinPalette(winPaletteSet, INTVAL(args[0]), 1, &col); 
  }
  return args[0];
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule graphicBuiltins = 
{
  MODULE_FUNC(init),
  BUILTINSYMBOL_H("*gstate*","((x . y) font pat mode fg-col bg-col txt-col)"), 
  {"move",       NATIVE2(nativeMove,       tySMALLINT, tySMALLINT)},
  {"draw",       NATIVE2(nativeDrawLine,   tySMALLINT, tySMALLINT)},
  {"rect",       NATIVE3(nativeDrawRect,   tySMALLINT, tySMALLINT, tySMALLINT)},
  {"text",       NATIVE1(nativeDrawText,   tyANY)},
  {"bitmap",     NATIVE1(nativeDrawBitmap, tySTRING)},
  {"rgb->index", NATIVE3(nativeRGB2Index,  tySMALLINT, tySMALLINT, tySMALLINT)}, 
  {"index->rgb", NATIVE1(nativeIndex2RGB,  tyCOL_IDX)},
  {"set-palette",NATIVE4_H(nativeSetPalette, tyCOL_IDX, tySMALLINT,
                           tySMALLINT, tySMALLINT,
                           "<color index> red green blue")},
  {NULL}
};
