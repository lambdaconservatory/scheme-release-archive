/**********************************************************************/
/*                                                                    */
/* socket.h: LISPME socket support                                    */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 26.05.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_SOCKET_H
#define INC_SOCKET_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule socketBuiltins; 

#endif
