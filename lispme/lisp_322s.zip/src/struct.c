/**********************************************************************/
/*                                                                    */
/* struct.c: LISPME C structure access support                        */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 30.11.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "struct.h"
#include "util.h"
#include "arith.h"
#include "io.h"
#include "LispMe.h"
#include "fpstuff.h"

/**********************************************************************/
/* Local definitions                                                  */
/**********************************************************************/

/**********************************************************************/
/* Local variables                                                    */
/**********************************************************************/
static MemHandle glHd;

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static UInt8* getStr(PTR* args, UInt16 size)                   SEC(MOD);

static PTR    nativeGetS8(PTR* args)                           SEC(MOD);
static PTR    nativeGetU8(PTR* args)                           SEC(MOD);
static PTR    nativeGetS16(PTR* args)                          SEC(MOD);
static PTR    nativeGetU16(PTR* args)                          SEC(MOD);
static PTR    nativeGetS32(PTR* args)                          SEC(MOD);
static PTR    nativeGetU32(PTR* args)                          SEC(MOD);
static PTR    nativeGetF32(PTR* args)                          SEC(MOD);
static PTR    nativeGetF64(PTR* args)                          SEC(MOD);
static PTR    nativeGetTS(PTR* args)                           SEC(MOD);
static PTR    nativeGetTime(PTR* args)                         SEC(MOD);
static PTR    nativeGetDate(PTR* args)                         SEC(MOD);
static PTR    nativeGetCStr(PTR* args)                         SEC(MOD);

static PTR    nativeSetS8(PTR* args)                           SEC(MOD);
static PTR    nativeSetU8(PTR* args)                           SEC(MOD);
static PTR    nativeSetS16(PTR* args)                          SEC(MOD);
static PTR    nativeSetU16(PTR* args)                          SEC(MOD);
static PTR    nativeSetS32(PTR* args)                          SEC(MOD);
static PTR    nativeSetU32(PTR* args)                          SEC(MOD);
static PTR    nativeSetF32(PTR* args)                          SEC(MOD);
static PTR    nativeSetF64(PTR* args)                          SEC(MOD);
static PTR    nativeSetTS(PTR* args)                           SEC(MOD);
static PTR    nativeSetTime(PTR* args)                         SEC(MOD);
static PTR    nativeSetDate(PTR* args)                         SEC(MOD);
static PTR    nativeSetCStr(PTR* args)                         SEC(MOD);

/**********************************************************************/
/* Get C buffer after checking parameters                             */
/**********************************************************************/
static UInt8* getStr(PTR* args, UInt16 size)
{
  UInt16 off = getUInt16(args[1]);

  if (args[0] == EMPTY_STR)
    error1(ERR_R2_INVALID_INDEX, args[1]);
  glHd = DmQueryRecord(dbRef, ARR_INDEX(args[0]));
  if (off+size > ArrayHandleSize(glHd))
    error1(ERR_R2_INVALID_INDEX, args[1]);
  return ArrayHandleLock(glHd)+off;
}

/**********************************************************************/
/* Get signed 8 bit integer from buffer                               */
/**********************************************************************/
static PTR nativeGetS8(PTR* args)
{
  Int8 res;
  Int8* cp = getStr(args, 1);
  res = *cp;
  ArrayHandleUnlock(glHd);
  return MKINT(res);
}

/**********************************************************************/
/* Get unsigned 8 bit integer from buffer                             */
/**********************************************************************/
static PTR nativeGetU8(PTR* args)
{
  UInt8 res;
  UInt8* cp = getStr(args, 1);
  res = *cp;
  ArrayHandleUnlock(glHd);
  return MKINT(res);
}

/**********************************************************************/
/* Get signed 16 bit integer from buffer                              */
/**********************************************************************/
static PTR nativeGetS16(PTR* args)
{
  Int16 res;
  UInt8* cp = getStr(args, 2);
  MemMove(&res, cp, 2);
  ArrayHandleUnlock(glHd);
  return makeNum(res);
}

/**********************************************************************/
/* Get unsigned 16 bit integer from buffer                            */
/**********************************************************************/
static PTR nativeGetU16(PTR* args)
{
  UInt16 res;
  UInt8* cp = getStr(args, 2);
  MemMove(&res, cp, 2);
  ArrayHandleUnlock(glHd);
  return makeUNum(res);
}

/**********************************************************************/
/* Get signed 32 bit integer from buffer                              */
/**********************************************************************/
static PTR nativeGetS32(PTR* args)
{
  Int32 res;
  UInt8* cp = getStr(args, 4);
  MemMove(&res, cp, 4);
  ArrayHandleUnlock(glHd);
  return makeNum(res);
}

/**********************************************************************/
/* Get unsigned 32 bit integer from buffer                            */
/**********************************************************************/
static PTR nativeGetU32(PTR* args)
{
  UInt32 res;
  UInt8* cp = getStr(args, 4);
  MemMove(&res, cp, 4);
  ArrayHandleUnlock(glHd);
  return makeUNum(res);
}

/**********************************************************************/
/* Get 32 bit IEEE real from buffer                                   */
/**********************************************************************/
static PTR nativeGetF32(PTR* args)
{
  float res;
  UInt8* cp = getStr(args, 4);
  MemMove(&res, cp, 4);
  ArrayHandleUnlock(glHd);
  return allocReal(floatToDouble(res));
}

/**********************************************************************/
/* Get 64 bit IEEE real from buffer                                   */
/**********************************************************************/
static PTR nativeGetF64(PTR* args)
{
  double res;
  UInt8* cp = getStr(args, 8);
  MemMove(&res, cp, 8);
  ArrayHandleUnlock(glHd);
  return allocReal(res);
}

/**********************************************************************/
/* Get timestamp from buffer                                          */
/**********************************************************************/
static PTR nativeGetTS(PTR* args)
{
  UInt32 res;
  UInt8* cp = getStr(args, 4);
  MemMove(&res, cp, 4);
  ArrayHandleUnlock(glHd);
  return allocForeign((void*)res, FT_TIMESTAMP);
}

/**********************************************************************/
/* Get PalmOS time from buffer                                        */
/**********************************************************************/
static PTR nativeGetTime(PTR* args)
{
  TimeType res;
  UInt8* cp = getStr(args, 2);
  MemMove(&res, cp, 2);
  ArrayHandleUnlock(glHd);
  return allocForeign((void*)*((UInt32*)&res), FT_TIME);
}

/**********************************************************************/
/* Get PalmOS date from buffer                                        */
/**********************************************************************/
static PTR nativeGetDate(PTR* args)
{
  DateType res;
  UInt8* cp = getStr(args, 2);
  MemMove(&res, cp, 2);
  ArrayHandleUnlock(glHd);
  return allocForeign((void*)*((UInt32*)&res), FT_DATE);
}

/**********************************************************************/
/* Get C string (NUL terminated) from buffer                          */
/**********************************************************************/
static PTR nativeGetCStr(PTR* args)
{
  UInt8* cp = getStr(args, 1);
  PTR res;
  if (StrLen(cp) >= ArrayHandleSize(glHd) - INTVAL(args[1]))
    error1(ERR_R2_INVALID_INDEX, args[1]);
  res = str2Lisp(cp);
  ArrayHandleUnlock(glHd);
  return res;
}

/**********************************************************************/
/* Set buffer to 8 bit integer                                        */
/**********************************************************************/
static PTR nativeSetS8(PTR* args)
{
  UInt8* cp  = getStr(args, 1);
  *cp = getInt16(args[2]);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to unsigned 8 bit integer                               */
/**********************************************************************/
static PTR nativeSetU8(PTR* args)
{
  UInt8* cp  = getStr(args, 1);
  *cp = getUInt16(args[2]);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to 16 bit integer                                       */
/**********************************************************************/
static PTR nativeSetS16(PTR* args)
{
  Int16 res = getInt16(args[2]);
  UInt8* cp = getStr(args, 2);
  MemMove(cp, &res, 2);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to unsigned 16 bit integer                              */
/**********************************************************************/
static PTR nativeSetU16(PTR* args)
{
  UInt16 res = getUInt16(args[2]);
  UInt8* cp  = getStr(args, 2);
  MemMove(cp, &res, 2);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to 32 bit integer                                       */
/**********************************************************************/
static PTR nativeSetS32(PTR* args)
{
  Int32 res = getInt32(args[2]);
  UInt8* cp = getStr(args, 4);
  MemMove(cp, &res, 4);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to unsigned 32 bit integer                              */
/**********************************************************************/
static PTR nativeSetU32(PTR* args)
{
  UInt32 res = getUInt32(args[2]);
  UInt8* cp  = getStr(args, 4);
  MemMove(cp, &res, 4);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to 32 bit IEEE real                                     */
/**********************************************************************/
static PTR nativeSetF32(PTR* args)
{
  float res  = doubleToFloat(realVal(args[2]));
  UInt8* cp  = getStr(args, 4);
  MemMove(cp, &res, 4);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to 64 bit IEEE real                                     */
/**********************************************************************/
static PTR nativeSetF64(PTR* args)
{
  double res = realVal(args[2]);
  UInt8* cp  = getStr(args, 8);
  MemMove(cp, &res, 8);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Insert C string (NUL terminated) into buffer                       */
/**********************************************************************/
static PTR nativeSetCStr(PTR* args)
{
  UInt16 len = stringLength(args[2]);
  UInt8* cp  = getStr(args, len+1);
  MemMove(cp, printString(args[2]), len+1);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to PalmOS timestamp                                     */
/**********************************************************************/
static PTR nativeSetTS(PTR* args)
{
  UInt32 res = (UInt32)FOREIGNVAL(args[2]);
  UInt8* cp  = getStr(args, 4);
  MemMove(cp, &res, 4);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to PalmOS date                                          */
/**********************************************************************/
static PTR nativeSetDate(PTR* args)
{
  DateType res = GETDATE(args[2]);
  UInt8* cp  = getStr(args, 2);
  MemMove(cp, &res, 2);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Set buffer to PalmOS time                                          */
/**********************************************************************/
static PTR nativeSetTime(PTR* args)
{
  TimeType res = GETTIME(args[2]);
  UInt8* cp  = getStr(args, 2);
  MemMove(cp, &res, 2);
  ArrayHandleUnlock(glHd);
  return args[0];
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule structBuiltins = 
{
  MODULE_FUNC(NULL),
  {"buf-get-s8",    NATIVE2(nativeGetS8,  tySTRING, tyINDEX)},
  {"buf-get-u8",    NATIVE2(nativeGetU8,  tySTRING, tyINDEX)},
  {"buf-get-s16",   NATIVE2(nativeGetS16, tySTRING, tyINDEX)},
  {"buf-get-u16",   NATIVE2(nativeGetU16, tySTRING, tyINDEX)},
  {"buf-get-s32",   NATIVE2(nativeGetS32, tySTRING, tyINDEX)},
  {"buf-get-u32",   NATIVE2(nativeGetU32, tySTRING, tyINDEX)},
  {"buf-get-f32",   NATIVE2(nativeGetF32, tySTRING, tyINDEX)},
  {"buf-get-f64",   NATIVE2(nativeGetF64, tySTRING, tyINDEX)},
  {"buf-get-ts",    NATIVE2(nativeGetTS,  tySTRING, tyINDEX)},
  {"buf-get-time",  NATIVE2(nativeGetTime,tySTRING, tyINDEX)},
  {"buf-get-date",  NATIVE2(nativeGetDate,tySTRING, tyINDEX)},
  {"buf-get-cstr",  NATIVE2(nativeGetCStr,tySTRING, tyINDEX)},

  {"buf-set-s8!",   NATIVE3(nativeSetS8,  tySTRING, tyINDEX, tyINT)},
  {"buf-set-u8!",   NATIVE3(nativeSetU8,  tySTRING, tyINDEX, tyINT)},
  {"buf-set-s16!",  NATIVE3(nativeSetS16, tySTRING, tyINDEX, tyINT)},
  {"buf-set-u16!",  NATIVE3(nativeSetU16, tySTRING, tyINDEX, tyINT)},
  {"buf-set-s32!",  NATIVE3(nativeSetS32, tySTRING, tyINDEX, tyINT)},
  {"buf-set-u32!",  NATIVE3(nativeSetU32, tySTRING, tyINDEX, tyINT)},
  {"buf-set-f32!",  NATIVE3(nativeSetF32, tySTRING, tyINDEX, tyREAL)},
  {"buf-set-f64!",  NATIVE3(nativeSetF64, tySTRING, tyINDEX, tyREAL)},
  {"buf-set-ts!",   NATIVE3(nativeSetTS,  tySTRING, tyINDEX, FOREIGN(FT_TIMESTAMP))},
  {"buf-set-time!", NATIVE3(nativeSetTime,tySTRING, tyINDEX, FOREIGN(FT_TIME))},
  {"buf-set-date!", NATIVE3(nativeSetDate,tySTRING, tyINDEX, FOREIGN(FT_DATE))},
  {"buf-set-cstr!", NATIVE3(nativeSetCStr,tySTRING, tyINDEX, tySTRING)},
  {NULL}
};
