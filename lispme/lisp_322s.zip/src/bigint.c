/**********************************************************************/
/*                                                                    */
/* bigint.c: LISPME unlimited precision integers                      */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 24.12.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "bigint.h"
#include "io.h"
#include "util.h"
#include "LispMe.h"
#include "port.h"
#include "fpstuff.h"
#include "arith.h"

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define LIMB_MAX_VAL  65535u
#define LIMB_BASE     (((DLimb)1) << LIMB_BITS)
#define MAX_OUT_LIMBS 3000 
//#define MAX_OUT_LIMBS -1 

#define BIGMEM(p) ((Limb*)ArrayHandleLock(DmQueryRecord(dbRef,ARR_INDEX(p))))
#define BIGSIZE(p) (ArrayHandleSize(DmQueryRecord(dbRef, ARR_INDEX(p)))/LIMB_SIZE)

#define NORMALIZE_REDUCE(x,lx,px) \
    normalize(x, &lx);\
    if (lx==1) {\
      int neg = !!BIGSIGN(px);\
      if (*x <= MAX_SMALLINT+neg)\
        px = MKINT(neg?-*x:*x);}

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/

/**********************************************************************/
/* Local data                                                         */
/**********************************************************************/

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static PTR  addsub(PTR pa, PTR pb, Boolean invert)             SEC(MOD);
static PTR  makeBigint(UInt16 len, UInt16 low, UInt16 high, 
                       Boolean negative)                       SEC(MOD);
static void normalize(Limb* a, UInt16* la)                     SEC(MOD);
static int  bigComp(Limb* a, UInt16 la, Limb* b, UInt16 lb)    SEC(MOD);
static Limb divSingle(Limb* a, UInt16 la, Limb b)              SEC(MOD);
static void divBig(Limb* u, UInt16 lu, Limb* v, UInt16 lv,
                   Limb* q)                                    SEC(MOD);

/**********************************************************************/
/* Print a big integer                                                */
/**********************************************************************/
void writeBig(PTR p)
{
  Int16     i, num;
  MemHandle recHand;
  Limb      *pli, *d, *t;
  UInt32    size;

  recHand = DmQueryRecord(dbRef, ARR_INDEX(p));
  num = ArrayHandleSize(recHand)/LIMB_SIZE;
  pli = (Limb*)(ArrayHandleLock(recHand));

  if (BIGSIGN(p))
    outStr("-");

  /*------------------------------------------------------------------*/
  /* Try to allocate a buffer t containing both the bigint and its    */
  /* equivalent in base 10000 (the largest power of ten < max Limb)   */
  /* The storage needed is ceiling(num*log(65536)/log(10000)) which   */
  /* is num*1.204... < num*5/4 used as upper bound.                   */
  /* While the bigint decreases, the digit sequence grows into the    */
  /* same storage.                                                    */
  /*------------------------------------------------------------------*/
  size = (UInt32)num*5/4 + 3; 
  if (num >= MAX_OUT_LIMBS || (t = MemPtrNew(size*LIMB_SIZE)) == NULL) {
    /*----------------------------------------------------------------*/
    /* No space for decimal output, at least print limbs sedecimally  */
    /*----------------------------------------------------------------*/
    outStr("#x");

    for (i=num-1; i>=0; --i) {
      StrIToH(token, pli[i]);
      outStr(token+4);
    }
  }
  else {
    /*----------------------------------------------------------------*/
    /* Convert to decimal in groups of 4 digits                       */
    /* Use first num Limbs of output buf for copy of number (it's     */
    /* destroyed by in-place division) and the remaining Limbs are    */
    /* the digits in base 10000                                       */
    /*----------------------------------------------------------------*/
    MemMove(t, pli, num*LIMB_SIZE);
    d = t + size;
    do {    
      *--d = divSingle(t, num, 10000);
      if (t[num-1] == 0)
        --num;
    } while (num>0);
    
    StrIToA(token, *d++); // print first "digit" without leading zeros
    outStr(token);
    while (d < t+size) {
      StrPrintF(token, "%04d", *d++); // and following with leading zeros
      outStr(token);
    }
    MemPtrFree(t);
  }
  ArrayHandleUnlock(recHand);
}

/**********************************************************************/
/* Count leading zeros in Limb                                        */
/**********************************************************************/
static UInt16 leadingZeros(Limb a)
{
  UInt16 lz;
  for (lz = LIMB_BITS; a>0; a >>= 1)
    --lz; 
  return lz;
}

/**********************************************************************/
/* Normalize a big int (trim most significant (trailing) zero limbs)  */
/**********************************************************************/
static void normalize(Limb* a, UInt16* la)
{
  UInt16 i = *la;
  while (i > 1) 
    if (a[i-1] != 0) 
      break;
    else
      --i;
  if (i < *la) {
    ArrayPtrResize(a, ArraySize(i*LIMB_SIZE));
    *la = i;
  }
}

/**********************************************************************/
/* Add two big integers (Assume: ld > la >= lb)                       */
/**********************************************************************/
static void addBig(Limb* a, UInt16 la, Limb* b, UInt16 lb, Limb* d)
{
  Int32 s;
  Limb   c = 0;
  while (lb-- > 0 && la-- > 0) {
    s = (DLimb)*a++ + *b++ + c;
    c = s > LIMB_MAX_VAL;
    *d++ = s; 
  }
  while (la-- > 0) {
    s = (DLimb)*a++ + c;
    c = s > LIMB_MAX_VAL;
    *d++ = s; 
  }
  *d = c;
}

/**********************************************************************/
/* Subtract two big integers (Assume: ld > la >= lb)                  */
/**********************************************************************/
static void subBig(Limb* a, UInt16 la, Limb* b, UInt16 lb, Limb* d)
{
  Int32 s;
  Limb   c = 0;
  while (lb-- > 0 && la-- > 0) {
    s = (DLimb)*a++ - *b++ - c;
    c = s < 0;
    *d++ = s; 
  }
  while (la-- > 0) {
    s = (DLimb)*a++ - c;
    c = s < 0;
    *d++ = s; 
  }
}

/**********************************************************************/
/* compare two big integers                                           */
/**********************************************************************/
int bigComp(Limb* a, UInt16 la, Limb* b, UInt16 lb)
{
  if (la == lb) {
    do {
      --la;
      if (a[la] > b[la])
        return 1;
      else if (a[la] < b[la])
        return -1;
    } while (la > 0);
    return 0;
  }
  else
    return (Int32)la-(Int32)lb; 
}

/**********************************************************************/
/* Simple multiplication (Assume: ld >= la+lb)                        */
/* Should use Karatsuba multiplication e.g. for larger operands...    */
/**********************************************************************/
static void mulBig(Limb* a, UInt16 la, Limb* b, UInt16 lb, Limb* d)
{
  DLimb  p;
  Limb   c;
  UInt16 i,j;
  
  // Assume d[0..la-1] == 0

  for (j=0; j<lb; ++j) {
    if (b[j] == 0)
      d[j+la] = 0;
    else {
      for (i=0,c=0; i<la; ++i) {
        p = (DLimb)a[i]*b[j] + d[i+j] + c;
        d[i+j] = p;
        c = p >> LIMB_BITS;
      }
      d[j+la] = c;
    }
  }
}

/**********************************************************************/
/* Multiply (in place) by single limb and add  (a = a*b+c)            */
/**********************************************************************/
Limb mulAddSingle(Limb* a, UInt16* la, Limb b, Limb c)
{
  DLimb  p;
  UInt16 i;

  for (i=0; i < *la; ++i) {
    p = (DLimb)a[i]*b+c;
    a[i] = p;
    c = p >> LIMB_BITS;
  }
  if (c)
    a[(*la)++] = c;
    
  return c;
}

/**********************************************************************/
/* Shift left in place, no carry (upto LIMB_BITS places)              */
/**********************************************************************/
static void simpleShiftLeft(Limb* a, UInt16 la, UInt16 n)
{
  int i;
  UInt16 b,c=0;
  for (i=0; i<la; ++i) {
    b = a[i];
    a[i] = c>>(LIMB_BITS-n) | b<<n;
    c = b;
  }
}

/**********************************************************************/
/* Shift right in place, no carry (upto LIMB_BITS places)             */
/**********************************************************************/
static void simpleShiftRight(Limb* a, UInt16 la, UInt16 n)
{
  int i;
  UInt16 b,c=0;
  for (i=la-1; i>=0; --i) {
    b = a[i];
    a[i] = c<<(LIMB_BITS-n) | b>>n;
    c = b;
  }
}

/**********************************************************************/
/* General shift (SMALLINT and BIGINT), arbitrary shift count         */
/**********************************************************************/
PTR shiftBigint(PTR pa, Int32 n) 
{
  Limb    *a, *d;
  UInt16  la, ld;
  PTR     res = NIL;
  Int32   lshift;
  Int16   bshift;
  Boolean neg = false;

  if (n==0)
    return pa;
  else {
    if (n > 0) {
      /*--------------------------------------------------------------*/
      /* Shift left                                                   */
      /*--------------------------------------------------------------*/
      if (IS_SMALLINT(pa)) {
        /*------------------------------------------------------------*/
        /* Check if shifted value fits in SMALLINT                    */
        /*------------------------------------------------------------*/
        Int16 v = INTVAL(pa);
        if (v == 0)
          return pa;
        else if (v > 0) {
          if (n+1 < leadingZeros(v))
            return MKINT(v << n);
        }
        else {
          if (n+1 < leadingZeros(~v))
            return MKINT(v << n);
        }
        pa = int16ToBig(v);
      }

      PROTECT(pa);
      PROTECT(res);
      lshift = n / LIMB_BITS;
      bshift = n % LIMB_BITS;
      la = BIGSIZE(pa);
      ld = la + lshift + (bshift > 0);
      res = makeBigint(ld, 0, 0, BIGSIGN(pa));
    
      a = BIGMEM(pa);
      d = BIGMEM(res);
      MemMove(d+lshift, a, la*LIMB_SIZE);
      if (bshift) 
        simpleShiftLeft(d+lshift, la+1, bshift);

      normalize(d, &ld); // cannot fit in SMALLINT!
    }
    else {
      /*--------------------------------------------------------------*/
      /* Shift right                                                  */
      /*--------------------------------------------------------------*/
      n = -n;
      if (IS_SMALLINT(pa))
        return MKINT(INTVAL(pa) >> min(n,LIMB_BITS));

      lshift = n / LIMB_BITS;
      bshift = n % LIMB_BITS;
      la = BIGSIZE(pa);
      if (la <= lshift) // All bits shifted out
        return MKINT(BIGSIGN(pa) ? -1 : 0);

      PROTECT(pa);
      PROTECT(res);
      if (BIGSIGN(pa)) {
        /*------------------------------------------------------------*/
        /* Shift the complement and remember to complement afterwards */
        /*------------------------------------------------------------*/
        pa  = logNot(pa);
        neg = true;
      }
      res = makeBigint(ld=la-lshift, 0, 0, false);
    
      a = BIGMEM(pa);
      d = BIGMEM(res);
      MemMove(d, a+lshift, ld*LIMB_SIZE);
      if (bshift) 
        simpleShiftRight(d, ld, bshift);

      NORMALIZE_REDUCE(d, ld, res)
    }

    ArrayPtrUnlock(d);
    ArrayPtrUnlock(a);
    if (neg)
      res = logNot(res); 
    UNPROTECT(res); 
    UNPROTECT(pa); 
    return res;  
  }
}

/**********************************************************************/
/* Division by multi-limb divisor                                     */
/* Uses Knuth's Algorithm D, section 4.3.1, Volume 2                  */
/* Assumes that u and v are already copies and modifiable             */
/**********************************************************************/
static void divBig(Limb* u, UInt16 lu, Limb* v, UInt16 lv, Limb* q)
{
  UInt16  shift;
  int     i,j;

  // D1: Normalization
  shift = leadingZeros(v[lv-1]);
  simpleShiftLeft(u,lu+1,shift); // lu is original length without leading 0
  simpleShiftLeft(v,lv,shift);

  // D2: j loop
  for (j=lu-lv; j>=0; --j) {
    // D3: Calculate qhat
    DLimb qhat, rhat, c, d;
    DLimb tdiv = ((DLimb)u[lv+j] << LIMB_BITS) | u[lv+j-1];

    // The following two assignments generate suboptimal machine code
    // (TWO calls to 32:32 library division!), the M68000 DIVU
    // instruction gives both quotient and remainder of 
    // a 32:16 bit division in 1/7 of the time.
    // The test for qhat overflow is also done by checking the
    // overflow bit and setting qhat to LIMB_BASE-1
    //
    // qhat = tdiv / v[lv-1];
    // rhat = tdiv % v[lv-1];

    asm("clr.l %0\n"
        "\tclr.l %1\n"
        "\tdivu.w %2,%3\n"
        "\tjbvc .LSKIP\n"
        "\tmove.w #0xffff,%0\n"
        "\tmove.w %0,%1\n"
        "\tjbra .LDONE\n" 
        ".LSKIP: move.w %3,%0\n"
        "\tswap %3\n"
        "\tmove.w %3,%1\n"
        ".LDONE:\n"
        : "=d" (qhat), "=d" (rhat) : "d" (v[lv-1]), "d" (tdiv));

    while (/* qhat==LIMB_BASE || !! already tested in ASM code !! */
        qhat*v[lv-2] > ((rhat << LIMB_BITS) | u[lv+j-2])) {
      qhat--;
      rhat+=v[lv-1];
      if (rhat >= LIMB_BASE)
        break;
    }

    // D4: Multiply and subtract
    for (i=0, c=0; i<lv; ++i) {
      d = v[i]*qhat + c;
      c = d >> LIMB_BITS;
      if (u[i+j] < (Limb)d)
        c++;
      u[i+j] -= d;
    }
    d = c;
    c = u[lv+j] < (Limb)d;
    u[lv+j] -= d;

    // D5: Test remainder
    if (c) {
      // D6: Add back
      for (i=0, c=0; i<lv ; ++i) {
        c += (DLimb)u[i+j] + v[i];
        u[i+j] = c;
        c >>= LIMB_BITS;
      }
      u[lv+j] += c; 
      qhat--;
    }
    q[j] = qhat;
  } // D7: Loop on j

  // D8: Unnormalize
  simpleShiftRight(u,lv,shift);
  ArrayPtrResize(u, ArraySize(lv*LIMB_SIZE));
}

/**********************************************************************/
/* Divide (in place) by single limb returning remainder               */
/**********************************************************************/
Limb divSingle(Limb* a, UInt16 la, Limb b)
{
  Limb  r = 0;
  DLimb d;
  
  do {
    --la;
    d = ((DLimb)r << LIMB_BITS) + a[la];
    // The following two assignments generate suboptimal machine code
    // (TWO calls to 32:32 library division!), the M68000 DIVU
    // instruction gives both quotient and remainder of 
    // a 32:16 bit division in 1/7 of the time,
    // which is most significant for printing bigints.
    //
    // a[la] = d/b; r = d%b;
    asm("divu.w %2,%3\n"
        "\tmove.l %3,%1\n"
        "\tswap %1\n" 
        : "=d" (a[la]), "=d" (r) : "d" (b), "d" (d));
  } while (la>0);
  return r;
}

/**********************************************************************/
/* Adding/subtracting                                                 */
/**********************************************************************/
static PTR addsub(PTR pa, PTR pb, Boolean invert)
{
  Limb   *a, *b, *d;
  UInt16 la, lb, ld;
  PTR    res;

  /*------------------------------------------------------------------*/
  /* Create destination (worst case size assumption)                  */
  /*------------------------------------------------------------------*/
  la  = BIGSIZE(pa);
  lb  = BIGSIZE(pb);
  ld  = max(la,lb)+1;
  res = makeBigint(ld, 0, 0, false);

  /*------------------------------------------------------------------*/
  /* Have to query records again (makeBigint might have caused GC)    */
  /*------------------------------------------------------------------*/
  a = BIGMEM(pa);
  b = BIGMEM(pb);
  d = BIGMEM(res);

  if (invert != (BIGSIGN(pa) == BIGSIGN(pb))) {
    /*----------------------------------------------------------------*/
    /* Same sign, just add                                            */
    /*----------------------------------------------------------------*/
    if (la >= lb)
      addBig(a, la, b, lb, d);
    else 
      addBig(b, lb, a, la, d);
  
    SET_BIGSIGN(res, BIGSIGN(pa));
  }
  else {
    /*----------------------------------------------------------------*/
    /* Different sign, subtract smaller from larger                   */
    /*----------------------------------------------------------------*/
    int co = bigComp(a, la, b, lb);
    if (co == 0) {
      res = MKINT(0);
      goto cleanup;
    }
    else if (co > 0) 
      subBig(a, la, b, lb, d);
    else 
      subBig(b, lb, a, la, d);

    SET_BIGSIGN(res, BIGSIGN(pa) ? co>0 : co<0);
  }

  NORMALIZE_REDUCE(d,ld,res)

  /*------------------------------------------------------------------*/
  /* Cleanup                                                          */
  /*------------------------------------------------------------------*/
cleanup:
  ArrayPtrUnlock(d);
  ArrayPtrUnlock(b);
  ArrayPtrUnlock(a);

  return res;
}

/**********************************************************************/
/* Adding                                                             */
/**********************************************************************/
PTR addBigint(PTR pa, PTR pb)
{
  return addsub(pa, pb, false);
}

/**********************************************************************/
/* Subtracting                                                        */
/**********************************************************************/
PTR subBigint(PTR pa, PTR pb)
{
  return addsub(pa, pb, true);
}

/**********************************************************************/
/* Multiplying                                                        */
/**********************************************************************/
PTR mulBigint(PTR pa, PTR pb) 
{
  Limb   *a, *b, *d;
  UInt16 la, lb, ld;
  PTR    res;

  /*------------------------------------------------------------------*/
  /* Create destination (worst case size assumption)                  */
  /*------------------------------------------------------------------*/
  la = BIGSIZE(pa);
  lb = BIGSIZE(pb);
  ld = la+lb;
  res = makeBigint(ld, 0, 0, BIGSIGN(pa) != BIGSIGN(pb));

  /*------------------------------------------------------------------*/
  /* Have to query records again (makeBigint might have caused GC)    */
  /*------------------------------------------------------------------*/
  a = BIGMEM(pa);
  b = BIGMEM(pb);
  d = BIGMEM(res);

  mulBig(a, la, b, lb, d);

  NORMALIZE_REDUCE(d,ld,res);

  /*------------------------------------------------------------------*/
  /* Cleanup                                                          */
  /*------------------------------------------------------------------*/
  ArrayPtrUnlock(d);
  ArrayPtrUnlock(b);
  ArrayPtrUnlock(a);

  return res;
}

/**********************************************************************/
/* Division/remainder                                                 */
/**********************************************************************/
PTR divRemBigint(PTR pa, PTR pb, DivOp op) 
{
  Limb   *a, *b, *q, *u, *v;
  UInt16 la, lb, lq;
  PTR    res, pq=NIL, pu=NIL, pv=NIL;
  int    cmp;

  /*------------------------------------------------------------------*/
  /* Determine lengths and special cases                              */
  /*------------------------------------------------------------------*/
  la  = BIGSIZE(pa);
  lb  = BIGSIZE(pb);
  a   = BIGMEM(pa);
  b   = BIGMEM(pb);
  cmp = bigComp(a,la,b,lb);
  ArrayPtrUnlock(b);
  ArrayPtrUnlock(a);

  PROTECT(pq);
  PROTECT(pu);
  PROTECT(pv);

  /*------------------------------------------------------------------*/
  /* Some special cases                                               */
  /*------------------------------------------------------------------*/
  if (cmp < 0) {
    pq = MKINT(0); 
    pu = pa;
  }
  else if (cmp == 0) {
    pq = MKINT(BIGSIGN(pa) == BIGSIGN(pb) ? 1 : -1); 
    pu = MKINT(0);
  }
  else if (lb == 1) {
    /*----------------------------------------------------------------*/
    /* Divide by single limb                                          */
    /*----------------------------------------------------------------*/
    Int32 rem;
    pq = makeBigint(lq=la, 0, 0, BIGSIGN(pa) != BIGSIGN(pb));
    a = BIGMEM(pa);
    b = BIGMEM(pb);
    q = BIGMEM(pq);
    MemMove(q, a, la*LIMB_SIZE);

    rem = divSingle(q, lq, b[0]); 
    pu  = makeNum(BIGSIGN(pa) ? -rem : rem);

    NORMALIZE_REDUCE(q,lq,pq)

    ArrayPtrUnlock(q);
    ArrayPtrUnlock(b);
    ArrayPtrUnlock(a);
  }
  else {
    /*----------------------------------------------------------------*/
    /* The hard case                                                  */
    /*----------------------------------------------------------------*/
    pu = makeBigint(la+1,       0, 0, BIGSIGN(pa));
    pv = makeBigint(lb,         0, 0, BIGSIGN(pb));
    pq = makeBigint(lq=la-lb+1, 0, 0, BIGSIGN(pa) != BIGSIGN(pb));

    /*----------------------------------------------------------------*/
    /* Have to query records again (makeBigint might have caused GC)  */
    /*----------------------------------------------------------------*/
    a = BIGMEM(pa);
    b = BIGMEM(pb);
    u = BIGMEM(pu);
    v = BIGMEM(pv);
    q = BIGMEM(pq);

    MemMove(u, a, la*LIMB_SIZE);
    u[la] = 0;
    MemMove(v, b, lb*LIMB_SIZE);
    ArrayPtrUnlock(b);
    ArrayPtrUnlock(a);

    divBig(u,la,v,lb,q);

    NORMALIZE_REDUCE(u,lb,pu)
    NORMALIZE_REDUCE(q,lq,pq)

    ArrayPtrUnlock(q);
    ArrayPtrUnlock(v);
    ArrayPtrUnlock(u);
  }

  switch (op) {
    case DIVOP_DIV:
      /*--------------------------------------------------------------*/
      /* Leave exact result if no remainder, use real division else   */
      /* (FIXME: Has precision problems with very large BIGINTS not   */
      /* representable as reals!)                                     */
      /*--------------------------------------------------------------*/
      if (pu == MKINT(0))
        res = pq;
      else {
        FlpCompDouble frac;
        frac.d = divDouble(IS_SMALLINT(pu)
                             ? longToDouble(INTVAL(pu))
                             : bigToDouble(pu),
                           bigToDouble(pb));
        if (isNan(frac)) {
          /*----------------------------------------------------------*/
          /* All fractional digits lost since, use 0                  */
          /*----------------------------------------------------------*/
          frac.d = 0.0;   
        }
        res = allocReal(addDouble(IS_SMALLINT(pq)
                                    ? longToDouble(INTVAL(pq))
                                    : bigToDouble(pq),
                                  frac.d));
      }
      break;
       
    case DIVOP_IDIV: res = pq; break;
    case DIVOP_REM:  res = pu; break;
    case DIVOP_BOTH: res = cons(pq,pu); break;
  }

  UNPROTECT(pv);
  UNPROTECT(pu);
  UNPROTECT(pq);
  return res;
}

/**********************************************************************/
/* Logic operations                                                   */
/* This function has been inspired by Python's long integer routines  */
/**********************************************************************/
PTR logBigint(PTR pa, PTR pb, BitOp op)
{
  Limb    *a, *b, *d, ma, mb;
  UInt16  la, lb, ld, i;
  PTR     res = NIL;
  Boolean neg = false;

  PROTECT(pa);
  PROTECT(pb);
  PROTECT(res);

  if (BIGSIGN(pa)) {
    pa = logNot(pa);
    ma = LIMB_MAX_VAL;
  }
  else
    ma = 0;

  if (BIGSIGN(pb)) {
    pb = logNot(pb);
    mb = LIMB_MAX_VAL;
  }
  else
    mb = 0;
  
  switch (op) {
    case BITOP_AND:
      if (ma && mb) {
        op = BITOP_IOR;
        ma ^= LIMB_MAX_VAL;
        mb ^= LIMB_MAX_VAL;
        neg = true;
      }
      break;

    case BITOP_IOR:
      if (ma || mb) {
        op = BITOP_AND;
        ma ^= LIMB_MAX_VAL;
        mb ^= LIMB_MAX_VAL;
        neg = true;
      }
      break;

    case BITOP_XOR:
      if (ma != mb) {
        ma ^= LIMB_MAX_VAL;
        neg = true;
      }
      break;
  }

  /*------------------------------------------------------------------*/
  /* Create destination                                               */
  /*------------------------------------------------------------------*/
  la  = BIGSIZE(pa);
  lb  = BIGSIZE(pb);
  ld  = op == BITOP_AND
        ? (ma
          ? lb 
          : (mb ? la
                : min(la,lb)))
        : max(la,lb);
  res = makeBigint(ld, 0, 0, false);

  /*------------------------------------------------------------------*/
  /* Have to query records again (makeBigint might have caused GC)    */
  /*------------------------------------------------------------------*/
  a = BIGMEM(pa);
  b = BIGMEM(pb);
  d = BIGMEM(res);

  for (i=0; i<ld; ++i) {
    Limb da = (i<la ? a[i] : 0) ^ ma;
    Limb db = (i<lb ? b[i] : 0) ^ mb;
    switch (op) {
      case BITOP_AND: d[i] = da & db; break;
      case BITOP_IOR: d[i] = da | db; break;
      case BITOP_XOR: d[i] = da ^ db; break;
    }
  }
  
  NORMALIZE_REDUCE(d,ld,res)

  /*------------------------------------------------------------------*/
  /* Cleanup                                                          */
  /*------------------------------------------------------------------*/
  ArrayPtrUnlock(d);
  ArrayPtrUnlock(b);
  ArrayPtrUnlock(a);

  if (neg)
    res = logNot(res);

  UNPROTECT(res);
  UNPROTECT(pb);
  UNPROTECT(pa);

  return res;
}

/**********************************************************************/
/* Binary not (1-complement)                                          */
/**********************************************************************/
PTR logNot(PTR pa)
{
  Limb   *a, *d;
  Limb   one = 1;
  UInt16 la, ld;
  PTR    res;

  if (IS_SMALLINT(pa)) {
    /*----------------------------------------------------------------*/
    /* Complement is SMALLINT, too                                    */
    /*----------------------------------------------------------------*/
    return MKINT(~INTVAL(pa));
  }
  else {
    /*----------------------------------------------------------------*/
    /* Compute ~x as -(x+1) (May increase/decrease size in rare cases)*/
    /*----------------------------------------------------------------*/
    la  = BIGSIZE(pa);
    res = makeBigint(ld=la+1, 0, 0, !BIGSIGN(pa));

    a = BIGMEM(pa);
    d = BIGMEM(res);

    if (BIGSIGN(pa))
      subBig(a, la, &one, 1, d);
    else 
      addBig(a, la, &one, 1, d);

    normalize(d, &ld); // Don't have to reduce, since never SMALLINT!
    ArrayPtrUnlock(d);
    ArrayPtrUnlock(a);
    return res;
  }
}

/**********************************************************************/
/* Comparison                                                         */
/**********************************************************************/
int compBigint(PTR pa, PTR pb)
{
  Limb      *a, *b;
  UInt16    la, lb;
  MemHandle recHand;
  int       res;

  if (BIGSIGN(pa) != BIGSIGN(pb)) 
    return BIGSIGN(pa) ? -1 : 1;
  else {
    recHand = DmQueryRecord(dbRef, ARR_INDEX(pa));
    la  = ArrayHandleSize(recHand) / LIMB_SIZE;
    a   = (Limb*)(ArrayHandleLock(recHand));
    recHand = DmQueryRecord(dbRef, ARR_INDEX(pb));
    lb  = ArrayHandleSize(recHand) / LIMB_SIZE;
    b   = (Limb*)(ArrayHandleLock(recHand));
    res = bigComp(a,la,b,lb);
    ArrayPtrUnlock(b);
    ArrayPtrUnlock(a);
    return BIGSIGN(pa) ? -res : res;
  }
}

/**********************************************************************/
/* Convert real to bigint                                             */
/**********************************************************************/
PTR realToBig(PTR real)
{
  Int16 la,n;
  PTR   res;
  Limb* a;
  FlpCompDouble fcd;

  fcd.d = getReal(real);
  if (leqDouble((double)MIN_SMALLINT, fcd.d) &&
      leqDouble(fcd.d, (double)MAX_SMALLINT))
    return MKINT(doubleToLong(fcd.d));
  else if ((fcd.ul[0] & 0x7ff00000) == 0x7ff00000) {
    /*----------------------------------------------------------------*/
    /* Infinity or NaN                                                */
    /*----------------------------------------------------------------*/
    parmError(real,"integer");
  }
  else {
    n  = FlpGetExponent(fcd.d);
    la = n / LIMB_BITS + 1;

    res = makeBigint(la, 0, 0, FlpGetSign(fcd));
    a = BIGMEM(res);
    a[la-1] = (fcd.fdb.manH>>5) | (1<<(LIMB_BITS-1)); // implicit MSB 1 
    if (la >= 2) {
      a[la-2] = (fcd.fdb.manH<<11) | (fcd.fdb.manL>>21);
      if (la >= 3) {
        a[la-3] = fcd.fdb.manL>>5;
        if (la >= 4)
          a[la-4] = fcd.fdb.manL<<11;
      }
    }
    simpleShiftRight(a, la, LIMB_BITS - 1 - n%LIMB_BITS); 
    ArrayPtrUnlock(a);
    return res;
  }
}

/**********************************************************************/
/* Convert to real                                                    */
/**********************************************************************/
double bigToReal(Limb* a, UInt16 la, Boolean negative)
{
  FlpCompDouble fcd = {0.0};
  int lz;
  UInt32 exp;

  lz = leadingZeros(a[la-1]);
  exp = la*LIMB_BITS-lz-1; // implicit 1 before binary point
  if (exp >= 1024) {
    /*----------------------------------------------------------------*/
    /* Too big for double format, set to infinity instead             */
    /*----------------------------------------------------------------*/
    fcd.fdb.exp = 0x7ff;
  }
  else {
    fcd.fdb.exp = exp + 1023;

    /*----------------------------------------------------------------*/
    /* Copy shifted mantissa bits                                     */
    /*----------------------------------------------------------------*/
#define A(ix) (la>=(ix)?a[la-(ix)]:0)
#define SHIFT(x,y) (((y)>0)? ((DLimb)(x))<<(y) : ((DLimb)(x))>>(-(y)))

    fcd.fdb.manH = SHIFT(A(1),lz+5)  | SHIFT(A(2),lz-11) | SHIFT(A(3),lz-27);
    fcd.fdb.manL = SHIFT(A(2),lz+21) | SHIFT(A(3),lz+5)  |
                   SHIFT(A(4),lz-11) | SHIFT(A(5),lz-27);
#undef A
#undef SHIFT
  }

  if (negative)
    FlpSetNegative(fcd);

  return fcd.d;
}

/**********************************************************************/
/* Convert PTR to real                                                */
/**********************************************************************/
double bigToDouble(PTR big)
{
  Limb* a;
  Int16 la;
  MemHandle recHand;
  double d;

  recHand = DmQueryRecord(dbRef, ARR_INDEX(big));
  la = ArrayHandleSize(recHand) / LIMB_SIZE;
  a = (Limb*)(ArrayHandleLock(recHand));
  d = bigToReal(a, la, BIGSIGN(big));
  ArrayHandleUnlock(recHand);
  return d;
}

/**********************************************************************/
/* Create big integer with given length, initialized by high and low  */
/* limb values                                                        */
/**********************************************************************/
static PTR makeBigint(UInt16 len, Limb low, Limb high, Boolean negative)
{
  MemHandle recHand;
  Limb*     recPtr;
  Limb*     lp;
  UInt16    index = dmMaxRecordIndex;
  PTR       res;
  Boolean   tried = false;

  if (len == 0)
    return MKINT(0);

  res = cons(NIL,NIL);
  while (true) {
    if ((recHand = DmNewRecord(dbRef, &index, ArraySize(len*LIMB_SIZE))))
      break;
    else if (tried)
      ErrThrow(ERR_M7_NO_RECORD_MEM);
    else {
      gc(res,NIL);
      tried = true; 
    }
  } 

  lp  = recPtr = ArrayHandleLock(recHand);
  *lp = low;
  if (len > 1) {
    *++lp = high;
    --len;
  }
  while (--len)
    *++lp = 0;

  ArraySetBackPtr(recPtr, res);
  ArrayHandleUnlock(recHand);
  DmReleaseRecord(dbRef, index, true);
  car(res) = MKARR_CAR(negative ? BIGNTAG : BIGPTAG);
  cdr(res) = MKARR_CDR(index);
  return res;
}

/**********************************************************************/
/* Create big integer from Int16                                      */
/**********************************************************************/
PTR int16ToBig(Int16 val)
{
  return makeBigint(1, abs(val), 0, val < 0);  
}

/**********************************************************************/
/* Create big integer from Int32                                      */
/**********************************************************************/
PTR int32ToBig(Int32 val)
{
  UInt32 v = Abs(val); // abs() only works with Int16 :-(
  UInt32 h = v >> LIMB_BITS;
  return makeBigint(h ? 2 : 1, v, h, val < 0);  
}

/**********************************************************************/
/* Create big integer from UInt32                                     */
/**********************************************************************/
PTR uint32ToBig(UInt32 val)
{
  UInt32 h = val >> LIMB_BITS;
  return makeBigint(h ? 2 : 1, val, h, false);  
}

/**********************************************************************/
/* Create big integer from buffer                                     */
/**********************************************************************/
PTR copyBigint(Limb* a, UInt16 la, Boolean negative)
{
  PTR   res = makeBigint(la, 0, 0, negative);
  Limb* b   = (Limb*)ArrayHandleLock(DmQueryRecord(dbRef, ARR_INDEX(res)));
  MemMove(b, a, la*LIMB_SIZE);
  ArrayPtrUnlock(b);
  return res;
}

/**********************************************************************/
/* Extract Int32 from any integer                                     */
/**********************************************************************/
Int32 getInt32(PTR val)
{
  Int32 res=0;

  if (IS_SMALLINT(val))
    res = INTVAL(val);
  else {
    Limb*  a;
    UInt16 la;
    MemHandle recHand;

    recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
    la = ArrayHandleSize(recHand) / LIMB_SIZE;
    if (la > 2)
      error1(ERR_R6_INT_RANGE, val);
    a = (Limb*)(ArrayHandleLock(recHand));

    if (la == 1)
      res = a[0]; 
    else if (a[1] == 0x8000 && a[0] == 0 && BIGSIGN(val))
      res = 0x80000000;
    else if (a[1] & 0x8000) {
      ArrayHandleUnlock(recHand);
      error1(ERR_R6_INT_RANGE, val);
    }
    else
      res = (Int32)a[1] << LIMB_BITS | a[0]; 
    ArrayHandleUnlock(recHand);
    if (BIGSIGN(val))
      res = -res;
  }
  return res;
}

/**********************************************************************/
/* Extract UInt32 from any integer                                    */
/**********************************************************************/
UInt32 getUInt32(PTR val)
{
  UInt32 res=0;

  if (IS_SMALLINT(val)) {
    if (INTVAL(val) < 0)
      error1(ERR_R6_INT_RANGE, val);
    else
      res = INTVAL(val);
  }
  else {
    Limb*  a;
    UInt16 la;
    MemHandle recHand;

    recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
    la = ArrayHandleSize(recHand) / LIMB_SIZE;
    if (la > 2 || BIGSIGN(val))
      error1(ERR_R6_INT_RANGE, val);
    a = (Limb*)(ArrayHandleLock(recHand));

    if (la == 1)
      res = a[0]; 
    else
      res = (UInt32)a[1] << LIMB_BITS | a[0]; 
    ArrayHandleUnlock(recHand);
  }
  return res;
}

/**********************************************************************/
/* Extract Int16 from any integer                                     */
/**********************************************************************/
Int16 getInt16(PTR val)
{
  Int16 res=0;

  if (IS_SMALLINT(val))
    res = INTVAL(val);
  else {
    Limb*  a;
    UInt16 la;
    MemHandle recHand;

    recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
    la = ArrayHandleSize(recHand) / LIMB_SIZE;
    if (la > 1)
      error1(ERR_R6_INT_RANGE, val);
    a = (Limb*)(ArrayHandleLock(recHand));

    if (a[0] == 0x8000 && BIGSIGN(val))
      res = 0x8000;
    else if (a[0] & 0x8000) {
      ArrayHandleUnlock(recHand);
      error1(ERR_R6_INT_RANGE, val);
    }
    else
      res = a[0]; 
    ArrayHandleUnlock(recHand);
    if (BIGSIGN(val))
      res = -res;
  }
  return res;
}

/**********************************************************************/
/* Extract UInt16 from any integer                                    */
/**********************************************************************/
UInt16 getUInt16(PTR val)
{
  UInt16 res=0;

  if (IS_SMALLINT(val)) {
    if (INTVAL(val) < 0)
      error1(ERR_R6_INT_RANGE, val);
    else
      res = INTVAL(val);
  }
  else {
    Limb*  a;
    UInt16 la;
    MemHandle recHand;

    recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
    la = ArrayHandleSize(recHand) / LIMB_SIZE;
    if (la > 1 || BIGSIGN(val))
      error1(ERR_R6_INT_RANGE, val);
    a = (Limb*)(ArrayHandleLock(recHand));
    res = a[0]; 
    ArrayHandleUnlock(recHand);
  }
  return res;
}

/**********************************************************************/
/* Is number a valid array index? 0 <= n < 65536                      */
/**********************************************************************/
Boolean isIndex(PTR val)
{
  if (IS_SMALLINT(val)) 
    return INTVAL(val) >= 0;
  else if IS_BIGINT(val) {
    UInt16 la;
    MemHandle recHand;

    recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
    la = ArrayHandleSize(recHand) / LIMB_SIZE;
    return la == 1 && !BIGSIGN(val);
  }
  else
    return false;
}

/**********************************************************************/
/* Is bigint odd?                                                     */
/**********************************************************************/
Boolean bigintOdd(PTR val)
{
  Boolean res;
  Limb*  a;
  MemHandle recHand;

  recHand = DmQueryRecord(dbRef, ARR_INDEX(val));
  a = (Limb*)(ArrayHandleLock(recHand));
  res = a[0] & 1;
  ArrayHandleUnlock(recHand);
  return res;
}
