/**********************************************************************/
/*                                                                    */
/* arith.h: LISPME arithmetic functions                               */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_ARITH_H
#define INC_ARITH_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"
#include "bigint.h"

/**********************************************************************/
/* Definitions                                                        */
/**********************************************************************/

/**********************************************************************/
/* Exported functions                                                 */
/**********************************************************************/
double realVal(PTR p)                                           SEC(VM);
PTR    makeNum(Int32 n)                                         SEC(VM);
PTR    makeUNum(UInt32 n)                                       SEC(VM);
PTR    storeNum(double re, double im)                           SEC(VM);
PTR    makePolar(double mag, double ang)                        SEC(VM);
PTR    div(PTR a, PTR b)                                        SEC(VM);
PTR    genBinOp(PTR a, PTR b, ArithOp op)                       SEC(VM);
PTR    genBitOp(PTR a, PTR b, BitOp op)                         SEC(VM);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule numberBuiltins;
extern BuiltInModule numberBuiltins2;
extern BuiltInModule transBuiltins; 

#endif
