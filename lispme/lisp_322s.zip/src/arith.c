/**********************************************************************/
/*                                                                    */
/* arith.c: LISPME arithmetic functions                               */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "arith.h"
#include "vm.h"
#include "LispMe.h"
#include "fpstuff.h"
#include "util.h"
#include "cplx.h"

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void init(ModuleMessage mess);                           SEC(VM);
static PTR  nativeRand(PTR* args)                               SEC(VM);
static PTR  nativeEven(PTR* args)                               SEC(VM);
static PTR  nativeOdd(PTR* args)                                SEC(VM);
static PTR  nativeQuotient(PTR* args)                           SEC(VM);
static PTR  nativeRemainder(PTR* args)                          SEC(VM);
static PTR  nativeDivide(PTR* args)                             SEC(VM);
static PTR  nativeCompl(PTR* args)                              SEC(VM);
static PTR  nativeShift(PTR* args)                              SEC(VM);
static PTR  nativeExact(PTR* args)                              SEC(VM);
static PTR  nativeInexact(PTR* args)                            SEC(VM);
static PTR  nativeInteger(PTR* args)                            SEC(VM);
static PTR  nativeRealPart(PTR* args)                           SEC(VM);
static PTR  nativeImagPart(PTR* args)                           SEC(VM);
static PTR  nativeConjugate(PTR* args)                          SEC(VM);
static PTR  nativeMagnitude(PTR* args)                          SEC(VM);
static PTR  nativeAngle(PTR* args)                              SEC(VM);
static PTR  intdiv(PTR a, PTR b, DivOp op)                      SEC(VM);

/**********************************************************************/
/* Integer arithmetic                                                 */
/**********************************************************************/
static long addInt(long a, long b) {return a+b;};
static long subInt(long a, long b) {return a-b;};
static long mulInt(long a, long b) {return a*b;};

/**********************************************************************/
/* Table of function pointers for arithmetic operations               */
/**********************************************************************/
typedef struct {
  long (*intOp)(long,long);
  long floatOp;
  PTR  (*cplOp)(double,double,double,double);
  PTR  (*bigOp)(PTR,PTR);
} ArithOps;

ArithOps opTable[] = {
  {&addInt, sysFloatEm_d_add, &addCpl, &addBigint},
  {&subInt, sysFloatEm_d_sub, &subCpl, &subBigint},
  {&mulInt, sysFloatEm_d_mul, &mulCpl, &mulBigint}
};

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  Err error;
  UInt16 useCount;

  switch (mess)
  {
    case APP_START: 
      /*--------------------------------------------------------------*/
      /* Search and open MathLib                                      */
      /*--------------------------------------------------------------*/
      error = SysLibFind(MathLibName, &MathLibRef);
      if (error)
        error = SysLibLoad(LibType, MathLibCreator, &MathLibRef);
      if (!error)
        mathLibOK = !MathLibOpen(MathLibRef, MathLibVersion);
      break;

    case APP_STOP:
      /*--------------------------------------------------------------*/
      /* Close MathLib                                                */
      /*--------------------------------------------------------------*/
      if (mathLibOK)
      {
        error = MathLibClose(MathLibRef, &useCount);
        ErrFatalDisplayIf(error, "Can't close MathLib");
        if (useCount == 0)
          SysLibRemove(MathLibRef);
      }
      break;

    default:
  }
}

/**********************************************************************/
/* Invent random number                                               */
/**********************************************************************/
static PTR nativeRand(PTR* args)
{
  if (INTVAL(args[0]) == 0)
    ErrThrow(ERR_R8_DIV_BY_ZERO);
  return MKINT(SysRandom(0) % INTVAL(args[0]));
}

/**********************************************************************/
/* Is number even?                                                    */
/**********************************************************************/
static PTR nativeEven(PTR* args)
{
  if (IS_SMALLINT(args[0]))
    return INTVAL(args[0]) & 1 ? FALSE : TRUE;
  else
    return bigintOdd(args[0]) ? FALSE : TRUE;  
}

/**********************************************************************/
/* Is number odd?                                                     */
/**********************************************************************/
static PTR nativeOdd(PTR* args)
{
  if (IS_SMALLINT(args[0]))
    return INTVAL(args[0]) & 1 ? TRUE : FALSE;
  else
    return bigintOdd(args[0]) ? TRUE : FALSE;  
}

/**********************************************************************/
/* Make Lisp type for Int32                                           */
/**********************************************************************/
PTR makeNum(Int32 n)
{
  if (MIN_SMALLINT<=n && n<=MAX_SMALLINT)
    return MKINT(n);
  else
    return int32ToBig(n);
}

/**********************************************************************/
/* Make Lisp type for UInt32                                          */
/**********************************************************************/
PTR makeUNum(UInt32 n)
{
  if (n <= MAX_SMALLINT)
    return MKINT(n);
  else
    return uint32ToBig(n);
}

/**********************************************************************/
/* Make a real from int or real                                       */
/**********************************************************************/
double realVal(PTR p)
{
  if (IS_SMALLINT(p))
    return longToDouble(INTVAL(p));
  else if (IS_REAL(p))
    return getReal(p);
  else if (IS_BIGINT(p))
    return bigToDouble(p);
  else
    typeError(p,"real");
}

/**********************************************************************/
/* Store a number, reducing it to real if possible                    */
/**********************************************************************/
PTR storeNum(double re, double im)
{
  FlpCompDouble fcd;
  fcd.d = im;
  if (FlpIsZero(fcd))
    return allocReal(re);
  else
    return cons(CPLX_TAG, cons(W=allocReal(re), W=allocReal(im)));
}

/**********************************************************************/
/* Make complex number from polar representation                      */
/**********************************************************************/
PTR makePolar(double mag, double ang)
{
  double x,y;
  if (!mathLibOK)
    ErrThrow(ERR_R12_NO_MATHLIB);
  LMcos(ang,&x);
  LMsin(ang,&y);
  return storeNum(mulDouble(mag,x),mulDouble(mag,y));
}

/**********************************************************************/
/* generic operation with two arbitrary numbers                       */
/**********************************************************************/
PTR genBinOp(PTR a, PTR b, ArithOp op)
{
  if (IS_SMALLINT(a)) {
    if (IS_SMALLINT(b))
      return makeNum(opTable[op].intOp(INTVAL(a),INTVAL(b)));
    else if (IS_BIGINT(b))
      return opTable[op].bigOp(W=int16ToBig(INTVAL(a)),b);
    else if (IS_REAL(b))
      return allocReal(genericDoubleOp(longToDouble(INTVAL(a)),
                                       getReal(b),
                                       opTable[op].floatOp));
    else if (IS_COMPLEX(b))
      return opTable[op].cplOp(longToDouble(INTVAL(a)), 0.0,
                               getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_BIGINT(a)) {
    if (IS_SMALLINT(b))
      return opTable[op].bigOp(a,W=int16ToBig(INTVAL(b)));
    else if (IS_BIGINT(b))
      return opTable[op].bigOp(a,b);
    else if (IS_REAL(b))
      return allocReal(genericDoubleOp(bigToDouble(a),
                                       getReal(b),
                                       opTable[op].floatOp));
    else if (IS_COMPLEX(b))
      return opTable[op].cplOp(bigToDouble(a), 0.0,
                               getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_REAL(a)) {
    if (IS_SMALLINT(b))
      return allocReal(genericDoubleOp(getReal(a),
                                       longToDouble(INTVAL(b)),
                                       opTable[op].floatOp));
    else if (IS_BIGINT(b))
      return allocReal(genericDoubleOp(getReal(a),
                                       bigToDouble(b),
                                       opTable[op].floatOp));
    else if (IS_REAL(b))
      return allocReal(genericDoubleOp(getReal(a),
                                       getReal(b),
                                       opTable[op].floatOp));
    else if (IS_COMPLEX(b))
      return opTable[op].cplOp(getReal(a), 0.0,
                               getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_COMPLEX(a)) {
    if (IS_SMALLINT(b))
      return opTable[op].cplOp(getReal(cadr(a)), getReal(cddr(a)),
                               longToDouble(INTVAL(b)), 0.0);
    if (IS_BIGINT(b))
      return opTable[op].cplOp(getReal(cadr(a)), getReal(cddr(a)),
                               bigToDouble(b), 0.0);
    else if (IS_REAL(b))
      return opTable[op].cplOp(getReal(cadr(a)), getReal(cddr(a)),
                               getReal(b), 0.0);
    else if (IS_COMPLEX(b))
      return opTable[op].cplOp(getReal(cadr(a)), getReal(cddr(a)),
                               getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else
    typeError(a,"number");
}

/**********************************************************************/
/* divide two arbitrary numbers                                       */
/**********************************************************************/
PTR div(PTR a, PTR b)
{
  if (IS_SMALLINT(a)) {
    long a1 = INTVAL(a);
    if (IS_SMALLINT(b)) {
      long b1 = INTVAL(b);
      if (b1 == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      if (a1%b1 == 0)
        return makeNum(a1/b1);
      else
        return allocReal(divDouble(longToDouble(a1),longToDouble(b1)));
    }
    else if (IS_BIGINT(b))
      // can't be zero and can't be a divisor of a small int
      return a1 == 0 ? a : 
        allocReal(divDouble(longToDouble(a1),bigToDouble(b)));
    else if (IS_REAL(b))
      if (eqDouble(getReal(b), 0.0))
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return allocReal(divDouble(longToDouble(a1),getReal(b)));
    else if (IS_COMPLEX(b))
      return divCpl(longToDouble(a1), 0.0,
                    getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_BIGINT(a)) {
    if (IS_SMALLINT(b)) {
      if (INTVAL(b) == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return divRemBigint(a, W=int16ToBig(INTVAL(b)), DIVOP_DIV);   
    }
    else if (IS_BIGINT(b))
      // can't be zero 
      return divRemBigint(a, b, DIVOP_DIV);   
    else if (IS_REAL(b))
      if (eqDouble(getReal(b), 0.0))
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return allocReal(divDouble(bigToDouble(a),getReal(b)));
    else if (IS_COMPLEX(b))
      return divCpl(bigToDouble(a), 0.0,
                    getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_REAL(a)) {
    if (IS_SMALLINT(b)) {
      if (INTVAL(b) == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return allocReal(divDouble(getReal(a),longToDouble(INTVAL(b))));
    } 
    else if (IS_BIGINT(b))
      return allocReal(divDouble(getReal(a),bigToDouble(b)));
    else if (IS_REAL(b)) {
      if (eqDouble(getReal(b), 0.0))
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return allocReal(divDouble(getReal(a),getReal(b)));
    }
    else if (IS_COMPLEX(b))
      return divCpl(getReal(a), 0.0,
                    getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else if (IS_COMPLEX(a)) {
    if (IS_SMALLINT(b)) {
      if (INTVAL(b) == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return divCpl(getReal(cadr(a)), getReal(cddr(a)),
                     longToDouble(INTVAL(b)), 0.0);
    }
    else if (IS_BIGINT(b))
      return divCpl(getReal(cadr(a)), getReal(cddr(a)),
                    bigToDouble(b), 0.0);
    else if (IS_REAL(b)) {
      if (eqDouble(getReal(b), 0.0))
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return divCpl(getReal(cadr(a)), getReal(cddr(a)),
                      getReal(b), 0.0);
    }
    else if (IS_COMPLEX(b))
      return divCpl(getReal(cadr(a)), getReal(cddr(a)),
                    getReal(cadr(b)), getReal(cddr(b)));
    else
      typeError(b,"number");
  }
  else
    typeError(a,"number");
}

/**********************************************************************/
/* integer division and friends                                       */
/**********************************************************************/
static PTR intdiv(PTR a, PTR b, DivOp op)
{
  if (IS_SMALLINT(a)) {
    long a1 = INTVAL(a);
    if (IS_SMALLINT(b)) {
      long b1 = INTVAL(b);
      if (b1 == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      switch (op) {
        case DIVOP_IDIV: return makeNum(a1/b1);
        case DIVOP_REM:  return makeNum(a1%b1);
        case DIVOP_BOTH: return cons(W=makeNum(a1/b1), W=makeNum(a1%b1));
      }
    }
    else { /* b is BIGINT, thus |b| > |a| (almost ever :-() */
      /*--------------------------------------------------------------*/
      /* Check for that nasty special case |b| == |a| which can only  */
      /* happen when a is the smallest SMALLINT and b is the smallest */
      /* BIGINT, i.e. the case (quotient -8192 8192) or similar       */
      /*--------------------------------------------------------------*/
      if (a1==MIN_SMALLINT) {
        ErrTry {
          if (getInt16(b) == (MAX_SMALLINT+1))
            switch (op) {
              case DIVOP_IDIV: return MKINT(-1);
              case DIVOP_REM:  return MKINT(0);
              case DIVOP_BOTH: return cons(MKINT(-1),MKINT(0));
            }
         } ErrCatch(err) {
           // b too big for Int16, continue with ordinary case
         } ErrEndCatch 
      } 
      switch (op) {
        case DIVOP_IDIV: return MKINT(0);
        case DIVOP_REM:  return a;
        case DIVOP_BOTH: return cons(MKINT(0),a);
      }
    } // b BIGINT
  }
  else { /* BIGINT */
    if (IS_SMALLINT(b)) {
      if (INTVAL(b) == 0)
        ErrThrow(ERR_R8_DIV_BY_ZERO);
      else
        return divRemBigint(a, W=int16ToBig(INTVAL(b)), op);   
    }
    else /* BIGINT */
      return divRemBigint(a, b, op);   
  }
}

/**********************************************************************/
/* Quotient                                                           */
/**********************************************************************/
static PTR nativeQuotient(PTR* args)
{
  return intdiv(args[0], args[1], DIVOP_IDIV);
}

static PTR nativeRemainder(PTR* args)
{
  return intdiv(args[0], args[1], DIVOP_REM);
}

static PTR nativeDivide(PTR* args)
{
  return intdiv(args[0], args[1], DIVOP_BOTH);
}

/**********************************************************************/
/* Bitwise operations                                                 */
/**********************************************************************/
PTR genBitOp(PTR a, PTR b, BitOp op)
{
  EXT_TCHECK(tyINT,a,"bit operation",0);
  EXT_TCHECK(tyINT,b,"bit operation",1);

  if (IS_SMALLINT(a)) {
    long a1 = INTVAL(a);
    if (IS_SMALLINT(b)) {
      long b1 = INTVAL(b);
      switch (op) {
        case BITOP_AND: return makeNum(a1 & b1);
        case BITOP_IOR: return makeNum(a1 | b1);
        case BITOP_XOR: return makeNum(a1 ^ b1);
      }
    }
    else /* BIGINT */
      return logBigint(W=int16ToBig(a1), b, op);   
  }
  else { /* BIGINT */
    if (IS_SMALLINT(b)) 
      return logBigint(a, W=int16ToBig(INTVAL(b)), op);   
    else /* BIGINT */
      return logBigint(a, b, op);   
  }
}

/**********************************************************************/
/* Bit complement                                                     */
/**********************************************************************/
static PTR nativeCompl(PTR* args)
{
  return logNot(args[0]);
}

/**********************************************************************/
/* Bit shifting                                                       */
/**********************************************************************/
static PTR nativeShift(PTR* args)
{
  return shiftBigint(args[0], getInt32(args[1]));
}

/**********************************************************************/
/* Convert to real                                                    */
/**********************************************************************/
static PTR nativeExact2Inexact(PTR* args)
{
  if (IS_SMALLINT(args[0]))
    return allocReal(longToDouble(INTVAL(args[0])));
  else
    return allocReal(bigToDouble(args[0]));
}

/**********************************************************************/
/* Convert real to integer                                            */
/**********************************************************************/
static PTR nativeInteger(PTR* args)
{
  if (IS_SMALLINT(args[0]) || IS_BIGINT(args[0]))
    return args[0];
  else 
    return realToBig(args[0]);
}

/**********************************************************************/
/* Is number exact?                                                   */
/**********************************************************************/
static PTR nativeExact(PTR* args)
{
  return IS_SMALLINT(args[0]) || IS_BIGINT(args[0]) ? TRUE : FALSE;
}

/**********************************************************************/
/* Is number inexact?                                                 */
/**********************************************************************/
static PTR nativeInexact(PTR* args)
{
  return IS_REAL(args[0]) || IS_COMPLEX(args[0]) ? TRUE : FALSE;
}

/**********************************************************************/
/* Extract real part of number                                        */
/**********************************************************************/
static PTR nativeRealPart(PTR* args)
{
  if (IS_COMPLEX(args[0]))
    return cadr(args[0]);
  else if (IS_REAL(args[0]) || IS_INT(args[0]))
    return args[0];
  else
    typeError(car(S),"number");
}

/**********************************************************************/
/* Extract imaginary part of number                                   */
/**********************************************************************/
static PTR nativeImagPart(PTR* args)
{
  if (IS_COMPLEX(args[0]))
    return cddr(args[0]);
  else if (IS_REAL(args[0]) || IS_INT(args[0]))
    return MKINT(0);
  else
    typeError(car(S),"number");
}

/**********************************************************************/
/* Conjugate a complex number                                         */
/**********************************************************************/
static PTR nativeConjugate(PTR* args)
{
  if (IS_COMPLEX(args[0]))
    return cons2(CPLX_TAG, cadr(args[0]),
                 allocReal(-getReal(cddr(args[0]))));
  else if (IS_REAL(args[0]) || IS_INT(args[0]))
    return args[0];
  else
    typeError(car(S),"number");
}

/**********************************************************************/
/* Magnitude of a complex number                                      */
/**********************************************************************/
static PTR nativeMagnitude(PTR* args)
{
  return magnitude(args[0]);
}

/**********************************************************************/
/* Angle of a complex number                                          */
/**********************************************************************/
static PTR nativeAngle(PTR* args)
{
  return angle(args[0]);
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule numberBuiltins = 
{
  MODULE_FUNC(NULL),
  {"+",                PRIMFOLD(0, ADD,  0, "<number>*")},
  {"*",                PRIMFOLD(0, MUL,  1, "<number>*")},
  {"-",                PRIMDEF(1, SUB, 0,   "<number> [<number>]")},
  {"/",                PRIMDEF(1, DIV, 1,   "<number> [<number>]")},
  {"<=",               PRIM1(2, LEQ,        "<real/char/string> <real/char/string>")},
  {">",                PRIM2(2, NOT,  LEQ,  "<real/char/string> <real/char/string>")},
  {">=",               PRIM1(2, GEQ,        "<real/char/string> <real/char/string>")},
  {"<",                PRIM2(2, NOT,  GEQ,  "<real/char/string> <real/char/string>")},
  {"floor",            PRIMTRANS(FLOR,      "<real>")},
  {"ceiling",          PRIMTRANS(CEIL,      "<real>")},
  {"truncate",         PRIMTRANS(TRUN,      "<real>")},
  {"round",            PRIMTRANS(ROUN,      "<real>")},
  {"integer",          NATIVE1(nativeInteger,   tyREAL)},
  {"remainder",        NATIVE2(nativeRemainder, tyINT, tyINT)},
  {"quotient",         NATIVE2(nativeQuotient,  tyINT, tyINT)},
  {"divide",           NATIVE2(nativeDivide,    tyINT, tyINT)},
  {"random",           NATIVE1(nativeRand,      tySMALLINT)},
  {"even?",            NATIVE1(nativeEven,      tyINT)},
  {"odd?",             NATIVE1(nativeOdd,       tyINT)},
  {"=",                PRIM1(2, EQV, "<number> <number>")},
  {"exact->inexact",   NATIVE1(nativeExact2Inexact, tyINT)},
  {"inexact->exact",   NATIVE1(nativeInteger,   tyREAL)},
  {"exact?",           NATIVE1(nativeExact,     tyNUMBER)},
  {"inexact?",         NATIVE1(nativeInexact,   tyNUMBER)},
  {"real-part",        NATIVE1(nativeRealPart,  tyNUMBER)},
  {"imag-part",        NATIVE1(nativeImagPart,  tyNUMBER)},
  {"conjugate",        NATIVE1(nativeConjugate, tyNUMBER)},
  {"magnitude",        NATIVE1(nativeMagnitude, tyNUMBER)},
  {"angle",            NATIVE1(nativeAngle,     tyNUMBER)},
  {NULL}
};

BuiltInModule numberBuiltins2 = 
{
  MODULE_FUNC(NULL),
  {"bit-and",          PRIMFOLD(0, LAND, -1,"<integer>*")},
  {"bit-or",           PRIMFOLD(0, LIOR, 0, "<integer>*")},
  {"bit-xor",          PRIMFOLD(0, LXOR, 0, "<integer>*")},
  {"bit-not",          NATIVE1(nativeCompl, tyINT)},
  {"bit-shift",        NATIVE2(nativeShift,     tyINT, tyINT)},
};

BuiltInModule transBuiltins = 
{
  MODULE_FUNC(init),
  {"atan",             PRIM12OP(ATAN, ATN2, "<number> [<number>]")},
  {"sqrt",             PRIMTRANS(SQRT,      "<number>")},
  {"sin",              PRIMTRANS(SIN,       "<number>")},
  {"cos",              PRIMTRANS(COS,       "<number>")},
  {"tan",              PRIMTRANS(TAN,       "<number>")},
  {"asin",             PRIMTRANS(ASIN,      "<number>")},
  {"acos",             PRIMTRANS(ACOS,      "<number>")},
  {"exp",              PRIMTRANS(EXP,       "<number>")},
  {"log",              PRIMTRANS(LOG,       "<number>")},
  {"sinh",             PRIMTRANS(SINH,      "<number>")},
  {"cosh",             PRIMTRANS(COSH,      "<number>")},
  {"tanh",             PRIMTRANS(TANH,      "<number>")},
  {"asinh",            PRIMTRANS(ASIH,      "<number>")},
  {"acosh",            PRIMTRANS(ACOH,      "<number>")},
  {"atanh",            PRIMTRANS(ATAH,      "<number>")},
  {"make-rectangular", PRIM1(2, MKRA,       "<real> <real>")},
  {"make-polar",       PRIM1(2, MKPO,       "<real> <real>")},
  {NULL}
};

