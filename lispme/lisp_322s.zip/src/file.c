/**********************************************************************/
/*                                                                    */
/* file.c: LISPME "file" (Memo) management                            */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.10.1998 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "file.h"
#include "io.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"

/**********************************************************************/
/* Local definitions                                                  */
/**********************************************************************/
#define DOC_BLOCK_SIZE 4096

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
LocalID   memoId;
LocalID   memo32Id;
DmOpenRef memoRef;
DmOpenRef memo32Ref;
DmOpenRef fileDBRef;

/**********************************************************************/
/* Module local data                                                  */
/**********************************************************************/
static UInt16    currFmt;
static DmOpenRef srcDbRef;
static MemHandle srcRecHand;
static Boolean   compressed;
static UInt16    nextRecord;
static UInt16    numRecords;
static UInt16    bufLen;

/**********************************************************************/
/* Module local types                                                 */
/**********************************************************************/
typedef struct {	    /* 16 bytes total */
  UInt8         crap;
  UInt8 	version;    /* 1 = plain text, 2 = compressed */
  UInt16	reserved1;
  UInt32	doc_size;   /* in bytes, when uncompressed */
  UInt16	numRecords; /* text rec's only; = pdb_header.numRecords-1 */
  UInt16	rec_size;   /* usually RECORD_SIZE_MAX */
  UInt32	reserved2;
} docHeader;

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static void  initModule(ModuleMessage mess)                     SEC(IO);
static PTR   openFile(PTR fileName, Boolean append, UInt8 type) SEC(IO);
static PTR   createFile(PTR fileName, UInt8 type)               SEC(IO);
static UInt8 getFileType(int argc, PTR* args)                   SEC(IO);
static char* refill(void)                                       SEC(IO);
static Boolean fillDocBuffer(InPort* inp)                       SEC(IO);
static int   decodeFromBuffer(UInt8* decodeTo, UInt8* decodeFrom,
                           int decodeFromLen, int maxDecodeLen) SEC(IO);

static void    writeMemo(WriterCmd cmd, OutPort* outp)          SEC(IO);
static Boolean readMemo(ReaderCmd cmd, InPort* inp)             SEC(IO);
static void    writeDoc(WriterCmd cmd, OutPort* outp)           SEC(IO);
static Boolean readDoc(ReaderCmd cmd, InPort* inp)              SEC(IO);

static PTR   nativeDir(int argc, PTR* args)                     SEC(IO);
static PTR   nativeDeleteFile(PTR* args)                        SEC(IO);
static PTR   nativeCreateFile(int argc, PTR* args)              SEC(IO); 
static PTR   nativeOpenFile(int argc, PTR* args)                SEC(IO);
static PTR   nativeAppendFile(int argc, PTR* args)              SEC(IO);

/**********************************************************************/
/* Module control function                                            */
/**********************************************************************/
static void initModule(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
    {
      /*--------------------------------------------------------------*/
      /* Search memo DB and set access mode acc. to secret pref.      */
      /* MemoDB (and, if found Memo32DB) are kept open during the     */
      /* entire runtime.                                              */
      /*--------------------------------------------------------------*/
      SystemPreferencesType sysp;
      UInt16 memoDBMode = dmModeReadWrite;

      PrefGetPreferences(&sysp);
      if (!sysp.hideSecretRecords)
        memoDBMode |= dmModeShowSecret;
      memo32Id = DmFindDatabase(0, "Memo32DB");
      memoId   = DmFindDatabase(0, "MemoDB");
      ErrFatalDisplayIf(!memoId,"No memoDB?");
      memoRef = DmOpenDatabase(0, memoId, memoDBMode);
      if (memo32Id)
        memo32Ref = DmOpenDatabase(0, memo32Id, memoDBMode);

      /*--------------------------------------------------------------*/
      /* Register hooks for reading/writing ports                     */
      /*--------------------------------------------------------------*/
      registerWriteFct(PT_MEMO,   writeMemo);
      registerWriteFct(PT_MEMO32, writeMemo);
      registerWriteFct(PT_DOC,    writeDoc);
      registerReadFct(PT_MEMO,    readMemo);
      registerReadFct(PT_MEMO32,  readMemo);
      registerReadFct(PT_DOC,     readDoc);
      registerReadFct(PT_CDOC,    readDoc);
      break;
    }

    case APP_STOP:
      if (memo32Ref)
        DmCloseDatabase(memo32Ref);   
      DmCloseDatabase(memoRef);
      break; 

    default:
  }
}

/**********************************************************************/
/* Get memodirectory                                                  */
/**********************************************************************/
static PTR nativeDir(int argc, PTR* args)
{
  UInt16    numRec,i;
  MemHandle recHand;
  char      *s,*d,*recPtr;
  PTR       res;
  PTR*      dest = &res;
  UInt16    category = dmAllCategories;
  UInt16    recNum   = 0;

  if (argc>1)
    arityError("dir",argc); 

  if (argc == 1)
  {
    if (!IS_STRING(car(args[0])))
      typeError(car(args[0]),"string");
    category = CategoryFind(memoRef, printString(car(args[0])));
    if (category == dmAllCategories)
    {
      /*--------------------------------------------------------------*/
      /* Category does not exist => return empty list                 */
      /*--------------------------------------------------------------*/
      return NIL;
    }
  }

  res = NIL;
  PROTECT(res);
  numRec = DmNumRecordsInCategory(memoRef, category);
  for (i=0;i<numRec;++i)
  {
    if ((recHand = DmQueryNextInCategory(memoRef, &recNum, category)))
    {
      recPtr = MemHandleLock(recHand);
      /*--------------------------------------------------------------*/
      /* Copy beginning of memo text upto first \n or MAX_LINE_LEN    */
      /*--------------------------------------------------------------*/
      for (s = recPtr, d = msg;
           s-recPtr < MAX_FILENAME_LEN && *s && *s != '\n';
           ++s, ++d)
        *d = *s;
      *d = '\0';
      MemHandleUnlock(recHand);
      *dest = cons(str2Lisp(msg),NIL);
      dest = &cdr(*dest);
    }
    ++recNum;
  }
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Create a file                                                      */
/**********************************************************************/
static PTR createFile(PTR fileName, UInt8 type)
{
  UInt16    index;
  MemHandle recHand;
  UInt16    nameLen;
  UInt32    uid;

  switch (type) {
    case PT_MEMO:
      fileDBRef = memoRef; 
      goto contCreate;

    case PT_MEMO32:
      fileDBRef = memo32Ref; 
    contCreate:
      /*--------------------------------------------------------------*/
      /* Memo/Memo32 files (single record, uncompressed)              */
      /*--------------------------------------------------------------*/
      nameLen = makeFileName(fileName);
      if (!(recHand = DmNewRecord(fileDBRef, &index, nameLen)))
        error1(ERR_R16_CREATE_FILE, fileName);

      DmWrite(MemHandleLock(recHand), 0, msg, nameLen);
      MemHandleUnlock(recHand);
      DmReleaseRecord(fileDBRef, index, true);
      DmRecordInfo(fileDBRef, index, 0, &uid, 0);
      return makeMemoOutPort(uid, type, fileDBRef);

    case PT_DOC: {
      /*--------------------------------------------------------------*/
      /* DOC (multirecord, currently only uncompressed)               */
      /*--------------------------------------------------------------*/
      LocalID    id;
      DmOpenRef  ref;
      docHeader* header;

      printString(fileName);
      if (DmCreateDatabase(0, msg, DOC_CREATOR, DOC_TYPE, false))
        error1(ERR_R16_CREATE_FILE, fileName);
      id  = DmFindDatabase(0, msg);
      ref = DmOpenDatabase(0, id, dmModeReadWrite);

      /*--------------------------------------------------------------*/
      /* Create DOC header                                            */
      /*--------------------------------------------------------------*/
      header = MemHandleLock(DmNewRecord(ref, &index, sizeof(docHeader)));
      MemSet(header, sizeof(docHeader), '\0');
      header->version = 1;
      header->rec_size = DOC_BLOCK_SIZE;
      MemPtrUnlock(header);
      DmReleaseRecord(ref, index, true);
      DmCloseDatabase(ref);
      return makeBufOutPort(PT_DOC, fileName, DOC_BLOCK_SIZE, OPF_NORMAL);
    }
  }
}

/**********************************************************************/
/* Open an existing file                                              */
/* Currently don't allow opening DOC files in append mode             */
/**********************************************************************/
static PTR openFile(PTR fileName, Boolean append, UInt8 type)
{
  MemHandle recHand;
  UInt16    nameLen;
  UInt32    uid;
  UInt16    numRec,i;
  char      *s,*d,*recPtr;

  switch (type) {
    case PT_MEMO:  
      fileDBRef = memoRef; 
      goto contOpen;
 
    case PT_MEMO32:
      fileDBRef = memo32Ref; 
    contOpen:
      /*--------------------------------------------------------------*/
      /* Memo/Memo32 files (single record, uncompressed)              */
      /*--------------------------------------------------------------*/
      nameLen = makeFileName(fileName);
      msg[nameLen-2] = '\0';
      numRec  = DmNumRecords(fileDBRef);
      for (i=0;i<numRec;++i) {
        if ((recHand = DmQueryRecord(fileDBRef, i))) {
          recPtr = MemHandleLock(recHand);
          /*----------------------------------------------------------*/
          /* Compare first line with filename                         */
          /*----------------------------------------------------------*/
          for (s = recPtr, d = msg;
               *s && *s == *d;
               ++s, ++d)
            ;
          if ((*s == '\n' && !*d) || s-recPtr >= MAX_FILENAME_LEN) {
            if (append) {
              MemHandleUnlock(recHand);
              DmRecordInfo(fileDBRef, i, 0, &uid, 0);
              W = makeMemoOutPort(uid, type, fileDBRef);
            }
            else {
              /*------------------------------------------------------*/
              /* Establish read position                              */
              /*------------------------------------------------------*/
              while (*s && *s != '\n') ++s;
              if (*s) ++s;
              MemHandleUnlock(recHand);
              DmRecordInfo(fileDBRef, i, 0, &uid, 0);
              W = makeMemoInPort(type, fileDBRef, uid, s-recPtr);
            }
            return W;
          }
          MemHandleUnlock(recHand);
        }
      }
      if (append)
        return createFile(fileName, type);
      else
        error1(ERR_R17_OPEN_FILE, fileName);


    case PT_DOC:
      /*--------------------------------------------------------------*/
      /* DOC (multirecord, compressed, unique database)               */
      /*--------------------------------------------------------------*/
      if (append)
        error1(ERR_R17_OPEN_FILE, fileName);
      else {
        LocalID    id;
        DmOpenRef  ref;
        docHeader* header;
        UInt8      ver;
        UInt16     nRec;
        PTR        str;
        PTR        res =  NIL;
        InPort*    inp; 

        if ((id = DmFindDatabase(0, printString(fileName))) != 0) {
          ref  = DmOpenDatabase(0, id, dmModeReadOnly);
          /*----------------------------------------------------------*/
          /* Read DOC header                                          */
          /*----------------------------------------------------------*/
          header = (docHeader*)MemHandleLock(DmQueryRecord(ref, 0));
          ver    = header->version;
          nRec   = header->numRecords; 
          MemPtrUnlock(header);
          switch (ver) {
            case 1: break;
            case 2: type = PT_CDOC;  break;
            default: error1(ERR_L7_INVALID_DOC,MKINT(ver));
          }
          str = createString(DOC_BLOCK_SIZE);
          PROTECT(res); 
          res = makeBufInPort(type, fileName, str); 
          inp = FOREIGNVAL(res);
          inp->next = 1;
          inp->nRec = nRec; 
          DmCloseDatabase(ref);
          fillDocBuffer(inp);
          UNPROTECT(res);  
          return res;
        }  
        else
          error1(ERR_R17_OPEN_FILE, fileName);
      }
  }
}

/**********************************************************************/
/* Fill the DOC buffer                                                */
/**********************************************************************/
static Boolean fillDocBuffer(InPort* inp)
{
  LocalID   id;
  DmOpenRef ref;
  char*     destPtr;
  char*     srcPtr;
  static char nameBuf[dmDBNameLength];

  if (inp->next <= inp->nRec) {
    /*----------------------------------------------------------------*/
    /* Fetch DOC name from implementation PTR: Note, that msg can't   */
    /* be used here since read-line may construct its result in msg.  */
    /*----------------------------------------------------------------*/
    srcPtr = ArrayHandleLock(DmQueryRecord(dbRef, ARR_INDEX(inp->impl)));
    MemMove(nameBuf, srcPtr, ArrayPtrSize(srcPtr));
    nameBuf[ArrayPtrSize(srcPtr)] = '\0';
    ArrayPtrUnlock(srcPtr);
    if ((id = DmFindDatabase(0, nameBuf)) != 0) {
      ref    = DmOpenDatabase(0, id, dmModeReadOnly);
      srcPtr = MemHandleLock(DmQueryRecord(ref, inp->next++));
      inp->bufLen = MemPtrSize(srcPtr);
      destPtr = ArrayHandleLock(DmQueryRecord(dbRef, ARR_INDEX(inp->buf)));
      if (inp->type == PT_CDOC) // compressed DOC
        inp->bufLen = decodeFromBuffer(destPtr, srcPtr, inp->bufLen,
                                     DOC_BLOCK_SIZE);   
      else
        MemMove(destPtr, srcPtr, inp->bufLen);
      destPtr[inp->bufLen] = '\0';
      MemPtrUnlock(srcPtr);
      ArrayPtrUnlock(destPtr);
      DmCloseDatabase(ref);
      inp->pos = 0;
      return true;
    }
  }
  return false;
}

static PTR nativeOpenFile(int argc, PTR* args)
{
  return openFile(args[0], false, getFileType(argc, args));
}

static PTR nativeAppendFile(int argc, PTR* args)
{
  return openFile(args[0], true, getFileType(argc, args));
}

static PTR nativeCreateFile(int argc, PTR* args)
{
  return createFile(args[0], getFileType(argc, args));
}

/**********************************************************************/
/* Write to a memo                                                    */
/**********************************************************************/
static void writeMemo(WriterCmd cmd, OutPort* outp)
{
  UInt16    index;
  MemHandle recHand;
  UInt32    oldSize, newSize;
  UInt16    attr;
  Int32     maxSize;
  Boolean   overflow = false;

  switch (cmd) {
    case WC_WRITE:
      /*--------------------------------------------------------------*/
      /* Check for vanished memo                                      */
      /*--------------------------------------------------------------*/
      if (DmFindRecordByID(outp->dbRef, outp->uid, &index))
        ErrThrow(ERR_R18_LOST_FILE);
      DmRecordInfo(outp->dbRef, index, &attr, 0, 0);
      if (attr & dmRecAttrDelete)
        ErrThrow(ERR_R18_LOST_FILE);

      maxSize = outp->type == PT_MEMO ? 4096 : 32700;
      recHand = DmGetRecord(outp->dbRef, index);
      oldSize = MemHandleSize(recHand);
      if (oldSize < maxSize) {
        /*------------------------------------------------------------*/
        /* Resize record and append msg buffer                        */
        /*------------------------------------------------------------*/
        MemHandle newHand;
        newSize = oldSize+outp->pos;
        newHand = DmResizeRecord(outp->dbRef, index, min(newSize,maxSize));
        if (!newHand) {
          DmReleaseRecord(outp->dbRef, index, false);
          ErrThrow(ERR_R19_WRITE_FILE);
        }
        if (newSize >= maxSize) {
          outp->mem[maxSize-oldSize-1] = charEllipsis;
          outp->mem[maxSize-oldSize]   = '\0';
          overflow = true;
        }
        DmStrCopy(MemHandleLock(newHand), oldSize-1, outp->mem);
        MemHandleUnlock(newHand);
      }
      DmReleaseRecord(outp->dbRef, index, true);
      if (overflow)
        ErrThrow(ERR_O5_OUTPUT_TRUNC);
      break;

    case WC_CLOSE:
      outp->flags |= OPF_CLOSED;
      break;
  }
}

/**********************************************************************/
/* Read from a memo (bug fixed in V3.0a)                              */
/**********************************************************************/
static Boolean readMemo(ReaderCmd cmd, InPort* inp)
{
  switch (cmd) {
    case RC_READ:
      return false; // since only one buffer, arrggh

    case RC_CLOSE:
      inp->status = INP_STATUS_CLOSED;
      return true;
  }
}

/**********************************************************************/
/* Write to a DOC file                                                */
/**********************************************************************/
static void writeDoc(WriterCmd cmd, OutPort* outp)
{
  UInt16  index;
  char*   dest;
  LocalID    id;
  DmOpenRef  ref;

  /*------------------------------------------------------------------*/
  /* Check for vanished DOC                                           */
  /*------------------------------------------------------------------*/
  if ((id = DmFindDatabase(0, printString(outp->impl))) != 0) 
    ref = DmOpenDatabase(0, id, dmModeReadWrite);
  else {
    ErrThrow(ERR_R18_LOST_FILE);
    return; // not reached
  }

  /*------------------------------------------------------------------*/
  /* Copy buffer to new DOC record                                    */
  /*------------------------------------------------------------------*/
  index = dmMaxRecordIndex;
  dest = MemHandleLock(DmNewRecord(ref, &index,
           cmd==WC_WRITE ? DOC_BLOCK_SIZE : outp->pos));
  DmWrite(dest, 0, outp->mem, outp->pos);
  MemPtrUnlock(dest);
  DmReleaseRecord(ref, index, true);

  if (cmd == WC_CLOSE) {
    /*----------------------------------------------------------------*/
    /* Update header                                                  */
    /*----------------------------------------------------------------*/
    docHeader* header = MemHandleLock(DmGetRecord(ref, 0));
    header->numRecords = DmNumRecords(ref)-1;
    header->doc_size = (header->numRecords-1) * DOC_BLOCK_SIZE +
                       outp->pos;
    MemPtrUnlock(header);
    DmReleaseRecord(ref, 0, true);
    outp->flags |= OPF_CLOSED;
  }
  outp->pos = 0;
  DmCloseDatabase(ref);
}

/**********************************************************************/
/* Read from a DOC file                                               */
/**********************************************************************/
static Boolean readDoc(ReaderCmd cmd, InPort* inp)
{
  switch (cmd) {
    case RC_READ:
      return fillDocBuffer(inp);

    case RC_CLOSE:
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL; 
      inp->impl   = NIL;
      return true;
  }     
}

/**********************************************************************/
/* Retrieve file type (memo, memo32, doc) from args, several poss:    */
/* - an optional argument 0,1,2 default 0 (=memo)                     */
/* - an optional argument symbol memo, memo32, doc, default memo      */
/* - URL-like notation in filename "memo32:FooBar" etc.               */
/* Currently the first alternative is used                            */
/**********************************************************************/
static UInt8 getFileType(int argc, PTR* args)
{
  int type;
  switch (argc) {
    case 1:
      return PT_MEMO;

    case 2:
      TCHECK(tySMALLINT, car(args[1]));
      type = INTVAL(car(args[1]));
      if (type >= PT_MEMO && type <= PT_DOC)
        return type;

    default:
      parmError(car(args[1]),"file open");
  }
}

/**********************************************************************/
/* Delete an existing file                                            */
/**********************************************************************/
static PTR nativeDeleteFile(PTR* args)
{
  MemHandle recHand;
  UInt16    nameLen;
  UInt16    numRec,i;
  char      *s, *d, *recPtr;

  nameLen = makeFileName(args[0]);
  msg[nameLen-2] = '\0';
  numRec  = DmNumRecords(memoRef);
  for (i=0;i<numRec;++i)
  {
    if ((recHand = DmQueryRecord(memoRef, i)))
    {
      recPtr = MemHandleLock(recHand);
      /*--------------------------------------------------------------*/
      /* Compare first line with filename                             */
      /*--------------------------------------------------------------*/
      for (s = recPtr, d = msg;
           *s && *s == *d;
           ++s, ++d)
        ;
      if ((*s == '\n' && !*d) || s-recPtr >= MAX_FILENAME_LEN)
      {
        /*------------------------------------------------------------*/
        /* Memo found, delete it                                      */
        /*------------------------------------------------------------*/
        MemHandleUnlock(recHand);
        DmRemoveRecord(memoRef, i);
        return NOPRINT;
      }
      MemHandleUnlock(recHand);
    }
  }
  error1(ERR_R17_OPEN_FILE, args[0]);
}

/**********************************************************************/
/* The DOC uncompression routine: This code has been taken from       */
/* also GPLed CSpotRun                                                */
/**********************************************************************/
static int decodeFromBuffer(UInt8* decodeTo, UInt8* decodeFrom,
                            int decodeFromLen, int maxDecodeLen)
{
  UInt8* fromTooFar = &decodeFrom[decodeFromLen];
  UInt8* toTooFar = &decodeTo[maxDecodeLen];
  UInt8* decodeStart = decodeTo;
  unsigned int c;

  // These are used only in B commands
  int     windowLen;
  int     windowDist;
  UInt8* windowCopyFrom;

  while(decodeFrom < fromTooFar && decodeTo < toTooFar)
  {
    c = *(decodeFrom++);

    // type C command (space + char)
    if (c >= 0xC0)
    {
      *(decodeTo++)=' ';
      if (decodeTo < toTooFar)
        *(decodeTo++)=c & 0x7F;
    }
    // type B command (sliding window sequence)
    else if (c >= 0x80)
    {
      c = (c<<8) | *(decodeFrom++);   // Move this to high bits and read low bits
      windowLen = 3 + (c & 0x7);      // 3 + low 3 bits (Beirne's 'n'+3)
      windowDist = (c >> 3) & 0x07FF; // next 11 bits (Beirne's 'm')
      windowCopyFrom = decodeTo - windowDist;

      windowLen = min(windowLen, toTooFar - decodeTo);
      while(windowLen--)
        *(decodeTo++) = *(windowCopyFrom++);
    }
    //self-representing, no command.
    else if (c >= 0x09)
    {
      *(decodeTo++)=c;
    }
    //type A command (next c chars are literal)
    else if (c >= 0x01)
    {
      c = min(c, toTooFar - decodeTo);
      while(c--)
        *(decodeTo++) = *(decodeFrom++);
    }
    //c == 0, also self-representing
    else
    {
      *(decodeTo++)=c;
    }
  }
  return decodeTo - decodeStart;
}

/**********************************************************************/
/* The following functions are for loading source code only. They     */
/* should be integrated better with LispMe's port reading routines,   */
/* right now there's some duplicate code:-(                           */
/**********************************************************************/

/**********************************************************************/
/* Read from an arbitrary source                                      */
/**********************************************************************/
char* openSrcFile(UInt16 format, SourceRef* src)
{
  docHeader* header;
  char* p;
  int version;

  switch (currFmt=format) {
    case IDC_RB_MEMO:
      srcDbRef   = memoRef;
      goto cont;

    case IDC_RB_MEMO32:
      srcDbRef   = memo32Ref;
    cont:  
      srcRecHand = DmQueryRecord(srcDbRef, src->recNr);
      EOFHandler = NULL;
      return MemHandleLock(srcRecHand);
      break;
         
    case IDC_RB_DOC:
      srcDbRef   = DmOpenDatabase(0, src->dbId, dmModeReadOnly);
      srcRecHand = DmQueryRecord(srcDbRef, 0);
      header     = (docHeader*)MemHandleLock(srcRecHand);
      numRecords = header->numRecords; 
      version    = header->version;
      MemHandleUnlock(srcRecHand);
      switch (version) {
        case 1: compressed = false; break;
        case 2: compressed = true;  break;
        default: error1(ERR_L7_INVALID_DOC,MKINT(version));
      }
      srcRecHand = DmQueryRecord(srcDbRef, src->recNr);
      bufLen = MemHandleSize(srcRecHand);
      p = MemHandleLock(srcRecHand);     
      if (compressed)
        bufLen = decodeFromBuffer(msg, p, bufLen, MEMO_OUTPUT_SIZE);   
      else
        MemMove(msg,p,bufLen);
      msg[bufLen] = '\0';
      MemHandleUnlock(srcRecHand);
      nextRecord = src->recNr + 1;        
      EOFHandler = refill;
      return msg;
  }
}

/**********************************************************************/
/* Refill the DOC buffer when a block has been fully read             */
/**********************************************************************/
static char* refill(void)
{
  char* p;
  if (nextRecord <= numRecords) {
    srcRecHand = DmQueryRecord(srcDbRef, nextRecord++);
    bufLen = MemHandleSize(srcRecHand);
    p = MemHandleLock(srcRecHand);     
    if (compressed)
      bufLen = decodeFromBuffer(msg, p, bufLen, MEMO_OUTPUT_SIZE);   
    else
      MemMove(msg,p,bufLen);
    msg[bufLen] = '\0';
    MemHandleUnlock(srcRecHand);
    return msg;
  }
  else 
    return NULL;
}

/**********************************************************************/
/* Close a source file                                                */
/**********************************************************************/
void closeSrcFile(void) 
{
  switch (currFmt) {
    case IDC_RB_MEMO:
    case IDC_RB_MEMO32:
      MemHandleUnlock(srcRecHand);
      break;
 
    case IDC_RB_DOC:
      DmCloseDatabase(srcDbRef);
      break;
  }
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule fileBuiltins = 
{
  MODULE_FUNC(initModule),
  
  {"dir",              NATIVEV0(nativeDir)}, 
  {"open-output-file", NATIVEV1(nativeCreateFile, tySTRING)},
  {"open-input-file",  NATIVEV1(nativeOpenFile,   tySTRING)},
  {"open-append-file", NATIVEV1(nativeAppendFile, tySTRING)},
  {"delete-file",      NATIVE1(nativeDeleteFile, tySTRING)},
  {NULL}
};
