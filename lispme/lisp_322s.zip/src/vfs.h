/**********************************************************************/
/*                                                                    */
/* vfs.h: LISPME virtual file system support                          */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 23.11.2003 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_VFS_H
#define INC_VFS_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule vfsBuiltins; 

#endif
