/**********************************************************************/
/*                                                                    */
/* store.h: Structures for storage management                         */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 14.07.1997 New                                                FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_STORE_H
#define INC_STORE_H

/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include <PalmOS.h>
#include <CoreTraps.h>

/**********************************************************************/
/* Put a function into a specific section                             */
/**********************************************************************/
#define SEC(s) __attribute__((section(#s)))

/**********************************************************************/
/*                                                                    */
/* Memory organization of LispMe:                                     */
/*                                                                    */
/* 1. Symbol store                                                    */
/*                                                                    */
/*    All atoms are stored contiguously, separated by 0x00 bytes, so  */
/*    they can be accessed as C strings. After last used atom, the    */
/*    entire storage is initialized with 0x01                         */
/*                                                                    */
/* 2. Cons storage                                                    */
/*                                                                    */
/*    two blocks of 16 bit PTRs, one block holds CARS, the other CDRS */
/*                                                                    */
/* 3. PTR format                                                      */
/*                                                                    */
/*    16 bit binary, lower 1-8 bits determine type:                   */
/*                                                                    */
/*    sddd dddd dddd ddd0    16 bit signed offset into heap           */
/*                           (no scale neccessary)                    */
/*    sddd dddd dddd dd01    14 bit signed integer (-8192 .. 8191)    */
/*                                                                    */
/*    dddd dddd dddd 0011    12 bit index into atom table (char*)     */
/*    dddd dddd dddd 0111    12 bit index into double table (double*) */
/*                                                                    */
/*    ffff ffss sss0 1011    Primitive symbol                         */
/*    ffff ffss sss1 1011    Primitive binding                        */
/*                           in both cases, f is an index into the    */
/*                           builtins table and s an index into the   */
/*                           slot table of the frame f                */ 
/*                                                                    */
/*    ???? ???? 0000 1111    vector in heap, upper 8 bit unused,      */
/*                           cdr field of this cell contains 16 bit   */
/*                           index (untagged), elts. are 16 bit PTRs  */
/*                                                                    */
/*    ???? ???? 0001 1111    string in heap, upper 8 bit unused,      */
/*                           cdr field of this cell contains 16 bit   */
/*                           index (untagged), elts. are 8 bit chars  */
/*                                                                    */
/*    ???? ???? 001s 1111    bigint in heap, upper 8 bit of unused,   */
/*                           cdr field of this cell contains 16 bit   */
/*                           index (untagged), elts. are 16 bit ushort*/
/*                           s is sign of bigint                      */
/*                                                                    */
/*    0000 tttt 0100 1111    Foreign data, 4 type bits                */
/*                           cdr field of this cell points to         */
/*                           32 bits _untagged_, see GC note          */
/*                                                                    */
/*    All tags  0??? 1111    indicate "pseudo" cons cell where cdr    */
/*                           contains/points to unboxed data          */
/*                                                                    */
/*    cccc cccc 1000 1111    8 bit ASCII/PalmOS char                  */
/*                                                                    */
/*    Tags 0x9f - 0xff reserved for future extensions                 */
/*                                                                    */
/* 4. Internal compund data (Pseudo-cons cells)                       */
/*                                                                    */
/*    Complex:       (CPLX_TAG real . imag)                           */
/*    Closures:      (CLOS_TAG (arity parms) code . env)              */
/*    Macros:        (MACR_TAG . expander)                            */
/*    Continuations: (CONT_TAG stack env code . dump)                 */
/*    Promises:      (RCPD_TAG code . env)                            */
/*                   (RCPF_TAG . value)                               */
/*    Vectors:       (VECTAG . index)                                 */
/*    Strings:       (STRTAG . index)                                 */
/*    Big integers:  (BIGxTAG . index)                                */
/*    Macros:        (MACR_TAG CLOS_TAG 1 code . env)                 */
/*                                                                    */
/* 5. Vector/string/bigint (aka Array) storage                        */
/*                                                                    */
/*    A record in the current session database identified by its      */
/*    record nr. (No more UID like in previous versions!) The first   */
/*    two bytes of the record contain a PTR back to the heap cell     */
/*    containing the RecMem's header. Thus, the actual length of the  */
/*    useful data is MemHandleSize()-sizeof(PTR).                     */
/*    Vectors: an array of PTR follows.                               */
/*    Strings: an array of char follows (no trailing \0 byte!)        */
/*    Bigints: an array of Limb (=UInt16) follows, little endian,     */
/*             sign is encoded in header                              */
/*                                                                    */
/* 6. Foreign data                                                    */
/*                                                                    */
/*    Allow user modules defining their own datatypes. It's a 32 bit  */
/*    value which is put into the cell the cdr points to. Any 32 bit  */
/*    value is allowed, proper GC handling is ensured by putting      */
/*    the value at a higher address in the heap than the descriptor   */
/*    cell. Currently only 16 types (4 bit tag) are allowed to keep   */
/*    the finalizer (destructor) table small, but this can be easily  */
/*    extended on demand.                                             */
/*                                                                    */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* defines                                                            */
/**********************************************************************/
#define MAX_HEAP_SIZE   (131072L - 64)
#define MAX_REAL_SIZE     32768L
#define MIN_SMALLINT      -8192
#define MAX_SMALLINT       8191
#define MSG_OUTPUT_SIZE     256
#define MAX_PROTECT         120
#define OS3_STACK_AVAIL    3800
#define ALL_ELEMENTS      32767

/*--------------------------------------------------------------------*/
/* Magic numbers identifying heap versions                            */
/*--------------------------------------------------------------------*/
#define SESAME 0x3204 /* version 3.2 heap tag + revision nr.          */
                      /* please update version string in LispMe.prc   */
                      /* (help text for ERR_O10_ILLEGAL_SESS) also,   */
                      /* when changing this!                          */  

/*--------------------------------------------------------------------*/
/* Record numbers in session database                                 */
/*--------------------------------------------------------------------*/
#define REC_GLOB   0
#define REC_ATOM   1
#define REC_REAL   2
#define REC_CARS   3
#define REC_CDRS   4
#define REC_INP    5 
#define REC_OUT    6
#define REC_VECTOR 7

/*--------------------------------------------------------------------*/
/* Automaton states for last loaded memo                              */
/*--------------------------------------------------------------------*/
#define LS_INIT    0
#define LS_LOADED  1
#define LS_ERROR   2

/**********************************************************************/
/* typedefs                                                           */
/**********************************************************************/
typedef Int16 PTR;
#define PTR_BITLEN 16

typedef struct {
  LocalID dbId;   
  UInt16  recNr;  
} SourceRef;

struct MemGlobal {
  UInt16    magic;
  PTR       tlVals;
  PTR       tlNames;
  PTR       firstFree;
  PTR       firstFreeReal;
  PTR       S,E,C,D,W;
  PTR       newTopLevelVals;
  PTR       newTopLevelNames;
  UInt32    numStep;
  UInt32    numGC;
  UInt32    tickStart;
  Boolean   running;
  Boolean   waitEvent;
  Boolean   getEvent;
  Boolean   fileLoad;
  Boolean   ownGUI;
  Boolean   caseSens;
  Boolean   pickled;
  UInt8     loadState;
  Int16     symCnt;
  SourceRef lastSrc;
  UInt16    sourceFmt;
};

struct LispMeGlobPrefs {
  UInt8   watchDogSel;
  UInt8   printDepth;
  Boolean printQuotes;
  Boolean noAutoOff;
  Boolean lefty;
  Boolean bigMemo;
  Boolean rewriteDef;
  Boolean showParms;
  Boolean matchParens;
  char    sessDB[dmDBNameLength];
};

struct Session {
  Boolean icon;
  UInt16  size;
  UInt16  card;
  LocalID id;
  char    name[dmDBNameLength];
};

/**********************************************************************/
/* Module control function codes                                      */
/**********************************************************************/
typedef enum 
{
  APP_START,    APP_STOP,
  SESS_CREATE,  SESS_DELETE,
  SESS_CONNECT, SESS_DISCONNECT,
  INIT_HEAP
} ModuleMessage;

/**********************************************************************/
/* Memory control function codes                                      */
/**********************************************************************/
typedef enum
{
  MEM_MARK, 
  MEM_DELETE,
  MEM_PICKLE,
  MEM_UNPICKLE
} MemMessage;

typedef void (*memHookType)(MemMessage,PTR);

/**********************************************************************/
/* Data access macros                                                 */
/**********************************************************************/
#define VECTAG   0x0f
#define STRTAG   0x1f
#define BIGPTAG  0x2f
#define BIGNTAG  0x3f
#define FORTAG   0x4f
#define CHARTAG  0x8f

#define BIG_SIGN_MASK 0x0010

#define IS_SMALLINT(ptr) (((ptr) & 0x03) == 1)
#define IS_REAL(ptr)     (((ptr) & 0x0f) == 7)
#define IS_ATOM(ptr)     (((ptr) & 0x0f) == 3)
#define IS_CONS(ptr)     (((ptr) & 0x01) == 0)
#define IS_CHAR(ptr)     (((ptr) & 0xff) == CHARTAG)

#define IS_NE_VEC(ptr)   (IS_CONS(ptr) && (((car(ptr)) & 0xff) == VECTAG))
#define IS_VEC(ptr)      ((ptr)==EMPTY_VEC || IS_NE_VEC(ptr))
#define IS_STRING(ptr)   ((ptr)==EMPTY_STR ||\
                         (IS_CONS(ptr) && (((car(ptr)) & 0xff) == STRTAG)))

#define IS_BIGINT(ptr)   (IS_CONS(ptr) && (((car(ptr)) & 0xef) == BIGPTAG))
#define BIGSIGN(ptr)       (car(ptr) & BIG_SIGN_MASK)
#define SET_BIGSIGN(ptr,s) {if (s) car(ptr) |= BIG_SIGN_MASK;\
                            else car(ptr) &= ~BIG_SIGN_MASK;}
#define IS_INT(ptr)      (IS_SMALLINT(ptr) || IS_BIGINT(ptr))

#define IS_FOREIGN(ptr) (IS_CONS(ptr) && (((car(ptr)) & 0xff) == FORTAG))
#define IS_FORFAST(ptr) (((car(ptr)) & 0xff) == FORTAG)
#define IS_COMPLEX(ptr) (IS_CONS(ptr) && car(ptr) == CPLX_TAG)
#define IS_MACRO(ptr)   (IS_CONS(ptr) && car(ptr) == MACR_TAG)

#define ATOMVAL(ptr)  (((UInt16)(ptr))>>4)
#define MKATOM(off)   (((off)<<4) | 0x03)
#define REALVAL(ptr)  ((((UInt16)(ptr))>>4)<<3)
#define MKREAL(off)   (((off)<<1) | 0x07)
#define INTVAL(ptr)   ((ptr) >> 2)
#define MKINT(i)      ((PTR)((i)<<2) | 1)
#define CHARVAL(ptr)  (((UInt16)(ptr))>>8)
#define MKCHAR(c)     ((PTR)(((UInt8)(c))<<8) | CHARTAG)

#define car(ptr)    (*((PTR*)(carHeap+(ptr))))
#define cdr(ptr)    (*((PTR*)(cdrHeap+(ptr))))

/**********************************************************************/
/* Array access                                                       */
/**********************************************************************/
#define ArrayHandleLock(hd)   (MemHandleLock(hd)+sizeof(PTR))
#define ArrayHandleUnlock(hd) MemHandleUnlock(hd)
#define ArrayHandleSize(hd)   (MemHandleSize(hd)-sizeof(PTR))
#define ArrayPtrSize(p)       (MemPtrSize(((char*)(p))-sizeof(PTR))-sizeof(PTR))
#define ArrayPtrUnlock(p)     MemPtrUnlock(((char*)(p))-sizeof(PTR))
#define ArraySize(s)          ((s)+sizeof(PTR)) 
#define ArraySetBackPtr(r, p) ((PTR*)(r))[-1]=(p)
#define ArrayPtrResize(p, as) MemPtrResize(((char*)(p))-sizeof(PTR),(as))
#define ArrayBackPtr(p)       (*((PTR*)(p)))

#define MKARR_CAR(tag) ((PTR)(tag))
#define MKARR_CDR(idx) ((PTR)(idx))
#define ARR_TAG(ptr)   (car(ptr))
#define ARR_INDEX(ptr) ((UInt16)cdr(ptr))

/**********************************************************************/
/* Encoding of (frame . slot) in an integer (must fit in SMALLINT)    */
/**********************************************************************/
typedef Int16 LEXADR;
#define FRAME_SHIFT           7
#define SLOT_MASK          0x7f   
#define MAX_FRAMES           64
#define MAX_VARS_IN_FRAME   128
#define VAR_NOT_FOUND       MAX_SMALLINT

/******************************************************************/
/* Primitive symbols defined by an index within a frame           */
/* Supports 64 (6 bits) frames and 32 (5 bits) symbols in each    */
/******************************************************************/
#define IS_PRIMBIND(ptr) (((ptr) & 0x1f) == 0x1b)
#define IS_PRIMSYM(ptr)  (((ptr) & 0x1f) == 0x0b)
#define IS_PRIM(ptr)     (((ptr) & 0x0f) == 0x0b)

#define IS_FRAME0(ptr) (((ptr) & 0xfc1f) == 0x000b)
#define IS_SPECIAL(ptr) (IS_FRAME0(ptr) && ((ptr) < MLAMBDA))
#define IS_STAG(ptr)    (IS_FRAME0(ptr) && ((ptr) > MLAMBDA))

#define IS_SYM(ptr) (IS_ATOM(ptr) || IS_PRIMSYM(ptr))

#define MKPRIM(frame,index) (((frame&0x3f)<<10)|(index&0x1f)<<5)
#define MKPRIMSYM(frame,index) (MKPRIM(frame,index)|0x0b)
#define MKPRIMBIND(primsym) (primsym|0x1b)
#define PRIMVAL(ptr) (((unsigned)(ptr)) >> 5)
#define PRIMVAL1(ptr) (PRIMVAL(ptr) >> 5)
#define PRIMVAL2(ptr) (PRIMVAL(ptr) & 0x1f)

/**********************************************************************/
/* Foreign data: cdr points to 32 bit value in heap (split in 16 bit  */
/* in car and 16 bit in cdr)                                          */
/* !!! SETFOREIGNVAL uses macro parameter val twice !!!               */
/**********************************************************************/
#define FOREIGNTYPE(ptr) (car(ptr)>>8)
#define FOREIGNVAL(ptr)  ((void*)((((UInt32)(cadr(ptr)))<<16)|((UInt16)(cddr(ptr)))))
#define SETFOREIGNVAL(ptr,val) {cadr(ptr)=(PTR)(((UInt32)(val))>>16);\
                                cddr(ptr)=(PTR)(((UInt32)(val))&0xffff);}
#define MKFOREIGN(type)  ((PTR)(((type)<<8) | FORTAG))

/**********************************************************************/
/* First frame in primitives table is reserved for special values     */
/**********************************************************************/
#define BLACK_HOLE   MKPRIMSYM(0,1)
#define NIL          MKPRIMSYM(0,2)
#define FALSE        MKPRIMSYM(0,3)
#define TRUE         MKPRIMSYM(0,4)
#define NOPRINT      MKPRIMSYM(0,5)
#define END_OF_FILE  MKPRIMSYM(0,6)
#define EMPTY_VEC    MKPRIMSYM(0,7)
#define EMPTY_STR    MKPRIMSYM(0,8)
#define LET_TAG      MKPRIMSYM(0,9)

// MLAMBDA is used as a separator
#define MLAMBDA      MKPRIMSYM(0,10)

#define CLOS_TAG     MKPRIMSYM(0,11)
#define RCPD_TAG     MKPRIMSYM(0,12)
#define RCPF_TAG     MKPRIMSYM(0,13)
#define CONT_TAG     MKPRIMSYM(0,14)
#define CPLX_TAG     MKPRIMSYM(0,15)
#define MACR_TAG     MKPRIMSYM(0,16)
#define CXR_TAG      MKPRIMSYM(0,17)

/**********************************************************************/
/* Aliases for keyword PTRs                                           */
/**********************************************************************/
/* these four macro characters must be first     */
/* in order matching macroChars constant in io.c */
#define QUOTE           MKPRIMSYM(KEYWORD_MODULE,1)
#define QUASIQUOTE      MKPRIMSYM(KEYWORD_MODULE,2)
#define UNQUOTE         MKPRIMSYM(KEYWORD_MODULE,3)
#define UNQUOTESPLICING MKPRIMSYM(KEYWORD_MODULE,4)

#define DEFINE          MKPRIMSYM(KEYWORD_MODULE,5)
#define LETREC          MKPRIMSYM(KEYWORD_MODULE,6)
#define LAMBDA          MKPRIMSYM(KEYWORD_MODULE,7)
#define BEGIN           MKPRIMSYM(KEYWORD_MODULE,8)
#define ELSE            MKPRIMSYM(KEYWORD_MODULE,9)
#define COND            MKPRIMSYM(KEYWORD_MODULE,10)
#define IF              MKPRIMSYM(KEYWORD_MODULE,11)
#define AND             MKPRIMSYM(KEYWORD_MODULE,12)
#define OR              MKPRIMSYM(KEYWORD_MODULE,13)
#define SET             MKPRIMSYM(KEYWORD_MODULE,14)
#define DELAY           MKPRIMSYM(KEYWORD_MODULE,15)
#define CALLCC          MKPRIMSYM(KEYWORD_MODULE,16)
#define APPLY           MKPRIMSYM(KEYWORD_MODULE,17)
#define IT              MKPRIMSYM(KEYWORD_MODULE,18)
#define CASE            MKPRIMSYM(KEYWORD_MODULE,19)
#define MACRO           MKPRIMSYM(KEYWORD_MODULE,20)
#define HIST            MKPRIMSYM(KEYWORD_MODULE,21)

#define LET             MKPRIMSYM(MISC_MODULE, 1)

/**********************************************************************/
/* Generalized operations                                             */
/**********************************************************************/
typedef enum {
  ARITHOP_ADD,
  ARITHOP_SUB,
  ARITHOP_MUL
} ArithOp;

typedef enum {
  DIVOP_DIV,
  DIVOP_IDIV,
  DIVOP_REM,
  DIVOP_BOTH
} DivOp;

typedef enum {
  BITOP_AND,
  BITOP_IOR,
  BITOP_XOR 
} BitOp;

/**********************************************************************/
/* Protect for GC                                                     */
/**********************************************************************/
#define PROTECT(p)   {protPtr[protIdx++] = &p;}
#define UNPROTECT(p) {--protIdx;}

/**********************************************************************/
/* Check stack overflow                                               */
/**********************************************************************/
#define CHECKSTACK(p) {if (((char*)&(p))<stackLimit) \
                         ErrThrow(ERR_O7_STACK_OVER);}

/**********************************************************************/
/* Some list handling macros                                          */
/**********************************************************************/
#define pop(val,ptr)  (val=car(ptr),ptr = cdr(ptr))
#define push(val,ptr) (ptr=cons(val,ptr))

#define caar(ptr)   car(car(ptr))
#define cadr(ptr)   car(cdr(ptr))
#define cdar(ptr)   cdr(car(ptr))
#define cddr(ptr)   cdr(cdr(ptr))
#define caaar(ptr)  car(car(car(ptr)))
#define caadr(ptr)  car(car(cdr(ptr)))
#define cadar(ptr)  car(cdr(car(ptr)))
#define caddr(ptr)  car(cdr(cdr(ptr)))
#define cdaar(ptr)  cdr(car(car(ptr)))
#define cdadr(ptr)  cdr(car(cdr(ptr)))
#define cddar(ptr)  cdr(cdr(car(ptr)))
#define cdddr(ptr)  cdr(cdr(cdr(ptr)))
#define cadddr(ptr) car(cdr(cdr(cdr(ptr))))
#define cddddr(ptr) cdr(cdr(cdr(cdr(ptr))))

#define cons2(v1,v2,t)          cons(v1,cons(v2,t))
#define cons3(v1,v2,v3,t)       cons(v1,cons2(v2,v3,t))
#define cons4(v1,v2,v3,v4,t)    cons(v1,cons3(v2,v3,v4,t))
#define cons5(v1,v2,v3,v4,v5,t) cons(v1,cons4(v2,v3,v4,v5,t))

#define list1(v)                cons(v,NIL)
#define list2(v1,v2)            cons2(v1,v2,NIL)
#define list3(v1,v2,v3)         cons3(v1,v2,v3,NIL)
#define list4(v1,v2,v3,v4)      cons4(v1,v2,v3,v4,NIL)
#define list5(v1,v2,v3,v4,v5)   cons5(v1,v2,v3,v4,v5,NIL)


/**********************************************************************/
/* Some string creation macros                                        */
/* copyString:   given length and (char*) buffer                      */
/* createString: given length, init with '\0'                         */
/* make4Byteg:   given UInt32, interprete as 4 chars and constr. str. */
/**********************************************************************/
#define copyString(len, buf) makeString((len),(buf),0,0,NIL)
#define createString(len)    makeString((len),NULL,0,(char*)1,MKCHAR('\0'))
#define make4Byte(i32)       makeString(4,(char*)&(i32),0,0,NIL)

/**********************************************************************/
/* external data                                                      */
/**********************************************************************/
extern LocalID   dbId;
extern DmOpenRef dbRef;

extern struct MemGlobal* pMemGlobal;
extern PTR S,E,C,D,W;
extern PTR firstFree;

extern char*    carHeap;
extern char*    cdrHeap;
extern char*    strStore;

extern Int32    atomSize;
extern Int32    heapSize;
extern Int32    heapLimit;
extern char*    markBit;

extern MemHandle realHandle;
extern Int32     realSize;
extern char*     reals;
extern char*     markRealBit;
extern PTR       firstFreeReal;

extern Int32   numGC;
extern Int32   numStep;
extern UInt32  tickStart;
extern UInt32  tickStop;
extern Boolean caseSens;

extern Int16    depth;              /* stack depth for printing or GC */
extern Boolean  running;
extern Boolean  palmOS5; 
extern Boolean  parHackActive;
extern Boolean  useMSR; 

extern MemHandle atomHandle;
extern MemHandle carsHandle;
extern MemHandle cdrsHandle;
extern MemHandle globHandle;
extern MemHandle outHandle;
extern MemHandle inHandle;
extern FieldPtr  inField;
extern FieldPtr  outField;
extern ScrollBarPtr scrollBar;
extern FormPtr      mainForm;

extern struct LispMeGlobPrefs LispMePrefs;
extern PTR keyWords[];

extern PTR*  protPtr[MAX_PROTECT];
extern int   protIdx;
extern char* stackLimit;

extern char  charEllipsis;
extern char  charNumSpace;

extern int     actContext;

extern Boolean   quitHandler;
extern Boolean   changeHandler;

extern char**    symbols;
extern char**    historyStr;

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
PTR     findAtom(char* str, Boolean create)                     SEC(VM);
char*   getAtom(PTR p)                                          SEC(VM);

PTR     allocReal(double d)                                     SEC(VM);
double  getReal(PTR p)                                          SEC(VM);

PTR     allocForeign(void* p, UInt8 ftype)                      SEC(VM);
void    registerMemHook(UInt8 ftype, memHookType fp)            SEC(VM);
PTR     cons(PTR a, PTR b)                                      SEC(VM);
void    gc(PTR a, PTR b)                                        SEC(VM);
void    mark(PTR p)                                             SEC(VM);

void    pickle(void)                                            SEC(VM);
void    unpickle(void)                                          SEC(VM);
void    FreeDynMem(void)                                               ;

void    memStat(Int32* heapUse, Int32* realUse, Int32* atomUse,
                Int32* vecSize, Int32* strSize, Int32* bigSize);
void    formatRight(char* buf, Int32 n, Int16 pl);
void    formatMemStat(char* buf, Int32 use, Int32 total);

void    initHeap(void);
void    destroyHeap(void);                                              
PTR     makeVector(UInt16 len, PTR fill, Boolean advance)       SEC(VM);
PTR     makeString(UInt16 len, const char* buf,
                   UInt16 len2, const char* buf2, PTR l)        SEC(VM);
PTR     appendStrings(PTR a, PTR b)                             SEC(VM);
PTR*    listCopy(PTR* d, PTR l, Int16 nc)                       SEC(VM);
PTR     vector2List(PTR v)                                      SEC(VM);
PTR     string2List(PTR str)                                    SEC(VM);
UInt16  stringLength(PTR s)                                     SEC(VM);
UInt16  vectorLength(PTR v)                                     SEC(VM);
void    vectorAcc(PTR* obj, PTR vec, UInt16 n, Boolean write)   SEC(VM);
void    stringAcc(PTR* c, PTR str, UInt16 n, Boolean write)     SEC(VM);
PTR     substring(PTR str, UInt16 start, UInt16 end)            SEC(VM);
int     strComp(PTR a, PTR b)                                   SEC(VM);
char**  allSymbols(UInt16* num);
char**  prefixSymbols(char *prefix, UInt16 len, UInt16* num);
char*   completeAtoms(char *prefix, UInt16 len, Boolean force)  SEC(VM);
Boolean IS_PAIR(PTR ptr)                                        SEC(VM);

#define DUMP(m) {ReleaseMem();FrmCustomAlert(ALERT_DEBUG,m,"none",NULL); GrabMem();}
#define DUMP2(m,n) {StrIToH(msg,n);ReleaseMem();FrmCustomAlert(ALERT_DEBUG,m,msg,NULL); GrabMem();}

#endif
