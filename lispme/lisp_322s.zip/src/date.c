/**********************************************************************/
/*                                                                    */
/* date.c: LISPME sample extension: date                              */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed und^er the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "date.h"
#include "vm.h"
#include "io.h"
#include "util.h"
#include "arith.h"

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
static DateFormatType dFmt;
static TimeFormatType tFmt;
void*  auxP;

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void    init(ModuleMessage mess)                        SEC(MOD); 
static void    timeStampPrinter(Boolean machineFormat, void* p)SEC(MOD);
static void    datePrinter(Boolean machineFormat, void* p)     SEC(MOD); 
static void    timePrinter(Boolean machineFormat, void* p)     SEC(MOD);
static void    ticksPrinter(Boolean machineFormat, void* p)    SEC(MOD);
static Boolean eqv16Bit(void* a, void* b)                      SEC(MOD);

static PTR  nativeMakeTS(PTR* args)                            SEC(MOD);
static PTR  nativeCurrTS(PTR* args)                            SEC(MOD);
static PTR  nativeTS2Number(PTR* args)                         SEC(MOD); 
static PTR  nativeTSSecond(PTR* args)                          SEC(MOD);
static PTR  nativeMakeDate(PTR* args)                          SEC(MOD); 
static PTR  nativeDateAddDays(PTR* args)                       SEC(MOD); 
static PTR  nativeDateDiff(PTR* args)                          SEC(MOD);
static PTR  nativeDateYear(PTR* args)                          SEC(MOD);
static PTR  nativeDateMonth(PTR* args)                         SEC(MOD);
static PTR  nativeDateDay(PTR* args)                           SEC(MOD);
static PTR  nativeTimeHour(PTR* args)                          SEC(MOD);
static PTR  nativeTimeMinute(PTR* args)                        SEC(MOD);
static PTR  nativeCurrentTicks(PTR* args)                      SEC(MOD);
static PTR  nativeSetTicks(PTR* args)                          SEC(MOD);
static PTR  nativeTicksPerSec(PTR* arg)                        SEC(MOD);
static PTR  nativeTicksSince(PTR* arg)                         SEC(MOD);

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START:
      registerTypename(FT_TIMESTAMP, "timestamp");
      registerTypename(FT_DATE,      "date");
      registerTypename(FT_TIME,      "time");
      registerTypename(FT_TICKS,     "ticks");
      registerPrinter(FT_TIMESTAMP, timeStampPrinter);
      registerPrinter(FT_DATE,      datePrinter);
      registerPrinter(FT_TIME,      timePrinter);
      registerPrinter(FT_TICKS,     ticksPrinter);
      registerEQV(FT_TIME, eqv16Bit);
      registerEQV(FT_DATE, eqv16Bit);
      dFmt = PrefGetPreference(prefLongDateFormat);
      tFmt = PrefGetPreference(prefTimeFormat);
      break;

    default:
  }
}

/**********************************************************************/
/* Compare only upper 16 bits of value                                */
/**********************************************************************/
static Boolean eqv16Bit(void* a, void* b)
{
  return *((Int16*)&a) == *((Int16*)&b);
}

/**********************************************************************/
/* Print a timestamp                                                  */
/**********************************************************************/
static void timeStampPrinter(Boolean machineFormat, void* p)
{
  UInt32 secs = (UInt32)p;
  DateTimeType dt;
  TimSecondsToDateTime(secs, &dt);
  
  // The following format string does NOT work with pre-3.0 versions
  // of PalmOS!
  StrPrintF(token,"%04d-%02d-%02d-%02d-%02d-%02d",
            dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second);
  if (machineFormat)
    outStr("[ts ");
  outStr(token);
  if (machineFormat)
    outStr("]");
}

/**********************************************************************/
/* Print a date                                                       */
/**********************************************************************/
static void datePrinter(Boolean machineFormat, void* p)
{
  DatePtr pd = (DatePtr)&p;
  DateToAscii(pd->month, pd->day, pd->year + 1904, dFmt, token);
  if (machineFormat)
    outStr("[date ");
  outStr(token);
  if (machineFormat)
    outStr("]");
}

/**********************************************************************/
/* Print a time                                                       */
/**********************************************************************/
static void timePrinter(Boolean machineFormat, void* p)
{
  TimePtr pt = (TimePtr)&p;
  TimeToAscii(pt->hours, pt->minutes, tFmt, token);
  if (machineFormat)
    outStr("[time ");
  outStr(token);
  if (machineFormat)
    outStr("]");
}

/**********************************************************************/
/* Print a ticks                                                      */
/**********************************************************************/
static void ticksPrinter(Boolean machineFormat, void* p)
{
  StrIToA(token, (Int32)p);
  outStr(token);
  outStr("\217"); // :-)
}

/**********************************************************************/
/* Create a timestamp from seconds                                    */
/**********************************************************************/
static PTR nativeMakeTS(PTR* args)
{
  UInt32 secs = getUInt32(args[0]);
  return allocForeign((void*)secs, FT_TIMESTAMP);
}

/**********************************************************************/
/* Create a new date from year, month, day                            */
/**********************************************************************/
PTR allocDate(int year, int month, int day)
{
  DateType dt;
  dt.year  = year-1904;
  dt.month = month;
  dt.day   = day;
  return allocForeign((void*)*((UInt32*)&dt), FT_DATE);
}

/**********************************************************************/
/* Create a new time from hour and minute                             */
/**********************************************************************/
PTR allocTime(int hour, int minute)
{
  TimeType tt;
  tt.hours   = hour;
  tt.minutes = minute;
  return allocForeign((void*)*((UInt32*)&tt), FT_TIME);
}

/**********************************************************************/
/* Create a date from year, month, day                                */
/**********************************************************************/
static PTR nativeMakeDate(PTR* args)
{
  return allocDate(INTVAL(args[0]),
                   INTVAL(args[1]), 
                   INTVAL(args[2]));
}

/**********************************************************************/
/* Create a time from hour and minute                                 */
/**********************************************************************/
static PTR nativeMakeTime(PTR* args)
{
  return allocTime(INTVAL(args[0]),
                   INTVAL(args[1]));
}

/**********************************************************************/
/* Add days to a date                                                 */
/**********************************************************************/
static PTR nativeDateAddDays(PTR* args)
{
  DateType date = GETDATE(args[0]);

  DateAdjust(&date, getInt32(args[1]));
  return allocDate(date.year+1904, date.month, date.day);
}

/**********************************************************************/
/* Difference between two dates                                       */
/**********************************************************************/
static PTR nativeDateDiff(PTR* args)
{
  DateType date1 = GETDATE(args[0]);
  DateType date2 = GETDATE(args[1]);

  return makeNum(((Int32)DateToDays(date1)) -
                 ((Int32)DateToDays(date2)));
}

/**********************************************************************/
/* Day of week [0==Sunday, 1==Monday etc.]                            */
/**********************************************************************/
static PTR nativeDayOfWeek(PTR* args)
{
  DateType d = GETDATE(args[0]);

  return MKINT(DayOfWeek(d.month, d.day, d.year+1904));
}

/**********************************************************************/
/* Extract components of a date/time/timestamp                        */
/**********************************************************************/
static PTR nativeDateYear(PTR* args)
{
  DateType d = GETDATE(args[0]);
  return MKINT(d.year+1904);
}

static PTR nativeDateMonth(PTR* args)
{
  DateType d = GETDATE(args[0]);
  return MKINT(d.month);
}

static PTR nativeDateDay(PTR* args)
{
  DateType d = GETDATE(args[0]);
  return MKINT(d.day);
}

static PTR nativeTimeHour(PTR* args)
{
  TimeType t = GETTIME(args[0]);
  return MKINT(t.hours);
}

static PTR nativeTimeMinute(PTR* args)
{
  TimeType t = GETTIME(args[0]);
  return MKINT(t.minutes);
}

static PTR nativeTSSecond(PTR* args)
{
  UInt32 secs = (UInt32)FOREIGNVAL(args[0]);
  DateTimeType dt;
  TimSecondsToDateTime(secs, &dt); // probably secs%60 works also ???
  return MKINT(dt.second);
}

/**********************************************************************/
/* Get current timestamp                                              */
/**********************************************************************/
static PTR nativeCurrTS(PTR* args)
{
  return allocForeign((void*)TimGetSeconds(), FT_TIMESTAMP);
}

/**********************************************************************/
/* Convert timestamp to number                                        */
/**********************************************************************/
static PTR nativeTS2Number(PTR* args)
{
  return makeUNum((UInt32)FOREIGNVAL(args[0]));
}

/**********************************************************************/
/* Extract date from a timestamp                                      */
/**********************************************************************/
static PTR nativeTS2Date(PTR* args)
{
  DateType     date;
  DateTimeType dt;
  UInt32       secs = (UInt32)FOREIGNVAL(args[0]);
  TimSecondsToDateTime(secs, &dt);
  date.year  = dt.year-1904;
  date.month = dt.month;
  date.day   = dt.day;
  return allocForeign((void*)*((UInt32*)&date), FT_DATE);
}

/**********************************************************************/
/* Extract time from a timestamp                                      */
/**********************************************************************/
static PTR nativeTS2Time(PTR* args)
{
  TimeType     time;
  DateTimeType dt;
  UInt32       secs = (UInt32)FOREIGNVAL(args[0]);
  TimSecondsToDateTime(secs, &dt);
  time.hours   = dt.hour;
  time.minutes = dt.minute;
  return allocForeign((void*)*((UInt32*)&time), FT_TIME);
}

/**********************************************************************/
/* Current tick counter                                               */
/**********************************************************************/
static PTR nativeCurrentTicks(PTR* args)
{ return allocForeign((void*)TimGetTicks(), FT_TICKS);}

/**********************************************************************/
/* Set ticks                                                          */
/**********************************************************************/
static PTR nativeSetTicks(PTR* args)
{
  UInt32 ticks = TimGetTicks();
  SETFOREIGNVAL(args[0],ticks);
  return args[0];
}

/**********************************************************************/
/* Ticks pr. sec                                                      */
/**********************************************************************/
static PTR nativeTicksPerSec(PTR* args)
{
  return makeNum(SysTicksPerSecond());
}

/**********************************************************************/
/* Compute ticks difference                                           */
/**********************************************************************/
static PTR nativeTicksSince(PTR* args)
{
  return makeNum(TimGetTicks()-((UInt32)FOREIGNVAL(args[0])));
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule dateBuiltins = 
{
  MODULE_FUNC(init),
  {"make-ts",       NATIVE1(nativeMakeTS,    tyINT)},
  {"current-ts",    NATIVE0(nativeCurrTS)},     
  {"ts->number",    NATIVE1(nativeTS2Number, FOREIGN(FT_TIMESTAMP))},     
  {"ts->date",      NATIVE1(nativeTS2Date,   FOREIGN(FT_TIMESTAMP))},
  {"ts->time",      NATIVE1(nativeTS2Time,   FOREIGN(FT_TIMESTAMP))},
  {"ts-second",     NATIVE1(nativeTSSecond,  FOREIGN(FT_TIMESTAMP))},
  {"ts?",           PRIMTYPE(FOREIGN(FT_TIMESTAMP))},

  {"make-date",     NATIVE3_H(nativeMakeDate, tySMALLINT, tySMALLINT, tySMALLINT,
                              "year month day")},
  {"date+",         NATIVE2(nativeDateAddDays, FOREIGN(FT_DATE), tyINT)},
  {"date-diff",     NATIVE2(nativeDateDiff,  FOREIGN(FT_DATE), FOREIGN(FT_DATE))},
  {"date-year",     NATIVE1(nativeDateYear,  FOREIGN(FT_DATE))},
  {"date-month",    NATIVE1(nativeDateMonth, FOREIGN(FT_DATE))},
  {"date-day",      NATIVE1(nativeDateDay,   FOREIGN(FT_DATE))},
  {"day-of-week",   NATIVE1(nativeDayOfWeek, FOREIGN(FT_DATE))},
  {"date?",         PRIMTYPE(FOREIGN(FT_DATE))},

  {"make-time",     NATIVE2(nativeMakeTime,   tySMALLINT, tySMALLINT)},
  {"time-hour",     NATIVE1(nativeTimeHour,   FOREIGN(FT_TIME))},
  {"time-minute",   NATIVE1(nativeTimeMinute, FOREIGN(FT_TIME))},
  {"time?",         PRIMTYPE(FOREIGN(FT_TIME))},

  {"current-ticks", NATIVE0(nativeCurrentTicks)},
  {"set-ticks!",    NATIVE1(nativeSetTicks, FOREIGN(FT_TICKS))},
  {"ticks-since",   NATIVE1(nativeTicksSince, FOREIGN(FT_TICKS))},
  {"ticks-per-sec", NATIVE0(nativeTicksPerSec)},
  {"ticks?",        PRIMTYPE(FOREIGN(FT_TICKS))},
  
  {NULL}
};
