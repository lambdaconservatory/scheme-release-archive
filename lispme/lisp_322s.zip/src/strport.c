/**********************************************************************/
/*                                                                    */
/* strport.c: LISPME string port support                              */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 04.06.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "strport.h"
#include "util.h"

/**********************************************************************/
/* Local definitions                                                  */
/**********************************************************************/
#define DEFAULT_OUTSTRING_SIZE 256

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void    initModule(ModuleMessage mess)                   SEC(IO);
static void    writeStr(WriterCmd cmd, OutPort* outp)           SEC(IO);
static Boolean readStr(ReaderCmd cmd, InPort* inp)              SEC(IO);
static Boolean readLst(ReaderCmd cmd, InPort* inp)              SEC(IO);

static PTR  nativeOpenInStr(PTR* args)                          SEC(IO);
static PTR  nativeOpenOutStr(PTR* args)                         SEC(IO);
static PTR  nativeGetOutStr(PTR* args)                          SEC(IO);
static PTR  nativeOpenInLst(PTR* args)                          SEC(IO);

/**********************************************************************/
/* Module control function                                            */
/**********************************************************************/
static void initModule(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
      /*--------------------------------------------------------------*/
      /* Register hooks                                               */
      /*--------------------------------------------------------------*/
      registerWriteFct(PT_STRING, writeStr);
      registerReadFct(PT_STRING,  readStr);
      registerReadFct(PT_STRLIST,  readLst);
      break;

    default:
  }
}

/**********************************************************************/
/* Open a string as an input port                                     */
/**********************************************************************/
static PTR nativeOpenInStr(PTR* args)
{
  return makeBufInPort(PT_STRING, args[0], args[0]);
}

/**********************************************************************/
/* Open a string as an outut port                                     */
/**********************************************************************/
static PTR nativeOpenOutStr(PTR* args)
{
  return makeBufOutPort(PT_STRING, EMPTY_STR,
                        DEFAULT_OUTSTRING_SIZE, OPF_NORMAL);
}

/**********************************************************************/
/* Get a string of an output string port                              */
/**********************************************************************/
static PTR nativeGetOutStr(PTR* args)
{
  OutPort* outp = FOREIGNVAL(args[0]);

  if (outp->type != PT_STRING)
    extTypeError("get-output-string", 0, args[0], "string output port");

  // Always make copy to avoid letting user modify buffer!    
  return appendStrings(outp->impl,substring(outp->buf, 0, outp->pos)); 
}

/**********************************************************************/
/* Read from a string                                                 */
/**********************************************************************/
static Boolean readStr(ReaderCmd cmd, InPort* inp)
{
  switch (cmd) {
    case RC_READ: 
      return false; 

    case RC_CLOSE: 
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL;
      inp->impl   = NIL;
      return true;
  }
}

/**********************************************************************/
/* Open a string list as an input port                                */
/**********************************************************************/
static PTR nativeOpenInLst(PTR* args)
{
  TCHECK(tySTRING, car(args[0]));
  return makeBufInPort(PT_STRLIST, cdr(args[0]), car(args[0]));
}

/**********************************************************************/
/* Read from a string list                                            */
/**********************************************************************/
static Boolean readLst(ReaderCmd cmd, InPort* inp)
{
  switch (cmd) {
    case RC_READ: 
      if (inp->impl == NIL)
        return false; 
      else {
        TCHECK(tySTRING, car(inp->impl));
        inp->buf    = car(inp->impl);
        inp->bufLen = stringLength(inp->buf);
        inp->impl   = cdr(inp->impl);
        inp->pos    = 0;
        return true;
      }  

    case RC_CLOSE: 
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL;
      inp->impl   = NIL;
      return true;
  }
}

/**********************************************************************/
/* Write to a string                                                  */
/**********************************************************************/
static void writeStr(WriterCmd cmd, OutPort* outp)
{
  switch (cmd) {
    case WC_WRITE:
      outp->impl = appendStrings(outp->impl, outp->buf);
      outp->pos = 0;
      break;
    
    case WC_CLOSE:
      outp->flags |= OPF_CLOSED;
      break;
  }
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule strPortBuiltins = 
{
  MODULE_FUNC(initModule),
  {"open-input-string",   NATIVE1(nativeOpenInStr, tySTRING)},
  {"open-output-string",  NATIVE0(nativeOpenOutStr)},
  {"get-output-string",   NATIVE1(nativeGetOutStr, FOREIGN(FT_OUTPORT))},
  {"open-input-list",     NATIVE1(nativeOpenInLst, tyPROPLIST)},

  {NULL}
};
