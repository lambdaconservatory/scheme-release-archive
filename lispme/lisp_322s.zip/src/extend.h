/**********************************************************************/
/*                                                                    */
/* extend.h: LISPME extension module defines                          */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* All modules and foreign types are defined here.                    */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.03.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_EXTEND_H
#define INC_EXTEND_H

/**********************************************************************/
/* Modules                                                            */
/**********************************************************************/
#define SPECIAL_MODULE      0
#define KEYWORD_MODULE      1
#define EVENT_MODULE        2
#define PRIMITIVE_MODULE    3
#define NUMBER_MODULE       4
#define NUMBER_MODULE2      5
#define TRANS_MODULE        6
#define LIST_MODULE         7
#define VECSTR_MODULE       8
#define GRAPHIC_MODULE      9
#define HBASE_MODULE       10
#define GUI_MODULE         11 
#define GUI_MODULE2        12 
#define MISC_MODULE        13 
#define PORT_MODULE        14
#define FILE_MODULE        15
#define DATE_MODULE        16
#define DM_MODULE          17
#define SOCKET_MODULE      18
#define STRPORT_MODULE     19
#define STRUCT_MODULE      20
#define SERIAL_MODULE      21 
#define VFS_MODULE         22 

#define MAX_MODULES_COUNT  64

/**********************************************************************/
/* Foreign types @@maxFT                                              */
/**********************************************************************/
#define FT_TIMESTAMP        0
#define FT_DATE             1
#define FT_TIME             2
#define FT_TICKS            3
#define FT_DBREF            4
#define FT_INPORT           5
#define FT_OUTPORT          6
#define FT_SOCKET           7
#define FT_SERIAL           8
#define FT_STR_ARR          9
#define FT_VFS_FILE        10

#define MAX_FOREIGN_TYPES  16

/**********************************************************************/
/* Input/output port subtypes                                         */
/**********************************************************************/
#define PT_MEMO             0
#define PT_MEMO32           1
#define PT_DOC              2
#define PT_CDOC             3
#define PT_OUTFIELD         4 
#define PT_MESSAGE          5
#define PT_SOCKET           6
#define PT_STRING           7
#define PT_STRLIST          8
#define PT_SERIAL           9
#define PT_VFS             10

#define MAX_PORT_TYPES     16

/**********************************************************************/
/* Extension module headers                                           */
/**********************************************************************/
#include "lists.h"
#include "graphic.h"
#include "gui.h"
#include "hbase.h"
#include "misc.h"
#include "port.h"
#include "file.h"
#include "date.h"
#include "dm.h"
#include "socket.h"
#include "strport.h"
#include "struct.h"
#include "serial.h"
#include "vfs.h"

/**********************************************************************/
/* Add all modules to module table                                    */
/**********************************************************************/
#define ADD_ALL_MODULES\
  ADD_MOD(SPECIAL_MODULE,   specialBuiltins)\
  ADD_MOD(KEYWORD_MODULE,   keywordBuiltins)\
  ADD_MOD(EVENT_MODULE,     eventBuiltins)\
  ADD_MOD(PRIMITIVE_MODULE, primitiveBuiltins)\
  ADD_MOD(NUMBER_MODULE,    numberBuiltins)\
  ADD_MOD(NUMBER_MODULE2,   numberBuiltins2)\
  ADD_MOD(TRANS_MODULE,     transBuiltins)\
  ADD_MOD(LIST_MODULE,      listBuiltins)\
  ADD_MOD(VECSTR_MODULE,    vecStrBuiltins)\
  ADD_MOD(GRAPHIC_MODULE,   graphicBuiltins)\
  ADD_MOD(HBASE_MODULE,     hbaseBuiltins)\
  ADD_MOD(GUI_MODULE,       guiBuiltins)\
  ADD_MOD(GUI_MODULE2,      guiBuiltins2)\
  ADD_MOD(MISC_MODULE,      miscBuiltins)\
  ADD_MOD(PORT_MODULE,      portBuiltins)\
  ADD_MOD(FILE_MODULE,      fileBuiltins)\
  ADD_MOD(DATE_MODULE,      dateBuiltins)\
  ADD_MOD(DM_MODULE,        dmBuiltins)\
  ADD_MOD(SOCKET_MODULE,    socketBuiltins)\
  ADD_MOD(STRPORT_MODULE,   strPortBuiltins)\
  ADD_MOD(STRUCT_MODULE,    structBuiltins)\
  ADD_MOD(SERIAL_MODULE,    serialBuiltins)\
  ADD_MOD(VFS_MODULE,       vfsBuiltins)\

#endif
