/**********************************************************************/
/*                                                                    */
/* date.h: LISPME sample extension module: date                       */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_DATE_H
#define INC_DATE_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Access macros                                                      */
/**********************************************************************/
#define GETDATE(ptr) (auxP=FOREIGNVAL(ptr),*((DatePtr)(&auxP)))
#define GETTIME(ptr) (auxP=FOREIGNVAL(ptr),*((TimePtr)(&auxP)))

/**********************************************************************/
/* Exported functions                                                 */
/**********************************************************************/
PTR allocDate(int year, int month, int day);
PTR allocTime(int hour, int minute);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern void* auxP;
extern BuiltInModule dateBuiltins; 

#endif
