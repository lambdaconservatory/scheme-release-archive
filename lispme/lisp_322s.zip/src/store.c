/**********************************************************************/
/*                                                                    */
/* store.c: LISPME memory management                                  */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 20.07.1997 New                                                FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/


/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include "LispMe.h"
#include "vm.h"
#include "util.h"
#include "builtin.h"
#include "arith.h"

/**********************************************************************/
/* global data                                                        */
/**********************************************************************/
PTR*      protPtr[MAX_PROTECT];
int       protIdx;
char*     stackLimit;
char      charEllipsis;
char      charNumSpace;
LocalID   dbId;
MemHandle atomHandle;
MemHandle carsHandle;
MemHandle cdrsHandle;
MemHandle globHandle;
Boolean   caseSens;

char**    symbols;
char**    historyStr;

/**********************************************************************/
/* static data                                                        */
/**********************************************************************/
static memHookType memHooks[MAX_FOREIGN_TYPES];

/**********************************************************************/
/* find atom in store or add it if not found and create               */
/**********************************************************************/
PTR findAtom(char* str, Boolean create)
{
  char* store  = strStore;
  char* newstr = str;
 
  for(;;)
  {
    if (*store == *newstr)
    {
      if (*store == '\0')
      {
        /* string found */
        return MKATOM(store-strStore-(newstr-str));
      }
      /* compare next chars */
      ++store;
      ++newstr;
    }
    else
    {
      /* advance to end of string in store */
      while (*store++)
        ;
      if (*store != '\x01') {
        /* continue comparison at start of search string */
        newstr = str;
      }
      else if (!create)
        return FALSE;
      else
      {
        /* end of store, check for space and insert string */
        int len = StrLen(str);
        if (store-strStore+len+1 >= atomSize)
          ErrThrow(ERR_M1_STRING_FULL);
        MemMove(store,str,len+1);
        return MKATOM(store-strStore);
      }
    }
  }
}

/**********************************************************************/
/* get string for atom from memory                                    */
/**********************************************************************/
char* getAtom(PTR p)
{
  if (IS_ATOM(p))
    return strStore + ATOMVAL(p);
  else
    error1(ERR_M2_INVALID_PTR,p);
}

/**********************************************************************/
/* comparison function for quicksort                                  */
/**********************************************************************/
static Int16 compare(void* a, void* b, Int32 ignore)
{
  return StrCompare(*((const char**)a),*((const char**)b));
}

/**********************************************************************/
/* Build list of all available symbols                                */
/**********************************************************************/
char** prefixSymbols(char *prefix, UInt16 len, UInt16* num)
{
   char**  res = NULL;
   char*   p;
   UInt16  idx = 0;
   Boolean pp = true;

   *num = 0;
   for (p = strStore+1; *p != '\x01'; ++p) {
     if (pp && prefixOf(prefix, len, p, -1))
       ++*num;
     pp = (*p == '\0');
   }
   prefixBuiltins(prefix, len, num, NULL);

   if ((*num > 0) && (res = (char**)MemPtrNew(*num*sizeof(char*))))
   {
     pp = true;
     for (p = strStore+1; *p != '\x01'; ++p) {
       if (pp && prefixOf(prefix, len, p, -1))
        res[idx++] = p;
       pp = (*p == '\0');
     }
     prefixBuiltins(prefix, len, NULL, res+idx);
     SysQSort(res,*num,sizeof(char*),&compare,0L);
   }
   return res;
}

/**********************************************************************/
/* Build list of all available symbols                                */
/**********************************************************************/
char** allSymbols(UInt16* num)
{
   return prefixSymbols(NULL, 0, num);
}

/**********************************************************************/
/* complete string from atom store                                    */
/**********************************************************************/
char* completeAtoms(char* prefix, UInt16 len, Boolean force)
{
  UInt16 n;
  char * ss = strStore+1, *c = NULL;

  for (; *ss != '\x01'; ss += (n + 1)) {
    n = StrLen(ss);
    c = completeString1(prefix, len, ss, force);
  }
  return c;
}

/**********************************************************************/
/* init heap cells                                                    */
/**********************************************************************/
void initHeap(void)
{
  PTR p;
  MemHandle recHand;

  /*------------------------------------------------------------------*/
  /* Destroy all vectors and strings                                  */
  /*------------------------------------------------------------------*/
  while ((recHand = DmQueryRecord(dbRef, REC_VECTOR)))
    DmRemoveRecord(dbRef, REC_VECTOR);

  GrabMem();
  pMemGlobal->magic = SESAME;

  /*------------------------------------------------------------------*/
  /* Init string store for atoms                                      */
  /*------------------------------------------------------------------*/
  MemSet(strStore,atomSize,'\x01');
  strStore[0] = '\0';
  firstFree = NIL;
  firstFreeReal = NIL;

  /*------------------------------------------------------------------*/
  /* Init machine registers                                           */
  /*------------------------------------------------------------------*/
  S = E = C = D = W = NIL;
  running = false;
  numStep = numGC = tickStart = 0;
  pMemGlobal->waitEvent = pMemGlobal->getEvent = false;
  pMemGlobal->newTopLevelVals  = NIL;

  /*------------------------------------------------------------------*/
  /* Build linked list of free heap cells                             */
  /*------------------------------------------------------------------*/
  for (p=0x8000; p<heapLimit; p+=sizeof(PTR))
  {
    car(p) = firstFree;
    firstFree = p;
  }

  /*------------------------------------------------------------------*/
  /* Build linked list of free real cells                             */
  /*------------------------------------------------------------------*/
  for (p=0; p<realSize; p+=sizeof(double))
  {
    *((PTR*)(reals+p)) = firstFreeReal;
    firstFreeReal = p;
  }

  /*------------------------------------------------------------------*/
  /* Other initialization                                             */
  /*------------------------------------------------------------------*/
  forAllModules(INIT_HEAP,false);

  pMemGlobal->loadState = LS_INIT;
  pMemGlobal->sourceFmt = IDC_RB_MEMO;
  ReleaseMem();

  DmStrCopy(MemHandleLock(outHandle), 0,"\n\n\n\n\t\tWelcome to LispMe");
  MemHandleUnlock(outHandle);
  DmStrCopy(MemHandleLock(inHandle), 0, "");
  MemHandleUnlock(inHandle);
}

/**********************************************************************/
/* MARK macros for garbage collection                                 */
/**********************************************************************/
#define MARK(n)   markBit[n>>4] |= (1<<((n>>1)&0x07))
#define MARKED(n) (markBit[n>>4] & (1<<((n>>1)&0x07)))
#define MARK_REAL(n)   markRealBit[((UInt16)n)>>7] |=\
                       (1<<((((UInt16)n)>>4)&0x07))
#define MARKED_REAL(n) (markRealBit[((UInt16)n)>>6] &\
                       (1<<((((UInt16)n)>>3)&0x07)))

/**********************************************************************/
/* mark phase of garbage collection                                   */
/**********************************************************************/
static void markVector(PTR p);
void mark(PTR p)
{
  static memHookType mh;

  CHECKSTACK(p)
loop:
  if (IS_CONS(p))
  {
    if (!MARKED(p))
    {
      MARK(p);
      switch (car(p) & 0xff) // special type tags
      {
        case BIGPTAG: 
        case BIGNTAG: 
        case STRTAG:
          // These types don't contain markable sub-components
          return;

        case VECTAG:
          markVector(p);
          break;

        case FORTAG:
          // Don't collect its 32bit value
          MARK(cdr(p));
          // Let the foreign type mark its sub-components
          if ((mh = memHooks[FOREIGNTYPE(p)]))
            mh(MEM_MARK, p);
          break;

        default:
          // recursive call may exceed stack, perhaps use pointer
          // reversal mark algorithm here
          mark(car(p));
          p = cdr(p);
          goto loop;
      }
    }
  }
  else if (IS_REAL(p))
    MARK_REAL(p);
}

/**********************************************************************/
/* mark a vector                                                      */
/**********************************************************************/
static void markVector(PTR p)
{
  MemHandle recHand;
  PTR*      pel;
  Int16     num;

  recHand = DmQueryRecord(dbRef, ARR_INDEX(p));
  pel = (PTR*)(ArrayHandleLock(recHand));
  num = ArrayHandleSize(recHand)/2;
  ErrTry {
    while (num--)
      mark(*pel++);
  } ErrCatch(err) {
    ArrayHandleUnlock(recHand);
    ErrThrow(err);
  } ErrEndCatch
  ArrayHandleUnlock(recHand);
}

/**********************************************************************/
/* collect unused cells and free resources                            */
/**********************************************************************/
static void collect(void)
{
  static memHookType mh;
  PTR       p;
  UInt16    i1 = REC_VECTOR;
  UInt16    i2 = DmNumRecords(dbRef)-1;
  MemHandle h1, h2;
  MemPtr    mp;

  /*==================================================================*/
  /* Remove all arrays no more accessible and relocate index of others*/
  /*==================================================================*/
  while (true) {
    /*----------------------------------------------------------------*/
    /* Find unmarked array with lowest index (i1)                     */
    /*----------------------------------------------------------------*/
    while (i1 <= i2) { 
      mp = MemHandleLock(DmQueryRecord(dbRef,i1));
      p  = ArrayBackPtr(mp);
      MemPtrUnlock(mp);
      if (!MARKED(p)) 
        break;
      ++i1;
    } 

    /*----------------------------------------------------------------*/
    /* Find marked array with highest index (i2), removing all        */
    /* unmarked records encountered                                   */
    /*----------------------------------------------------------------*/
    while (i1 <= i2) { 
      mp = MemHandleLock(DmQueryRecord(dbRef,i2));
      p  = ArrayBackPtr(mp);
      MemPtrUnlock(mp);
      if (MARKED(p)) 
        break;
      DmRemoveRecord(dbRef, i2);  
      --i2;  
    }        

    if (i1 >= i2)
      break;

    /*----------------------------------------------------------------*/
    /* Reuse (garbage) i1 index record for content of (useful) i2     */
    /* and update pointer in heap cell                                */
    /*----------------------------------------------------------------*/
    DmDetachRecord(dbRef, i2, &h2);
    DmAttachRecord(dbRef, &i1, h2, &h1);
    MemHandleFree(h1);

    ARR_INDEX(p) = i1;
    --i2;
  }

  /*==================================================================*/
  /* Collect all unreachable heap cells                               */
  /*==================================================================*/
  for (p=0x8000; p<heapLimit; p+=sizeof(PTR))
    if (!MARKED(p))
    {
      if (IS_FORFAST(p))
      {
        if ((mh = memHooks[FOREIGNTYPE(p)]))
          mh(MEM_DELETE, p);
        /*------------------------------------------------------------*/ 
        /* prevent 2nd cons cell from being collected as a PTR and    */
        /* collect it explicitely                                     */
        /*------------------------------------------------------------*/ 
        MARK(cdr(p));
        cadr(p) = firstFree;
        firstFree = cdr(p);  
      }
      car(p) = firstFree;
      firstFree = p;
    }

  /*==================================================================*/
  /* Collect all unreachable floating point slots                     */
  /*==================================================================*/
  for (p=0; p<realSize; p+=sizeof(double))
    if (!MARKED_REAL(p))
    {
      *((PTR*)(reals+p)) = firstFreeReal;
      firstFreeReal = p;
    }
}

/**********************************************************************/
/* collect garbage                                                    */
/**********************************************************************/
void gc(PTR a, PTR b)
{
  int i;

  /*------------------------------------------------------------------*/
  /* mark reachable cells and collect                                 */
  /*------------------------------------------------------------------*/
  MemSet(markBit-0x0800, (UInt32)(heapSize >> 5), 0);
  MemSet(markRealBit, max(1ul,(UInt32)(realSize >> 6)), 0);
  mark(pMemGlobal->newTopLevelVals);
  mark(pMemGlobal->tlNames); mark(pMemGlobal->tlVals);
  mark(a); mark(b);
  mark(S); mark(E); mark(C); mark(D); mark(W);

  for (i=0;i<protIdx;++i)
    mark(*(protPtr[i]));

  for (i=0;i<=actContext;++i) {
    mark(contexts[i].prevCont);
    mark(contexts[i].handler);
    mark(contexts[i].data);
  }

  firstFree = NIL;
  firstFreeReal = NIL;
  collect();
  ++numGC;
  YIELD();
}

/**********************************************************************/
/* Pickle a session (prepare it for being exported/beamed)            */
/**********************************************************************/
void pickle(void)
{
  PTR    p;
  static memHookType mh;

  /*------------------------------------------------------------------*/
  /* Call foreign data types' memory control hook                     */
  /*------------------------------------------------------------------*/
  MemSet(markBit-0x0800, (UInt32)(heapSize >> 5), 0);
  for (p=0x8000; p<heapLimit; p+=sizeof(PTR))
    if (!MARKED(p) && IS_FORFAST(p)) {
      MARK(cdr(p)); // avoid cdr being pickled normally
      if ((mh = memHooks[FOREIGNTYPE(p)]))
        mh(MEM_PICKLE, p);
    }
        
  pMemGlobal->pickled = true;
}

/**********************************************************************/
/* Unpickle a session (inverse of pickle())                           */
/**********************************************************************/
void unpickle(void)
{
  PTR    p;
  static memHookType mh;

  /*------------------------------------------------------------------*/
  /* 1. Mark each foreign type cdr cell                               */
  /*------------------------------------------------------------------*/
  MemSet(markBit-0x0800, (UInt32)(heapSize >> 5), 0);
  for (p=0x8000; p<heapLimit; p+=sizeof(PTR))
    if (!MARKED(p) && IS_FORFAST(p)) 
      MARK(cdr(p));

  /*------------------------------------------------------------------*/
  /* 2. Call foreign type memory hook in reverse order                */
  /*------------------------------------------------------------------*/
  p=heapLimit;
  do {
    p-=sizeof(PTR);
    if (!MARKED(p) && IS_FORFAST(p)) 
      if ((mh = memHooks[FOREIGNTYPE(p)]))
        mh(MEM_UNPICKLE, p);
  } while (p != 0x8000);

  pMemGlobal->pickled = false;
}

/**********************************************************************/
/* Destroy all foreign objects                                        */
/**********************************************************************/
void destroyHeap(void)
{
  PTR    p;
  static memHookType mh;

  /*------------------------------------------------------------------*/
  /* Call DELETE memory hook for all foreign objects                  */
  /*------------------------------------------------------------------*/
  GrabMem();
  MemSet(markBit-0x0800, (UInt32)(heapSize >> 5), 0);
  for (p=0x8000; p<heapLimit; p+=sizeof(PTR))
    if (!MARKED(p) && IS_FORFAST(p)) {
      MARK(cdr(p)); // avoid cdr being destroyed normally
      if ((mh = memHooks[FOREIGNTYPE(p)]))
        mh(MEM_DELETE, p);
      car(p) = NIL; // invalidate p to avoid unpickling later 
    } 
  ReleaseMem();
}

/**********************************************************************/
/* memory statistics                                                  */
/**********************************************************************/
void memStat(Int32* heapUse, Int32* realUse, Int32* atomUse,
             Int32* vecSize, Int32* strSize, Int32* bigSize)
{
  PTR    i;
  char*  p;
  Int16  numRec;

  W = NIL;
  GrabMem();
  if (pMemGlobal->pickled)
    unpickle();
  if (!running)
  {
    S = E = D = NIL;
    protIdx = 0;
  }
  gc(NIL,NIL);

  *heapUse = *realUse = 0;
  for (i=0x8000; i < heapLimit; i+=sizeof(PTR))
    if (MARKED(i))
      *heapUse += 2*sizeof(PTR);

  for (i=0; i < realSize; i+=sizeof(double))
    if (MARKED_REAL(i))
      *realUse += sizeof(double);

  for (p=strStore; *p != '\x01'; ++p)
    ;
  *atomUse = p-strStore;
  ReleaseMem();
  numRec = DmNumRecords(dbRef);
  *vecSize = *strSize = *bigSize = 0;

  for (i=REC_VECTOR; i<numRec; ++i)
  {
    Int32     size;
    MemHandle mh = DmQueryRecord(dbRef,i);
    // No ArrayHandleSize(), want actual size used!
    size = MemHandleSize(mh); 

    switch (ARR_TAG(ArrayBackPtr(MemHandleLock(mh)))) {
      case VECTAG:  *vecSize += size; break;
      case STRTAG:  *strSize += size; break;
      case BIGPTAG:
      case BIGNTAG: *bigSize += size; break;
      default: /* ignore */
    }
    MemHandleUnlock(mh);
  }
}

/**********************************************************************/
/* Format a number right-aligned                                      */
/**********************************************************************/
void formatRight(char* buf, Int32 n, Int16 pl)
{
  Int16 l;

  StrIToA(buf, n);
  l = StrLen(buf);
  MemMove(buf+pl-l, buf, l+1);
  MemSet(buf, pl-l, charNumSpace);
}

void formatMemStat(char* buf, Int32 use, Int32 total)
{
  char numBuf[8];
  formatRight(buf, use, 6);
  StrCat(buf,"/");
  formatRight(numBuf, total, 6);
  StrCat(buf, numBuf);
}

/**********************************************************************/
/* Create a vector (either filled with constant or init'ed by a list) */
/**********************************************************************/
PTR makeVector(UInt16 len, PTR fill, Boolean advance)
{
  MemHandle recHand;
  char*     recPtr;
  UInt16    index = dmMaxRecordIndex;
  UInt16    i;
  PTR       res;
  Boolean   tried = false;

  if (len == 0)
    return EMPTY_VEC;

  /*------------------------------------------------------------------*/
  /* Can't use straightforward cons, as car and cdr of vector cell    */
  /* are not regular pointers that can be protected!                  */
  /*------------------------------------------------------------------*/
  res = cons(NIL,NIL);
  while (true) {
    if ((recHand = DmNewRecord(dbRef, &index, ArraySize((Int32)len*2))))
      break;
    else if (tried)
      ErrThrow(ERR_M7_NO_RECORD_MEM);
    else {
      gc(res,NIL);
      tried = true; 
    }
  } 
  recPtr = ArrayHandleLock(recHand);
  for (i=0; i<len; ++i)
   if (advance)
   {
     ((PTR*)recPtr)[i] = car(fill);
     fill = cdr(fill);
   }
   else
     ((PTR*)recPtr)[i] = fill;

  ArraySetBackPtr(recPtr, res);
  ArrayHandleUnlock(recHand);
  DmReleaseRecord(dbRef, index, true);
  car(res) = MKARR_CAR(VECTAG);
  cdr(res) = MKARR_CDR(index);
  return res;
}

/**********************************************************************/
/* Append 2 strings                                                   */
/**********************************************************************/
PTR appendStrings(PTR a, PTR b)
{
  MemHandle recHand1, recHand2;
  PTR       res;

  if (!IS_STRING(a))
    typeError(a,"string");
  if (!IS_STRING(b))
    typeError(b,"string");

  if (a==EMPTY_STR && b==EMPTY_STR)
    return EMPTY_STR;

  if (a == EMPTY_STR) {
    a = b; b = EMPTY_STR;
  }
  recHand1 = DmQueryRecord(dbRef,ARR_INDEX(a));
  if (b != EMPTY_STR)
  {
    recHand2 = DmQueryRecord(dbRef,ARR_INDEX(b));
    res = makeString(ArrayHandleSize(recHand1),ArrayHandleLock(recHand1),
                     ArrayHandleSize(recHand2),ArrayHandleLock(recHand2), NIL);
    ArrayHandleUnlock(recHand2);
  }
  else
    res = copyString(ArrayHandleSize(recHand1),ArrayHandleLock(recHand1));
  ArrayHandleUnlock(recHand1);
  return res;
}

/**********************************************************************/
/* Extract substring                                                  */
/**********************************************************************/
PTR substring(PTR str, UInt16 start, UInt16 end)
{
  UInt16    len;
  MemHandle recHand;
  PTR       res;

  if (!IS_STRING(str))
    typeError(str,"string");

  if (str==EMPTY_STR)
  {
    if (start != 0)
      error1(ERR_R2_INVALID_INDEX, makeNum(start));
    else
      return EMPTY_STR;
  }
  recHand = DmQueryRecord(dbRef,ARR_INDEX(str));
  len = ArrayHandleSize(recHand);
  if (start > len)
    error1(ERR_R2_INVALID_INDEX, makeNum(start));
  if (end > len)
    end = len;
  res = copyString(max(0,end-start),ArrayHandleLock(recHand)+start);
  ArrayHandleUnlock(recHand);
  return res;
}

/**********************************************************************/
/* copy a list (one level) into destination, return last pair         */
/**********************************************************************/
PTR* listCopy(PTR* d, PTR l, Int16 nc)
{
  while (IS_PAIR(l) && --nc >= 0)
  {
    *d = cons(car(l), NIL);
    d = &cdr(*d);
    l = cdr(l);
  }
  return d;
}

/**********************************************************************/
/* create a list from a vector                                        */
/**********************************************************************/
PTR vector2List(PTR v)
{
  Int16     i,num;
  MemHandle recHand;
  PTR*      pel;
  PTR       res = NIL;
  PTR*      d = &res;

  if (v==EMPTY_VEC)
    return NIL;

  PROTECT(res);
  recHand = DmQueryRecord(dbRef, ARR_INDEX(v));
  num = ArrayHandleSize(recHand)/2;
  pel = (PTR*)(ArrayHandleLock(recHand));
  for (i=0;i<num;++i)
  {
    *d = cons(pel[i],NIL);
    d = &cdr(*d);
  }
  ArrayHandleUnlock(recHand);
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* create a list from a string                                        */
/**********************************************************************/
PTR string2List(PTR str)
{
  Int16     i,num;
  MemHandle recHand;
  char*     pc;
  PTR       res = NIL;
  PTR*      d = &res;

  if (str==EMPTY_STR)
    return NIL;

  PROTECT(res);
  recHand = DmQueryRecord(dbRef, ARR_INDEX(str));
  num = ArrayHandleSize(recHand);
  pc = ArrayHandleLock(recHand);
  for (i=0;i<num;++i)
  {
    *d = cons(MKCHAR(*pc++),NIL);
    d = &cdr(*d);
  }
  ArrayHandleUnlock(recHand);
  UNPROTECT(res);
  return res;
}

/**********************************************************************/
/* Create a string                                                    */
/**********************************************************************/
PTR makeString(UInt16 len,  const char* buf,
               UInt16 len2, const char* buf2, PTR l)
{
  MemHandle recHand;
  char*     recPtr;
  UInt16    index = dmMaxRecordIndex;
  PTR       p = l;
  PTR       res;
  Boolean   tried = false;

  if (len+len2 == 0 || (buf == 0 && p == NIL))
    return EMPTY_STR;

  /*------------------------------------------------------------------*/
  /* Can't use straightforward cons, as car and cdr of string cell    */
  /* are not regular pointers that can be protected!                  */
  /*------------------------------------------------------------------*/
  res = cons(NIL,NIL);
  while (true) {
    if ((recHand = DmNewRecord(dbRef, &index, ArraySize((Int32)len+len2))))
      break;
    else if (tried)
      ErrThrow(ERR_M7_NO_RECORD_MEM);
    else {
      gc(res,NIL);
      tried = true; 
    }
  } 
  recPtr = ArrayHandleLock(recHand);
  if (buf==0)
  {
    if (buf2==0)
    { 
      /*--------------------------------------------------------------*/
      /* Fill by copying characters from list                         */
      /*--------------------------------------------------------------*/
      char* cp = recPtr;
      while (IS_PAIR(p))
      {
        if (!IS_CHAR(car(p)))
        {
          ArrayHandleUnlock(recHand);
          DmRemoveRecord(dbRef,index);
          typeError(car(p),"char");
        }
        *cp++ = CHARVAL(car(p));
        p = cdr(p);
      }
      if (p!=NIL)
      {
        ArrayHandleUnlock(recHand);
        DmRemoveRecord(dbRef,index);
        typeError(l,"list");
      }
    }
    else
    {
      /*--------------------------------------------------------------*/
      /* Fill with copies of single character                         */
      /*--------------------------------------------------------------*/
      MemSet(recPtr, len, CHARVAL(l));
    }   
  }
  else
  {
    MemMove(recPtr,buf,len);
    if (buf2)
      MemMove(recPtr+len,buf2,len2);
  }
  ArraySetBackPtr(recPtr, res);
  ArrayHandleUnlock(recHand);
  DmReleaseRecord(dbRef, index, true);
  car(res) = MKARR_CAR(STRTAG);
  cdr(res) = MKARR_CDR(index);
  return res;
}

/**********************************************************************/
/* compare strings                                                    */
/**********************************************************************/
int strComp(PTR a, PTR b)
{
  MemHandle recHand1, recHand2;
  UInt16    len1,len2,i;
  int       d;
  char      *p1, *p2;

  if (a==EMPTY_STR && b==EMPTY_STR)  return 0;
  if (a==EMPTY_STR)                  return -1;
  if (b==EMPTY_STR)                  return 1;

  recHand1 = DmQueryRecord(dbRef,ARR_INDEX(a));
  p1 = ArrayHandleLock(recHand1);
  len1 = ArrayHandleSize(recHand1);
  recHand2 = DmQueryRecord(dbRef,ARR_INDEX(b));
  p2 = ArrayHandleLock(recHand2);
  len2 = ArrayHandleSize(recHand2);
  for (i=0;i<min(len1,len2);++i)
  {
    d = *p1++ - *p2++;
    if (d)
    {
      ArrayHandleUnlock(recHand1);
      ArrayHandleUnlock(recHand2);
      return d;
    }
  }
  ArrayHandleUnlock(recHand1);
  ArrayHandleUnlock(recHand2);
  return i==len1 ? (i==len2 ? 0 : -1) : 1;
}

/**********************************************************************/
/* Free all memory from the dynamic heap                              */
/**********************************************************************/
void FreeDynMem(void)
{
  int i;

  for (i=0; i<HIST_SIZE; ++i) 
    MemPtrFree(historyStr[i]);
  MemPtrFree(historyStr);
  if (symbols)
    MemPtrFree(symbols);

  MemPtrFree(markBit-0x0800);
  MemPtrFree(markRealBit);
}

/**********************************************************************/
/* allocate a  heap cell protecting both arguments from being GCed    */
/* !!! in the case of consing two newly allocated cells (real or cons)*/
/* !!! both must be assigned to W to avoid GCing the inner cell when  */
/* !!! the other inner cell is allocated, _before_ it's protected by  */
/* !!! the outer cons, e.g.                                           */
/* !!! don't write S = cons(cons(a,b),cons(c,d));                     */
/* !!! but write S = cons(W=cons(a,b),W=cons(c,d));                   */
/**********************************************************************/
PTR cons(PTR a, PTR b)
{
  PTR res;

  if (firstFree == NIL)
  {
    gc(a,b);
    if (firstFree == NIL)
      ErrThrow(ERR_M4_NO_HEAP);
  }
  res = firstFree;
  firstFree = car(firstFree);
  car(res) = a; cdr(res) = b;
  return res;
}

/**********************************************************************/
/* allocate a cell representing a pointer to foreign data             */
/* !!! two conses are used,                                           */
/* !!! the first containing type data in the car,                     */
/* !!! the cdr pointing to the second cons,                           */
/* !!! which contains the whole addr in the car and cdr               */
/* !!! to ensure proper GCing, the first cons must also be the lowest */
/**********************************************************************/
PTR allocForeign(void* p, UInt8 ftype)
{
  static PTR res, addr, tmp; 

  if (ftype >= MAX_FOREIGN_TYPES)
    error1(ERR_M10_INV_FOR_TYPE,MKINT(ftype));

  res  = W = cons(NIL,NIL);
  addr = cons(NIL,NIL);
  if (res > addr) {
    tmp = res;
    res = addr;
    addr = tmp;
  }
  car(res) = MKFOREIGN(ftype);
  cdr(res) = addr;
  SETFOREIGNVAL(res,p);
  return res;
}

/**********************************************************************/
/* register memory hook function for a foreign data type              */
/**********************************************************************/
void registerMemHook(UInt8 ftype, memHookType fp)
{
  if (ftype >= MAX_FOREIGN_TYPES)
    error1(ERR_M10_INV_FOR_TYPE,MKINT(ftype));
  memHooks[ftype] = fp;
}

/**********************************************************************/
/* allocate a real in memory                                          */
/**********************************************************************/
PTR allocReal(double d)
{
  PTR res;
  if (firstFreeReal == NIL)
  {
    gc(NIL,NIL);
    if (firstFreeReal == NIL)
      ErrThrow(ERR_M9_NO_REALS);
  }
  res = firstFreeReal;
  firstFreeReal = *((PTR*)(reals+firstFreeReal));
  *((double*)(reals+res)) = d;
  return MKREAL(res);
}

/**********************************************************************/
/* get a real from memory                                             */
/**********************************************************************/
double getReal(PTR p)
{
  if (IS_REAL(p))
    return *((double*)(reals+REALVAL(p)));
  else
    error1(ERR_M2_INVALID_PTR,p);
}

/**********************************************************************/
/* Access a vector                                                    */
/**********************************************************************/
void vectorAcc(PTR* obj, PTR vec, UInt16 n, Boolean write)
{
  MemHandle recHand;
  PTR*      pel;

  TCHECK(tyVECTOR,vec);
  if (vec==EMPTY_VEC)
    error1(ERR_R2_INVALID_INDEX, makeNum(n));
  recHand = DmQueryRecord(dbRef,ARR_INDEX(vec));
  if (n >= ArrayHandleSize(recHand)/2)
    error1(ERR_R2_INVALID_INDEX, makeNum(n));
  pel = (PTR*)(ArrayHandleLock(recHand));
  if (write)
    pel[n] = *obj;
  else
    *obj = pel[n];
  ArrayHandleUnlock(recHand);
}

/**********************************************************************/
/* Access a string                                                    */
/**********************************************************************/
void stringAcc(PTR* c, PTR str, UInt16 n, Boolean write)
{
  MemHandle recHand;
  char*     pc;

  TCHECK(tySTRING,str);
  if (write && !IS_CHAR(*c))
    typeError(*c, "char");
  if (str==EMPTY_STR)
    error1(ERR_R2_INVALID_INDEX, makeNum(n));
  recHand = DmQueryRecord(dbRef,ARR_INDEX(str));
  if (n >= ArrayHandleSize(recHand))
    error1(ERR_R2_INVALID_INDEX, makeNum(n));
  pc = ArrayHandleLock(recHand);
  if (write)
    pc[n] = CHARVAL(*c);
  else
    *c = MKCHAR(pc[n]);
  ArrayHandleUnlock(recHand);
}

/**********************************************************************/
/* length of a vector                                                 */
/**********************************************************************/
UInt16 vectorLength(PTR v)
{ 
  MemHandle recHand;

  if (v==EMPTY_VEC)
    return 0;
  recHand = DmQueryRecord(dbRef,ARR_INDEX(v));
  return ArrayHandleSize(recHand)/2;
}

/**********************************************************************/
/* length of a string                                                 */
/**********************************************************************/
UInt16 stringLength(PTR s)
{
  MemHandle recHand;

  if (!IS_STRING(s))
    typeError(s,"string");
  if (s==EMPTY_STR)
    return 0;
  recHand = DmQueryRecord(dbRef,ARR_INDEX(s));
  return ArrayHandleSize(recHand);
}

/**********************************************************************/
/* Is PTR a real pair?                                                */
/**********************************************************************/
Boolean IS_PAIR(PTR ptr)
{
  return IS_CONS(ptr) &&
         (((car(ptr)) & 0x8f) != VECTAG) &&
         !IS_STAG(car(ptr));
}

