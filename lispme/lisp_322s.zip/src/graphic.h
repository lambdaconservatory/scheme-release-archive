/**********************************************************************/
/*                                                                    */
/* graphic.h: LISPME graphic functions                                */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 08.04.2000 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_GRAPHIC_H
#define INC_GRAPHIC_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern Boolean       newGraphic;
extern BuiltInModule graphicBuiltins; 

#endif
