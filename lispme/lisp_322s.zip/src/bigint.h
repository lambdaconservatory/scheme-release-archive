/**********************************************************************/
/*                                                                    */
/* bigint.h: LISPME unlimited precision integers                      */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 15.12.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_BIGINT_H
#define INC_BIGINT_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Types                                                              */
/**********************************************************************/
typedef UInt16 Limb;
typedef UInt32 DLimb;

/**********************************************************************/
/* Defines                                                            */
/**********************************************************************/
#define LIMB_BITS    16
#define LIMB_SIZE    sizeof(Limb)

/**********************************************************************/
/* Exported functions                                                 */
/**********************************************************************/
void    writeBig(PTR p)                                        SEC(MOD);
Limb    mulAddSingle(Limb* a, UInt16* la, Limb b, Limb c)      SEC(MOD);
double  bigToReal(Limb* a, UInt16 la, Boolean negative)        SEC(MOD); 
double  bigToDouble(PTR big)                                   SEC(MOD);
PTR     realToBig(PTR real)                                    SEC(MOD);
PTR     int16ToBig(Int16 val)                                  SEC(MOD);
PTR     int32ToBig(Int32 val)                                  SEC(MOD);
PTR     uint32ToBig(UInt32 val)                                SEC(MOD);
PTR     copyBigint(Limb* a, UInt16 la, Boolean negative)       SEC(MOD);
PTR     addBigint(PTR a, PTR b)                                SEC(MOD);
PTR     subBigint(PTR a, PTR b)                                SEC(MOD);
PTR     mulBigint(PTR a, PTR b)                                SEC(MOD);
PTR     divRemBigint(PTR pa, PTR pb, DivOp op)                 SEC(MOD);
int     compBigint(PTR pa, PTR pb)                             SEC(MOD);
Int32   getInt32(PTR val)                                      SEC(MOD);
UInt32  getUInt32(PTR val)                                     SEC(MOD);
Int16   getInt16(PTR val)                                      SEC(MOD);
UInt16  getUInt16(PTR val)                                     SEC(MOD);
Boolean bigintOdd(PTR val)                                     SEC(MOD);
Boolean isIndex(PTR val)                                       SEC(MOD);
PTR     logBigint(PTR pa, PTR pb, BitOp op)                    SEC(MOD);
PTR     logNot(PTR pa)                                         SEC(MOD);
PTR     shiftBigint(PTR pa, Int32 n)                           SEC(MOD);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule bigintBuiltins; 

#endif
