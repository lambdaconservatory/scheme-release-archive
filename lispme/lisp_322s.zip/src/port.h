/**********************************************************************/
/*                                                                    */
/* port.h: LISPME port management                                     */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 03.06.2001 Created from file.h                                FBI  */
/* 03.11.2001 Final update for 3.0                               FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_PORT_H
#define INC_PORT_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Port structures                                                    */
/**********************************************************************/
typedef struct {
  UInt8     type; 
  UInt8     status;
  UInt32    uid;    // == 0 to use stringBuffer instead
  UInt16    pos;    // current read position from beginning of buffer
  UInt16    next;   // next record (DOC)
  UInt16    nRec;   // number of records (DOC)
  UInt16    bufLen; // length of buffer          
  DmOpenRef dbRef;  // MEMO, MEMO32, or DOC database
  PTR       impl;   // implementation specific
  PTR       buf;    // a LispMe string used as buffer
} InPort;

typedef struct {
  UInt8     type; 
  UInt8     flags;
  UInt32    uid;    // uid of memo-like database
  UInt16    pos;    // current write position from beginning of buffer
  UInt16    bufLen; // length of buffer          
  DmOpenRef dbRef;  // MEMO or MEMO32 database reference
  PTR       impl;   // depending on port type
  PTR       buf;    // a LispMe string used as buffer
  char*     mem;    // cache the actual buffer
} OutPort;

/**********************************************************************/
/* Commands for reader function                                       */
/**********************************************************************/
typedef enum {
  RC_READ,
  RC_CLOSE,
} ReaderCmd;

/**********************************************************************/
/* Commands for writer function                                       */
/**********************************************************************/
typedef enum {
  WC_WRITE,
  WC_CLOSE,
} WriterCmd;

/**********************************************************************/
/* Defines                                                            */
/**********************************************************************/
#define CHAR_EOF      (-1)
#define CHAR_PEEKNONE (-2)

#define INP_STATUS_OK        0
#define INP_STATUS_CLOSED    1

/* Output port flags */
#define OPF_NORMAL           0x00
#define OPF_CLOSED           0x01
#define OPF_BUFFERED         0x02  
#define OPF_SUPPRESS_NOPRINT 0x04
#define OPF_AUTOFLUSH        0x08 
#define OPF_NUL_TERMINATE    0x10

/**********************************************************************/
/* Pointer to reader/writer function                                  */
/**********************************************************************/
typedef Boolean (*readFctType) (ReaderCmd, InPort*);
typedef void    (*writeFctType)(WriterCmd, OutPort*);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule portBuiltins; 

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
PTR  makeBufInPort(UInt8 ptype, PTR impl, PTR buf)              SEC(IO);
PTR  makeMemoInPort(UInt8 ptype, DmOpenRef ref,
                    UInt32 uid, UInt16 pos)                     SEC(IO);
PTR  makeMemoOutPort(UInt32 uid, UInt8 ptype, DmOpenRef dbRef)  SEC(IO);
PTR  makeBufOutPort(UInt8 ptype, PTR impl,
                    UInt16 bufLen, UInt8 flags)                 SEC(IO);
void registerReadFct(UInt8 ptype, readFctType fp)               SEC(IO);
void registerWriteFct(UInt8 ptype, writeFctType fp)             SEC(IO);
void updateOutpSize()                                           SEC(IO);
void outStr(char* p)                                            SEC(IO);
void flushPort(OutPort* outp)                                   SEC(IO);

#endif
