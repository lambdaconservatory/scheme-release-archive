/**********************************************************************/
/*                                                                    */
/* lists.h: LISPME list handling functions                            */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 05.05.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_LISTS_H
#define INC_LISTS_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
Boolean improperListP(PTR l, Boolean nilEnding)                 SEC(VM);
PTR     cxr(PTR l, UInt16 bits)                                 SEC(VM);
PTR     find(PTR l, PTR p, Int16 step,
             Int16 from, Int16 to, PTR def,
             Boolean (*comp)(PTR,PTR))                          SEC(VM);
Boolean equal(PTR a, PTR b)                                     SEC(VM);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule listBuiltins; 
extern BuiltInModule vecStrBuiltins; 

#endif
