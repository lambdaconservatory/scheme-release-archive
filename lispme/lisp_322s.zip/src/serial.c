/**********************************************************************/
/*                                                                    */
/* serial.c: LISPME serial port support                               */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 31.01.2002 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "serial.h"
#include "io.h"
#include "vm.h"
#include "arith.h"
#include "util.h"
#include "LispMe.h"
#include "port.h"
#include <SerialMgr.h>
#include <SerialMgrOld.h>

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define CLOSED_SERIAL   0
#define ONLY_PORT_OLD   1
#define SERIAL_BUF_SIZE 512
#define DEFAULT_TIMEOUT 500

#define SER0(func,p) (newSerial ? Srm##func(p) : Ser##func(serRefNum))
#define SER1(func,p,a) (newSerial ? Srm##func(p,a) : Ser##func(serRefNum,a))
#define SER2(func,p,a,b) (newSerial ? Srm##func(p,a,b) : Ser##func(serRefNum,a,b))
#define SER3(func,p,a,b,c) (newSerial ? Srm##func(p,a,b,c) : Ser##func(serRefNum,a,b,c))
#define SER4(func,p,a,b,c,d) (newSerial ? Srm##func(p,a,b,c,d) : Ser##func(serRefNum,a,b,c,d))

/**********************************************************************/
/* Local types                                                        */
/**********************************************************************/
typedef struct {
  UInt32 openId;  // for re-opening
  Int32  baud;    // for re-opening
  UInt32 flags;   // for re-opening
  UInt16 portId; 
  Int32  timeout;
  Int32  CTS;
  PTR    inPort;
  PTR    outPort;
} LMSerial;

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
static Boolean newSerial;
static UInt16  serRefNum;

/**********************************************************************/
/* Local data                                                         */
/**********************************************************************/

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void    init(ModuleMessage mess)                         SEC(IO); 
static void    serialMemHook(MemMessage mess, PTR ptr)          SEC(IO);
static void    serialPrinter(Boolean machineFormat, void* p)    SEC(IO);
static void    writeSerial(WriterCmd cmd, OutPort* outp)        SEC(IO);
static Boolean readSerial(ReaderCmd cmd, InPort* inp)           SEC(IO);

static PTR  nativeOpenSerial(PTR* args)                         SEC(IO);
static PTR  nativeCloseSerial(PTR* args)                        SEC(IO);
static PTR  nativeSerialStatus(PTR* args)                       SEC(IO);
static PTR  nativeSerialInfo(PTR* args)                         SEC(IO);
static PTR  nativeSetTimeout(PTR* args)                         SEC(IO);
static PTR  nativeGetTimeout(PTR* args)                         SEC(IO);
static PTR  nativeSendFlush(PTR* args)                          SEC(IO);
static PTR  nativeRecvFlush(PTR* args)                          SEC(IO);

static PTR  nativeSerialInput(PTR* args)                        SEC(IO);
static PTR  nativeSerialOutput(PTR* args)                       SEC(IO);
static PTR  nativeNewSerial(PTR* args)                          SEC(IO);
static PTR  nativeGetCTS(PTR* args)                             SEC(IO);
static PTR  nativeSetCTS(PTR* args)                             SEC(IO);
static PTR  nativeSetBreak(PTR* args)                           SEC(IO);
static PTR  nativeSetIrDA(PTR* args)                            SEC(IO);
static PTR  nativeSetRx(PTR* args)                              SEC(IO);

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  UInt32 val;

  switch (mess)
  {
    case APP_START: 
      /*--------------------------------------------------------------*/
      /* Check for availability of routines                           */
      /* Use NewSerialManager routines if available, otherwise use    */
      /* SerialManager.                                               */
      /*--------------------------------------------------------------*/
      newSerial = FtrGet(sysFileCSerialMgr, sysFtrNewSerialPresent, &val)
                  ==0 && val != 0;
      if (!newSerial) {
        Err err = SysLibFind("Serial Library", &serRefNum);
        ErrFatalDisplayIf(err, "Can't find serial library");
      }

      /*--------------------------------------------------------------*/
      /* Register hooks for serial datatype                           */
      /*--------------------------------------------------------------*/
      registerMemHook(FT_SERIAL,  serialMemHook);
      registerTypename(FT_SERIAL, "serial");
      registerPrinter(FT_SERIAL, serialPrinter);

      /*--------------------------------------------------------------*/
      /* Register hooks for port layer                                */
      /*--------------------------------------------------------------*/
      registerReadFct(PT_SERIAL, readSerial);
      registerWriteFct(PT_SERIAL, writeSerial);
      break;

    case APP_STOP:
      break;

    case INIT_HEAP: 

    case SESS_CONNECT: 
      break;

    default:
  }
}

/**********************************************************************/
/* The memory hook function for serial ports                          */
/**********************************************************************/
static void serialMemHook(MemMessage mess, PTR ptr) 
{
  LMSerial* pser;
  UInt16    len  = sizeof(UInt32);

  switch (mess) {
    case MEM_MARK:
      pser = FOREIGNVAL(ptr);
      mark(pser->inPort);
      mark(pser->outPort);
      break;
  
    case MEM_DELETE:
      /*--------------------------------------------------------------*/
      /* Close the serial port                                        */
      /*--------------------------------------------------------------*/
      pser = FOREIGNVAL(ptr);
      if (pser->portId != CLOSED_SERIAL) {
        ReleaseMem();
        SER0(Close,pser->portId);
        GrabMem();
      }
      MemPtrFree(FOREIGNVAL(ptr));
      break;

    case MEM_UNPICKLE:
      /*--------------------------------------------------------------*/
      /* Reopen port using connection parms stored                    */
      /*--------------------------------------------------------------*/
      standardUnpickle(ptr);
      pser = FOREIGNVAL(ptr);
      if (pser->openId != CLOSED_SERIAL) {
        ReleaseMem();
        if (newSerial) {
          if (SrmOpen(pser->openId, pser->baud, &pser->portId) == 0)
            SrmControl(pser->portId, srmCtlSetFlags, &pser->flags, &len);
        }
        else {
          if (SerOpen(serRefNum, 0, pser->baud) == 0) {
            SerSettingsType settings;
            SerGetSettings(serRefNum, &settings);
            settings.flags = pser->flags;
            SerSetSettings(serRefNum, &settings);
            pser->portId = ONLY_PORT_OLD;
          }
        } 
        GrabMem();
      }
      break;

    case MEM_PICKLE:
      /*--------------------------------------------------------------*/
      /* Close port (all parameters known for reopen)                 */
      /*--------------------------------------------------------------*/
      pser = FOREIGNVAL(ptr);
      if (pser->openId != CLOSED_SERIAL) {
        ReleaseMem();
        SER0(Close,pser->portId);  
        GrabMem();
      }
      pser->portId = CLOSED_SERIAL;     
      standardPickle(ptr);
      break;

    default:
  }
}

/**********************************************************************/
/* Print a serial port                                                */
/**********************************************************************/
static void serialPrinter(Boolean machineFormat, void* p)
{
  LMSerial* pser = p;

  if (pser->portId == CLOSED_SERIAL) 
    outStr("[\254serial]");
  else {
    outStr("[serial ");
    StrIToA(token, pser->portId);
    outStr(token);
    outStr(" ");      

    /*----------------------------------------------------------------*/
    /* Print baud rate                                                */
    /*----------------------------------------------------------------*/
    StrIToA(token, pser->baud);
    outStr(token);
    outStr(" ");      

    /*----------------------------------------------------------------*/
    /* Print serial flags                                             */
    /*----------------------------------------------------------------*/
    token[0] = '5' + ((pser->flags & srmSettingsFlagBitsPerCharM) >> 6);
    token[1] = pser->flags & srmSettingsFlagParityOnM
                 ? (pser->flags & srmSettingsFlagParityEvenM ? 'E' : 'O')
                 : 'N';
    token[2] = '1' + (pser->flags & srmSettingsFlagStopBitsM);
    if (pser->flags & srmSettingsFlagRTSAutoM)
      token[3] = pser->flags & srmSettingsFlagCTSAutoM ? 'H' : 'R';
    else
      token[3] = pser->flags & srmSettingsFlagCTSAutoM ? 'C' : 'N';
    token[4] = '\0';
    outStr(token);
    outStr("]");
  }
}

/**********************************************************************/
/* Are we using the old or the new routines?                          */
/**********************************************************************/
static PTR nativeNewSerial(PTR* args)
{
  return newSerial ? TRUE : FALSE;
}

/**********************************************************************/
/* Open a serial port                                                 */
/**********************************************************************/
static PTR nativeOpenSerial(PTR* args)
{
  UInt16 portId;
  UInt32 flags = 0;
  UInt16 len   = sizeof(flags);
  Err    err;

  if (StrLen(printString(args[2])) != 4)
    parmError(args[2],"open-serial");

  if ('5' <= msg[0] && msg[0] <= '8')
    flags |= (msg[0] - '5') << 6;
  else
    parmError(args[2],"open-serial");

  // At least the flag bit patterns are identical for old and new serial :-/
  switch (msg[1]) {
    case 'e': case 'E':
      flags |= srmSettingsFlagParityEvenM;
    case 'o': case 'O': 
      flags |= srmSettingsFlagParityOnM;
    case 'n': case 'N': 
      break;
    default:
      parmError(args[2],"open-serial");
  }
  switch (msg[2]) {
    case '2':
      flags |= srmSettingsFlagStopBits2;
    case '1':
      break;
    default:
      parmError(args[2],"open-serial");
  }
  switch (msg[3]) {
    case 'h': case 'H':
      flags |= srmSettingsFlagCTSAutoM;
    case 'r': case 'R':
      flags |= srmSettingsFlagRTSAutoM;
      break;
    case 'c': case 'C':
      flags |= srmSettingsFlagCTSAutoM;
    case 'n': case 'N':
      break;
    default:
      parmError(args[2],"open-serial");
  }

  ReleaseMem();
  if (newSerial)
    err = SrmOpen(getUInt32(args[0]), getUInt32(args[1]), &portId);
  else {
    err = SerOpen(serRefNum, 0, getUInt32(args[1]));
    portId = ONLY_PORT_OLD;
  }
  GrabMem();
  if (err==0) {
    LMSerial* pser = MemPtrNew(sizeof(LMSerial));
    PTR       res  = allocForeign(pser, FT_SERIAL);

    ReleaseMem();
    if (newSerial)
      SrmControl(portId, srmCtlSetFlags, &flags, &len);
    else {
      SerSettingsType settings;
      SerGetSettings(serRefNum, &settings);
      settings.flags = flags;
      SerSetSettings(serRefNum, &settings);
    }
    GrabMem();

    PROTECT(res);
    pser->openId  = getUInt32(args[0]);
    pser->baud    = getInt32(args[1]);
    pser->flags   = flags;
    pser->CTS     = DEFAULT_TIMEOUT;
    pser->timeout = DEFAULT_TIMEOUT;
    pser->portId  = portId;
    pser->inPort  = pser->outPort = NIL;
    pser->inPort  = makeBufInPort(PT_SERIAL,res,EMPTY_STR);
    pser->outPort = makeBufOutPort(PT_SERIAL,res,
                                   SERIAL_BUF_SIZE, OPF_AUTOFLUSH);
    UNPROTECT(res);
    return res;
  }
  return FALSE;
}

/**********************************************************************/
/* Close a serial port                                                */
/**********************************************************************/
static PTR nativeCloseSerial(PTR* args)
{
  LMSerial* pser = FOREIGNVAL(args[0]); 
  OutPort* outp  = FOREIGNVAL(pser->outPort);
  InPort* inp    = FOREIGNVAL(pser->inPort);

  ReleaseMem();
  SER0(Close, pser->portId);
  GrabMem();
  pser->openId = CLOSED_SERIAL;
  pser->portId = CLOSED_SERIAL;
  inp->status  = INP_STATUS_CLOSED;
  inp->buf     = NIL;
  outp->flags  |= OPF_CLOSED;
  outp->buf    = NIL;
  return args[0];
}

/**********************************************************************/
/* Write to a serial port                                             */
/**********************************************************************/
static void writeSerial(WriterCmd cmd, OutPort* outp)
{
  UInt16 portId = ((LMSerial*)FOREIGNVAL(outp->impl))->portId;
  UInt32 sent = 0, blk;
  Err    err;
 
  switch (cmd) {
    case WC_WRITE:
      if (portId != CLOSED_SERIAL) {
        while (sent < outp->pos) {
          ReleaseMem();
          blk = SER3(Send, portId, outp->mem+sent, outp->pos-sent, &err);
          GrabMem();
          if (err!=0) 
            ErrThrow(ERR_R19_WRITE_FILE);
          sent += blk; 
        }
        outp->pos = 0;
      }
      break;
 
    case WC_CLOSE:
      outp->flags |= OPF_CLOSED;
      break;
  }
}

/**********************************************************************/
/* Read from a serial port                                            */
/**********************************************************************/
static Boolean readSerial(ReaderCmd cmd, InPort* inp)
{
  LMSerial* pser   = FOREIGNVAL(inp->impl);
  UInt16    portId = pser->portId;
  Err    err;
  UInt32 blk;

  switch (cmd) {
    case RC_READ:
      if (portId != CLOSED_SERIAL) {
        ReleaseMem();
        SER1(ReceiveCheck, portId, &blk);
        GrabMem();
        if (blk==0) {
          /*----------------------------------------------------------*/ 
          /* Receive buffer empty, try to recv 1 char within timeout  */ 
          /*----------------------------------------------------------*/ 
          ReleaseMem();
          blk = SER4(Receive, portId, token, 1, pser->timeout, &err);
          GrabMem();
          if (err==serErrTimeOut && blk==0)
            return false; 
        }
        else {
          /*----------------------------------------------------------*/ 
          /* Receive entire buffer                                    */ 
          /*----------------------------------------------------------*/ 
          ReleaseMem();
          blk = SER4(Receive, portId, token, min(blk, SERIAL_BUF_SIZE),
                     0, &err);
          GrabMem();
        }  

        inp->buf    = copyString(blk, token);
        inp->bufLen = blk;
        inp->pos    = 0;
        return true;
      }
      return false;
   
    case RC_CLOSE:
      inp->status = INP_STATUS_CLOSED;
      inp->buf    = NIL;
      return true;
  }
}

/**********************************************************************/
/* Get status of serial port (New serial only!)                       */
/**********************************************************************/
static PTR nativeSerialStatus(PTR* args)
{
  UInt16 portId = ((LMSerial*)FOREIGNVAL(args[0]))->portId;
  UInt32 status;
  UInt16 errors;

  ReleaseMem();
  if (newSerial && portId != CLOSED_SERIAL &&
      SrmGetStatus(portId, &status, &errors) == 0)
  {
    GrabMem();
    return cons(W=makeUNum(status), W=makeUNum(errors));
  }
  else {
    GrabMem();
    return FALSE;
  }
}

/**********************************************************************/
/* Get device info for a serial port (New serial only!)               */
/**********************************************************************/
static PTR nativeSerialInfo(PTR* args)
{
  UInt16 portId = ((LMSerial*)FOREIGNVAL(args[0]))->portId;
  DeviceInfoType info;
  PTR res = NIL;

  ReleaseMem();
  if (newSerial && portId != CLOSED_SERIAL &&
      SrmGetDeviceInfo(portId, &info) == 0) {
    GrabMem();
    PROTECT(res);
    res = cons(str2Lisp(info.serDevPortInfoStr), res);
    res = cons(makeUNum(info.serDevHandshakeBaud), res);
    res = cons(makeUNum(info.serDevMaxBaudRate), res);
    res = cons(makeUNum(info.serDevFtrInfo), res);
    res = cons(make4Byte(info.serDevCreator), res);
    UNPROTECT(res);
    return res;
  }
  else {
    GrabMem();
    return FALSE;
  }
}

/**********************************************************************/
/* Get CTS timeout value                                              */
/**********************************************************************/
static PTR nativeGetCTS(PTR* args)
{
  LMSerial* pser = FOREIGNVAL(args[0]);

  if (pser->portId != CLOSED_SERIAL) 
    return makeNum(pser->CTS);
  return FALSE;
}

/**********************************************************************/
/* Set CTS timeout value                                              */
/**********************************************************************/
static PTR nativeSetCTS(PTR* args)
{
  LMSerial* pser = FOREIGNVAL(args[0]);

  if (pser->portId != CLOSED_SERIAL) {
    Int32  timeout = getInt32(args[1]);
    ReleaseMem();
    if (newSerial) {
      UInt16 len     = sizeof(timeout);
      if (SrmControl(pser->portId,
                     srmCtlSetCtsTimeout, &timeout, &len) == 0) {
        pser->CTS = timeout; 
        GrabMem();
        return TRUE;
      }
    }
    else {
      SerSettingsType settings;
      if (SerGetSettings(serRefNum, &settings) == 0       &&
          (settings.ctsTimeout = timeout, true) &&
          SerSetSettings(serRefNum, &settings) == 0) {
        pser->CTS = timeout; 
        GrabMem();
        return TRUE;
      }
    }
    GrabMem();
  }
  return FALSE;
}

/**********************************************************************/
/* Set receive timeout value                                          */
/**********************************************************************/
static PTR nativeSetTimeout(PTR* args)
{
  ((LMSerial*)FOREIGNVAL(args[0]))->timeout = getInt32(args[1]);
  return args[1];
}

/**********************************************************************/
/* Get receive timeout value                                          */
/**********************************************************************/
static PTR nativeGetTimeout(PTR* args)
{
  return makeNum(((LMSerial*)FOREIGNVAL(args[0]))->timeout);
}

/**********************************************************************/
/* Flush the receive FIFO                                             */
/**********************************************************************/
static PTR nativeRecvFlush(PTR* args)
{
  LMSerial* pser = FOREIGNVAL(args[0]);

  if (pser->portId != CLOSED_SERIAL) { 
    ReleaseMem();
    SER1(ReceiveFlush, pser->portId, pser->timeout);
    GrabMem();
    return TRUE;
  }
  return FALSE;
}

/**********************************************************************/
/* Flush the send FIFO                                                */
/**********************************************************************/
static PTR nativeSendFlush(PTR* args)
{
  LMSerial* pser = FOREIGNVAL(args[0]);

  if (pser->portId != CLOSED_SERIAL) {
    ReleaseMem();
    SER0(SendFlush, pser->portId);
    GrabMem();
    return TRUE;
  }
  return FALSE;
}

/**********************************************************************/
/* Set RS232 break signal                                             */
/**********************************************************************/
static PTR nativeSetBreak(PTR* args)
{
  UInt16 portId  = ((LMSerial*)FOREIGNVAL(args[0]))->portId;

  if (portId != CLOSED_SERIAL) {
    Boolean res;
    UInt16 op = args[1] == FALSE ?
                  (newSerial ? srmCtlStopBreak : serCtlStopBreak) :
                  (newSerial ? srmCtlStartBreak : serCtlStartBreak);
    ReleaseMem();
    res = SER3(Control, portId, op, NULL, NULL) == 0;
    GrabMem();
    return res ? TRUE : FALSE;
  }
  return FALSE;
}

/**********************************************************************/
/* Set IrDA enable                                                    */
/**********************************************************************/
static PTR nativeSetIrDA(PTR* args)
{
  UInt16 portId  = ((LMSerial*)FOREIGNVAL(args[0]))->portId;

  if (portId != CLOSED_SERIAL) {
    Boolean res;
    UInt16 op = args[1] == FALSE ?
                  (newSerial ? srmCtlIrDADisable : serCtlIrDADisable) :
                  (newSerial ? srmCtlIrDAEnable : serCtlIrDAEnable);
    ReleaseMem();
    res = SER3(Control, portId, op, NULL, NULL) == 0;
    GrabMem();
    return res ? TRUE : FALSE;
  }
  return FALSE;
}

/**********************************************************************/
/* Set IrDA receiver enable                                           */
/**********************************************************************/
static PTR nativeSetRx(PTR* args)
{
  UInt16 portId  = ((LMSerial*)FOREIGNVAL(args[0]))->portId;

  if (portId != CLOSED_SERIAL) {
    Boolean res;
    UInt16 op = args[1] == FALSE ?
                  (newSerial ? srmCtlRxDisable : serCtlRxDisable) :
                  (newSerial ? srmCtlRxEnable : serCtlRxEnable);
    ReleaseMem();
    res = SER3(Control, portId, op, NULL, NULL) == 0;
    GrabMem();
    return res ? TRUE : FALSE;
  }
  return FALSE;

}

/**********************************************************************/
/* Retrieve input port from a serial port                             */
/**********************************************************************/
static PTR nativeSerialInput(PTR* args)
{
  return ((LMSerial*)FOREIGNVAL(args[0]))->inPort;
}

/**********************************************************************/
/* Retrieve output port from a serial port                            */
/**********************************************************************/
static PTR nativeSerialOutput(PTR* args)
{
  return ((LMSerial*)FOREIGNVAL(args[0]))->outPort;
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule serialBuiltins = 
{
  MODULE_FUNC(init),
  {"open-serial",         NATIVE3(nativeOpenSerial,  tyINT, tyINT, tySTRING)},
  {"close-serial",        NATIVE1(nativeCloseSerial, FOREIGN(FT_SERIAL))},
  {"serial-input",        NATIVE1(nativeSerialInput,    FOREIGN(FT_SERIAL))},
  {"serial-output",       NATIVE1(nativeSerialOutput,   FOREIGN(FT_SERIAL))},
  {"serial?",             PRIMTYPE(FOREIGN(FT_SERIAL))},
  {"new-serial?",         NATIVE0(nativeNewSerial)},
  {"serial-status",       NATIVE1(nativeSerialStatus, FOREIGN(FT_SERIAL))},
  {"serial-info",         NATIVE1(nativeSerialInfo, FOREIGN(FT_SERIAL))},
  {"serial-send-flush",   NATIVE1(nativeSendFlush, FOREIGN(FT_SERIAL))},
  {"serial-receive-flush",NATIVE1(nativeRecvFlush, FOREIGN(FT_SERIAL))},
  {"serial-set-timeout!", NATIVE2(nativeSetTimeout, FOREIGN(FT_SERIAL), tyINT)},
  {"serial-get-timeout",  NATIVE1(nativeGetTimeout, FOREIGN(FT_SERIAL))},
  {"serial-set-cts!",     NATIVE2(nativeSetCTS, FOREIGN(FT_SERIAL), tyINT)},
  {"serial-get-cts",      NATIVE1(nativeGetCTS, FOREIGN(FT_SERIAL))},
  {"serial-set-break!",   NATIVE2(nativeSetBreak, FOREIGN(FT_SERIAL), tyBOOL)},
  {"serial-set-irda!",    NATIVE2(nativeSetIrDA, FOREIGN(FT_SERIAL), tyBOOL)},
  {"serial-set-rx!",      NATIVE2(nativeSetRx, FOREIGN(FT_SERIAL), tyBOOL)},

  {NULL}
};
