/**********************************************************************/
/*                                                                    */
/* port.c: LISPME port management                                     */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 03.06.2001 Created from file.c                                FBI  */
/* 03.11.2001 Final update for 3.0                               FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "port.h"
#include "io.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"
#include "comp.h"

#include "file.h"

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define SYM_OUTFIELD MKPRIMSYM(PORT_MODULE,1)

/**********************************************************************/
/* Module local data                                                  */
/**********************************************************************/
static readFctType  readers[MAX_PORT_TYPES];
static writeFctType writers[MAX_PORT_TYPES];

static char*     readPtr;
static MemHandle readHand;

typedef enum {MODE_PEEK, MODE_CHAR, MODE_LINE, MODE_SEXP} READ_MODE;

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static void initModule(ModuleMessage mess)                      SEC(IO);
static void inPortMemHook(MemMessage mess, PTR ptr)             SEC(IO);  
static void inPortPrinter(Boolean machineFormat, void* p)       SEC(IO);
static void outPortMemHook(MemMessage mess, PTR ptr)            SEC(IO);  
static void outPortPrinter(Boolean machineFormat, void* p)      SEC(IO);
static void writeField(WriterCmd cmd, OutPort* outp)            SEC(IO);

static PTR   readPort(PTR port, READ_MODE mode)                 SEC(IO);
static void  writePort(PTR expr, PTR port, Boolean machine)     SEC(IO);
static char* refill(void)                                       SEC(IO);

static PTR  nativePeekChar(PTR* args)                           SEC(IO);
static PTR  nativeReadChar(PTR* args)                           SEC(IO);
static PTR  nativeReadLine(PTR* args)                           SEC(IO);
static PTR  nativeRead(PTR* args)                               SEC(IO);
static PTR  nativeDisplay(int argc, PTR* args)                  SEC(IO);
static PTR  nativeWrite(int argc, PTR* args)                    SEC(IO);
static PTR  nativeNewline(int argc, PTR* args)                  SEC(IO);
static PTR  nativeCloseInport(PTR* args)                        SEC(IO);
static PTR  nativeCloseOutport(PTR* args)                       SEC(IO);

/**********************************************************************/
/* Module control function                                            */
/**********************************************************************/
static void initModule(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
    {
      /*--------------------------------------------------------------*/
      /* Register hooks for port datatypes.                           */
      /*--------------------------------------------------------------*/
      registerMemHook(FT_INPORT,    inPortMemHook);
      registerTypename(FT_INPORT,   "input port");
      registerPrinter(FT_INPORT,    inPortPrinter);
      registerMemHook(FT_OUTPORT,   outPortMemHook);
      registerTypename(FT_OUTPORT,  "output port");
      registerPrinter(FT_OUTPORT,   outPortPrinter);
      registerWriteFct(PT_OUTFIELD, writeField);
      registerWriteFct(PT_MESSAGE,  writeField);
      break;
    }

    case INIT_HEAP:
    {
      /*--------------------------------------------------------------*/
      /* Add *outfield* variable                                      */
      /*--------------------------------------------------------------*/
      OutPort* pof = MemPtrNew(sizeof(OutPort));
      pof->type   = PT_OUTFIELD;
      // Don't set the OPF_AUTOFLUSH flag for the output field since
      // flushing is handled specially in this case!!!
      pof->flags  = OPF_SUPPRESS_NOPRINT | OPF_NUL_TERMINATE;
      pof->uid    = 0;
      pof->pos    = 0;
      pof->bufLen = 0;
      pof->dbRef  = 0;
      pof->impl   = NIL;
      pof->buf    = NIL;
      W =  allocForeign(pof, FT_OUTPORT);
      createGlobalVar(SYM_OUTFIELD, W);
      /* fall thru */
    }  

    case SESS_CONNECT:
    {
      PTR ptr = locVal(symLoc(SYM_OUTFIELD));
      TCHECK(FOREIGN(FT_OUTPORT),ptr);
      portOutField = (OutPort*)FOREIGNVAL(ptr);
      updateOutpSize();
      break;
    }

    default:
  }
}

void updateOutpSize() 
{
  portOutField->bufLen = outpSize;
}

/**********************************************************************/
/* The memory hook function for input ports                           */
/**********************************************************************/
static void inPortMemHook(MemMessage mess, PTR ptr) 
{
  switch (mess) {
    case MEM_MARK:
      if (FOREIGNVAL(ptr)) {
        mark(((InPort*)FOREIGNVAL(ptr))->impl);
        mark(((InPort*)FOREIGNVAL(ptr))->buf);
      }
      break;

    case MEM_DELETE:
      if (FOREIGNVAL(ptr))
        MemPtrFree(FOREIGNVAL(ptr));
      break;

    case MEM_PICKLE:
      standardPickle(ptr);
      break;

    case MEM_UNPICKLE:
      standardUnpickle(ptr);
      break;
  }
}

/**********************************************************************/
/* The memory hook function for output ports                          */
/**********************************************************************/
static void outPortMemHook(MemMessage mess, PTR ptr) 
{
  switch (mess) {
    case MEM_MARK:
      if (FOREIGNVAL(ptr)) {
        mark(((OutPort*)FOREIGNVAL(ptr))->impl);
        mark(((OutPort*)FOREIGNVAL(ptr))->buf);
      }  
      break;

    case MEM_DELETE:
      if (FOREIGNVAL(ptr))
        MemPtrFree(FOREIGNVAL(ptr));
      break;

    case MEM_PICKLE:
      standardPickle(ptr);
      break;

    case MEM_UNPICKLE:
      standardUnpickle(ptr);
      break;
  }
}

/**********************************************************************/
/* Print an input port                                                */
/**********************************************************************/
static void inPortPrinter(Boolean machineFormat, void* p)
{
  // Too much output?
  InPort* inp = p; 
  outStr("[inport ");
  StrIToA(token,inp->type);
  outStr(token);
  outStr(" @");
  StrIToA(token,inp->pos);
  outStr(token);
  outStr(" ");
  writeSEXP(inp->impl);
  outStr("]");
}

/**********************************************************************/
/* Print an output port                                               */
/**********************************************************************/
static void outPortPrinter(Boolean machineFormat, void* p)
{
  // Too much output?
  OutPort* outp = p; 
  outStr("[outport ");
  StrIToA(token,outp->type);
  outStr(token);
  outStr(" @");
  StrIToA(token,outp->pos);
  outStr(token);
  outStr(" ");
  writeSEXP(outp->impl);
  outStr("]");
}


/**********************************************************************/
/* Make a (non-memo) input port from components                       */
/**********************************************************************/
PTR makeBufInPort(UInt8 ptype, PTR impl, PTR buf)
{
  InPort* inp   = MemPtrNew(sizeof(InPort));

  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE, MKINT(ptype));

  inp->type   = ptype;
  inp->status = INP_STATUS_OK;
  inp->uid    = 0;
  inp->pos    = 0;
  inp->next   = 0;
  inp->nRec   = 0;
  inp->dbRef  = 0;            
  inp->impl   = impl;
  inp->buf    = buf;
  inp->bufLen = stringLength(buf);
  return allocForeign(inp, FT_INPORT);
}

/**********************************************************************/
/* Make a input port for a memo-like file                             */
/**********************************************************************/
PTR makeMemoInPort(UInt8 ptype, DmOpenRef ref, UInt32 uid, UInt16 pos)
{
  InPort* inp   = MemPtrNew(sizeof(InPort));

  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE, MKINT(ptype));

  inp->type   = ptype;
  inp->status = INP_STATUS_OK;
  inp->uid    = uid;
  inp->pos    = pos;
  inp->next   = 0;
  inp->nRec   = 0;
  inp->dbRef  = ref;
  inp->impl   = NIL;
  inp->buf    = NIL;
  inp->bufLen = 0;
  return allocForeign(inp, FT_INPORT);
}

/**********************************************************************/
/* Make a string-buffered output port                                 */
/**********************************************************************/
PTR makeBufOutPort(UInt8 ptype, PTR impl, UInt16 bufLen, UInt8 flags)
{
  OutPort* outp = MemPtrNew(sizeof(OutPort));

  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE, MKINT(ptype));

  outp->type      = ptype;
  outp->flags     = OPF_BUFFERED | flags;
  outp->uid       = 0;
  outp->pos       = 0;
  outp->bufLen    = bufLen;
  outp->dbRef     = 0;
  outp->impl      = impl;
  outp->buf       = createString(bufLen);
  return allocForeign(outp, FT_OUTPORT);
}

/**********************************************************************/
/* Make a output port from components                                 */
/**********************************************************************/
PTR makeMemoOutPort(UInt32 uid, UInt8 ptype, DmOpenRef dbRef)
{
  OutPort* outp  = MemPtrNew(sizeof(OutPort));

  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE, MKINT(ptype));

  outp->type    = ptype;
  outp->flags   = OPF_AUTOFLUSH | OPF_NUL_TERMINATE;  
  outp->uid     = uid;
  outp->pos     = 0;
  outp->bufLen  = MEMO_OUTPUT_SIZE;
  outp->dbRef   = dbRef;
  outp->impl    = NIL;
  outp->buf     = NIL;
  return allocForeign(outp, FT_OUTPORT);
}

/**********************************************************************/
/* output a token to current output port                              */
/**********************************************************************/
void outStr(char* p) 
{
  while (*p)
  {
    if (gOut->pos >= gOut->bufLen) {
      writeFctType wr = writers[gOut->type];
      if (wr)
        wr(WC_WRITE, gOut);
    }
    else
      gOut->mem[gOut->pos++] = *p++;
  }
}

/**********************************************************************/
/* Flush string buffer to port                                        */
/**********************************************************************/
void flushPort(OutPort* outp) 
{
  writeFctType wr = writers[outp->type];
  if (wr)
    wr(WC_WRITE, outp);
}

/**********************************************************************/
/* Write to the output field                                          */
/**********************************************************************/
static void writeField(WriterCmd cmd, OutPort* outp)
{
  switch (cmd) {
    case WC_WRITE:
      /*--------------------------------------------------------------*/
      /* Abbreviate output and throw exception                        */
      /*--------------------------------------------------------------*/
      outp->mem[outp->bufLen-2] = charEllipsis;
      ErrThrow(ERR_O5_OUTPUT_TRUNC);
    
    case WC_CLOSE:
      /*--------------------------------------------------------------*/
      /* Ignore close attempts                                        */
      /*--------------------------------------------------------------*/
      break;
  }
}

/**********************************************************************/
/* Write to a generic port                                            */
/**********************************************************************/
static void writePort(PTR expr, PTR port, Boolean machine)
{
  OutPort* outp = FOREIGNVAL(port);

  if (outp->flags & OPF_CLOSED)
    error1(ERR_R13_CLOSED_PORT, port);

  printSEXP(expr, (machine ? PRT_ESCAPE | PRT_SPACE : 0), outp);
}

/**********************************************************************/
/* Refill the read buffer                                             */
/**********************************************************************/
static InPort* globalInp;

static char* refill(void)
{
  if (readers[globalInp->type](RC_READ, globalInp) == 0)
    return NULL;
  MemHandleUnlock(readHand);
  readHand = DmQueryRecord(dbRef, ARR_INDEX(globalInp->buf));
  readPtr = ArrayHandleLock(readHand);
  globalInp->pos = 0;
  limit = readPtr + globalInp->bufLen; // hate global vars :-(
  return readPtr;
}

/**********************************************************************/
/* Read from a generic port                                           */
/**********************************************************************/
static PTR readPort(PTR port, READ_MODE mode)
{
  InPort* inp = FOREIGNVAL(port);
  readFctType rd = readers[inp->type];
  int c;
  char* dest;
  UInt16    index;
  Boolean   anyRead = false;

  if (inp->status == INP_STATUS_CLOSED)
    error1(ERR_R13_CLOSED_PORT, port);

  if (rd) {
    if (inp->uid != 0) {
      /*--------------------------------------------------------------*/  
      /* Read from fixed memory block                                 */  
      /* (Re-)determine length in case it has been changed by editing */  
      /* the memo in the meantime                                     */  
      /*--------------------------------------------------------------*/  
      DmFindRecordByID(inp->dbRef, inp->uid, &index);
      readHand = DmQueryRecord(inp->dbRef,index);
      readPtr = MemHandleLock(readHand);
      inp->bufLen = MemHandleSize(readHand);
    }
    else {   
      /*--------------------------------------------------------------*/  
      /* Read from string buffer                                      */  
      /* don't modify buffer length, the refill function is           */  
      /* responsible for that                                         */  
      /*--------------------------------------------------------------*/  
      if (inp->buf != EMPTY_STR) {
        readHand = DmQueryRecord(dbRef,ARR_INDEX(inp->buf));
        readPtr = ArrayHandleLock(readHand);
      }
    }

    switch (mode) {
      case MODE_CHAR:
      case MODE_PEEK:
        /*------------------------------------------------------------*/  
        /* Look ahead/read a single char                              */  
        /*------------------------------------------------------------*/
        if (inp->pos >= inp->bufLen) {
          if (inp->buf != EMPTY_STR) 
            MemHandleUnlock(readHand);
          if (!rd(RC_READ, inp))
            return END_OF_FILE;
          readHand = DmQueryRecord(dbRef, ARR_INDEX(inp->buf));
          readPtr = ArrayHandleLock(readHand);
        }  
        c = readPtr[inp->pos];
        MemHandleUnlock(readHand);
        if (mode == MODE_CHAR)
          inp->pos++;
        return MKCHAR(c);
  
      case MODE_LINE:
        /*------------------------------------------------------------*/  
        /* Read an entire line                                        */  
        /*------------------------------------------------------------*/
        dest = msg;
        readPtr += inp->pos;
        while (true) {
          while (inp->pos < inp->bufLen && *readPtr != '\n') {
            *dest++ = *readPtr++;
            inp->pos++;
            anyRead = true;
          }  
          if (inp->pos >= inp->bufLen) {
            /*--------------------------------------------------------*/ 
            /* Refill buffer                                          */ 
            /*--------------------------------------------------------*/ 
            if (inp->buf != EMPTY_STR) 
              MemHandleUnlock(readHand);
            if (!rd(RC_READ, inp)) {
              if (anyRead) 
                goto done;
              else 
                return END_OF_FILE;
            }
            readHand = DmQueryRecord(dbRef,ARR_INDEX(inp->buf));
            readPtr = ArrayHandleLock(readHand);
          }  
          else { 
            /*--------------------------------------------------------*/ 
            /* Ignore \n and return                                   */ 
            /*--------------------------------------------------------*/ 
            MemHandleUnlock(readHand);
            inp->pos++;
          done:
            *dest = '\0';
            return str2Lisp(msg);
          }
        }  
        return NOPRINT; // Never reached 

      case MODE_SEXP:  
        /*------------------------------------------------------------*/  
        /* Read a SEXP                                                */  
        /*------------------------------------------------------------*/
        if (EOFHandler != NULL)
          return FALSE; // currently don't allow nested buffered files
        if (inp->buf == EMPTY_STR) {
          if (!rd(RC_READ, inp))
            return END_OF_FILE;
          readHand = DmQueryRecord(dbRef, ARR_INDEX(inp->buf));
          readPtr = ArrayHandleLock(readHand);
        }
        ErrTry {
          EOFHandler = refill;
          globalInp = inp; 
          W = readBufSEXP(readPtr+inp->pos, readPtr+inp->bufLen);
        } ErrCatch(err) {
          EOFHandler = NULL;
          if (onlyWS)
            W = END_OF_FILE;
          else {
            MemHandleUnlock(readHand);
            ErrThrow(err); 
          }   
        } ErrEndCatch 
        EOFHandler = NULL;
        inp->pos = currPtr-readPtr;
        MemHandleUnlock(readHand);
        return W; 
    }
  }
  else
    error1(ERR_R5_NO_IO_HOOK, port);
}

/**********************************************************************/
/* Native interface for reading                                       */
/**********************************************************************/
static PTR nativePeekChar(PTR* args)
{
  return readPort(args[0], MODE_PEEK);
}

static PTR nativeReadChar(PTR* args)
{
  return readPort(args[0], MODE_CHAR);
}

static PTR nativeReadLine(PTR* args)
{
  return readPort(args[0], MODE_LINE);
}

static PTR nativeRead(PTR* args)
{
  return readPort(args[0], MODE_SEXP);
}

/**********************************************************************/
/* Display a value in human-readable format (optional output port)    */
/**********************************************************************/
static PTR nativeDisplay(int argc, PTR* args)
{
  switch (argc) 
  {
    case 1:
      printSEXP(args[0], 0, portOutField);
      break;
  
    case 2:
      EXT_TCHECK(FOREIGN(FT_OUTPORT),car(args[1]),"display",1);
      writePort(args[0], car(args[1]), false);
      break;
    
    default:
      arityError("display",argc); 
  }
  return args[0];
}

/**********************************************************************/
/* Write a value in machine-readable format (optional output port)    */
/**********************************************************************/
static PTR nativeWrite(int argc, PTR* args)
{
  switch (argc) 
  {
    case 1:
      printSEXP(args[0], PRT_ESCAPE | PRT_SPACE, portOutField);
      break;             
  
    case 2:
      EXT_TCHECK(FOREIGN(FT_OUTPORT),car(args[1]),"write",1);
      writePort(args[0], car(args[1]), true);
      break;
    
    default:
      arityError("write",argc); 
  }
  return args[0];
}

/**********************************************************************/
/* Write a newline character (optional output port)                   */
/**********************************************************************/
static PTR nativeNewline(int argc, PTR* args)
{
  args[1] = args[0];
  args[0] = MKCHAR('\x0a');
  return nativeDisplay(argc+1, args);
}

/**********************************************************************/
/* Close an input port                                                */
/**********************************************************************/
static PTR nativeCloseInport(PTR* args)
{
  InPort*     inp = FOREIGNVAL(args[0]);
  readFctType rd  = readers[inp->type];

  if (inp->status != INP_STATUS_CLOSED) {
    if (rd) 
      rd(RC_CLOSE, inp);
    else
      error1(ERR_R5_NO_IO_HOOK, args[0]);
  }
  return args[0];
}

/**********************************************************************/
/* Close an output port                                               */
/**********************************************************************/
static PTR nativeCloseOutport(PTR* args)
{
  OutPort*     outp = FOREIGNVAL(args[0]);
  writeFctType wr   = writers[outp->type];

  if (!(outp->flags & OPF_CLOSED)) {
    if (wr) {
      if ((outp->flags & OPF_BUFFERED) && outp->type != PT_DOC) {
        // DOCs writes automatically on close smaller block
        wr(WC_WRITE, outp);
      }
      wr(WC_CLOSE, outp);
    }
    else
      error1(ERR_R5_NO_IO_HOOK, args[0]);
  }
  return args[0];
}

/**********************************************************************/
/* register writer function for a port type                           */
/**********************************************************************/
void registerWriteFct(UInt8 ptype, writeFctType fp)
{
  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE,MKINT(ptype));
  writers[ptype] = fp;
}

/**********************************************************************/
/* register reader function for a port type                           */
/**********************************************************************/
void registerReadFct(UInt8 ptype, readFctType fp)
{
  if (ptype >= MAX_PORT_TYPES)
    error1(ERR_M11_INV_PORT_TYPE,MKINT(ptype));
  readers[ptype] = fp;
}


/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule portBuiltins = 
{
  MODULE_FUNC(initModule),
  BUILTINSYMBOL_H("*outfield*","port for output field"),
  {"display",          NATIVEV1_H(nativeDisplay, tyANY, "<any> [<output port>]")},
  {"write",            NATIVEV1_H(nativeWrite,   tyANY, "<any> [<output port>]")},
  {"newline",          NATIVEV0_H(nativeNewline, "[<output port>]")},

  {"read",             NATIVE1(nativeRead,     FOREIGN(FT_INPORT))},
  {"read-char",        NATIVE1(nativeReadChar, FOREIGN(FT_INPORT))},
  {"peek-char",        NATIVE1(nativePeekChar, FOREIGN(FT_INPORT))},
  {"read-line",        NATIVE1(nativeReadLine, FOREIGN(FT_INPORT))},

  {"close-input-port", NATIVE1(nativeCloseInport,  FOREIGN(FT_INPORT))},
  {"close-output-port",NATIVE1(nativeCloseOutport, FOREIGN(FT_OUTPORT))},

  {"input-port?",      PRIMTYPE(FOREIGN(FT_INPORT))},
  {"output-port?",     PRIMTYPE(FOREIGN(FT_OUTPORT))},
  {"eof-object?",      PRIMTYPE(tyEOFOBJ)},
  {NULL}
};
