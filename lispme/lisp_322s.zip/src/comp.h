/**********************************************************************/
/*                                                                    */
/* comp.h:  LISP to SECD compiler                                     */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 04.03.1998 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include "store.h"

/**********************************************************************/
/* types                                                              */
/**********************************************************************/
typedef enum {GLOBAL, RGLOBAL, LOCAL} VARLOC;

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern PTR   joinCont;
extern PTR   rtnCont;

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
LEXADR  location(PTR var, PTR env, Boolean throwErr,
                 VARLOC* where)                               SEC(COMP);
PTR     compile(PTR expr, PTR names)                          SEC(COMP);
Boolean buildIn(PTR func, PTR args, Int16 argl,
                PTR names, PTR* code)                         SEC(COMP);

/**********************************************************************/
/* Helper functions useful for compiler extension                     */
/**********************************************************************/
void comp(PTR expr, PTR names, PTR* code)                     SEC(COMP);
void compseq(PTR exlist, PTR names, PTR* code)                SEC(COMP);
void complist(PTR exlist, PTR names, PTR* code)               SEC(COMP);
void compVar(Boolean store, LEXADR la, VARLOC where,
             PTR* code)                                       SEC(COMP); 
void compConst(PTR con, PTR* code)                            SEC(COMP);
