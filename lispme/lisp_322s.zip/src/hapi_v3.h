/**********************************************************************/
/*                                                                    */
/* hapi_v3.h: Header for HandBase API version 3                       */
/*                                                                    */
/* Copied from original DDH hapi.h and renamed due to incompatible    */
/* changes in data structures from HBase V2 -> V3 :-(                 */
/*                                                                    */
/**********************************************************************/

#ifndef __HAPI_V3_H__
#define __HAPI_V3_H__

typedef enum {
                HapiGetDBNames = sysAppLaunchCmdCustomBase,
                HapiGetDBInfo,
                HapiGetFieldValue,
                HapiGetLinkInfo,
                HapiFindNextLinkedRecord,
                HapiSetFieldValue,
                HapiSetRecordValue,
                HapiAddRecord,
                HapiGetRecordValue,
                HapiCreateDatabase
} HapiCustomActionCodes;

#define HAPI_MAX_FIELDS_V3 100
#define HAPI_MAX_DBS_V3    200

#define HAPI_MIN_VERSION 290

enum HAPIFIELDTYPES {
  HB_FIELD_NOT_USED,
  HB_STRING_FIELD,
  HB_DECIMAL_FIELD,
  HB_FLOAT_FIELD,
  HB_POPUP_FIELD,
  HB_CHECKBOX_FIELD,
  HB_UNIQUE_FIELD,
  HB_IMAGE_FIELD,
  HB_DATE_FIELD, 
  HB_TIME_FIELD,
  HB_LINK_FIELD,
  HB_LINKED_FIELD,
  HB_NOTE_FIELD,
  HB_HEADING_FIELD,
  HB_LINKLIST_FIELD,
  HB_CALCULATED_FIELD
};


// For use with HapiGetDBInfo
#if 0
// not needed, same format as in V2
typedef struct {
  int fieldtype;   // use HAPIFIELDTYPES enum
  unsigned char exportable;   // Whether to export and print this field
  unsigned char visible;  // Whether field is visible in Edit Record screen.
  int maxsize;            // Maximum size of this field in bytes.
  char fieldname[20];     // Name given to field
} HapiFieldDefType;
#endif

typedef struct {
  // input fields
  char dbname[32];   // name of db to look at.
  // output fields
  HapiFieldDefType fields[HAPI_MAX_FIELDS_V3];   // field definition information
  UInt16 numrecs;      // number of records in database.
} HapiFieldsDefTypeV3;


// For use with HapiGetDBNames
typedef struct {
  // output type
  char dbnames[HAPI_MAX_DBS_V3][32];  // Names of databases
  int numdbs;                      // Number of databases.
} HapiDBListTypeV3;


// For use with HapiGetFieldValue and HapiSetFieldValue
typedef struct {
  // input variables
  char dbname[32];   // name of db to look at
  UInt16 recnum;       // number of record to retrieve.
  int maxsizeofvalue;    // maximum size defined of the outvalue pointer below.
  int fieldnum;      // field number to retrieve
  // output variables for Get and input for Set routine.
  char *outvalue;  // For HapiGetFieldValue - returned value of record.  You must make sure to allocate at least maxsizeofvalue before calling HanDBase!
} HapiFieldValueTypeV3;

// For use with HapiSetRecord and HapiAddRecord
// and for use with HapiGetRecord
typedef struct {
  // input variables
  char dbname[32];   // name of db to look at
  UInt16 recnum;       // number of record to set (N/A for Add Record)
  char *fieldvalues[HAPI_MAX_FIELDS_V3];
  int maxsizeoffield[HAPI_MAX_FIELDS_V3];
} HapiRecordValueTypeV3;

// For use with HapiGetLinkInfo
typedef struct {
  // input variables
  char dbname[32];   // name of db to look at
  UInt16 recnum;       // number of record to retrieve.
  int fieldnum;      // field number to retrieve
  // output variables
  char linkeddatabasename[32];  // returns the name of the database that is linked to
  int linkedfieldnum;  // returns the field number of the linked field
  unsigned char outvalue[24];  // returned value of link field.
} HapiLinkInfoTypeV3;

// For use with HapiFindNextLinkedRecord
typedef struct {
  // input variables
  char dbname[32];   // name of db to look at
  int fieldnum;      // field number of linked field
  int maxsizeofvalue;    // maximum size defined of the outvalue pointer below.
  int newsearch;        // set to 1 if this is a new search- HanDBase will start from the beginning if true.
  unsigned char linkvalue[24];  // returned value of link field.  You must make sure to allocate at least 24 bytes for this.
  // input and output
  UInt16 recnum;       // number of record to start looking from. And record that has the match.
  // output variables
  char *outvalue;  // returned value of linked record.  You must make sure to allocate at least maxsizeofvalue bytes for this.
} HapiLinkedRecordInfoTypeV3;

#endif
