/**********************************************************************/
/*                                                                    */
/* hbase.c: LISPME HandBase access functions                          */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 04.04.2000 New                                                FBI  */
/* 23.11.2003 Support both V2 and V3 of HanDBase                 FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "hbase.h"
#include "hapi_v2.h"
#include "hapi_v3.h"
#include "vm.h"
#include "util.h"
#include "io.h"
#include "arith.h"
#include "LispMe.h"

/**********************************************************************/
/* Static data                                                        */
/**********************************************************************/
static LocalID handBaseID;
static PTR     version;

/**********************************************************************/
/* Local macros                                                       */
/**********************************************************************/
#define HB_CALL(cmd,buf) \
  {UInt32 rc1; int rc=SysAppLaunch(0,handBaseID,0,cmd,(char*)buf,&rc1);\
  if(!rc) rc = rc1; if (rc) error1(ERR_H2_ERROR,MKINT(rc));}

/**********************************************************************/
/* Local functions                                                    */
/**********************************************************************/
static void init(ModuleMessage mess)                          SEC(MISC); 
static PTR  nativeDir(PTR* args)                              SEC(MISC);
static PTR  nativeInfo(PTR* args)                             SEC(MISC);
static PTR  nativeGetField(PTR* args)                         SEC(MISC);  
static PTR  nativeSetField(PTR* args)                         SEC(MISC);
static PTR  nativeGetLinks(PTR* args)                         SEC(MISC); 
static PTR  nativeAdd(PTR* args)                              SEC(MISC);
static PTR  nativeVersion(PTR* args)                          SEC(MISC);

/**********************************************************************/
/* Module initialization                                              */
/**********************************************************************/
static void init(ModuleMessage mess)
{
  switch (mess)
  {
    case APP_START: 
      if (handBaseID = DmFindDatabase(0, "HanDBase3")) 
        version = 3;
      else if (handBaseID = DmFindDatabase(0, "HanDBase"))
        version = 2;
      else 
        version = 0; 
      break;

    default:
  }
}

/**********************************************************************/
/* List HanDBase directory                                            */
/**********************************************************************/
static PTR nativeDir(PTR* args)
{
  PTR             res = NIL;
  PTR*            d = &res;
  int             i;

  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version==2) {
    HapiDBListTypeV2* buf = MemPtrNew(sizeof(HapiDBListTypeV2));
    ErrTry {
      HB_CALL(HapiGetDBNames, buf)
      PROTECT(res);
      for (i=0; i<buf->numdbs; ++i)
      {
        *d = cons(str2Lisp(buf->dbnames[i]), NIL);
        d  = &cdr(*d);
      }
      UNPROTECT(res);
    } ErrCatch(err) {
      MemPtrFree(buf);
      ErrThrow(err);
    } ErrEndCatch
    MemPtrFree(buf);
  }
  else {
    HapiDBListTypeV3* buf = MemPtrNew(sizeof(HapiDBListTypeV3));

    ErrTry {
      HB_CALL(HapiGetDBNames, buf)
      PROTECT(res);
      for (i=0; i<buf->numdbs; ++i)
      {
        *d = cons(str2Lisp(buf->dbnames[i]), NIL);
        d  = &cdr(*d);
      }
      UNPROTECT(res);
    } ErrCatch(err) {
      MemPtrFree(buf);
      ErrThrow(err);
    } ErrEndCatch
    MemPtrFree(buf);
  }
  return res;
}

/**********************************************************************/
/* Get version of HanDBase                                            */
/**********************************************************************/
static PTR nativeVersion(PTR* args)
{
  return version == 0 ? FALSE : MKINT(version);
}

/**********************************************************************/
/* Get info for HanDBase DB                                           */
/**********************************************************************/
static PTR nativeInfo(PTR* args)
{
  PTR                res;
  PTR*               d;
  int                i;
  PTR                temp;

  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version == 2) {
    HapiFieldsDefTypeV2* buf = MemPtrNew(sizeof(HapiFieldsDefTypeV2));
    ErrTry {
      StrCopy(buf->dbname, printString(args[0]));
      HB_CALL(HapiGetDBInfo, buf)
      res = cons(makeUNum(buf->numrecs), NIL);
      d = &cdr(res);
      PROTECT(res);
      for (i=0; i<HAPI_MAX_FIELDS_V2; ++i) 
      {
        HapiFieldDefType* c = &buf->fields[i];

        if (c->fieldtype == HB_FIELD_NOT_USED)
          continue;    

        temp = cons(MKINT(i),
                 cons(str2Lisp(c->fieldname),
                   cons(MKINT(c->fieldtype),
                     cons(MKINT(c->maxsize),
                       cons(c->exportable ? TRUE : FALSE,
                         cons(c->visible ? TRUE : FALSE, NIL))))));
        *d = cons(temp, NIL);
        d  = &cdr(*d);
      }
      UNPROTECT(res);
    } ErrCatch(err) {
      MemPtrFree(buf);
      ErrThrow(err);
    } ErrEndCatch
    MemPtrFree(buf);
  }
  else {
    HapiFieldsDefTypeV3* buf = MemPtrNew(sizeof(HapiFieldsDefTypeV3));
    ErrTry {
      StrCopy(buf->dbname, printString(args[0]));
      HB_CALL(HapiGetDBInfo, buf)
      res = cons(makeUNum(buf->numrecs), NIL);
      d = &cdr(res);
      PROTECT(res);
      for (i=0; i<HAPI_MAX_FIELDS_V3; ++i) 
      {
        HapiFieldDefType* c = &buf->fields[i];

        if (c->fieldtype == HB_FIELD_NOT_USED)
          continue;    

        temp = cons(MKINT(i),
                 cons(str2Lisp(c->fieldname),
                   cons(MKINT(c->fieldtype),
                     cons(MKINT(c->maxsize),
                       cons(c->exportable ? TRUE : FALSE,
                         cons(c->visible ? TRUE : FALSE, NIL))))));
        *d = cons(temp, NIL);
        d  = &cdr(*d);
      }
      UNPROTECT(res);
    } ErrCatch(err) {
      MemPtrFree(buf);
      ErrThrow(err);
    } ErrEndCatch
    MemPtrFree(buf);
  }
  return res;
}

/**********************************************************************/
/* Get field value as text                                            */
/**********************************************************************/
static PTR nativeGetField(PTR* args)
{
  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version==2) {
    HapiFieldValueTypeV2 value;
    StrCopy(value.dbname, printString(args[0]));
    value.recnum         = getUInt16(args[1]);
    value.fieldnum       = INTVAL(args[2]);
    value.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    value.outvalue       = msg;
    HB_CALL(HapiGetFieldValue, &value)
  }
  else {
    HapiFieldValueTypeV3 value;
    StrCopy(value.dbname, printString(args[0]));
    value.recnum         = getUInt16(args[1]);
    value.fieldnum       = INTVAL(args[2]);
    value.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    value.outvalue       = msg;
    HB_CALL(HapiGetFieldValue, &value)
  }
  return str2Lisp(msg);
}

/**********************************************************************/
/* Set field value as text                                            */
/**********************************************************************/
static PTR nativeSetField(PTR* args)
{
  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version==2) {
    HapiFieldValueTypeV2 value;
    StrCopy(value.dbname, printString(args[0]));
    printSEXP(args[3], 0, &portConv);
    value.recnum         = getUInt16(args[1]);
    value.fieldnum       = INTVAL(args[2]);
    value.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    value.outvalue       = msg;
    HB_CALL(HapiSetFieldValue, &value)
  }
  else {
    HapiFieldValueTypeV3 value;
    StrCopy(value.dbname, printString(args[0]));
    printSEXP(args[3], 0, &portConv);
    value.recnum         = getUInt16(args[1]);
    value.fieldnum       = INTVAL(args[2]);
    value.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    value.outvalue       = msg;
    HB_CALL(HapiSetFieldValue, &value)
  }
  return NOPRINT;
}

/**********************************************************************/
/* Add a new (empty) record                                           */
/**********************************************************************/
static PTR nativeAdd(PTR* args)
{
  int i;

  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version==2) {
    HapiRecordValueTypeV2 rec;

    for (i=0; i<HAPI_MAX_FIELDS_V2; ++i)
      rec.fieldvalues[i] = "";

    StrCopy(rec.dbname, printString(args[0]));
    HB_CALL(HapiAddRecord, &rec)
    return makeUNum(rec.recnum);
  }
  else {
    HapiRecordValueTypeV3 rec;

    for (i=0; i<HAPI_MAX_FIELDS_V3; ++i)
      rec.fieldvalues[i] = "";

    StrCopy(rec.dbname, printString(args[0]));
    HB_CALL(HapiAddRecord, &rec)
    return makeUNum(rec.recnum);
  }
}

/**********************************************************************/
/* Get a list of fields this field is linked to                       */
/**********************************************************************/
static PTR nativeGetLinks(PTR* args)
{
  PTR  res;
  PTR* d;

  if (!handBaseID)
    ErrThrow(ERR_H1_NO_HANDBASE);

  if (version==2) {
    HapiLinkInfoTypeV2         info;
    HapiLinkedRecordInfoTypeV2 lrec;
  
    StrCopy(info.dbname, printString(args[0]));
    info.recnum         = getUInt16(args[1]);
    info.fieldnum       = INTVAL(args[2]);
    HB_CALL(HapiGetLinkInfo, &info);

    StrCopy(lrec.dbname, info.linkeddatabasename);
    lrec.fieldnum       = info.linkedfieldnum;
    lrec.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    lrec.outvalue       = msg;
    lrec.newsearch      = true;
    MemMove(lrec.linkvalue, info.outvalue, sizeof(lrec.linkvalue));

    res = cons(str2Lisp(lrec.dbname), NIL);
    d   = &cdr(res);
    PROTECT(res);
  
    while (true) {
      UInt32 rc1;
      int rc=SysAppLaunch(0,handBaseID,0,HapiFindNextLinkedRecord,
                          (char*)&lrec,&rc1);
      if (!rc) rc = rc1;

      switch (rc) {
        case 0:
          lrec.newsearch = false;
          *d = cons(makeUNum(lrec.recnum), NIL);
          d  = &cdr(*d);
          break; 

        case 7: // no more matches
          UNPROTECT(res);
          return res;
 
        default:
          error1(ERR_H2_ERROR,MKINT(rc));
      }
    }
  }
  else {
    HapiLinkInfoTypeV3         info;
    HapiLinkedRecordInfoTypeV3 lrec;
  
    StrCopy(info.dbname, printString(args[0]));
    info.recnum         = getUInt16(args[1]);
    info.fieldnum       = INTVAL(args[2]);
    HB_CALL(HapiGetLinkInfo, &info);

    StrCopy(lrec.dbname, info.linkeddatabasename);
    lrec.fieldnum       = info.linkedfieldnum;
    lrec.maxsizeofvalue = MEMO_OUTPUT_SIZE;
    lrec.outvalue       = msg;
    lrec.newsearch      = true;
    MemMove(lrec.linkvalue, info.outvalue, sizeof(lrec.linkvalue));

    res = cons(str2Lisp(lrec.dbname), NIL);
    d   = &cdr(res);
    PROTECT(res);
  
    while (true) {
      UInt32 rc1;
      int rc=SysAppLaunch(0,handBaseID,0,HapiFindNextLinkedRecord,
                          (char*)&lrec,&rc1);
      if (!rc) rc = rc1;

      switch (rc) {
        case 0:
          lrec.newsearch = false;
          *d = cons(makeUNum(lrec.recnum), NIL);
          d  = &cdr(*d);
          break; 

        case 7: // no more matches
          UNPROTECT(res);
          return res;
 
        default:
          error1(ERR_H2_ERROR,MKINT(rc));
      }
    }
  }
}

/**********************************************************************/
/* Bundle all functions from the module                               */
/**********************************************************************/
BuiltInModule hbaseBuiltins = 
{
  MODULE_FUNC(init),
  {"hb-addrecord", NATIVE1(nativeAdd,      tySTRING)},
  {"hb-dir",       NATIVE0(nativeDir)},
  {"hb-getfield",  NATIVE3(nativeGetField, tySTRING, tyINT, tySMALLINT)},
  {"hb-getlinks",  NATIVE3(nativeGetLinks, tySTRING, tyINT, tySMALLINT)},
  {"hb-info",      NATIVE1(nativeInfo,     tySTRING)},
  {"hb-setfield",  NATIVE4(nativeSetField, tySTRING, tyINT, tySMALLINT, tyANY)},
  {"hb-version",   NATIVE0(nativeVersion)},
  {NULL}
};
