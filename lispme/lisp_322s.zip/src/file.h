/**********************************************************************/
/*                                                                    */
/* file.h: LISPME "file" (Memo) management                            */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.10.1998 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_FILE_H
#define INC_FILE_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "port.h"

/**********************************************************************/
/* Defines                                                            */
/**********************************************************************/
#define MAX_FILENAME_LEN 16
#define DOC_CREATOR  'REAd'
#define DOC_TYPE     'TEXt'

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule fileBuiltins; 
extern DmOpenRef     memoRef;
extern DmOpenRef     memo32Ref;
extern LocalID       memoId;
extern LocalID       memo32Id;

/**********************************************************************/
/* prototypes                                                         */
/**********************************************************************/
PTR     memoDir(PTR cat)                                        SEC(IO);
char*   openSrcFile(UInt16 format, SourceRef* src)              SEC(IO);
void    closeSrcFile(void)                                      SEC(IO);   

#endif
