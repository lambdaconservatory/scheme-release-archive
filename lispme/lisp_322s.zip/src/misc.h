/**********************************************************************/
/*                                                                    */
/* misc.h: LISPME miscellaneous native functions                      */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 01.02.2001 New                                                FBI  */
/*                                                                    */
/**********************************************************************/

#ifndef INC_MISC_H
#define INC_MISC_H

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "builtin.h"

/**********************************************************************/
/* Exported functions                                                 */
/**********************************************************************/
Boolean launchApp(PTR appId)                                    SEC(IO);
PTR     makeStrArr(PTR items)                                  SEC(MOD);

/**********************************************************************/
/* Exported data                                                      */
/**********************************************************************/
extern BuiltInModule miscBuiltins; 

#endif
