#/**********************************************************************/
/*                                                                    */
/* LispMe.c: Entire program                                           */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 27.07.1997 New                                                FBI  */
/* 02.08.1997 Combined all sorce modules, as linker fucks up!!   FBI  */
/* 09.10.1997 PalmOS2 only version                               FBI  */
/* 01.03.1998 Use DB mem as heap via MemSemaphoreReserve()       FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 21.11.1999 'Reload' button added                              FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* includes                                                           */
/**********************************************************************/
#include "store.h"
#include <limits.h>

#include "LispMe.h"
#include "io.h"
#include "vm.h"
#include "comp.h"
#include "fpstuff.h"
#include "util.h"
#include "gui.h"
#include "file.h"
#include "sess.h"
#include "setup.h"
#include "hbase.h"
#include "graphic.h"
#include "callback.h"

/**********************************************************************/
/* local defines                                                      */
/**********************************************************************/
#define MAX_LINE_LEN 32
#define OUTPUT_LINES  8
#define DOC_CREATOR  'REAd'
#define DOC_TYPE     'TEXt'

/*--------------------------------------------------------------------*/
/* Size of the internal editor                                        */
/*--------------------------------------------------------------------*/
#define BIG_EDIT 32768 
#define STD_EDIT  4096

/**********************************************************************/
/* predeclare static functions                                        */
/**********************************************************************/
static Boolean appHandleEvent(EventType*);
static Boolean MainFrameHandleEvent(EventType*);
static Boolean LoadHandleEvent(EventType*);
static Boolean EditFrameHandleEvent(EventType*);
static Boolean LispHandleEvent(EventType*);
static Boolean StartApp(char*);
static void    StopApp(void);

/**********************************************************************/
/* predeclare global functions                                        */
/**********************************************************************/
void    handleScrollEvents(EventType* e);
PTR     MakeLispEvent(EventType *e);
void    DoLMEvent(EventType *e);

/**********************************************************************/
/* global data                                                        */
/**********************************************************************/
DmOpenRef dbRef;
struct MemGlobal* pMemGlobal;
PTR       S,E,C,D,W;
PTR       firstFree;
char*     heap;
char*     strStore;

Int32     heapSize;
Int32     atomSize;
char*     markBit;
MemHandle realHandle;
Int32     realSize;
char*     reals;
char*     markRealBit;
PTR       firstFreeReal;

Int32  numGC;
Int32  numStep;
UInt32 tickStart;
UInt32 tickStop;

short    depth;              /* stack depth for printing or GC */
Boolean  running;
Boolean  quitHandler;
Boolean  changeHandler;
Int16    outPos;

MemHandle    outHandle;
MemHandle    inHandle;
FieldPtr     inField;
FieldPtr     outField;
FormPtr      mainForm;
ScrollBarPtr scrollBar;

struct LispMeGlobPrefs LispMePrefs;

UInt16  memoDBMode = dmModeReadOnly;

/**********************************************************************/
/* static data                                                        */
/**********************************************************************/
static Boolean   returning;
static Boolean   launchedExternally = true;
static UInt16    selMemo;

static LocalID   memoPadID = NULL;
static LocalID   peditID   = NULL;
static LocalID   pedit32ID = NULL;

/**********************************************************************/
/* Check for an application with given creator                        */
/**********************************************************************/
static LocalID findApp(UInt32 creator)
{
  DmSearchStateType sState;
  UInt16            card;
  LocalID           dbID;
  return DmGetNextDatabaseByTypeCreator(true, &sState, sysFileTApplication,
           creator, true, &card, &dbID) == errNone
         ? dbID : NULL;              
}

/**********************************************************************/
/* Switch to MemoPad or pedit to edit record (on error position)      */
/**********************************************************************/
static void startMemoPad(UInt16 recNum, Boolean usePedit, Boolean memo32)
{
  GoToParamsPtr     goPtr;

  goPtr = MemPtrNew(sizeof(GoToParamsType));
  MemPtrSetOwner(goPtr, 0);
  goPtr->searchStrLen  = !usePedit && startPtr ? 1 : 0;
  goPtr->dbCardNo      = 0;
  goPtr->dbID          = memo32 ? memo32Id : memoId;
  goPtr->recordNum     = recNum;
  goPtr->matchPos      = startPtr ? currPtr-startPtr-1 : 0;
  goPtr->matchFieldNum = 0;
  goPtr->matchCustom   = startPtr ? 1 : 0;

  if (usePedit)
    goPtr->matchCustom |= memo32 ? 0x20680000L : 0x19480000L;

  SysUIAppSwitch(0, usePedit ? (memo32 ? pedit32ID : peditID) : memoPadID,
                 sysAppLaunchCmdGoTo, (MemPtr)goPtr);
}

/**********************************************************************/
/* Init MathLib library                                               */
/**********************************************************************/
static void InitMathLib(void)
{
  Err error;

  error = SysLibFind(MathLibName, &MathLibRef);
  if (error)
    error = SysLibLoad(LibType, MathLibCreator, &MathLibRef);
  if (!error)
    mathLibOK = !MathLibOpen(MathLibRef, MathLibVersion);
}

/**********************************************************************/
/* Close MathLib library                                              */
/**********************************************************************/
static void CloseMathLib(void)
{
  Err    error;
  UInt16 useCount;

  if (mathLibOK)
  {
    error = MathLibClose(MathLibRef, &useCount);
    ErrFatalDisplayIf(error, "Can't close MathLib");
    if (useCount == 0)
      SysLibRemove(MathLibRef);
  }
}

/**********************************************************************/
/* Main entry                                                         */
/**********************************************************************/
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
  EventType e;
  short err;

  switch (cmd)
  {
    case sysAppLaunchCmdNormalLaunch:
      cmdPBP = NULL;
      launchedExternally = false;

    case sysAppLaunchCmdCustomBase:
      if (!StartApp((char*)cmdPBP))
        return 0;

      /*--------------------------------------------------------------*/
      /* Determine stack limit                                        */
      /*--------------------------------------------------------------*/
      stackLimit = ((char*)&e) - (palmIII ? OS3_STACK_AVAIL :
                                            OS2_STACK_AVAIL);
      FrmGotoForm(startPanel);
      do {
        EvtGetEvent(&e, running ? 0 : -1);
        if (!SysHandleEvent(&e))
          if (!MenuHandleEvent(0, &e, &err))
            if (!appHandleEvent(&e))
              FrmDispatchEvent(&e);
      } while (e.eType != appStopEvent);
      StopApp();
  }
  return 0;
}

/**********************************************************************/
/* Application event handling                                         */
/**********************************************************************/
static Boolean appHandleEvent(EventType* e)
{
  if (e->eType == frmLoadEvent)
  {
    Int16   formId = e->data.frmLoad.formID;
    FormPtr form   = FrmInitForm(formId);
    FrmSetActiveForm(form);

    switch(formId)
    {
      case IDD_MainFrame:
        FrmSetEventHandler(form, MainFrameHandleEvent);
        break;

      case IDD_Edit:
        FrmSetEventHandler(form, EditFrameHandleEvent);
        break;

      case IDD_SetupGlob:
        FrmSetEventHandler(form, SetupGlobHandleEvent);
        break;

      case IDD_SetupSess:
        FrmSetEventHandler(form, SetupSessHandleEvent);
        break;

      case IDD_Load:
        FrmSetEventHandler(form, LoadHandleEvent);
        break;

      case IDD_Sess:
        FrmSetEventHandler(form, SessHandleEvent);
        break;

      case IDD_NewSess:
        FrmSetEventHandler(form, NewSessHandleEvent);
        break;

      default:
        /*------------------------------------------------------------*/
        /* This is an ext.form, use special handler for Lisp callback */
        /* The LispMe handler function has already been installed     */
        /*------------------------------------------------------------*/
        returning = false;
        FrmSetEventHandler(form, LispHandleEvent);
        break;
    }
    return true;
  }
  return false;
}

/**********************************************************************/
/* Handle all events dealing with scrollbar/entryfield sync           */
/**********************************************************************/
void handleScrollEvents(EventType* e)
{
  FieldPtr fld;
  Int16    lines;
  switch (e->eType)
  {
    case keyDownEvent:
    {
      fld   = ptrFromObjID(IDC_EF_OUTPUT);
      lines = FldGetVisibleLines(fld)-1;
      switch (e->data.keyDown.chr)
      {
        case pageUpChr:
          if (FldScrollable(fld, winUp))
          {
            FldScrollField(fld, lines, winUp);
            updateScrollBar();
          }
          break;

        case pageDownChr:
          if (FldScrollable(fld, winDown))
          {
            FldScrollField(fld, lines, winDown);
            updateScrollBar();
          }
          break;
      }
      break;
    }
    case sclRepeatEvent:
    {
      fld   = ptrFromObjID(IDC_EF_OUTPUT);
      lines = e->data.sclRepeat.newValue-e->data.sclRepeat.value;
      if (lines > 0)
        FldScrollField(fld, lines, winDown);
      else
        FldScrollField(fld, -lines, winUp);
      break;
    }

    case fldChangedEvent:
      updateScrollBar();
      break;
    default:
  }
}

/**********************************************************************/
/* Set all up for an evaluation                                       */
/* n == 0: wrap (BEGIN ...) around expressions                        */
/* n > 0:  evaluate nth expression in buffer input                    */
/**********************************************************************/
static void setUpEval(char* input, int n)
{
  PTR res;

  tickStart = TimGetTicks();
  GrabMem();
  if (pMemGlobal->pickled)
    unpickle();
  S = E = C = D = W = NIL;
  pMemGlobal->fileLoad = n==0;
  protIdx = 0;
  if (n==0)
    res = loadMemo(input);
  else
    res = readNthSEXP(input,n);
  C = compile(res,NIL);
  S = D = W = NIL;
  E = pMemGlobal->tlVals;
  numGC = numStep = 0L;
  outPos = 0;
  running = true;
  evalMacro = false;
  actContext = -1;
}

/**********************************************************************/
/* Clean up after evaluation                                          */
/**********************************************************************/
static void cleanUpEval(Boolean buttons)
{
  tickStop  = TimGetTicks();
  running   = false;
  GrabMem();
  pMemGlobal->waitEvent = false;
  pMemGlobal->getEvent  = false;

  /*------------------------------------------------------------------*/
  /* Cleanup in case name and value lists are out of sync             */
  /*------------------------------------------------------------------*/
  if (listLength(pMemGlobal->tlNames) > listLength(pMemGlobal->tlVals))
      pMemGlobal->tlNames = cdr(pMemGlobal->tlNames);
  ReleaseMem();
  if (buttons)
    enableButtons();
  GUIFreeList();
  actContext = -1;
}

/**********************************************************************/
/* Convert PalmOS events to LispMe events                             */
/**********************************************************************/
PTR MakeLispEvent(EventType *e)
{
  PTR res;
  PROTECT(res)

  switch (e->eType)
  {
    case nilEvent:
      res = cons(FALSE,NIL);
      break;
 
    case penDownEvent:
      res = PENDOWN; goto PenEvent;
    case penUpEvent:
      res = PENUP; goto PenEvent;
    case penMoveEvent:
      res = PENMOVE;
    PenEvent:
      res = cons(res,
              cons(MKINT(e->screenX),
                cons(MKINT(e->screenY),NIL)));
      break;
  
    case keyDownEvent:
      res = cons(KEYDOWN,
              cons(MKCHAR(e->data.keyDown.chr),NIL));
      break;

    case ctlEnterEvent:
      res = cons(CTLENTER,
              cons(MKINT(e->data.ctlEnter.controlID),NIL));
      break;

    case ctlSelectEvent:
      res = cons(CTLSELECT,
              cons(MKINT(e->data.ctlSelect.controlID),
                cons(e->data.ctlSelect.on ? TRUE : FALSE,NIL)));
      break;

    case ctlRepeatEvent:
      res = cons(CTLREPEAT,
              cons(MKINT(e->data.ctlRepeat.controlID),NIL));
      break;

    case lstEnterEvent:
      res = cons(LSTENTER,
              cons(MKINT(e->data.lstEnter.listID),
                cons(MKINT(e->data.lstEnter.selection),NIL)));
      break;

    case lstSelectEvent:
      res = cons(LSTSELECT,
              cons(MKINT(e->data.lstSelect.listID),
                cons(MKINT(e->data.lstSelect.selection),NIL)));
      break;

    case popSelectEvent:
      res = cons(POPSELECT,
              cons(MKINT(e->data.popSelect.controlID),
                cons(MKINT(e->data.popSelect.listID),
                  cons(MKINT(e->data.popSelect.selection),
                    cons(MKINT(e->data.popSelect.priorSelection),NIL)))));
      break;

    case fldEnterEvent:
      res = cons(FLDENTER,
              cons(MKINT(e->data.fldEnter.fieldID),NIL));
      break;

    case fldChangedEvent:
      res = cons(FLDCHANGED,
              cons(MKINT(e->data.fldChanged.fieldID),NIL));
      break;

    case sclEnterEvent:
      res = cons(SCLENTER,
              cons(MKINT(e->data.sclEnter.scrollBarID),NIL));
      break;

    case sclRepeatEvent:
      res = cons(SCLREPEAT,
              cons(MKINT(e->data.sclExit.scrollBarID),
                cons(MKINT(e->data.sclExit.newValue),        
                  cons(MKINT(e->data.sclExit.value), NIL))));
      break;

    case sclExitEvent:
      res = cons(SCLEXIT,
              cons(MKINT(e->data.sclRepeat.scrollBarID),
                cons(MKINT(e->data.sclRepeat.newValue), NIL)));
      break;

    case menuEvent:
      res = cons(MENU,
              cons(MKINT(e->data.menu.itemID),NIL));
      break;

    case frmOpenEvent:
      res = cons(FRMOPEN,
              cons(MKINT(e->data.frmOpen.formID),NIL));
      break;

    case frmCloseEvent:
      res = cons(FRMCLOSE,
              cons(MKINT(e->data.frmClose.formID),NIL));
      break;

    default:
      res = cons(FALSE,NIL);
  }

  UNPROTECT(res)
  return res;
}

/**********************************************************************/
/* Low level LispMe hook to event handler                             */
/**********************************************************************/
void DoLMEvent(EventType *e)
{
  if (running && pMemGlobal->getEvent)
    if (e->eType != nilEvent || !pMemGlobal->waitEvent)
    {
      GrabMem();
      S = cons(MakeLispEvent(e), S);
      pMemGlobal->getEvent = false;
      pMemGlobal->waitEvent = false;
      ReleaseMem();
    }
}

static void PopEnvFrame(void)
{
  if (IS_CONS(pMemGlobal->tlNames) &&
      IS_CONS(cdr(pMemGlobal->tlNames)))
  {
    GrabMem();
    pMemGlobal->tlNames   = cdr(pMemGlobal->tlNames);
    pMemGlobal->tlVals    = cdr(pMemGlobal->tlVals);
    pMemGlobal->loadState = LS_INIT;
    ReleaseMem();
  }
  else
    displayError(ERR_O1_STACK_EMPTY);
}

/**********************************************************************/
/* Symbol start                                                       */
/**********************************************************************/
static char *startOfSymbol(FieldPtr field, UInt16 *len)
{
   UInt16 pos1 = 0, pos2 = -1;
   char *s = FldGetTextPtr(field);
   FldGetSelection(field, &pos1, &pos2);
   *len = 0;
   if (pos1 == pos2)
     for (; pos1 >= 0; pos1--)
       if (pos1 == 0 || !isSymbolChar(s[pos1-1])) {
         *len = pos2 - pos1;
         return s+pos1;
       }
   return NULL;
}

/**********************************************************************/
/* Complete symbol                                                    */
/**********************************************************************/
static void completeSymbol(FieldPtr field)
{
   UInt16 len = 0, newLen;
   char *s = startOfSymbol(field, &len), *completion;
   if (len <= 0)
     return;
   completion = completeString(s, len, strStore+1, &newLen, true);
   if (newLen > len)
     FldInsert(field, completion+len, newLen - len);
}

/**********************************************************************/
/* Build list of known symbols                                        */
/**********************************************************************/
static char** symbols;
static void fillSymbolList(FieldPtr field)
{
   static char* emergency[] = {"*** Not enough memory ***"};
   static char* empty[]     = {"*** No match ***"};
   UInt16 num, len = 0;
   ListPtr list = (ListPtr)ptrFromObjID(IDC_PL_SYMS);
   char *s = startOfSymbol(field, &len);
   if (symbols)
     MemPtrFree(symbols);
   if ((symbols = prefixSymbols(s, len, &num)))
     LstSetListChoices(list, symbols, num);
   else
     LstSetListChoices(list, num ? emergency : empty,1);
   list->attr.search = true;
}

/**********************************************************************/
/* Evaluate entered expr: Parse, compile and set state to running     */
/**********************************************************************/
static Boolean doEval(int n)
{
  ErrTry {
    disableButtons();
    setUpEval(FldGetTextPtr(inField), n);
  }
  ErrCatch(err) {
    cleanUpEval(true);
    displayError(err);
  } ErrEndCatch
  ReleaseMem();
  return true;
}

/**********************************************************************/
/* Event handler for main form                                        */
/**********************************************************************/
static Boolean MainFrameHandleEvent(EventType *e)
{
  PTR           res;
  static Char   buf[100];
  static Char   buf1[12];
  static Char   buf2[12];
  static Char   buf3[12];
  Boolean handled = false;
  CALLBACK_PROLOGUE

  DoLMEvent(e);
  handleScrollEvents(e);

  switch (e->eType)
  {
    case nilEvent:
      if (running && !pMemGlobal->waitEvent)
      {
        /*------------------------------------------------------------*/
        /* Run machine some steps                                     */
        /*------------------------------------------------------------*/
        ErrTry {
          GrabMem();
          res = exec();
          if (!running)
          {
            cleanUpEval(true);
            GrabMem();
            printSEXP(res, PRT_OUTFIELD | PRT_ESCAPE | PRT_AUTOLF);
          }
        }
        ErrCatch(err) {
          cleanUpEval(true);
          displayError(err);
        } ErrEndCatch
        ReleaseMem();
      }
      handled = true;
      break;

    case menuEvent:
      switch (e->data.menu.itemID)
      {
        case IDM_ViewStat:
        {
          /*----------------------------------------------------------*/
          /* Execution statistics                                     */
          /*----------------------------------------------------------*/
          UInt16 len;
          if (tickStop <= tickStart)
            StrCopy(buf1,"0.00");
          else
          {
            StrIToA(buf,tickStop-tickStart);
            switch (len = StrLen(buf))
            {
              case 1:
                StrCopy(buf1,"0.0"); StrCat(buf1,buf);
                break;

              case 2:
                StrCopy(buf1,"0."); StrCat(buf1,buf);
                break;

              default:
                StrCopy(buf1,buf); MemMove(buf1+len-1,buf1+len-2,3);
                buf1[len-2] = '.';
                break;
            }
          }
          StrIToA(buf2,numStep);
          StrIToA(buf3,numGC);
          FrmCustomAlert(IDA_STAT_EXE,buf1,buf2,buf3);
          handled = true;
        }
        break;

        case IDM_ViewMemory:
        {
          /*----------------------------------------------------------*/
          /* Memory statistics                                        */
          /*----------------------------------------------------------*/
          Int32 heapUse, atomUse, realUse;
          Int32 vecSize, strSize;
          ErrTry {  
            memStat(&heapUse, &realUse, &atomUse, &vecSize, &strSize);
            formatMemStat(buf, heapUse, heapSize);
            StrCat(buf,"\nAtoms:\t");
            formatMemStat(buf1, atomUse, atomSize);
            StrCat(buf,buf1);
            StrCat(buf,"\nReals:\t");
            formatMemStat(buf1, realUse, realSize);
            StrCat(buf,buf1);
            formatRight(buf2,strSize,11);
            formatRight(buf3,vecSize,11);
            FrmCustomAlert(IDA_STAT_MEM,buf,buf2,buf3);
          }
          ErrCatch(err) {
            displayError(err);
          } ErrEndCatch
          handled = true;
        }
        break;

        case IDM_ViewGUI:
          /*----------------------------------------------------------*/
          /* View standard LispMe GUI elements                        */
          /*----------------------------------------------------------*/
          GrabMem();
          pMemGlobal->ownGUI = false;
          ReleaseMem();
          enableCtls(true);
          handled = true;
          break;

        case IDM_EditClrIn:
          /*----------------------------------------------------------*/
          /* Clear input field                                        */
          /*----------------------------------------------------------*/
          FldDelete(inField, 0, FldGetTextLength(inField));
          handled = true;
          break;

        case IDM_EditClrOut:
          /*----------------------------------------------------------*/
          /* Clear output field                                       */
          /*----------------------------------------------------------*/
          FldDelete(outField, 0, FldGetTextLength(outField));
          handled = true;
          break;

        case IDM_Complete:
          /*----------------------------------------------------------*/
          /* Complete symbol                                          */
          /*----------------------------------------------------------*/
          completeSymbol(inField);
          handled = true;
          break;

        case IDM_OptGlob:
          /*----------------------------------------------------------*/
          /* Display global setup dialog                              */
          /*----------------------------------------------------------*/
          FrmPopupForm(IDD_SetupGlob);
          handled = true;
          break;

        case IDM_OptSess:
          /*----------------------------------------------------------*/
          /* Display session setup dialog                             */
          /*----------------------------------------------------------*/
          if (running)
          {
            cleanUpEval(true);
            displayError(ERR_O2_INTERRUPT);
          }
          FrmPopupForm(IDD_SetupSess);
          handled = true;
          break;

        case IDM_OptReset:
          /*----------------------------------------------------------*/
          /* Reset memory                                             */
          /*----------------------------------------------------------*/
          if (FrmAlert(ERR_O6_CONFIRM) == 0)
          {
            if (running)
            {
              cleanUpEval(true);
              displayError(ERR_O2_INTERRUPT);
            }
            initHeap(true,true);
          }
          handled = true;
          break;

        case IDM_Pickle:
          /*----------------------------------------------------------*/
          /* Pickle session                                           */
          /*----------------------------------------------------------*/
          if (running)
          {
            cleanUpEval(true);
            displayError(ERR_O2_INTERRUPT);
          }
          if (!pMemGlobal->pickled) {
            GrabMem();
            pickle();
            ReleaseMem();
            FrmAlert(IDA_PICKLED);
          }  
          handled = true;
          break;

        case IDC_PB_LOAD:
        case IDC_PB_RELOAD:
        case IDC_PB_POP:
        case IDC_PB_NAMES:
        case IDC_PB_EVAL:
        case IDC_PB_EVAL2:
        case IDC_PB_EVAL3:
        {
          /*----------------------------------------------------------*/
          /* Map these commands to corresponding buttons              */
          /*----------------------------------------------------------*/
          EventType ev; 
          ev.eType = ctlSelectEvent; 
          ev.data.ctlSelect.controlID = e->data.menu.itemID;
          EvtAddEventToQueue(&ev);
          handled = true;
          break;
        }  

        case IDM_HelpAbout:
          /*----------------------------------------------------------*/
          /* Show GNU GPL                                             */
          /*----------------------------------------------------------*/
          FrmAlert(IDA_ABOUT);
          handled = true;
          break;

        case IDM_HelpForm:
          /*----------------------------------------------------------*/
          /* Help for special forms                                   */
          /*----------------------------------------------------------*/
          FrmHelp(HLP_LANG_FORM);
          handled = true;
          break;

        case IDM_HelpFunc:
          /*----------------------------------------------------------*/
          /* Help for functions                                       */
          /*----------------------------------------------------------*/
          FrmHelp(HLP_LANG_FUNC);
          handled = true;
          break;

        case IDM_HelpEvent:
          /*----------------------------------------------------------*/
          /* Help for events                                          */
          /*----------------------------------------------------------*/
          FrmHelp(HLP_LANG_EVENT);
          handled = true;
          break;
      }
      break;

    case frmOpenEvent:
    {
      MemHandle oldHandle;
      startPanel = IDD_MainFrame;
      mainForm   = FrmGetActiveForm();
      inField    = ptrFromObjID(IDC_EF_INPUT);
      outField   = ptrFromObjID(IDC_EF_OUTPUT);
      scrollBar  = ptrFromObjID(IDC_SB_OUTPUT);

      /*--------------------------------------------------------------*/
      /* Init handle for input field                                  */
      /*--------------------------------------------------------------*/
      oldHandle = FldGetTextHandle(inField);
      FldSetTextHandle(inField, inHandle);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Init handle for output field                                 */
      /*--------------------------------------------------------------*/
      oldHandle = FldGetTextHandle(outField);
      FldSetTextHandle(outField, outHandle);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Init other controls                                          */
      /*--------------------------------------------------------------*/
      CtlSetLabel(ptrFromObjID(IDC_ST_SESSION), LispMePrefs.sessDB);
      handleLefty(mainForm);
      if (running)
        disableButtons();
      enableCtls(!pMemGlobal->ownGUI);

      if (!running && launchedExternally)
      {
        /*------------------------------------------------------------*/
        /* Started externally => simulate pressing EVAL               */
        /*------------------------------------------------------------*/
        launchedExternally = false;
        CtlHitControl(ptrFromObjID(IDC_PB_EVAL));
      }
      handled = true;
      break;
    }

    case frmCloseEvent:
      FldCompactText(inField); 
      FldSetTextHandle(inField, NULL);
      FldSetTextHandle(outField, NULL);
      break;
 
    case ctlSelectEvent:
      switch (e->data.ctlSelect.controlID)
      {
        case IDC_PB_EVAL:
          handled = doEval(1);
          break;

        case IDC_PB_EVAL2:
          handled = doEval(2);
          break;

        case IDC_PB_EVAL3:
          handled = doEval(3);
          break;

        case IDC_PB_RELOAD:
          /*----------------------------------------------------------*/
          /* Pop current and reload last loaded memo                  */
          /*----------------------------------------------------------*/
          if (pMemGlobal->loadState != LS_INIT)
          {
            if (pMemGlobal->loadState == LS_LOADED)
              PopEnvFrame();
            startPtr = 0;
            GrabMem(); 
            pMemGlobal->loadState = LS_LOADED;
            ReleaseMem();
            disableButtons();
            ErrTry {
              setUpEval(openSrcFile(pMemGlobal->sourceFmt,
                                    &pMemGlobal->lastSrc),0);
            }
            ErrCatch(err) {
              pMemGlobal->loadState = LS_ERROR;
              cleanUpEval(true);
              displayError(err);
              closeSrcFile();
              handled = true;
              break;
            } ErrEndCatch
            ReleaseMem();
            closeSrcFile();
          }
          else
            displayError(ERR_L5_LAST_NOT_MEMO);
          handled = true;
          break;

        case IDC_PB_BREAK:
          /*----------------------------------------------------------*/
          /* Break excution                                           */
          /*----------------------------------------------------------*/
          cleanUpEval(true);
          displayError(ERR_O2_INTERRUPT);
          handled = true;
          break;

        case IDC_PB_LOAD:
          /*----------------------------------------------------------*/
          /* Load a source memo                                       */
          /*----------------------------------------------------------*/
          FrmPopupForm(IDD_Load);
          handled = true;
          break;

        case IDC_PB_POP:
          /*----------------------------------------------------------*/
          /* Pop last loaded source from stack                        */
          /*----------------------------------------------------------*/
          PopEnvFrame();
          handled = true;
          break;

        case IDC_PB_NAMES:
          /*----------------------------------------------------------*/
          /* Display all available names                              */
          /*----------------------------------------------------------*/
          outPos = 0;
          GrabMem();
          printSEXP(pMemGlobal->tlNames, PRT_OUTFIELD);
          ReleaseMem();
          handled = true;
          break;

        case IDC_PT_SYMS:
          /*----------------------------------------------------------*/
          /* Build list of known symbols                              */
          /*----------------------------------------------------------*/
          fillSymbolList(inField);
          break;

        case IDC_ST_SESSION:
          /*----------------------------------------------------------*/
          /* Display session form                                     */
          /*----------------------------------------------------------*/
          FrmGotoForm(IDD_Sess);
          handled = true;
          break;

        default:
      }
      break;

    case popSelectEvent:
      /*--------------------------------------------------------------*/
      /* Insert selected symbol into input field                      */
      /*--------------------------------------------------------------*/
      if (symbols)
      {
        UInt16 sel = e->data.popSelect.selection, len;
        char*  sym = LstGetSelectionText((ListPtr)e->data.popSelect.listP,sel);
        startOfSymbol(inField, &len); 
        FldInsert(inField, sym+len, StrLen(sym) - len);
      }
      handled = true;
      break;

    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Globals dealing with source memo lists                             */
/**********************************************************************/
static char**     ppSrc;
static SourceRef* srcArr;
static UInt16     numSrc;

/**********************************************************************/
/* Fill list box with memos/memos32/DOCs                              */
/**********************************************************************/
static void fillMemoList(UInt16 format)
{
  static DmOpenRef  srcRef;
  static char* noCategory[] = {"*** Category 'LispMe' not found ***"};
  static char* noMemo[]     = {"*** No memo in 'LispMe' found ***"};
  static char* noDoc[]      = {"*** No DOC files found ***"};
  ListPtr    srcList  = ptrFromObjID(IDC_LIST_SOURCE);
  ControlPtr memoBut  = ptrFromObjID(IDC_PB_LOAD_MEMO);
  ControlPtr peditBut = ptrFromObjID(IDC_PB_LOAD_PEDIT);
  LocalID    srcId;
  Int16      i;
  Boolean    listOK = true;

  if (format == IDC_RB_DOC) {
    /*----------------------------------------------------------------*/
    /* Go thru all databases with type/creator DOC                    */
    /*----------------------------------------------------------------*/
    DmSearchStateType state;
    UInt16 card;

    for (numSrc=0;;++numSrc)
      if (DmGetNextDatabaseByTypeCreator(numSrc==0, &state,
                                         DOC_TYPE, DOC_CREATOR,false,
                                         &card, &srcId) != errNone)
        break;
    if (numSrc == 0) {
      listOK = false;
      LstSetListChoices(srcList, noDoc, 1);
    }
    else {
      ppSrc  = MemPtrNew(numSrc * sizeof(char*));
      srcArr = MemPtrNew(numSrc * sizeof(SourceRef));
      for (i=0;;++i)
        if (DmGetNextDatabaseByTypeCreator(i==0, &state,
                                           DOC_TYPE, DOC_CREATOR,false,
                                           &card, &srcId) != errNone)
          break;
        else {
          srcArr[i].dbId  = srcId;
          srcArr[i].recNr = 1;
          ppSrc[i] = MemPtrNew(dmDBNameLength);
          DmDatabaseInfo(card, srcId, ppSrc[i], NULL, NULL, NULL, NULL,
                         NULL, NULL, NULL, NULL, NULL, NULL);  
        }
      LstSetListChoices(srcList, ppSrc, numSrc);
    } // DOC found
  } // DOC format
  else {
    /*----------------------------------------------------------------*/
    /* Memo[32], go thru all records of category 'LispMe'             */
    /*----------------------------------------------------------------*/
    UInt16     lispCat;
    UInt16     recId   = 0;
    MemHandle  recHand;

    srcId    = format == IDC_RB_MEMO ? memoId : memo32Id;
    srcRef   = DmOpenDatabase(0,srcId,memoDBMode);
    startPtr = 0;
    lispCat  = CategoryFind(srcRef, "LispMe");
    numSrc   = 0;

    if (lispCat == dmAllCategories) {
      listOK = false;
      LstSetListChoices(srcList, noCategory, 1);
    }
    else if ((numSrc = DmNumRecordsInCategory(srcRef, lispCat)) == 0) {
      listOK = false;
      LstSetListChoices(srcList, noMemo, 1);
    }
    else
    {
      ppSrc  = MemPtrNew(numSrc * sizeof(char*));
      srcArr = MemPtrNew(numSrc * sizeof(SourceRef));
      for (i=0; i<numSrc; ++i)
      {
        char  *recPtr, *s, *d;
        recHand         = DmQueryNextInCategory(srcRef, &recId, lispCat);
        recPtr          = MemHandleLock(recHand);
        ppSrc[i]        = MemPtrNew(MAX_LINE_LEN+2);
        srcArr[i].dbId  = srcId;
        srcArr[i].recNr = recId;

        /*--------------------------------------------------------------*/
        /* Copy beginning of memo text upto first \n or MAX_LINE_LEN    */
        /*--------------------------------------------------------------*/
        for (s = recPtr, d = ppSrc[i];
             s-recPtr < MAX_LINE_LEN && *s && *s != '\n';
             ++s, ++d)
          *d = *s;
        if (s-recPtr == MAX_LINE_LEN)
          *d++ = charEllipsis;
        *d = '\0';
        MemHandleUnlock(recHand);
        recId++;
      }
      LstSetListChoices(srcList, ppSrc, numSrc);
    } // memos found 
    DmCloseDatabase(srcRef);
  } // memo list

  /*------------------------------------------------------------------*/
  /* Select buttons according to sensible actions                     */
  /*------------------------------------------------------------------*/
  CtlSetUsable(memoBut,listOK && format == IDC_RB_MEMO);
  CtlSetUsable(peditBut,listOK && ((format == IDC_RB_MEMO && peditID) ||
                                   (format == IDC_RB_MEMO32 && pedit32ID)));
  CtlSetUsable((ControlPtr)ptrFromObjID(IDC_PB_LOAD_OK), listOK);
  CtlSetUsable((ControlPtr)ptrFromObjID(IDC_PB_LOAD_EDIT),
               listOK && format != IDC_RB_DOC);
}

/**********************************************************************/
/* Deallocate memo list structures                                    */
/**********************************************************************/
static void freeMemoList(void)
{
  Int16 i;
  for (i=0; i<numSrc; ++i)
    MemPtrFree(ppSrc[i]);
  if (numSrc) {
    MemPtrFree(ppSrc);
    MemPtrFree(srcArr);
    numSrc = 0;
  }
}

/**********************************************************************/
/* Event handler for load form                                        */
/**********************************************************************/
static Boolean LoadHandleEvent(EventType *e)
{
  Boolean handled = false;
  ListPtr srcList = ptrFromObjID(IDC_LIST_SOURCE);
  CALLBACK_PROLOGUE

  switch (e->eType)
  {
    case lstSelectEvent:
      startPtr = 0;
      break;

    case frmOpenEvent:
    {
      /*--------------------------------------------------------------*/
      /* Disable Memo32 selection if no DB (yet) created              */
      /*--------------------------------------------------------------*/
      if (memo32Id == 0) {
        GrabMem();
        if (pMemGlobal->sourceFmt == IDC_RB_MEMO32)
          pMemGlobal->sourceFmt = IDC_RB_MEMO;
        ReleaseMem();
        CtlHideControl((ControlPtr)ptrFromObjID(IDC_RB_MEMO32));
      }

      /*--------------------------------------------------------------*/
      /* Fill list from Memo DB                                       */
      /*--------------------------------------------------------------*/
      CtlSetValue(ptrFromObjID(pMemGlobal->sourceFmt), true);
      fillMemoList(pMemGlobal->sourceFmt); 
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;
    }

    case frmCloseEvent:
    {
      freeMemoList();
      handled = true;
      break;
    }

    case frmUpdateEvent:
    {
      /*--------------------------------------------------------------*/
      /* Erase button area only before redrawing                      */
      /*--------------------------------------------------------------*/
      RectangleType bottom = {{0,146},{160,14}};
      WinEraseRectangle(&bottom, 0);
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;
    }  

    case keyDownEvent:
    {
      int lines = LstGetVisibleItems(srcList)-1; 
      switch (e->data.keyDown.chr)
      {
        case pageUpChr:
          LstScrollList(srcList, winUp, lines);
          handled = true;
          break;

        case pageDownChr:
          LstScrollList(srcList, winDown, lines);
          handled = true;
          break;
      }
      break;
    }  

    case ctlSelectEvent:
    {
      UInt16 sel = LstGetSelection(srcList);
      UInt16 id  = e->data.ctlSelect.controlID;
      switch (id)
      {
        case IDC_RB_MEMO:  
        case IDC_RB_MEMO32:  
        case IDC_RB_DOC:  
          if (id != pMemGlobal->sourceFmt) {
            /*--------------------------------------------------------*/
            /* Reload memo list, enable editor buttons and remember it*/
            /*--------------------------------------------------------*/
            GrabMem();
            pMemGlobal->sourceFmt = id;
            ReleaseMem();
            freeMemoList();
            fillMemoList(id);
            FrmUpdateForm(IDD_Load, 0);
          }  
          handled = true;
          break; 

        case IDC_PB_LOAD_OK:
        {
          /*----------------------------------------------------------*/
          /* Load selected memo                                       */
          /*----------------------------------------------------------*/
          if (sel != -1)
          {
            GrabMem();
            pMemGlobal->lastSrc   = srcArr[sel];
            pMemGlobal->loadState = LS_LOADED;
            
            ErrTry {
              setUpEval(openSrcFile(pMemGlobal->sourceFmt,
                                    &pMemGlobal->lastSrc),0);
            }
            ErrCatch(err) {
              pMemGlobal->loadState = LS_ERROR;
              cleanUpEval(false);
              displayError(err);
              closeSrcFile(); 
              handled = true;
              break;
            } ErrEndCatch
            ReleaseMem();
            closeSrcFile();
          } // anything selected
        } // case PB_OK
        disableButtons();

        /*------------------------------------------------------------*/
        /* Load was OK, now clean up dialog (=fall thru to cancel)    */
        /*------------------------------------------------------------*/
        case IDC_PB_LOAD_CANCEL:
        {
          freeMemoList(); 
          FrmReturnToForm(IDD_MainFrame);
          handled = true;
          break;
        }

        case IDC_PB_LOAD_MEMO:
          /*----------------------------------------------------------*/
          /* Call MemoPad with selected memo, jump to error position, */
          /* if known                                                 */
          /*----------------------------------------------------------*/
          if (sel != -1)
            startMemoPad(srcArr[sel].recNr, false, false);
          handled = true;
          break;

        case IDC_PB_LOAD_PEDIT:
          /*----------------------------------------------------------*/
          /* Call PEDIT with selected memo, jump to error position,   */
          /* if known                                                 */
          /*----------------------------------------------------------*/
          if (sel != -1)
            startMemoPad(srcArr[sel].recNr, true,
                         pMemGlobal->sourceFmt == IDC_RB_MEMO32);
          handled = true;
          break;

        case IDC_PB_LOAD_EDIT:
          /*----------------------------------------------------------*/
          /* Call internal editor with selected memo                  */
          /*----------------------------------------------------------*/
          if (sel != -1)
          {
            selMemo = sel; 
            FrmPopupForm(IDD_Edit);
          }
          handled = true;
          break;
      }
    }
    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Event handler for edit form                                        */
/**********************************************************************/
static Boolean EditFrameHandleEvent(EventType *e)
{
  static FieldPtr  editField;
  static DmOpenRef srcRef;
  Boolean handled = false;
  CALLBACK_PROLOGUE

  handleScrollEvents(e);
  switch (e->eType)
  {
    case frmOpenEvent:
    {
      /*--------------------------------------------------------------*/
      /* Set field handle to memo DB record                           */
      /*--------------------------------------------------------------*/
      MemHandle oldHandle, recHand;
      FormPtr frm = FrmGetActiveForm();
      srcRef  = DmOpenDatabase(0, srcArr[selMemo].dbId, dmModeReadWrite);
      recHand = DmQueryRecord(srcRef, srcArr[selMemo].recNr);
      handleLefty(frm);
      editField = ptrFromObjID(IDC_EF_OUTPUT);

      /*--------------------------------------------------------------*/
      /* Set field size according to preferences                      */
      /*--------------------------------------------------------------*/
      FldSetMaxChars(editField,
                     LispMePrefs.bigMemo ? BIG_EDIT : STD_EDIT);

      oldHandle = FldGetTextHandle(editField);
      FldSetTextHandle(editField, recHand);
      if (oldHandle)
        MemHandleFree(oldHandle);

      /*--------------------------------------------------------------*/
      /* Scroll to error position if known                            */
      /*--------------------------------------------------------------*/
      if (startPtr)
      {
        FldSetSelection(editField, currPtr-startPtr-1, currPtr-startPtr);
        FldSetInsPtPosition(editField, currPtr-startPtr-1);
      }  
      else 
        FldSetInsPtPosition(editField, 0);
      updateScrollBar();
      FrmDrawForm(frm);
      FrmSetFocus(frm, FrmGetObjectIndex(frm,IDC_EF_OUTPUT));
      handled = true;
      break;
    }

    case frmCloseEvent:
      FldSetTextHandle(editField, NULL);
      DmCloseDatabase(srcRef);
      handled = true;
      break;

    case ctlSelectEvent:
      switch (e->data.ctlSelect.controlID)
      {
        case IDC_PB_EDIT_DONE:
          FldSetTextHandle(editField, NULL);
          DmCloseDatabase(srcRef);
          FrmReturnToForm(IDD_Load);
          handled = true;
          break;

        case IDC_PB_EDIT_EVAL:
        {
          /*----------------------------------------------------------*/
          /* Copy selection to input field and press EVAL             */
          /*----------------------------------------------------------*/
          UInt16 start, end;
          FldGetSelection(editField, &start, &end);
          FldSetSelection(inField, 0, FldGetTextLength(inField));
          FldInsert(inField, FldGetTextPtr(editField)+start, end-start);
          FldSetTextHandle(editField, NULL);
          DmCloseDatabase(srcRef); // fixed 17.07.2001
          FrmReturnToForm(IDD_Load);
          CtlHitControl(ptrFromObjID(IDC_PB_LOAD_CANCEL));
          CtlHitControl(FrmGetObjectPtr(mainForm,
                          FrmGetObjectIndex(mainForm, IDC_PB_EVAL)));
          handled = true;
          break;
        }  

        case IDC_PT_SYMS:
          /*----------------------------------------------------------*/
          /* Build list of known symbols                              */
          /*----------------------------------------------------------*/
          fillSymbolList(editField);
          break;
      }
      break; 

    case popSelectEvent:
      /*--------------------------------------------------------------*/
      /* Insert selected symbol into field                            */
      /*--------------------------------------------------------------*/
      if (symbols)
      {
        UInt16 sel = e->data.popSelect.selection, len;
        char*  sym = LstGetSelectionText((ListPtr)e->data.popSelect.listP,sel);
        startOfSymbol(editField, &len); 
        FldInsert(editField, sym+len, StrLen(sym) - len);
      }
      handled = true;
      break;

    case menuEvent:
      switch (e->data.menu.itemID)
      {
        case IDM_Complete:
          /*----------------------------------------------------------*/
          /* Complete symbol                                          */
          /*----------------------------------------------------------*/
          completeSymbol(editField);
          handled = true;
          break;
      }
    default:
  }
  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* Stub for Scheme event handler                                      */
/**********************************************************************/
static Boolean LispHandleEvent(EventType *e)
{
  static  UInt32 wdog[] = {1000ul,3000ul,6000ul,30000ul};
  Boolean handled = true;
  UInt32  timeLimit;

  CALLBACK_PROLOGUE

  if (LispMePrefs.watchDogSel == 4)
    timeLimit = ULONG_MAX;
  else
    timeLimit = TimGetTicks()+wdog[LispMePrefs.watchDogSel];

  if (e->eType == frmOpenEvent)
    FrmDrawForm(FrmGetActiveForm());

  GrabMem();
  if (!returning)
  {
    S = cons(contexts[actContext].handler,cons(MakeLispEvent(e),NIL));
    C = cons(MKINT(APC),cons(MKINT(STOP),NIL));
    E = pMemGlobal->tlVals;
    W = NIL;
  }

  running = true;
again:
  ErrTry {
    quitHandler = changeHandler = false;
    evalMacro = true;
    handled = exec() != FALSE;
    evalMacro = false;
    ReleaseMem();
  }
  ErrCatch(err) {
    displayError(err);
    goto cleanup;
  } ErrEndCatch

  returning = false;
  if (quitHandler)
  {
    /*----------------------------------------------------------------*/
    /* frm-return was called, restore context as before frm-popup     */
    /*----------------------------------------------------------------*/
    GrabMem();
    W = contexts[actContext--].prevCont;
    S = cons(car(S),car(W));
    E = cadr(W);
    C = caddr(W);
    D = cdddr(W);
    returning = true;
    ReleaseMem();
    FrmReturnToForm(0);
    GUIFreeList();
  }
  else if (changeHandler)
  {
    /*----------------------------------------------------------------*/
    /* frm-goto was called, leave this handler but don't change stack */
    /*----------------------------------------------------------------*/
  }
  else if (running)
  {
    if (TimGetTicks() <= timeLimit)
    {
      GrabMem();
      goto again;
    }
    /*----------------------------------------------------------------*/
    /* Too many steps !                                               */
    /*----------------------------------------------------------------*/
    displayError(ERR_U3_WATCHDOG);
  cleanup:
    FrmReturnToForm(IDD_MainFrame);
    cleanUpEval(true);
    enableCtls(true);
    quitHandler = true;
  }

  CALLBACK_EPILOGUE
  return handled;
}

/**********************************************************************/
/* init all subsystems                                                */
/**********************************************************************/
static Boolean StartApp(char* startSess)
{
  SystemPreferencesType sysp;

  Err     error;
  UInt32  ver;

  /*------------------------------------------------------------------*/
  /* Check for PalmOS2                                                */
  /*------------------------------------------------------------------*/
  error = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &ver);
  if (error || ver < 0x02000000)
  {
    FrmAlert(ERR_O4_OS_VERSION);
    return false;
  }

  /*------------------------------------------------------------------*/
  /* Version-specific settings                                        */
  /*------------------------------------------------------------------*/
  palmIII      = ver >= 0x03000000;
  charEllipsis = ver >= 0x03100000 ? 0x18 : 0x85;
  charNumSpace = ver >= 0x03100000 ? 0x19 : 0x80;
  newGraphic   = ver >= 0x03500000;

  /*------------------------------------------------------------------*/
  /* Open DB and init memory                                          */
  /*------------------------------------------------------------------*/
  startPanel = InitDB(startSess) ? IDD_MainFrame : IDD_Sess;
  if (startSess && startPanel == IDD_Sess)
  {
    FrmCustomAlert(ERR_OX_SESSION_MISS,startSess,0,0);
    return false;
  }
  InitMathLib();

  /*------------------------------------------------------------------*/
  /* Search memo DB and set access mode acc. to secret pref.          */
  /*------------------------------------------------------------------*/
  memo32Id = DmFindDatabase(0, "Memo32DB");
  memoId   = DmFindDatabase(0, "MemoDB");
  ErrFatalDisplayIf(!memoId,"No memoDB?");
  PrefGetPreferences(&sysp);
  if (!sysp.hideSecretRecords)
    memoDBMode |= dmModeShowSecret;

  /*------------------------------------------------------------------*/
  /* Check for different flavours of pedit.                           */
  /*------------------------------------------------------------------*/
  memoPadID  = findApp(sysFileCMemo);
  (peditID   = pedit32ID = findApp('pnPr')) ||
  (pedit32ID = findApp('pn32')              ,
   (peditID  = findApp('pn10'))             ||
   (peditID  = findApp('pnLi')));
    
  /*------------------------------------------------------------------*/
  /* Search HanDBase application                                      */
  /*------------------------------------------------------------------*/
  handBaseID = DmFindDatabase(0, "HanDBase");
  return true;
}

/**********************************************************************/
/* shutdown all subsystems                                            */
/**********************************************************************/
static void StopApp(void)
{
  FrmCloseAllForms();
  CloseMathLib();
  ShutdownDB();
}

