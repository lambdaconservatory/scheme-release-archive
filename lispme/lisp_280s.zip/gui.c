/**********************************************************************/
/*                                                                    */
/* gui.c:   LISPME user interface functions                           */
/*                                                                    */
/* LispMe System (c) FBI Fred Bayer Informatics                       */
/*                                                                    */
/* Distributed under the GNU General Public License;                  */
/* see the README file. This code comes with NO WARRANTY.             */
/*                                                                    */
/* Modification history                                               */
/*                                                                    */
/* When?      What?                                              Who? */
/* -------------------------------------------------------------------*/
/* 10.01.1999 New                                                FBI  */
/* 25.10.1999 Prepared for GPL release                           FBI  */
/* 01.04.2000 Prepared for GCC 2.0 and SDK 3.5                   FBI  */
/*                                                                    */
/**********************************************************************/

/**********************************************************************/
/* Includes                                                           */
/**********************************************************************/
#include "gui.h"
#include "io.h"
#include "util.h"
#include "LispMe.h"
#include "vm.h"
#include "util.h"

/**********************************************************************/
/* Static functions                                                   */
/**********************************************************************/
static void* checkedPtrFromObjID(UInt16 obj,
                                 FormObjectKind kind,
                                 char* msg);
static UInt16 checkedIndexFromObjID(UInt16 obj);

/**********************************************************************/
/* Global data                                                        */
/**********************************************************************/
struct UIContext contexts[MAX_GUI_NEST];
int              actContext = -1;
char**           pSlots;
int              numSlots;

/**********************************************************************/
/* Replace current LispMe form by another one                         */
/**********************************************************************/
void gotoForm(int resId, PTR handler)
{
  MemHandle frmHand = DmGetResource('tFRM',resId);
  if (frmHand)
  {
    DmReleaseResource(frmHand);
    if (actContext < 0)
      ErrThrow(ERR_U6_INVALID_GOTO);
    running = false;
    contexts[actContext].handler = handler;
    ReleaseMem();
    FrmGotoForm(resId);
    GrabMem();
    changeHandler = true;
    return;
  }
  error1(ERR_U1_INVALID_FORM, MKINT(resId));
}
/**********************************************************************/
/* Popup a nested LispMe form                                         */
/**********************************************************************/
void popupForm(int resId, PTR handler)
{
  MemHandle frmHand = DmGetResource('tFRM',resId);
  if (frmHand)
  {
    DmReleaseResource(frmHand);
    running = !++actContext;
    if (actContext >= MAX_GUI_NEST-1)
      ErrThrow(ERR_U7_FORM_NEST);
    contexts[actContext].prevCont = cons(cddr(S),cons(E,cons(cdr(C),D)));
    contexts[actContext].handler  = handler;
    ReleaseMem();
    FrmPopupForm(resId);
    GrabMem();
    changeHandler = false;
    return;
  }
  error1(ERR_U1_INVALID_FORM, MKINT(resId));
}

/**********************************************************************/
/* index from ID (check for valid ID)                                 */
/**********************************************************************/
static UInt16 checkedIndexFromObjID(UInt16 obj)
{
  FormPtr frm = FrmGetActiveForm();
  int i;
  for (i=FrmGetNumberOfObjects(frm)-1;i>=0;--i)
    if (FrmGetObjectId(frm,i) == obj)
      return i;
  error1(ERR_U2_INVALID_OBJ, MKINT(obj));
}

/**********************************************************************/
/* Get field text                                                     */
/**********************************************************************/
PTR  GUIfldGetText(PTR id)
{
  char* p;
  checkInt(id);
  p = FldGetTextPtr(checkedPtrFromObjID(INTVAL(id),frmFieldObj,"field"));
  return p ? str2Lisp(p) : EMPTY_STR;
}

/**********************************************************************/
/* Get field scroll parameters                                        */
/**********************************************************************/
PTR  GUIfldGetScroll(PTR id)
{
  UInt16 scrPos, totLines, visLines;

  checkInt(id);
  FldGetScrollValues(checkedPtrFromObjID(INTVAL(id),frmFieldObj,"field"),
                     &scrPos, &totLines, &visLines);
  return cons(MKINT(scrPos), 
           cons(MKINT(totLines),
             cons(MKINT(visLines), NIL)));
}

/**********************************************************************/
/* Get list text                                                      */
/**********************************************************************/
PTR  GUIlstGetText(PTR id, PTR obj)
{
  char* p;
  checkInt(id);
  checkInt(obj);
  p = LstGetSelectionText(checkedPtrFromObjID(INTVAL(id),frmListObj,"list"),
                           INTVAL(obj));
  return p ? str2Lisp(p) : EMPTY_STR;
}

/**********************************************************************/
/* Set list choices                                                   */
/* This currently allows only one list to avoid leaking               */
/**********************************************************************/
void GUIlstSetItems(PTR id, PTR items)
{
  ListPtr lst = checkedPtrFromObjID(INTVAL(id),frmListObj,"list");
  int i;
 
  GUIFreeList();

  if ((numSlots = listLength(items)))
  {
    pSlots   = MemPtrNew(numSlots*sizeof(char*));
    MemSet(pSlots,numSlots*sizeof(char*),0);
  }
  for (i=0;i<numSlots;++i)
  {
    printSEXP(car(items), PRT_MESSAGE);
    if (!(pSlots[i] = MemPtrNew(StrLen(msg)+1)))
    {
      GUIFreeList();
      ErrThrow(ERR_M5_LIST);
    }
    StrCopy(pSlots[i],msg);
    items = cdr(items);
  }
  LstSetListChoices(lst,pSlots,numSlots);
  LstDrawList(lst);
}

/**********************************************************************/
/* Free list choices                                                  */
/**********************************************************************/
void GUIFreeList(void)
{
  int i;

  if (pSlots)
  {
    for (i=numSlots-1;i>=0;--i)
      if (pSlots[i])
        MemPtrFree(pSlots[i]);
    MemPtrFree(pSlots);
  }
  pSlots = NULL;
  numSlots = 0;
}

/**********************************************************************/
/* ptr from ID (check for valid ID and kind)                          */
/**********************************************************************/
static void* checkedPtrFromObjID(UInt16 obj,
                                 FormObjectKind kind, char* msg)
{
  FormPtr frm = FrmGetActiveForm();
  UInt16  n   = checkedIndexFromObjID(obj);

  if (FrmGetObjectType(frm,n) != kind)
  {
    errInfo = msg;
    error1(ERR_U5_INVALID_KIND, MKINT(obj));
  }
  return FrmGetObjectPtr(frm,n);
}

/**********************************************************************/
/* Set field text                                                     */
/**********************************************************************/
void GUIfldSetText(PTR id, PTR obj)
{
  FieldPtr  fld;
  MemHandle oldH, newH;

  checkInt(id);
  printSEXP(obj, PRT_MESSAGE);
  fld  = checkedPtrFromObjID(INTVAL(id),frmFieldObj,"field");
  oldH = FldGetTextHandle(fld);
  newH = MemHandleNew(StrLen(msg)+1);
  StrCopy(MemHandleLock(newH),msg);
  MemHandleUnlock(newH);
  FldSetTextHandle(fld, newH);
  FldDrawField(fld);
  if (oldH)
    MemHandleFree(oldH);
}

/**********************************************************************/
/* Scroll field text                                                  */
/**********************************************************************/
void GUIfldScroll(PTR id, PTR obj)
{
  FieldPtr fld;
  Int16    delta;

  checkInt(id);
  checkInt(obj);
  delta = INTVAL(obj);
  fld  = checkedPtrFromObjID(INTVAL(id),frmFieldObj,"field");
  if (delta > 0) {
    if (FldScrollable(fld, winDown))
      FldScrollField(fld, delta, winDown);
  } else if (delta < 0) {
    if (FldScrollable(fld, winUp))
      FldScrollField(fld, -delta, winUp);
  }  
}

/**********************************************************************/
/* Do a clipboard operation with the field                            */
/**********************************************************************/
void GUIfldClipboardOp(PTR id, int op)
{
  FieldPtr  fld;

  checkInt(id);
  fld  = checkedPtrFromObjID(INTVAL(id),frmFieldObj,"field");
  switch (op) {
    case 0: FldCut(fld);   break;
    case 1: FldCopy(fld);  break;
    case 2: FldPaste(fld); break;
    case 3: FldUndo(fld);  break;
  }
}

/**********************************************************************/
/* Get control value                                                  */
/**********************************************************************/
PTR  GUIctlGetVal(PTR id)
{
  checkInt(id);
  return CtlGetValue(
           checkedPtrFromObjID(INTVAL(id),frmControlObj,"control"))
         ? TRUE : FALSE;
}

/**********************************************************************/
/* Set control value                                                  */
/**********************************************************************/
void GUIctlSetVal(PTR id, PTR obj)
{
  checkInt(id);
  CtlSetValue(checkedPtrFromObjID(INTVAL(id),frmControlObj,"control"),
              obj!=FALSE);
}

/**********************************************************************/
/* Get scrollbar values                                               */
/**********************************************************************/
PTR  GUIsclGetVal(PTR id)
{
  Int16 curr, minP, maxP, pageSize;

  checkInt(id);
  SclGetScrollBar(checkedPtrFromObjID(INTVAL(id),frmScrollBarObj,
                                      "scrollbar"),
                  &curr, &minP, &maxP, &pageSize);
  return cons(MKINT(curr), 
           cons(MKINT(minP),
             cons(MKINT(maxP),
               cons(MKINT(pageSize), NIL))));
}

/**********************************************************************/
/* Set scrollbar values                                               */
/**********************************************************************/
void GUIsclSetVal(PTR id, PTR obj)
{
  checkInt(id);
  if (listLength(obj) != 4 || 
      !IS_INT(car(obj)) ||
      !IS_INT(cadr(obj)) ||
      !IS_INT(caddr(obj)) ||
      !IS_INT(cadddr(obj)) ||
      INTVAL(cadr(obj)) > INTVAL(caddr(obj)))
    parmError(obj,"scl-set-val");

  SclSetScrollBar(checkedPtrFromObjID(INTVAL(id),frmScrollBarObj,
                                      "scrollbar"),
                  INTVAL(car(obj)),
                  INTVAL(cadr(obj)),
                  INTVAL(caddr(obj)),
                  INTVAL(cadddr(obj)));
}

/**********************************************************************/
/* Get list selection                                                 */
/**********************************************************************/
PTR  GUIlstGetSel(PTR id)
{
  UInt16 n;

  checkInt(id);
  n = LstGetSelection(checkedPtrFromObjID(INTVAL(id),frmListObj,"list"));
  return n==-1 ? FALSE : MKINT(n);
}

/**********************************************************************/
/* Set list selection                                                 */
/**********************************************************************/
void GUIlstSetSel(PTR id, PTR obj)
{
  checkInt(id);
  if (obj==FALSE)
    obj=MKINT(-1);
  checkInt(obj);
  LstSetSelection(checkedPtrFromObjID(INTVAL(id),frmListObj,"list"),
                  INTVAL(obj));
}

/**********************************************************************/
/* Set focus                                                          */
/**********************************************************************/
void GUIfrmSetFocus(PTR id)
{
  checkInt(id);
  FrmSetFocus(FrmGetActiveForm(),checkedIndexFromObjID(INTVAL(id)));
}

/**********************************************************************/
/* Get focus                                                          */
/**********************************************************************/
PTR GUIfrmGetFocus(void)
{
  FormPtr frm = FrmGetActiveForm();
  UInt16  n   = FrmGetFocus(frm);
  return n==-1 ? FALSE : MKINT(FrmGetObjectId(frm,n));
}

/**********************************************************************/
/* Show/hide a form object                                            */
/**********************************************************************/
void GUIfrmShow(PTR id, PTR show)
{
  FormPtr frm = FrmGetActiveForm();

  checkInt(id);
  if (show==FALSE)
    FrmHideObject(frm,checkedIndexFromObjID(INTVAL(id)));
  else
    FrmShowObject(frm,checkedIndexFromObjID(INTVAL(id)));
}
