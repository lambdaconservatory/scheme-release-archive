#ifdef __GNUC__
  yes;
#endif
