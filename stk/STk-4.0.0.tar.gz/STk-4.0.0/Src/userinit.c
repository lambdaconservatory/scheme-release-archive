/*
 *
 * u s e r i n i t . c			-- The place where user put his/her
 *					   initialization
 *
 * Copyright � 1993-1999 Erick Gallesio - I3S-CNRS/ESSI <eg@unice.fr>
 * 
 *
 * Permission to use, copy, modify, distribute,and license this
 * software and its documentation for any purpose is hereby granted,
 * provided that existing copyright notices are retained in all
 * copies and that this notice is included verbatim in any
 * distributions.  No written agreement, license, or royalty fee is
 * required for any of the authorized uses.
 * This software is provided ``AS IS'' without express or implied
 * warranty.
 *
 *           Author: Erick Gallesio [eg@kaolin.unice.fr]
 *    Creation date: 23-Jan-1994 19:09
 * Last file update:  3-Sep-1999 21:02 (eg)
 */

#include "stk.h"

void STk_user_init(void)
{
  /* Put here the code you want to be run at init time */
}

void STk_user_cleanup(void)
{
  /* Put here the code you want to be run when the interpreter dies */
}
