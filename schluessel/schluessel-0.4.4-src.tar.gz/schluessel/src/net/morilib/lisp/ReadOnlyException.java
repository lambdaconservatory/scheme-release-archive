package net.morilib.lisp;

/**
 * 
 *
 *
 * @author MORIGUCHI, Yuichiro 2011/07/09
 */
public class ReadOnlyException extends Exception {

	//
	static final long serialVersionUID = 3257185828837989322L;

}