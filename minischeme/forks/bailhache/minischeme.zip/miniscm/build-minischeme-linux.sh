cc -w -g -DLINUX -DCONSOLE -o minischeme-linux maincsl.c mslpia-mpf.c ext-linux.c -lm
