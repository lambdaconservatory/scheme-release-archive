
#include "mslpia.h"

#define DECL
#define INIT(x) = x
#define DECLINIT

#include "data.h"
