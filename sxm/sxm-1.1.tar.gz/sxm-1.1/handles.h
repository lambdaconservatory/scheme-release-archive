
/* os-dependent handles: unix cgi version */

#define HT_FILE_LOCK 1


