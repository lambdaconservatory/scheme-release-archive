#! C:/mksnt/sh.exe

java -classpath "C:\usr\local\kawa\kawa-1.6.1-compiled.zip;C:\usr\local\java\jdk1.1.5\lib\classes.zip;" gnu.bytecode.dump $*

