head	1.4;
access;
symbols;
locks; strict;
comment	@# @;


1.4
date	2004.11.27.18.11.15;	author carr;	state Exp;
branches;
next	1.3;

1.3
date	99.11.17.21.58.30;	author carr;	state Exp;
branches;
next	1.2;

1.2
date	99.06.11.06.46.24;	author carr;	state Exp;
branches;
next	1.1;

1.1
date	99.06.11.06.30.04;	author carr;	state Exp;
branches;
next	;


desc
@@


1.4
log
@*** empty log message ***
@
text
@;;;;                            Terms and Conditions 
;;;;             
;;;;              LLAVA COPYRIGHT AND PERMISSION NOTICE Version 1.0
;;;; 
;;;; Copyright (c) 1997, 1998, 1999, 2000, 2001, 2002 Harold Carr
;;;; All rights reserved.
;;;; 
;;;; Permission is hereby granted, free of charge, to any person obtaining
;;;; a copy of this software and associated documentation files (the
;;;; "Software"), to deal in the Software without restriction, including
;;;; without limitation the rights to use, copy, modify, merge, publish,
;;;; distribute, and/or sell copies of the Software, and to permit persons
;;;; to whom the Software is furnished to do so, provided that the above
;;;; copyright notice(s) and this permission notice appear in all copies of
;;;; the Software and that both the above copyright notice(s) and this
;;;; permission notice appear in supporting documentation.
    ;;;; 
;;;; THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
;;;; EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
;;;; MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
;;;; OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
;;;; HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY
;;;; SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER
;;;; RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
;;;; CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
;;;; CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
;;;; 
;;;; Except as contained in this notice, the name of a copyright holder
;;;; shall not be used in advertising or otherwise to promote the sale, use
;;;; or other dealings in this Software without prior written authorization
;;;; of the copyright holder.


package hc.llava;

import com.ibm.jikes.skij.*;

public class Foo
{
    public String fooBar(String a1)
	throws SchemeException
    {
	String ret = "fooBar " + a1;
	System.out.println(ret);
	return ret;
    }
}
@


1.3
log
@*** empty log message ***
@
text
@d1 47
a47 14
package hc.lava;

import com.ibm.jikes.skij.*;

public class Foo
{
    public String fooBar(String a1)
	throws SchemeException
    {
	String ret = "fooBar " + a1;
	System.out.println(ret);
	return ret;
    }
}
@


1.2
log
@*** empty log message ***
@
text
@d1 1
a1 1
package hc.util;
d5 1
a5 1
public interface Foo
d7 7
a13 2
    public String bar(String a1)
	throws SchemeException;
@


1.1
log
@Initial revision
@
text
@d3 2
d7 2
a8 1
    public String bar(String a1);
@
