head	1.3;
access;
symbols;
locks; strict;
comment	@# @;


1.3
date	2004.11.27.18.11.15;	author carr;	state Exp;
branches;
next	1.2;

1.2
date	99.11.17.21.58.30;	author carr;	state Exp;
branches;
next	1.1;

1.1
date	99.11.17.11.19.47;	author carr;	state Exp;
branches;
next	;


desc
@@


1.3
log
@*** empty log message ***
@
text
@# Copyright (c) 1997 - 2004 Harold Carr
#
# This work is licensed under the Creative Commons Attribution License.
# To view a copy of this license, visit 
#   http://creativecommons.org/licenses/by/2.0/
# or send a letter to
#   Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#-----------------------------------------------------------------------------



package hc.llava;

public class SomeException extends Exception {}
@


1.2
log
@*** empty log message ***
@
text
@d1 14
a14 3
package hc.lava;

public class SomeException extends Exception {}
@


1.1
log
@Initial revision
@
text
@d1 1
a1 1
package hc.tmp;
@
