The final PDF version of this paper was created on a machine by
Carl Shapiro.  See ilc2005.tex log for revision 1.11 for details.
