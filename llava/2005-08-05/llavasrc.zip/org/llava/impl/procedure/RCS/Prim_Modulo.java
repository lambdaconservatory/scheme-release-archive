head	1.4;
access;
symbols;
locks; strict;
comment	@# @;


1.4
date	2004.12.09.01.21.31;	author carr;	state Exp;
branches;
next	1.3;

1.3
date	2004.11.26.17.40.23;	author carr;	state Exp;
branches;
next	1.2;

1.2
date	2002.10.12.13.27.02;	author carr;	state Exp;
branches;
next	1.1;

1.1
date	2001.07.20.17.13.52;	author carr;	state Exp;
branches;
next	;


desc
@@


1.4
log
@Package movement.
@
text
@/*
Copyright (c) 1997 - 2004 Harold Carr

This work is licensed under the Creative Commons Attribution License.
To view a copy of this license, visit 
  http://creativecommons.org/licenses/by/2.0/
or send a letter to
  Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
------------------------------------------------------------------------------
*/

/**
 * Created       : 2001 Jul 21 (Sat) 01:11:16 by Harold Carr.
 * Last Modified : 2004 Dec 07 (Tue) 19:08:33 by Harold Carr.
 */

package org.llava.impl.procedure;

import org.llava.F;
import org.llava.Pair;
import org.llava.runtime.Engine;

import org.llava.impl.procedure.PrimitiveProcedure;

public class Prim_Modulo
    extends
	PrimitiveProcedure
{
    public Prim_Modulo ()
    {
    }

    public Prim_Modulo newPrim_Modulo ()
    {
	return new Prim_Modulo();
    }

    public Object apply (Pair args, Engine engine)
    {
	checkNumArgs(args, 2);
	return F.newInteger(((Integer)args.car()).intValue() 
			    % 
			    ((Integer)args.cadr()).intValue());
	    
    }
}

// End of file.

@


1.3
log
@working checkpoint
@
text
@d12 4
d17 26
a42 30
/**
 * Created       : 2001 Jul 21 (Sat) 01:11:16 by Harold Carr.
 * Last Modified : 2001 Jul 21 (Sat) 01:12:57 by Harold Carr.
 */

package org.llava.impl.runtime.procedure.primitive.java;

import org.llava.impl.F;
import org.llava.lang.types.Pair;
import org.llava.impl.runtime.Engine;
import org.llava.impl.runtime.procedure.primitive.PrimitiveProcedure;

public class Prim_Modulo
    extends
	PrimitiveProcedure
{
    public Prim_Modulo ()
    {
    }

    public Prim_Modulo newPrim_Modulo ()
    {
	return new Prim_Modulo();
    }

    public Object apply (Pair args, Engine engine)
    {
	checkNumArgs(args, 2);
	return F.newInteger(((Integer)args.car()).intValue() 
			    % 
d44 6
a49 5
	    
    }
}

// End of file.
@


1.2
log
@*** empty log message ***
@
text
@d1 12
d18 1
a18 1
package lavaProfile.runtime.procedure.primitive.java;
d20 4
a23 4
import lavaProfile.F;
import lava.lang.types.Pair;
import lavaProfile.runtime.Engine;
import lavaProfile.runtime.procedure.primitive.PrimitiveProcedure;
@


1.1
log
@Initial revision
@
text
@d1 36
a36 37
/**
 * Created       : 2001 Jul 21 (Sat) 01:11:16 by Harold Carr.
 * Last Modified : 2001 Jul 21 (Sat) 01:12:57 by Harold Carr.
 */

package lavaProfile.runtime.procedure.primitive.java;

import lavaProfile.F;
import lava.lang.types.Pair;
import lavaProfile.runtime.Engine;
import lavaProfile.runtime.procedure.primitive.PrimitiveProcedure;

public class Prim_Modulo
    extends
	PrimitiveProcedure
{
    public Prim_Modulo ()
    {
    }

    public Prim_Modulo newPrim_Modulo ()
    {
	return new Prim_Modulo();
    }

    public Object apply (Pair args, Engine engine)
    {
	checkNumArgs(args, 2);
	return
	    ((Integer)args.car()).intValue() 
	    % 
	    ((Integer)args.cadr()).intValue();
	    
    }
}

// End of file.
@
