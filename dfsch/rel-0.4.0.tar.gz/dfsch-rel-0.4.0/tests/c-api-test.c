#include "tests/test-macros.h"
#include <dfsch/dfsch.h>

int main(int argc, char**argv){
  TEST_INIT(argc, argv);


  TEST_EXIT(1);
}

