#include "dfsch-ext/example.h"

/* Write common code useful for C modules here, when your module is
   only thin wrapper you can probably omit this file and
   libdfsch-example.so library */
