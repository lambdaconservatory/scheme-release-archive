#ifndef H__dfsch_ext__example__
#define H__dfsch_ext__example__

#include <dfsch/dfsch.h>

/* Write prototypes for functionality exported by example.c here */

#endif
