# zip

For example:

    ]=> (zip '(a b c) '(1 2 3))
    ((a 1) (b 2) (c 3))
    ]=> (zip #(foo bar baz quux) (make-number-sequence ))
    ((foo 0) (bar 1) (baz 2) (quux 3))


