/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/kappa, an opus of Qfwfq

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

#ifndef lint
static char rcsid[] = "@(#)$Header: /u/master/rhizome/kappa/test.c,v 1.3 1996/10/10 08:26:48 qfwfq Exp $";
#endif
/*
 * $Log: test.c,v $
 * Revision 1.3  1996/10/10 08:26:48  qfwfq
 * Ported to Win32 environment.
 *
 * Revision 1.2  1996/09/06 06:08:36  qfwfq
 * Version 0.20 unix revision is up.
 *
 * Revision 1.1  1993/11/08 14:02:21  qfwfq
 * Initial revision
 *
 */

/*
 * Test driver for rhizome/kappa.
 */
#include "rhizome.h"

#include <stdio.h>
#include <string.h>
#ifdef WIN32
#	include <io.h>
#endif
#ifdef RK_USE_LOCALE
#	include <locale.h>
#endif
#ifndef __CYGWIN32__
extern int errno;
#else
#include <errno.h>
#endif

static rk_object read_proc, print_proc, error_proc;
static rk_object getchar_proc, ungetchar_proc, getlinenr_proc, putchar_proc;
static char prompt[16];
static rk_object which;

static char const *errdesc[] = {
	"No error",
	"OS function returned an error",
	"Syntax error",
	"Premature end of file",
	"Out of storage",
	"Numerical overflow",
};

void RK_VOLATILE
RkFatalAbort(char const *msg)
{
	fputs(msg, stderr);
	abort();
}

rk_object
RkHandleSignal(rk_object proc)
{
	return	proc;
}

static rk_object
test_getchar(void)
{
	int c;

	rk_eval_register[0] = ((c = getchar()) == EOF ? RK_SOBJ_EOF : RK_MAKEICHAR(c));
	rk_eval_register[1] = RK_DUMMY_OBJ;
	rk_valid_register = 2;
	RK_PROCEED();
}

static rk_object
test_ungetchar(void)
{
	ungetc(RK_GETICHAR(rk_eval_register[0]), stdin);
	rk_eval_register[0] = RK_DUMMY_OBJ;
	rk_valid_register = 1;
	RK_PROCEED();
}

static rk_object
test_getlinenr(void)
{
	rk_eval_register[0] = RK_MAKEINUM(0);
	rk_eval_register[1] = RK_DUMMY_OBJ;
	rk_valid_register = 2;
	RK_PROCEED();
}

static rk_object
test_putchar(void)
{
	putchar(RK_GETICHAR(rk_eval_register[0]));
	rk_eval_register[0] = RK_DUMMY_OBJ;
	RK_PROCEED();
}

static rk_object
test_read(void)
{
	rk_object *cp;

	printf("\n%s", prompt);
	rk_eval_register[0] = getchar_proc;
	rk_eval_register[1] = ungetchar_proc;
	rk_eval_register[2] = getlinenr_proc;
	rk_eval_register[3] = RK_DUMMY_OBJ;
	rk_valid_register = 4;
	cp = RkAllocCells(2);
	cp[0] = RK_VECTOR_TAG(2, 0);
	cp[1] = print_proc;
	rk_continuation = cp;
	return	rk_read_proc;
}

static rk_object
test_print(void)
{
	rk_object *cp;

	if (rk_eval_register[0] == RK_SOBJ_EOF)
		exit(0);
	if (rk_eval_register[0] == RK_SOBJ_ERROR)
		RK_SIGNAL_ERROR(rk_error_code);
	rk_eval_register[2] = rk_eval_register[0];
	rk_eval_register[0] = putchar_proc;
	rk_eval_register[1] = RK_DUMMY_OBJ;
	rk_valid_register = 3;
	cp = RkAllocCells(2);
	cp[0] = RK_VECTOR_TAG(2, 0);
	cp[1] = read_proc;
	rk_continuation = cp;
	return	which;
}

static rk_object
test_error(void)
{
	printf("%s\n", errdesc[RK_GETINUM(rk_eval_register[0])]);
	switch (RK_GETINUM(rk_eval_register[0])) {
	case RK_ERROR_OSERROR:
		printf("%s\n", strerror(errno));
		break;
	case RK_ERROR_READ_SYNTAX:
		printf("%s\n", rk_syntax_error_message);
		break;
	}
	return	read_proc;
}

static int
init_test(int index)
{
	if (index != -1) {
		read_proc = RkRegisterProcedure(index + 0, test_read);
		print_proc = RkRegisterProcedure(index + 1, test_print);
		error_proc = RkRegisterProcedure(index + 2, test_error);
		getchar_proc = RkRegisterProcedure(index + 3, test_getchar);
		ungetchar_proc = RkRegisterProcedure(index + 4, test_ungetchar);
		getlinenr_proc = RkRegisterProcedure(index + 5, test_getlinenr);
		putchar_proc = RkRegisterProcedure(index + 6, test_putchar);
	}
	return	7;
}

main(int argc, char *argv[])
{
	static int (* const initializor[])(int) = {RkInitializeRead, RkInitializeWrite, init_test};
	rk_object *cp;

#ifdef RK_USE_LOCALE
	setlocale(LC_ALL, "");
#endif
	RkInitializeHeap();
	RkInitializeSymbol();
	RkInitializeRunEngine(sizeof initializor / sizeof initializor[0], initializor);
	if (isatty(0))
		sprintf(prompt, "%.13s: ", argv[0]);
	else
		prompt[0] = '\0';
	if (argc == 1)
		which = rk_write_proc;
	else if (argc == 2 && !strcmp(argv[1], "-d"))
		which = rk_display_proc;
	else if (argc == 2 && !strcmp(argv[1], "-w"))
		which = rk_write_proc;
	else {
		fprintf(stderr, "usage: %s [-d|-w]\n", argv[0]);
		exit(2);
	}
	cp = RkAllocCells(2);
	cp[0] = RK_VECTOR_TAG(2, 0);
	cp[1] = error_proc;
	rk_error_catcher = cp;
	RkExecute(read_proc);
}
