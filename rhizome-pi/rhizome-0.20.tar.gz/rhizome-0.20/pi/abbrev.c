/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/pi, Qfwfq opus 1

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

#ifndef lint
static char rcsid[] = "@(#)$Id: abbrev.c,v 1.2 1996/09/06 06:11:22 qfwfq Exp $";
#endif
/*
 * $Log: abbrev.c,v $
 * Revision 1.2  1996/09/06 06:11:22  qfwfq
 * Version 0.20 unix revision is up.
 * Renamed pi.h to rhiz_pi.h for compiler support.
 * Split scheme.pi to interprt/*.pi files, load them with bootrc.pi.
 *
 * Revision 1.1  1993/11/08 14:09:46  qfwfq
 * Initial revision
 *
 */

/*
 * Extension of read to support abbreviations.
 */
#include "rhiz_pi.h"

#define GETSYM(name)	(RkInternSymbol((name), sizeof(name)-1))

static rk_object quotes_conti1_proc, unquotes_conti1_proc, unquotes_conti2_proc;

static rk_object
quotes(void)
{
	rk_object *cp;

	cp = RkAllocCells(4);
	cp[0] = RK_VECTOR_TAG(4, 0);
	cp[1] = quotes_conti1_proc;
	cp[2] = (rk_eval_register[0] == RK_MAKEICHAR('\'')
		? RP_CAR(rk_eval_register[3]) : RP_CDR(rk_eval_register[3]));
	cp[3] = (rk_object)rk_continuation;
	rk_continuation = cp;
	cp = (rk_object *)rk_eval_register[2];
	rk_eval_register[3] = rk_eval_register[1];
	rk_eval_register[0] = cp[1];
	rk_eval_register[1] = cp[2];
	rk_eval_register[2] = cp[3];
	return	rk_read_proc;
}

static rk_object
quotes_conti1(void)
{
	rk_object *cp;

	if (rk_eval_register[0] == RK_SOBJ_ERROR || rk_eval_register[0] == RK_SOBJ_EOF) {
		if (rk_eval_register[0] == RK_SOBJ_EOF) {
			rk_eval_register[0] = RK_SOBJ_ERROR;
			rk_error_code = RK_ERROR_PRMEOF;
		}
		rk_eval_register[2] = RK_DUMMY_OBJ;
		rk_valid_register = 3;
		rk_continuation = (rk_object *)rk_continuation[3];
		RK_PROCEED();
	}
	cp = RkAllocCells(4);
	cp[0] = rk_continuation[2];
	cp[1] = (rk_object)&cp[2];
	cp[2] = rk_eval_register[0];
	cp[3] = RK_SOBJ_NIL;
	rk_eval_register[0] = (rk_object)cp;
	rk_eval_register[2] = RK_DUMMY_OBJ;
	rk_valid_register = 3;
	rk_continuation = (rk_object *)rk_continuation[3];
	RK_PROCEED();
}

static rk_object
unquotes(void)
{
	rk_object *cp;

	cp = RkAllocCells(6);
	cp[0] = RK_VECTOR_TAG(6, 0);
	cp[1] = unquotes_conti1_proc;
	cp[2] = rk_eval_register[2];
	cp[3] = rk_eval_register[3];
	cp[4] = (rk_object)rk_continuation;
	cp[5] = RK_DUMMY_OBJ;
	rk_continuation = cp;
	rk_eval_register[0] = rk_eval_register[1];
	rk_valid_register = 1;
	return	((rk_object *)rk_continuation[2])[1];
}

static rk_object
unquotes_conti1(void)
{
	rk_object *cp;

	if (rk_eval_register[0] == RK_SOBJ_ERROR || rk_eval_register[0] == RK_SOBJ_EOF) {
		if (rk_eval_register[0] == RK_SOBJ_EOF) {
			rk_eval_register[0] = RK_SOBJ_ERROR;
			rk_error_code = RK_ERROR_PRMEOF;
		}
		rk_eval_register[2] = RK_DUMMY_OBJ;
		rk_valid_register = 3;
		rk_continuation = (rk_object *)rk_continuation[4];
		RK_PROCEED();
	}
	if (rk_eval_register[0] == RK_MAKEICHAR('@')) {
		cp = RkAllocCells(4);
		cp[0] = RK_VECTOR_TAG(4, 0);
		cp[1] = quotes_conti1_proc;
		cp[2] = RP_CDR(rk_continuation[3]);
		cp[3] = rk_continuation[4];
		rk_eval_register[3] = rk_eval_register[1];
		rk_eval_register[0] = ((rk_object *)rk_continuation[2])[1];
		rk_eval_register[1] = ((rk_object *)rk_continuation[2])[2];
		rk_eval_register[2] = ((rk_object *)rk_continuation[2])[3];
		rk_continuation = cp;
		rk_valid_register = 4;
		return	rk_read_proc;
	}
	cp = RkAllocCells(6);
	cp[0] = RK_VECTOR_TAG(6, 0);
	cp[1] = unquotes_conti2_proc;
	cp[2] = rk_continuation[2];
	cp[3] = RP_CAR(rk_continuation[3]);
	cp[4] = rk_continuation[4];
	cp[5] = RK_DUMMY_OBJ;
	rk_continuation = cp;
	return	((rk_object *)rk_continuation[2])[2];
}

static rk_object
unquotes_conti2(void)
{
	rk_object *cp;

	cp = RkAllocCells(4);
	cp[0] = RK_VECTOR_TAG(4, 0);
	cp[1] = quotes_conti1_proc;
	cp[2] = rk_continuation[3];
	cp[3] = rk_continuation[4];
	rk_eval_register[3] = rk_eval_register[0];
	rk_eval_register[0] = ((rk_object *)rk_continuation[2])[1];
	rk_eval_register[1] = ((rk_object *)rk_continuation[2])[2];
	rk_eval_register[2] = ((rk_object *)rk_continuation[2])[3];
	rk_continuation = cp;
	rk_valid_register = 4;
	return	rk_read_proc;
}

int
RpInitializeAbbreviation(int index)
{
	rk_object *cp, sym;

	if (index != -1) {
		cp = RkAllocCells(4);
		cp[0] = RkRegisterProcedure(index + 0, quotes);
		cp[1] = (rk_object)&cp[2];
		cp[2] = cp[3] = RK_DUMMY_OBJ;
		rk_eval_register[0] = (rk_object)cp;
		rk_valid_register = 1;
		if (!(sym = GETSYM("quote")))
			return	-1;
		RkWriteCell(&RP_CAR(RP_CDR(rk_eval_register[0])), sym);
		if (!(sym = GETSYM("quasiquote")))
			return	-1;
		RkWriteCell(&RP_CDR(RP_CDR(rk_eval_register[0])), sym);
		RkMakeCharTableEntry('\'', (rk_object *)rk_eval_register[0], RK_CFLAG_PUNCTUATION);
		RkMakeCharTableEntry('`', (rk_object *)rk_eval_register[0], RK_CFLAG_PUNCTUATION);
		quotes_conti1_proc = RkRegisterProcedure(index + 1, quotes_conti1);
		cp = RkAllocCells(4);
		cp[0] = RkRegisterProcedure(index + 2, unquotes);
		cp[1] = (rk_object)&cp[2];
		cp[2] = cp[3] = RK_DUMMY_OBJ;
		rk_eval_register[0] = (rk_object)cp;
		if (!(sym = GETSYM("unquote")))
			return	-1;
		RkWriteCell(&RP_CAR(RP_CDR(rk_eval_register[0])), sym);
		if (!(sym = GETSYM("unquote-splicing")))
			return	-1;
		RkWriteCell(&RP_CDR(RP_CDR(rk_eval_register[0])), sym);
		RkMakeCharTableEntry(',', (rk_object *)rk_eval_register[0], RK_CFLAG_PUNCTUATION);
		unquotes_conti1_proc = RkRegisterProcedure(index + 3, unquotes_conti1);
		unquotes_conti2_proc = RkRegisterProcedure(index + 4, unquotes_conti2);
		rk_valid_register = 0;
	}
	return	5;
}
