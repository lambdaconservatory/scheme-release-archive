/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/pi, Qfwfq opus 1

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

#ifndef lint
static char rcsid[] = "@(#)$Id: helper.c,v 1.2 1996/10/10 08:26:56 qfwfq Exp $";
#endif
/*
 * $Log: helper.c,v $
 * Revision 1.2  1996/10/10 08:26:56  qfwfq
 * Ported to Win32 environment.
 *
 * Revision 1.1  1996/09/06 06:11:25  qfwfq
 * Version 0.20 unix revision is up.
 * Renamed pi.h to rhiz_pi.h for compiler support.
 * Split scheme.pi to interprt/*.pi files, load them with bootrc.pi.
 *
 */

/*
 * Helper routines for compiled program.
 */
#include "rhiz_pi.h"

#include <string.h>

static rk_object apply_compiled_closure_r_proc, apply_compiled_closure_nr_proc;
rk_object rp_apply_object_proc;

static rk_object
apply_compiled_closure_r(void)
{
	rk_object *cp, *cp1, obj, proc;
	unsigned n, m, i, j, k;

	n = RK_GETINUM(rk_eval_register[2]);
	obj = rk_eval_register[3];
	proc = ((rk_object *)obj)[1];
	if (n < (i = RK_GETINUM(((rk_object *)obj)[2]) - 1))
		RK_SIGNAL_ERROR(RP_ERROR_ARGNO);
	m = ((i+4)&~1) + (n-i)*2;
	rk_eval_register[2] = RK_SOBJ_NIL;
	while (m > RK_HEAP_CHUNK_SIZE) {
		if ((n-i)*2 < (j = RK_HEAP_CHUNK_SIZE))
			j = (n-i)*2;
		cp = RkAllocCells(j);
		cp[j-1] = rk_eval_register[2];
		cp[j-2] = rk_eval_register[0];
		obj = rk_eval_register[1];
		for (k = j-2; k > 0; k -= 2) {
			cp[k-1] = (rk_object)&cp[k];
			cp[k-2] = RP_CAR(obj);
			obj = RP_CDR(obj);
		}
		rk_eval_register[2] = (rk_object)cp;
		m -= j;
		if ((n -= j/2) > 0) {
			rk_eval_register[1] = RP_CDR(obj);
			rk_eval_register[0] = RP_CAR(obj);
		}
	}
	cp = RkAllocCells(m);
	cp1 = &cp[j = (n-i)*2];
	cp[m - 1] = RK_DUMMY_OBJ;
	cp1[0] = RK_VECTOR_TAG(i+3, 0);
	cp1[1] = ((rk_object *)rk_eval_register[3])[3];
	if (j > 0) {
		cp[j-1] = rk_eval_register[2];
		cp[j-2] = rk_eval_register[0];
		obj = rk_eval_register[1];
		while ((j -= 2) > 0) {
			cp[j-1] = (rk_object)&cp[j];
			cp[j-2] = RP_CAR(obj);
			obj = RP_CDR(obj);
		}
		cp1[i+2] = (rk_object)cp;
		for (k = i; k > 0; --k) {
			cp1[k+1] = RP_CAR(obj);
			obj = RP_CDR(obj);
		}
	} else {
		cp1[i+2] = rk_eval_register[2];
		if (i > 0) {
			cp1[i+1] = rk_eval_register[0];
			obj = rk_eval_register[1];
			while (--i > 0) {
				cp1[i+1] = RP_CAR(obj);
				obj = RP_CDR(obj);
			}
		}
	}
	rk_eval_register[0] = (rk_object)cp1;
	rk_valid_register = 1;
	return	proc;
}

static rk_object
apply_compiled_closure_nr(void)
{
	rk_object *cp, obj, proc;
	unsigned n, i;

	n = RK_GETINUM(rk_eval_register[2]);
	obj = rk_eval_register[3];
	proc = ((rk_object *)obj)[1];
	if (n != RK_GETINUM(((rk_object *)obj)[2]))
		RK_SIGNAL_ERROR(RP_ERROR_ARGNO);
	cp = RkAllocCells((n+3)&~1);
	cp[0] = RK_VECTOR_TAG(n+2, 0);
	cp[((n+3)&~1) - 1] = RK_DUMMY_OBJ;
	cp[1] = ((rk_object *)rk_eval_register[3])[3];
	if (n > 0) {
		cp[n+1] = rk_eval_register[0];
		obj = rk_eval_register[1];
		for (i = n-1; i > 0; --i) {
			cp[i+1] = RP_CAR(obj);
			obj = RP_CDR(obj);
		}
	}
	rk_eval_register[0] = (rk_object)cp;
	rk_valid_register = 1;
	return	proc;
}

rk_object
RpMakeCompiledClosure(rk_object proc, int vno, int rest_p, rk_object env)
{
	rk_object *cp;

	rk_eval_register[rk_valid_register++] = env;
	cp = RkAllocCells(8);
	cp[0] = (rk_object)&cp[2] | 3;
	cp[1] = rp_evlis_proc;
	cp[2] = rest_p ? apply_compiled_closure_r_proc : apply_compiled_closure_nr_proc;
	cp[3] = (rk_object)&cp[4];
	cp[4] = RK_VECTOR_TAG(4, 0);
	cp[5] = proc;
	cp[6] = RK_MAKEINUM(vno);
	cp[7] = rk_eval_register[--rk_valid_register];
	return	(rk_object)cp;
}

static rk_object
apply_object(void)
{
	rk_object obj = rk_eval_register[3];

	if ((obj & 7) || (RP_CAR(obj) & 7) != 3)
		RK_SIGNAL_ERROR(RP_ERROR_ILLEGALAPPLY);
	obj = RP_CAR(obj) & ~7;
	rk_eval_register[3] = RP_CDR(obj);
	return	RP_CAR(obj);
}

static struct RADESC { int size; rk_object *refarray; } *refarrays;
static void (*p_traverse)(int, void (*)(rk_object *, void *), void *);

static void
traverse(int persistent_too, void (*scan_fun)(rk_object *, void *), void *cookie)
{
	int s, i, j;

	if (persistent_too)
		for (i = 0; (s = refarrays[i].size) >= 0; ++i)
			for (j = 0; j < s; ++j)
				(*scan_fun)(&refarrays[i].refarray[j], cookie);
	(*p_traverse)(persistent_too, scan_fun, cookie);
}

#define MKOBJ_STAT_TOP			16
#define MKOBJ_STAT_PAIR_CAR		17
#define MKOBJ_STAT_PAIR_CDR		18
#define MKOBJ_STAT_VECTOR_ELT(n)	(0x80000000|(n))
#define MKOBJ_STAT_ELTNO(s)		((s)&~0x80000000)

static int
make_object(rk_object *dest, struct RP_OBJECT_DESC *desc)
{
	rk_object obj;
	int stmp;
	struct RP_OBJECT_DESC *dtmp;
	int n, m, i, z;
	char *s, *t;

	int status = MKOBJ_STAT_TOP;
	struct RP_OBJECT_DESC *odesc = NULL;

ocode_dispatch:

	switch (desc->rp_ocode) {
	case RP_OTAG_SYMBOL:
		if (!(obj = RkInternSymbol((char *)desc->rp_odata, strlen((char *)desc->rp_odata))))
			return	0;
		goto got_result;
	case RP_OTAG_PAIR:
		dtmp = (struct RP_OBJECT_DESC *)desc->rp_odata;
		obj = (rk_object)RkAllocCells(2);
		((rk_object *)obj)[0] = ((rk_object *)obj)[1] = RK_DUMMY_OBJ;
		stmp = MKOBJ_STAT_PAIR_CAR;
		i = 1;
		goto stack_node;
	case RP_OTAG_NULL:
		obj = RK_SOBJ_NIL;
		goto got_result;
	case RP_OTAG_STRING:
		n = m = i = strlen(t = (char *)desc->rp_odata);
		if (n == 0 || n >= (1<<20)) {
			n += 4;
			i = 0;
		}
		if (!(s = malloc(n))) {
			RkScavenge(1);
			if (!(s = malloc(n)))
				return	0;
		}
		if (!(obj = RkMakeMallocObject(RK_MALLOC_TAG(i, RK_TCODE_STRING), free, s)))  {
			free(s);
			return	0;
		}
		if (!i) {
			*(unsigned long *)s = m;
			s += 4;
		}
		strncpy(s, t, m);
		goto got_result;
	case RP_OTAG_BOOLEAN:
		obj = (int)desc->rp_odata ? RK_SOBJ_TRUE : RK_SOBJ_FALSE;
		goto got_result;
	case RP_OTAG_CHARACTER:
		obj = RK_MAKEICHAR((int)desc->rp_odata);
		goto got_result;
	case RP_OTAG_VECTOR:
		dtmp = &((struct RP_OBJECT_DESC *)desc->rp_odata)[1];
		n = (int)dtmp[-1].rp_odata;
		if (n + 1 < RK_BULK_ALLOC_THRESHOLD) {
			m = (n+2)&~1;
			obj = (rk_object)RkAllocCells(m);
			((rk_object *)obj)[0] = RK_VECTOR_TAG(n+1, RK_TCODE_VECTOR);
			z = 1;
		} else if (n + 1 < (1<<20)) {
			m = n+1;
			if (!(obj = (rk_object)RkAllocVector(m)))
				return	0;
			((rk_object *)obj)[0] = RK_VECTOR_TAG(n+1, RK_TCODE_VECTOR);
			z = 1;
		} else {
			m = n+2;
			if (!(obj = (rk_object)RkAllocVector(m)))
				return	0;
			((rk_object *)obj)[0] = RK_VECTOR_TAG(0, RK_TCODE_VECTOR);
			((rk_object *)obj)[1] = RK_MAKEINUM(n+2);
			z = 2;
		}
		for (i = z; i < m; ++i)
			((rk_object *)obj)[i] = RK_DUMMY_OBJ;
		if (n == 0)
			goto got_result;
		stmp = MKOBJ_STAT_VECTOR_ELT(z);
		i = z+n-1;
		goto stack_node;
	case RP_OTAG_SHORTINT:
		obj = RK_MAKEINUM((int)desc->rp_odata);
		goto got_result;
	case RP_OTAG_BIGINT:
		for (i = 1; ((int *)desc->rp_odata)[i] != -1; ++i) ;
		obj = (rk_object)RkAllocCells((i+1)&~1);
		((rk_object *)obj)[0] = RK_VECTOR_TAG(i, ((int *)desc->rp_odata)[0]
								? RK_TCODE_BIGINT_POS : RK_TCODE_BIGINT_NEG);
		((rk_object *)obj)[((i+1)&~1) - 1] = RK_DUMMY_OBJ;
		for (i = 1; (n = ((int *)desc->rp_odata)[i]) != -1; ++i)
			((rk_object *)obj)[i] = (n << 2) | 2;
		goto got_result;
	case RP_OTAG_FRACTION:
		dtmp = &((struct RP_OBJECT_DESC *)desc->rp_odata)[1];
		z = (int)dtmp[-1].rp_odata;
		obj = (rk_object)RkAllocCells(4);
		((rk_object *)obj)[0] = RK_VECTOR_TAG(4, RK_TCODE_FRACTION);
		((rk_object *)obj)[1] = RK_MAKEINUM(z);
		((rk_object *)obj)[2] = ((rk_object *)obj)[3] = RK_DUMMY_OBJ;
		stmp = MKOBJ_STAT_VECTOR_ELT(2);
		i = 3;
		goto stack_node;
	case RP_OTAG_DBLFLOAT:
		obj = RkStoreFloat(((double *)desc->rp_odata)[0]);
		goto got_result;
	case RP_OTAG_COMPLEX:
		dtmp = &((struct RP_OBJECT_DESC *)desc->rp_odata)[0];
		obj = (rk_object)RkAllocCells(4);
		((rk_object *)obj)[0] = RK_VECTOR_TAG(4, RK_TCODE_COMPLEX);
		((rk_object *)obj)[1] = ((rk_object *)obj)[2] = ((rk_object *)obj)[3] = RK_DUMMY_OBJ;
		stmp = MKOBJ_STAT_VECTOR_ELT(1);
		i = 2;
		goto stack_node;
	}

got_result:

	switch (status) {
	case MKOBJ_STAT_TOP:
		RkWriteCell(dest, obj);
		return	1;
	case MKOBJ_STAT_PAIR_CAR:
		RkWriteCell(&RP_CAR(rk_eval_register[0]), obj);
		status = MKOBJ_STAT_PAIR_CDR;
		++desc;
		goto ocode_dispatch;
	case MKOBJ_STAT_PAIR_CDR:
		rk_eval_register[1] = RP_CDR(rk_eval_register[0]);
		RkWriteCell(&RP_CDR(rk_eval_register[0]), obj);
		goto next_node;
	default:
		if ((++desc)->rp_ocode != -1) {
			RkWriteCell(&((rk_object *)rk_eval_register[0])[MKOBJ_STAT_ELTNO(status)], obj);
			++status;
			goto ocode_dispatch;
		} else {
			rk_eval_register[1] = ((rk_object *)rk_eval_register[0])[MKOBJ_STAT_ELTNO(status)];
			RkWriteCell(&((rk_object *)rk_eval_register[0])[MKOBJ_STAT_ELTNO(status)], obj);
			goto next_node;
		}
	}

next_node:
	desc = odesc;
	status = desc->rp_ocode;
	odesc = (struct RP_OBJECT_DESC *)desc->rp_odata;
	switch (status) {
	case MKOBJ_STAT_TOP:
		return	1;
	case MKOBJ_STAT_PAIR_CAR:
		rk_eval_register[0] = rk_eval_register[1];
		status = MKOBJ_STAT_PAIR_CDR;
		++desc;
		goto ocode_dispatch;
	case MKOBJ_STAT_PAIR_CDR:
		goto next_node;
	default:
		if ((++desc)->rp_ocode != -1) {
			rk_eval_register[0] = rk_eval_register[1];
			++status;
			goto ocode_dispatch;
		} else
			goto next_node;
	}

stack_node:

	rk_eval_register[1] = obj;
	switch (status) {
	case MKOBJ_STAT_TOP:
		rk_eval_register[2] = RK_DUMMY_OBJ;
		RkWriteCell(dest, obj);
		break;
	case MKOBJ_STAT_PAIR_CAR:
		rk_eval_register[2] = rk_eval_register[0];
		RkWriteCell(&RP_CAR(rk_eval_register[0]), obj);
		break;
	case MKOBJ_STAT_PAIR_CDR:
		rk_eval_register[2] = RP_CDR(rk_eval_register[0]);
		RkWriteCell(&RP_CDR(rk_eval_register[0]), obj);
		break;
	default:
		if ((desc+1)->rp_ocode == -1)
			rk_eval_register[2] = ((rk_object *)rk_eval_register[0])[MKOBJ_STAT_ELTNO(status)];
		else
			rk_eval_register[2] = rk_eval_register[0];
		RkWriteCell(&((rk_object *)rk_eval_register[0])[MKOBJ_STAT_ELTNO(status)], obj);
		break;
	}
	rk_eval_register[0] = rk_eval_register[1];
	RkWriteCell(&((rk_object *)rk_eval_register[0])[i], rk_eval_register[2]);
	desc->rp_ocode = status;
	status = stmp;
	desc->rp_odata = (void *)odesc;
	odesc = desc;
	desc = dtmp;
	goto ocode_dispatch;
}

int
RpCallInitProcs(int index, int nmodules, void (**initp)(struct RP_MODULE_INIT *))
{
	struct RP_MODULE_INIT m;
	int n, i, j;

	if (index == -1) {
		n = 0;
		if ((refarrays = malloc(sizeof(struct RADESC) * (nmodules+1))) == NULL)
			RkFatalAbort("Out of memory in initializing compiled modules.\n");
		for (i = 0; i < nmodules; ++i) {
			(*initp[i])(&m);
			n += m.rp_nprocs;
			for (j = 0; m.rp_odesc[j].rp_ocode >= 0; ++j)
				m.rp_oarray[j] = RK_DUMMY_OBJ;
			refarrays[i].size = j;
			refarrays[i].refarray = m.rp_oarray;
		}
		refarrays[i].size = -1;
		refarrays[i].refarray = NULL;
		return	n;
	}
	p_traverse = rk_traverse_root;
	rk_traverse_root = traverse;
	n = 0;
	rk_eval_register[0] = rk_eval_register[1] = rk_eval_register[2] = RK_DUMMY_OBJ;
	rk_valid_register = 3;
	for (i = 0; i < nmodules; ++i) {
		(*initp[i])(&m);
		for (j = 0; j < m.rp_nprocs; ++j)
			*m.rp_procs[j].rp_paddr = RkRegisterProcedure(index + n + j, m.rp_procs[j].rp_faddr);
		n += m.rp_nprocs;
		for (j = 0; m.rp_odesc[j].rp_ocode >= 0; ++j)
			if (!make_object(&m.rp_oarray[j], &m.rp_odesc[j]))
				return	-1;
	}
	rk_valid_register = 0;
	return	n;
}

int
RpInitializeHelper(int index)
{
	if (index != -1) {
		apply_compiled_closure_r_proc = RkRegisterProcedure(index + 0, apply_compiled_closure_r);
		apply_compiled_closure_nr_proc = RkRegisterProcedure(index + 1, apply_compiled_closure_nr);
		rp_apply_object_proc = RkRegisterProcedure(index + 2, apply_object);
	}
	return	3;
}
