/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/pi, Qfwfq opus 1

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

/* @(#)$Id: rhiz_pi.h,v 1.2 1996/10/10 08:27:01 qfwfq Exp $ */
/*
 * $Log: rhiz_pi.h,v $
 * Revision 1.2  1996/10/10 08:27:01  qfwfq
 * Ported to Win32 environment.
 *
 * Revision 1.1  1996/09/06 06:11:31  qfwfq
 * Version 0.20 unix revision is up.
 * Renamed pi.h to rhiz_pi.h for compiler support.
 * Split scheme.pi to interprt/*.pi files, load them with bootrc.pi.
 *
 * Revision 1.2  1993/11/13 16:14:53  qfwfq
 * Add procedure-port feature.
 *
 * Revision 1.1  93/11/08  14:09:49  qfwfq
 * Initial revision
 * 
 */

#include "rhizome.h"

#define RP_CAR(x)	(((rk_object *)(x))[0])
#define RP_CDR(x)	(((rk_object *)(x))[1])
#define RP_ISCONS(x)	(!(x & 7) && !(RP_CAR(x) & 1))

#define RP_MAKEVLOC0(f, v)	(((unsigned long)(f)<<24)|((unsigned long)(v)<<8)|0x2c)
#define RP_GETFRAME0(x)		(((unsigned long)(x)>>24)&0xff)
#define RP_GETVNUM0(x)		(((unsigned long)(x)>>8)&0xffff)

#define RP_TCODE_VLOC1		7
#define RP_GETFRAME1(x)		RK_GETINUM(((rk_object *)(x))[1])
#define RP_GETVNUM1(x)		RK_GETINUM(((rk_object *)(x))[2])

#define RP_TCODE_PORT		8

#define RP_TCODE_FILE		2
#define RP_TCODE_STRPORT	3

#define RP_ASSERTARG(n)	do { if (rk_eval_register[2] != RK_MAKEINUM(n)) RK_SIGNAL_ERROR(RP_ERROR_ARGNO); } while (0)
#define RP_RETURN()	do { rk_valid_register = 1; RK_PROCEED(); } while (0)

#define RP_ERROR_ILLEGALEVAL	101
#define RP_ERROR_VARUNBOUND	102
#define RP_ERROR_ILLEGALAPPLY	103
#define RP_ERROR_ILLEGALARG	104
#define RP_ERROR_PRIMSYNTAX	105
#define RP_ERROR_TOOMANYFORMALS	106
#define RP_ERROR_ARGNO		107
#define RP_ERROR_ILLEGALDEF	108
#define RP_ERROR_PROGRAM	109
#define RP_ERROR_MACROBOTCH	110
#define RP_ERROR_MAPLENGTH	111
#define RP_ERROR_EVALRET	112
#define RP_ERROR_PORTBUSY	113
#define RP_ERROR_PORTPROC	114

#define RP_DEFINESUBR(name, proc, index, func)	if (!RpDefineSubr(name, sizeof(name)-1, &proc, (index), (func))) \
							return -1

struct RP_PROCEDURE_REC { rk_object (*rp_faddr)(void); rk_object *rp_paddr; };
struct RP_OBJECT_DESC { int rp_ocode; void *rp_odata; };

struct RP_MODULE_INIT {
	int rp_nprocs;
	struct RP_PROCEDURE_REC *rp_procs;
	struct RP_OBJECT_DESC *rp_odesc;
	rk_object *rp_oarray;
};

struct RP_PROGRAM_DESC {
	int rp_nmodules;
	rk_object (**rp_runprocs)(void);
	void (**rp_initprocs)(struct RP_MODULE_INIT *);
};

#define RP_OTAG_SYMBOL		0
#define RP_OTAG_PAIR		1
#define RP_OTAG_NULL		2
#define RP_OTAG_STRING		3
#define RP_OTAG_BOOLEAN		4
#define RP_OTAG_CHARACTER	5
#define RP_OTAG_VECTOR		6
#define RP_OTAG_SHORTINT	7
#define RP_OTAG_BIGINT		8
#define RP_OTAG_FRACTION	9
#define RP_OTAG_DBLFLOAT	10
#define RP_OTAG_COMPLEX		11

/* Main */
extern int rp_argc;
extern char **rp_argv;

/* Eval */
extern rk_object rp_default_eval_car_proc;
extern rk_object rp_eval_car_proc;
extern rk_object rp_evlis_proc;
extern rk_object rp_noapply_proc;
int RpInitializeEval(int);

/* Primitives */
int RpInitializePrimitives(int);

/* Abbreviation */
int RpInitializeAbbreviation(int);

/* Subr */
int RpDefineSubr(char const *, unsigned, rk_object *, int, rk_object (*)(void));
int RpInitializeSubr(int);

/* Port */
extern jmp_buf *rp_io_signal_catcher;
void RpResetStdioPorts(void);
int RpInitializePort(int);

/* Numeric */
int RpEqvP(rk_object, rk_object);
int RpInitializeNumeric(int);

/* Characters */
int RpInitializeCharacters(int);

/* Reflection */
int RpInitializeReflection(int);

/* Helper */
extern rk_object rp_apply_object_proc;
rk_object RpMakeCompiledClosure(rk_object, int, int, rk_object);
int RpCallInitProcs(int, int, void (**)());
int RpInitializeHelper(int);

/* Entry for compiled program */
struct RP_PROGRAM_DESC *RpProgramDesc(void);
