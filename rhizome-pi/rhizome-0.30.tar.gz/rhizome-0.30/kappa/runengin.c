/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/kappa, an opus of Qfwfq

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

#ifndef lint
static char rcsid[] = "@(#)$Id: runengin.c,v 1.2 1996/09/06 06:08:35 qfwfq Exp $";
#endif
/*
 * $Log: runengin.c,v $
 * Revision 1.2  1996/09/06 06:08:35  qfwfq
 * Version 0.20 unix revision is up.
 *
 * Revision 1.1  1993/11/08 14:02:20  qfwfq
 * Initial revision
 *
 */

/*
 * Execution engine.
 */
#include "rhizome.h"

rk_object *rk_continuation, *rk_error_catcher, rk_eval_register[RK_EVAL_REGISTER_SIZE];
int rk_valid_register;
int volatile rk_got_signal;

static rk_object (**procs)(void);
static void (*p_traverse)(int, void (*)(rk_object *, void *), void *);

static void
traverse(int persistent_too, void (*scan_fun)(rk_object *, void *), void *cookie)
{
	int i;

	(*scan_fun)((rk_object *)&rk_continuation, cookie);
	(*scan_fun)((rk_object *)&rk_error_catcher, cookie);
	for (i = 0; i < rk_valid_register; ++i)
		(*scan_fun)(&rk_eval_register[i], cookie);
	(*p_traverse)(persistent_too, scan_fun, cookie);
}

void
RkInitializeRunEngine(int nmodules, int (* const initializor[])(int))
{
	int total, n, i;

	rk_continuation = rk_error_catcher = (rk_object *)RK_DUMMY_OBJ;
	rk_valid_register = 0;
	p_traverse = rk_traverse_root;
	rk_traverse_root = traverse;
	rk_got_signal = 0;
	total = 0;
	for (i = 0; i < nmodules; ++i)
		total += (*initializor[i])(-1);
	if (!(procs = malloc(total * sizeof(rk_object (*)(void)))))
		RkFatalAbort("Failed to allocate procedure table.\n");
	total = 0;
	for (i = 0; i < nmodules; ++i) {
		if ((n = (*initializor[i])(total)) == -1)
			RkFatalAbort("Failure in a initialization procedure.\n");
		total += n;
	}
}

rk_object
RkRegisterProcedure(int index, rk_object (*proc)(void))
{
	procs[index] = proc;
	return	(index << 4) | 4;
}

void RK_VOLATILE
RkExecute(rk_object init_proc)
{
	register rk_object procedure = init_proc;

	for (; ; ) {
		if (rk_got_signal)
			procedure = RkHandleSignal(procedure);
		procedure = (*procs[procedure >> 4])();
	}
}
