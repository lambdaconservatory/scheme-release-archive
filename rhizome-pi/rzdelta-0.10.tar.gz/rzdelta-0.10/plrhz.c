/*
 * Copyright (c) 2005 Inujima, Masaru <qfwfq@kt.rim.or.jp>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/* $Id: plrhz.c,v 1.12 2005/09/14 05:40:02 qfwfq Exp $ */

/*
 * $Log: plrhz.c,v $
 * Revision 1.12  2005/09/14 05:40:02  qfwfq
 * add copyright notice
 *
 * Revision 1.11  2005/08/04 07:00:15  qfwfq
 * trace
 *
 * Revision 1.10  2005/07/28 09:44:56  qfwfq
 * external module loading
 *
 * Revision 1.9  2005/07/11 11:08:35  qfwfq
 * cursor
 *
 * Revision 1.8  2005/06/28 11:05:09  qfwfq
 * prepare & execute
 *
 * Revision 1.7  2005/06/13 06:47:50  qfwfq
 * trigger support
 *
 * Revision 1.6  2005/05/26 04:52:55  qfwfq
 * rd:spi-execute
 *
 * Revision 1.5  2005/05/13 08:01:26  qfwfq
 * procedure to invoke elog
 *
 * Revision 1.4  2005/05/06 09:24:23  qfwfq
 * generic types and record
 *
 * Revision 1.3  2005/04/15 07:15:04  qfwfq
 * support SRF
 *
 * Revision 1.2  2005/04/11 09:58:24  qfwfq
 * common numeric types as args and return
 *
 * Revision 1.1  2005/04/01 10:32:24  qfwfq
 * Initial revision
 *
 */

#include "postgres.h"
#include "commands/trigger.h"
#include "executor/spi.h"
#include "funcapi.h"
#include "miscadmin.h"
#include "parser/parse_type.h"
#include "utils/lsyscache.h"

#include "rhiz_pi.h"

#include <pthread.h>
#include <semaphore.h>
#include <signal.h>

#define RD_TCODE_PLAN	 	(RP_TCODE_VECTMAX+0)
#define RD_TCODE_CURSOR		(RP_TCODE_VECTMAX+1)
#define RD_TCODE_VECTMAX	(RP_TCODE_VECTMAX+2)

#define NFUNCTIONS_PER_CHUNK	50

int rp_argc = 1;
static char *fakeargv[] = {"plrhz", NULL};
char **rp_argv = fakeargv;

static struct RP_PROGRAM_DESC const *prog_d;

static rk_object topcont_proc, inierror_proc;

Datum plrhz_call_handler(PG_FUNCTION_ARGS);

static char *
get_string_body(rk_object str, int *len)
{
	char *s;

	s = RkGetMallocObject(str);
	if (!(*len = RP_CAR(str) >> 12)) {
		*len = *(unsigned long *)s;
		s += 4;
	}
	return	s;
}

static int
make_string_obj(char *str, rk_object *cp)
{
	int sz, tag, len;
	char *s;

	sz = tag = len = strlen(str);
	if (sz == 0 || sz >= (1<<20)) {
		sz += 4;
		tag = 0;
	}
	if (!(s = malloc(sz)))
		return	0;
	if (!(*cp = RkMakeMallocObject(RK_MALLOC_TAG(tag, RK_TCODE_STRING), free, s))) {
		free(s);
		return	0;
	}
	if (!tag) {
		*(unsigned long *)s = len;
		s += 4;
	}
	memcpy(s, str, len);
	return	1;
}

static int
get_integer_val(rk_object num, int *vp)
{
	unsigned int h;

	if (RK_ISINUM(num))
		*vp = RK_GETINUM(num);
	else if (num&7)
		return	0;
	else if (((rk_object *)num)[0] == RK_VECTOR_TAG(2, RK_TCODE_BIGINT_POS))
		*vp = ((rk_object *)num)[1]>>2;
	else if (((rk_object *)num)[0] == RK_VECTOR_TAG(2, RK_TCODE_BIGINT_NEG))
		*vp = -(signed int)(((rk_object *)num)[1]>>2);
	else if (((rk_object *)num)[0] == RK_VECTOR_TAG(3, RK_TCODE_BIGINT_POS)) {
		if ((h = ((rk_object *)num)[2]) & 0xfffffff0)
			return	0;
		h = ((h&0xc)<<28)|(((rk_object *)num)[1]>>2);
		if ((signed int)h < 0)
			return	0;
		*vp = (signed int)h;
	} else if (((rk_object *)num)[0] == RK_VECTOR_TAG(3, RK_TCODE_BIGINT_NEG)) {
		if ((h = ((rk_object *)num)[2]) & 0xfffffff0)
			return	0;
		h = ((h&0xc)<<28)|(((rk_object *)num)[1]>>2);
		h = (unsigned int)-(signed int)h;
		if ((signed int)h > 0)
			return	0;
		*vp = (signed int)h;
	} else
		return	0;
	return	1;
}

static rk_object
make_integer_obj(int n)
{
	int t;
	rk_object *cp;

	if (-0x20000000 <= n && n < 0x20000000)
		return	RK_MAKEINUM(n);
	else {
		if (n > 0)
			t = RK_TCODE_BIGINT_POS;
		else {
			n = -n;
			t = RK_TCODE_BIGINT_NEG;
		}
		if (n < 0x40000000) {
			cp = RkAllocCells(2);
			cp[0] = RK_VECTOR_TAG(2, t);
			cp[1] = RK_MAKEINUM(n);
		} else {
			cp = RkAllocCells(4);
			cp[0] = RK_VECTOR_TAG(3, t);
			cp[1] = RK_MAKEINUM(n);
			cp[2] = RK_MAKEINUM((unsigned)n>>30);
			cp[3] = RK_DUMMY_OBJ;
		}
		return	(rk_object)cp;
	}
}

static rk_object
make_unsigned_obj(unsigned n)
{
	rk_object *cp;

	if (n < 0x20000000)
		return	RK_MAKEINUM(n);
	else if (n < 0x40000000) {
		cp = RkAllocCells(2);
		cp[0] = RK_VECTOR_TAG(2, RK_TCODE_BIGINT_POS);
		cp[1] = RK_MAKEINUM(n);
	} else {
		cp = RkAllocCells(4);
		cp[0] = RK_VECTOR_TAG(3, RK_TCODE_BIGINT_POS);
		cp[1] = RK_MAKEINUM(n);
		cp[2] = RK_MAKEINUM(n>>30);
		cp[3] = RK_DUMMY_OBJ;
	}
	return	(rk_object)cp;
}

static int
obj_is_flonum(rk_object obj)
{
	return	!(obj&7) && ((rk_object *)obj)[0] == RK_VECTOR_TAG(4, RK_TCODE_FLONUM);
}

static void *
f_palloc(Size size)
{
	return	palloc(size);
}

static int
ship_string(rk_object obj, char **target, void *(*allocator)(Size))
{
	char *s;
	int l;

	if (!RK_ISSTRING(obj))
		return	0;
	s = get_string_body(obj, &l);
	*target = (char *)allocator(l+1);
	memcpy(*target, s, l);
	(*target)[l] = '\0';
	return	1;
}

void RK_VOLATILE
RkFatalAbort(char const *msg)
{
	elog(FATAL, "%s", msg);
	abort();
}

static rk_object
topcont(void)
{
	rk_object *cp;
	int n;

	if ((n = RK_GETINUM(rk_continuation[2])) == prog_d->rp_nmodules)
		RkFatalAbort("scheme level initialization code reached the end");
	cp = RkAllocCells(4);
	cp[0] = RK_VECTOR_TAG(4, 0);
	cp[1] = topcont_proc;
	cp[2] = RK_MAKEINUM(n+1);
	cp[3] = RK_DUMMY_OBJ;
	rk_continuation = cp;
	return	(prog_d->rp_runprocs[n])();
}

static rk_object
inierror(void)
{
	char buf[128];

	sprintf(buf, "error in scheme level initialization code: code=%ld, obj=0x%08lx"
		, RK_GETINUM(rk_eval_register[1]), rk_eval_register[0]);
	RkFatalAbort(buf);
}

static rk_object *interrupts_handler;
typedef enum VALTYPE {
	vt_void,
	vt_bool, vt_char,
	vt_int2, vt_int4,
	vt_float4, vt_float8,
	vt_generic,
	vt_record
} valtype;
static struct PROCREC {
	rk_object *procobj;
	TransactionId p_xmin;
	CommandId p_cmin;
	char volatility;
	bool retset;
	valtype rettype;
	FmgrInfo retconv;
	Oid rettypioparam;
	int nargs;
	valtype argtype[FUNC_MAX_ARGS];
	FmgrInfo argconv[FUNC_MAX_ARGS];
	Oid argtypioparam[FUNC_MAX_ARGS];
} *plrhz_procrec;
static int plrhz_nprocs, plrhz_procalloc;
static void (*p_traverse)(int, void (*)(rk_object *, void *), void *);

static void
traverse(int persistent_too, void (*scan_fun)(rk_object *, void *), void *cookie)
{
	int i;

	(*scan_fun)((rk_object *)&interrupts_handler, cookie);
	for (i = 0; i < plrhz_nprocs; ++i)
		(*scan_fun)((rk_object *)&plrhz_procrec[i].procobj, cookie);
	(*p_traverse)(persistent_too, scan_fun, cookie);
}

static int interrupt_in_process = 0;

static rk_object interrupts_conti1_proc;
static rk_object
interrupts_conti1(void)
{
	RkFatalAbort("interrupts handler returned; this shall not occur");
}

static rk_object
handle_interrupts(rk_object proc)
{
	rk_object *cp, func;

	if (InterruptHoldoffCount != 0 || CritSectionCount != 0
	 || (!ProcDiePending && !QueryCancelPending && ((InterruptPending = false), 1))
	 || interrupts_handler == (rk_object *)RK_DUMMY_OBJ)
		return	proc;
	interrupt_in_process = 1;
	cp = RkAllocCells(2);
	cp[0] = RK_VECTOR_TAG(2, 0);
	cp[1] = interrupts_conti1_proc;
	func = RP_CAR(interrupts_handler) & ~7;
	rk_continuation = cp;
	rk_eval_register[0] = RK_DUMMY_OBJ;
	rk_eval_register[1] = RK_DUMMY_OBJ;
	rk_eval_register[2] = RK_MAKEINUM(0);
	rk_eval_register[3] = RP_CDR(func);
	rk_valid_register = 4;
	rp_eval_car_proc = rp_default_eval_car_proc;
	return	RP_CAR(func);
}

rk_object rd_interruptshandler_proc;
static rk_object
interruptshandler(void)
{
	rk_object func;

	RP_ASSERTARG(1);
	func = rk_eval_register[0];
	if ((func & 7) || (RP_CAR(func) & 7) != 3)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	interrupts_handler = (rk_object *)func;
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static int suspend_interrupt = 1;

rk_object rd_suspendinterrupt_proc;
static rk_object
suspendinterrupt(void)
{
	RP_ASSERTARG(1);
	suspend_interrupt = (rk_eval_register[0] != RK_SOBJ_FALSE);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static void RK_VOLATILE
interp_loop(rk_object init_proc)
{
	extern rk_object (**rk_procs_array)(void);
	register rk_object procedure = init_proc;

	for (; ; ) {
		if (InterruptPending && !suspend_interrupt && !interrupt_in_process)
			procedure = handle_interrupts(procedure);
		procedure = (*rk_procs_array[procedure >> 4])();
	}
}

#define TASK_READ_EVAL	0
#define TASK_APPLY	1
#define TASK_SRF_FIRST	2
#define TASK_SRF_NEXT	3
#define TASK_SPI_RETURN	4
#define TASK_SPI_ABORT	5
#define TASK_TRIGGER	6

#define SPITASK_NONE	0
#define SPITASK_ABORT	1
#define SPITASK_ELOG	2
#define SPITASK_EXECUTE	3
#define SPITASK_GETVAL	4
#define SPITASK_PREPARE	5
#define SPITASK_EXECP	6
#define SPITASK_CURSOPN	7
#define SPITASK_CURSFND	8
#define SPITASK_CFETCH	9
#define SPITASK_CMOVE	10
#define SPITASK_CCLOSE	11

typedef union UVALREP {
	int v_bool;
	int v_char;
	int v_int2;
	int v_int4;
	double v_float4;
	double v_float8;
	char *v_generic;
	char **v_record;
} uvalrep;

static sem_t run_interpreter, run_dbserver;
static int task;
static int eval_result_store;
static int spicall_task = SPITASK_NONE;
static int spicall_context_id;
static int elog_level = 0;
static char *elog_message;
static char *sql_command;
static bool spicall_read_only;
static int max_row_count;
static int spicall_result_code;
static int ttvrn, ttvfn;
static char *ttvstring;
static int plan_nargs;
static char **plan_argtypes;
static struct SAVED_PLAN {
	void *plan;
	int nparams;
	struct PARAM_TYPE {
		valtype param_type;
		FmgrInfo param_ioconv;
		Oid param_typioparam;
	} params[1];
} *plan_dat;
static char *exec_param_nulls;
static uvalrep *exec_params;
static char *cursor_name;
static Portal opened_cursor;
static bool corsorop_forward;
static char *module_search_path;
static char *trace_tag_list;

struct EXEC_DATA { void RK_VOLATILE (*execute)(rk_object); rk_object proc; };

static void *
interpreter_thread_func(void *param)
{
	sigset_t set;

	sigfillset(&set);
	pthread_sigmask(SIG_BLOCK, &set, NULL);
	(((struct EXEC_DATA *)param)->execute)(((struct EXEC_DATA *)param)->proc);
	abort();
}

static void
dbserver_service(void)
{
	int stk, elev, ctx, i;
	List *tokens;
	TypeName *name;
	ListCell *cell;
	HeapTuple typeTup;
	Oid *typeOids;
	void *tplan;
	Datum *param_vals;

	for (; ; ) {
		while (sem_wait(&run_dbserver)) ;
		if (spicall_task == SPITASK_NONE)
			break;
		stk = spicall_task;
		spicall_task = SPITASK_NONE;
		ctx = spicall_context_id;
		switch (stk) {
		case SPITASK_ABORT:
			PG_RE_THROW();
		case SPITASK_ELOG:
			elev = elog_level;
			elog_level = 0;
			PG_TRY();
			{
				elog(elev, "%s", elog_message);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_EXECUTE:
			PG_TRY();
			{
				spicall_result_code = SPI_execute(sql_command, spicall_read_only, max_row_count);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_GETVAL:
			PG_TRY();
			{
				ttvstring = SPI_getvalue(SPI_tuptable->vals[ttvrn], SPI_tuptable->tupdesc, ttvfn+1);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_PREPARE:
			PG_TRY();
			{
				plan_dat = (struct SAVED_PLAN *)malloc(sizeof(struct SAVED_PLAN)
									+ sizeof(struct PARAM_TYPE) * (plan_nargs-1));
				plan_dat->nparams = plan_nargs;
				typeOids = (Oid *)palloc(sizeof(Oid) * plan_nargs);
				for (i = 0; i < plan_nargs; ++i) {
					SplitIdentifierString(plan_argtypes[i], '.', &tokens);
					name = makeNode(TypeName);
					foreach(cell, tokens)
						name->names = lappend(name->names, makeString(lfirst(cell)));
					typeTup = typenameType(name);
					typeOids[i] = HeapTupleGetOid(typeTup);
					switch (typeOids[i]) {
					case BOOLOID:	plan_dat->params[i].param_type = vt_bool; break;
					case CHAROID:	plan_dat->params[i].param_type = vt_char; break;
					case INT2OID:	plan_dat->params[i].param_type = vt_int2; break;
					case INT4OID:	plan_dat->params[i].param_type = vt_int4; break;
					case FLOAT4OID:	plan_dat->params[i].param_type = vt_float4; break;
					case FLOAT8OID:	plan_dat->params[i].param_type = vt_float8; break;
					default:
						plan_dat->params[i].param_type = vt_generic;
						fmgr_info_cxt(((Form_pg_type)GETSTRUCT(typeTup))->typinput
								, &plan_dat->params[i].param_ioconv, TopMemoryContext);
						plan_dat->params[i].param_typioparam = getTypeIOParam(typeTup);
						break;
					}
					ReleaseSysCache(typeTup);
					list_free(name->names);
					pfree(name);
					list_free(tokens);
					pfree(plan_argtypes[i]);
				}
				pfree(plan_argtypes);
				tplan = SPI_prepare(sql_command, plan_nargs, typeOids);
				if (!tplan)
					elog(ERROR, "SPI_prepare() failed");
				plan_dat->plan = SPI_saveplan(tplan);
				if (!plan_dat->plan)
					elog(ERROR, "SPI_saveplan() failed");
				SPI_freeplan(tplan);
				pfree(typeOids);
				pfree(sql_command);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				free(plan_dat);
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_EXECP:
		case SPITASK_CURSOPN:
			PG_TRY();
			{
				param_vals = (Datum *)palloc(sizeof(Datum) * plan_dat->nparams);
				for (i = 0; i < plan_dat->nparams; ++i) {
					if (exec_param_nulls[i] == 'n')
						continue;
					switch (plan_dat->params[i].param_type) {
					case vt_bool:	param_vals[i] = BoolGetDatum(exec_params[i].v_bool); break;
					case vt_char:	param_vals[i] = CharGetDatum(exec_params[i].v_char); break;
					case vt_int2:	param_vals[i] = Int16GetDatum(exec_params[i].v_int2); break;
					case vt_int4:	param_vals[i] = Int32GetDatum(exec_params[i].v_int4); break;
					case vt_float4:	param_vals[i] = Float4GetDatum(exec_params[i].v_float4); break;
					case vt_float8:	param_vals[i] = Float8GetDatum(exec_params[i].v_float8); break;
					default:
						param_vals[i]
						= FunctionCall3(&plan_dat->params[i].param_ioconv
							, CStringGetDatum(exec_params[i].v_generic)
							, ObjectIdGetDatum(plan_dat->params[i].param_typioparam)
							, Int32GetDatum(-1));
						pfree(exec_params[i].v_generic);
						break;
					}
				}
				pfree(exec_params);
				if (stk == SPITASK_EXECP)
					spicall_result_code = SPI_execute_plan(plan_dat->plan
								, param_vals, exec_param_nulls
								, spicall_read_only, max_row_count);
				else {
					opened_cursor = SPI_cursor_open(cursor_name, plan_dat->plan
								, param_vals, exec_param_nulls, spicall_read_only);
					if (cursor_name)
						pfree(cursor_name);
					if (!opened_cursor)
						elog(ERROR, "SPI_cursor_open() failed");
				}
				pfree(param_vals);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_CURSFND:
			PG_TRY();
			{
				opened_cursor = SPI_cursor_find(cursor_name);
				if (cursor_name)
					pfree(cursor_name);
				if (!opened_cursor)
					elog(ERROR, "SPI_cursor_find() failed");
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		case SPITASK_CFETCH:
		case SPITASK_CMOVE:
		case SPITASK_CCLOSE:
			PG_TRY();
			{
				if (stk == SPITASK_CFETCH) {
					SPI_cursor_fetch(opened_cursor, corsorop_forward, max_row_count);
					spicall_result_code = SPI_OK_SELECT;
				} else if (stk == SPITASK_CMOVE)
					SPI_cursor_move(opened_cursor, corsorop_forward, max_row_count);
				else
					SPI_cursor_close(opened_cursor);
				task = TASK_SPI_RETURN;
			}
			PG_CATCH();
			{
				task = TASK_SPI_ABORT;
			}
			PG_END_TRY();
			break;
		}
		spicall_context_id = ctx;
		sem_post(&run_interpreter);
	}
	if (interrupt_in_process) {
		interrupt_in_process = 0;
		CHECK_FOR_INTERRUPTS();
		elog(ERROR, "interrupt vanished, but too late");
	}
	if (elog_level) {
		elog_level = 0;
		elog(ERROR, "%s", elog_message);
	}
}

rk_object rd_dosch_elog_proc;
static rk_object
dosch_elog(void)
{
	RP_ASSERTARG(2);
	if (!RK_ISINUM(RP_CAR(rk_eval_register[1])) || !ship_string(rk_eval_register[0], &elog_message, f_palloc))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	elog_level = RK_GETINUM(RP_CAR(rk_eval_register[1]));
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static void
read_eval_procedure_source(int prono)
{
	eval_result_store = prono;
	task = TASK_READ_EVAL;
	sem_post(&run_interpreter);
	dbserver_service();
}

rk_object rd_gettask_proc;
static rk_object
gettask(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(task);
	RP_RETURN();
}

rk_object rd_evresult_proc;
static rk_object
evresult(void)
{
	RP_ASSERTARG(1);
	plrhz_procrec[eval_result_store].procobj = (rk_object *)rk_eval_register[0];
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static int proc_objnr;
static int proc_argcnt;
static int proc_arg_isnull[FUNC_MAX_ARGS];
static uvalrep proc_arg[FUNC_MAX_ARGS];
static FuncCallContext *proc_fctx;
static int proc_done;
static int proc_retv_isnull;
static uvalrep proc_retv;

#define TRGACT_PASS	0
#define TRGACT_SKIP	1
#define TRGACT_MODIFY	2

static TriggerEvent tdat_event;
static Relation tdat_relation;
static int tdat_tuple_natts;
static valtype *tdat_tuple_attrtypes;
static bool *tdat_trigtuple_isnull;
static uvalrep *tdat_trigtuple_attrs;
static bool *tdat_newtuple_isnull;
static uvalrep *tdat_newtuple_attrs;
static Trigger *tdat_trigger;
static int trig_action;
static int *trig_rettuple_isnull;
static uvalrep *trig_rettuple_attrs;

static void
run_procedure(int type)
{
	task = type;
	sem_post(&run_interpreter);
	dbserver_service();
}

rk_object rd_getproc_proc;
static rk_object
getproc(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = (rk_object)plrhz_procrec[proc_objnr].procobj;
	RP_RETURN();
}

rk_object rd_getparg_proc;
static rk_object
getparg(void)
{
	int i;
	rk_object *cp, obj;

	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_SOBJ_NIL;
	i = proc_argcnt;
	while (i-- > 0) {
		cp = RkAllocCells(2);
		cp[0] = RK_SOBJ_UNSPEC;
		cp[1] = rk_eval_register[0];
		rk_eval_register[0] = (rk_object)cp;
		if (!proc_arg_isnull[i]) {
			switch (plrhz_procrec[proc_objnr].argtype[i]) {
			case vt_bool:
				obj = proc_arg[i].v_bool ? RK_SOBJ_TRUE : RK_SOBJ_FALSE;
				break;
			case vt_char:
				obj = RK_MAKEICHAR(proc_arg[i].v_char);
				break;
			case vt_int2:
				obj = RK_MAKEINUM(proc_arg[i].v_int2);
				break;
			case vt_int4:
				obj = make_integer_obj(proc_arg[i].v_int4);
				break;
			case vt_float4:
				obj = RkStoreFloat(proc_arg[i].v_float4);
				break;
			case vt_float8:
				obj = RkStoreFloat(proc_arg[i].v_float8);
				break;
			case vt_generic:
				if (!make_string_obj(proc_arg[i].v_generic, &obj))
					RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
				break;
			default:	Assert(0); obj = RK_SOBJ_UNSPEC; break;
			}
			((rk_object *)rk_eval_register[0])[0] = obj;
		}
	}
	RP_RETURN();
}

rk_object rd_setsrfcont_proc;
static rk_object
setsrfcont(void)
{
	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	proc_fctx->user_fctx = (void *)RK_GETINUM(rk_eval_register[0]);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_getsrfcont_proc;
static rk_object
getsrfcont(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM((int)proc_fctx->user_fctx);
	RP_RETURN();
}

rk_object rd_setsrfdone_proc;
static rk_object
setsrfdone(void)
{
	RP_ASSERTARG(1);
	proc_done = (rk_eval_register[0] != RK_SOBJ_FALSE);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_putpretv_proc;
static rk_object
putpretv(void)
{
	int i, nelm;
	rk_object obj;

	RP_ASSERTARG(1);
	if (rk_eval_register[0] == RK_SOBJ_UNSPEC)
		proc_retv_isnull = 1;
	else {
		proc_retv_isnull = 0;
		switch (plrhz_procrec[proc_objnr].rettype) {
		case vt_void:
			break;
		case vt_bool:
			if (rk_eval_register[0] == RK_SOBJ_TRUE)
				proc_retv.v_bool = 1;
			else if (rk_eval_register[0] == RK_SOBJ_FALSE)
				proc_retv.v_bool = 0;
			else
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			break;
		case vt_char:
			if (!RK_ISICHAR(rk_eval_register[0]))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			proc_retv.v_char = RK_GETICHAR(rk_eval_register[0]);
			break;
		case vt_int2:
			if (!RK_ISINUM(rk_eval_register[0]))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			proc_retv.v_int2 = RK_GETINUM(rk_eval_register[0]);
			if (proc_retv.v_int2 < -0x8000 || 0x8000 <= proc_retv.v_int2)
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			break;
		case vt_int4:
			if (!get_integer_val(rk_eval_register[0], &proc_retv.v_int4))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			break;
		case vt_float4:
			if (!obj_is_flonum(rk_eval_register[0]))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			proc_retv.v_float4 = RkLoadFloat(rk_eval_register[0]);
			break;
		case vt_float8:
			if (!obj_is_flonum(rk_eval_register[0]))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			proc_retv.v_float8 = RkLoadFloat(rk_eval_register[0]);
			break;
		case vt_generic:
			if (!ship_string(rk_eval_register[0], &proc_retv.v_generic, SPI_palloc))
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			break;
		case vt_record:
			obj = rk_eval_register[0];
			nelm = 0;
			while (RP_ISCONS(obj)) {
				obj = RP_CDR(obj);
				++nelm;
			}
			if (obj != RK_SOBJ_NIL)
				RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
			proc_retv.v_record = (char **)SPI_palloc(nelm * sizeof(char *));
			for (i = 0; i < nelm; ++i) {
				obj = RP_CAR(rk_eval_register[0]);
				if (obj == RK_SOBJ_UNSPEC)
					proc_retv.v_record[i] = NULL;
				else if (!ship_string(obj, &proc_retv.v_record[i], SPI_palloc))
					RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
				rk_eval_register[0] = RP_CDR(rk_eval_register[0]);
			}
			break;
		}
	}
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_waitcall_proc;
static rk_object
waitcall(void)
{
	RP_ASSERTARG(0);
	sem_post(&run_dbserver);
	while (sem_wait(&run_interpreter)) ;
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static char *source_text = "";
static int source_ptr = 0, source_lno = 0;

#define PORT_INPUT	0x1

static rk_object source_getchar_proc, source_ungetchar_proc, source_getlinecount_proc, source_putchar_proc;

static rk_object
source_getchar(void)
{
	int c;
	rk_object cobj;

	rk_eval_register[1] = rk_eval_register[0];
	if (!(c = source_text[source_ptr]))
		cobj = RK_SOBJ_EOF;
	else {
		++source_ptr;
		if (c == '\n' && source_lno)
			if (!((++source_lno)<<2))
				source_lno = 0;
		cobj = RK_MAKEICHAR(c);
	}
	rk_eval_register[0] = cobj;
	rk_valid_register = 2;
	RK_PROCEED();
}

static rk_object
source_ungetchar(void)
{
	int c;

	if (source_ptr > 0) {
		c = RK_GETICHAR(rk_eval_register[0]);
		if (c == '\n' && source_lno > 1)
			--source_lno;
		source_text[--source_ptr] = c;
	}
	rk_eval_register[0] = rk_eval_register[1];
	rk_valid_register = 1;
	RK_PROCEED();
}

static rk_object
source_getlinecount(void)
{
	rk_eval_register[1] = rk_eval_register[0];
	rk_eval_register[0] = RK_MAKEINUM(source_lno);
	rk_valid_register = 2;
	RK_PROCEED();
}

static rk_object
source_putchar(void)
{
	rk_eval_register[0] = RK_DUMMY_OBJ;
	RK_PROCEED();
}

rk_object rd_open_source_proc;
static rk_object
open_source(void)
{
	rk_object *cp;

	RP_ASSERTARG(0);
	cp = RkAllocCells(8);
	cp[0] = RK_VECTOR_TAG(8, RP_TCODE_PORT);
	cp[1] = RK_MAKEINUM(PORT_INPUT);
	cp[2] = source_getchar_proc;
	cp[3] = source_ungetchar_proc;
	cp[4] = source_getlinecount_proc;
	cp[5] = source_putchar_proc;
	cp[6] = cp[7] = RK_DUMMY_OBJ;
	rk_eval_register[0] = (rk_object)cp;
	RP_RETURN();
}

rk_object rd_setspictx_proc;
static rk_object
setspictx(void)
{
	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	spicall_context_id = RK_GETINUM(rk_eval_register[0]);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_getspictx_proc;
static rk_object
getspictx(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(spicall_context_id);
	RP_RETURN();
}

rk_object rd_setspitask_proc;
static rk_object
setspitask(void)
{
	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	spicall_task = RK_GETINUM(rk_eval_register[0]);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_setsqlcmd_proc;
static rk_object
setsqlcmd(void)
{
	RP_ASSERTARG(1);
	if (!ship_string(rk_eval_register[0], &sql_command, f_palloc))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_checkvolatility_proc;
static rk_object
checkvolatility(void)
{
	RP_ASSERTARG(0);
	switch (plrhz_procrec[proc_objnr].volatility) {
	case PROVOLATILE_IMMUTABLE:
		rk_eval_register[0] = RK_SOBJ_FALSE;
		RP_RETURN();
	case PROVOLATILE_STABLE:
		spicall_read_only = true;
		break;
	case PROVOLATILE_VOLATILE:
		spicall_read_only = false;
		break;
	}
	rk_eval_register[0] = RK_SOBJ_TRUE;
	RP_RETURN();
}

rk_object rd_setmaxcnt_proc;
static rk_object
setmaxcnt(void)
{
	RP_ASSERTARG(1);
	if (!get_integer_val(rk_eval_register[0], &max_row_count))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_getspiresult_proc;
static rk_object
getspiresult(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(spicall_result_code);
	RP_RETURN();
}

rk_object rd_getspiprocessed_proc;
static rk_object
getspiprocessed(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = make_integer_obj(SPI_processed);
	RP_RETURN();
}

rk_object rd_getttnatts_proc;
static rk_object
getttnatts(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(SPI_tuptable->tupdesc->natts);
	RP_RETURN();
}

rk_object rd_getttattname_proc;
static rk_object
getttattname(void)
{
	int i;

	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	i = RK_GETINUM(rk_eval_register[0]);
	if (!make_string_obj(NameStr(SPI_tuptable->tupdesc->attrs[i]->attname), &rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
	RP_RETURN();
}

rk_object rd_getttatttype_proc;
static rk_object
getttatttype(void)
{
	int t;

	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	switch (SPI_tuptable->tupdesc->attrs[RK_GETINUM(rk_eval_register[0])]->atttypid) {
	case BOOLOID:	t = 0; break;
	case CHAROID:	t = 1; break;
	case INT2OID:	t = 2; break;
	case INT4OID:	t = 3; break;
	case FLOAT4OID:	t = 4; break;
	case FLOAT8OID:	t = 5; break;
	default:	t = 6; break;
	}
	rk_eval_register[0] = RK_MAKEINUM(t);
	RP_RETURN();
}

static int
ttgetdatum(Datum *dat, bool *isnull)
{
	int fn, rn;

	if (!RK_ISINUM(rk_eval_register[0]))
		return	0;
	fn = RK_GETINUM(rk_eval_register[0]);
	if (!get_integer_val(RP_CAR(rk_eval_register[1]), &rn))
		return	0;
	*dat = heap_getattr(SPI_tuptable->vals[rn], fn+1, SPI_tuptable->tupdesc, isnull);
	return	1;
}

rk_object rd_getttvbool_proc;
static rk_object
getttvbool(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : (DatumGetBool(dat) ? RK_SOBJ_TRUE : RK_SOBJ_FALSE);
	RP_RETURN();
}

rk_object rd_getttvchar_proc;
static rk_object
getttvchar(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : RK_MAKEICHAR(DatumGetChar(dat));
	RP_RETURN();
}

rk_object rd_getttvint2_proc;
static rk_object
getttvint2(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : RK_MAKEINUM(DatumGetInt16(dat));
	RP_RETURN();
}

rk_object rd_getttvint4_proc;
static rk_object
getttvint4(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : make_integer_obj(DatumGetInt32(dat));
	RP_RETURN();
}

rk_object rd_getttvfloat4_proc;
static rk_object
getttvfloat4(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : RkStoreFloat(DatumGetFloat4(dat));
	RP_RETURN();
}

rk_object rd_getttvfloat8_proc;
static rk_object
getttvfloat8(void)
{
	Datum dat;
	bool isnull;

	RP_ASSERTARG(2);
	if (!ttgetdatum(&dat, &isnull))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = isnull ? RK_SOBJ_UNSPEC : RkStoreFloat(DatumGetFloat8(dat));
	RP_RETURN();
}

rk_object rd_setttvrcno_proc;
static rk_object
setttvrcno(void)
{
	RP_ASSERTARG(2);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	ttvfn = RK_GETINUM(rk_eval_register[0]);
	if (!get_integer_val(RP_CAR(rk_eval_register[1]), &ttvrn))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_getttvstr_proc;
static rk_object
getttvstr(void)
{
	int ok;

	RP_ASSERTARG(0);
	if (!ttvstring)
		rk_eval_register[0] = RK_SOBJ_UNSPEC;
	else {
		ok = make_string_obj(ttvstring, &rk_eval_register[0]);
		pfree(ttvstring);
		if (!ok)
			RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
	}
	RP_RETURN();
}

rk_object rd_freett_proc;
static rk_object
freett(void)
{
	RP_ASSERTARG(0);
	SPI_freetuptable(SPI_tuptable);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_gettgevent_proc;
static rk_object
gettgevent(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = make_unsigned_obj((unsigned)tdat_event);
	RP_RETURN();
}

rk_object rd_gettgrelid_proc;
static rk_object
gettgrelid(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = make_unsigned_obj((unsigned)RelationGetRelid(tdat_relation));
	RP_RETURN();
}

rk_object rd_gettgrelname_proc;
static rk_object
gettgrelname(void)
{
	rk_object sobj;

	RP_ASSERTARG(0);
	if (!make_string_obj(RelationGetRelationName(tdat_relation), &sobj))
		RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
	rk_eval_register[0] = sobj;
	RP_RETURN();
}

rk_object rd_gettgrelattn_proc;
static rk_object
gettgrelattn(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(tdat_tuple_natts);
	RP_RETURN();
}

rk_object rd_gettgtupattr_proc;
static rk_object
gettgtupattr(void)
{
	rk_object sobj;
	int attrno;
	bool *tup_isnull;
	uvalrep *tup_attrs;

	RP_ASSERTARG(2);
	if (!TRIGGER_FIRED_FOR_ROW(tdat_event))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	attrno = RK_GETINUM(rk_eval_register[0]);
	if (attrno < 0 || attrno >= tdat_tuple_natts)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	if (RP_CAR(rk_eval_register[1]) == RK_SOBJ_FALSE) {
		tup_isnull = tdat_trigtuple_isnull;
		tup_attrs = tdat_trigtuple_attrs;
	} else {
		if (!TRIGGER_FIRED_BY_UPDATE(tdat_event))
			RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
		tup_isnull = tdat_newtuple_isnull;
		tup_attrs = tdat_newtuple_attrs;
	}
	if (tup_isnull[attrno]) {
		rk_eval_register[0] = RK_SOBJ_UNSPEC;
		RP_RETURN();
	}
	switch (tdat_tuple_attrtypes[attrno]) {
	case vt_bool:
		rk_eval_register[0] = tup_attrs[attrno].v_bool ? RK_SOBJ_TRUE : RK_SOBJ_FALSE;
		break;
	case vt_char:
		rk_eval_register[0] = RK_MAKEICHAR(tup_attrs[attrno].v_char);
		break;
	case vt_int2:
		rk_eval_register[0] = RK_MAKEINUM(tup_attrs[attrno].v_int2);
		break;
	case vt_int4:
		rk_eval_register[0] = make_integer_obj(tup_attrs[attrno].v_int4);
		break;
	case vt_float4:
		rk_eval_register[0] = RkStoreFloat(tup_attrs[attrno].v_float4);
		break;
	case vt_float8:
		rk_eval_register[0] = RkStoreFloat(tup_attrs[attrno].v_float8);
		break;
	default:
		if (!make_string_obj(tup_attrs[attrno].v_generic, &sobj))
			RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
		rk_eval_register[0] = sobj;
		break;
	}
	RP_RETURN();
}

rk_object rd_gettgtrigname_proc;
static rk_object
gettgtrigname(void)
{
	rk_object sobj;

	RP_ASSERTARG(0);
	if (!make_string_obj(tdat_trigger->tgname, &sobj))
		RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
	rk_eval_register[0] = sobj;
	RP_RETURN();
}

rk_object rd_gettgtrigargc_proc;
static rk_object
gettgtrigargc(void)
{
	RP_ASSERTARG(0);
	rk_eval_register[0] = RK_MAKEINUM(tdat_trigger->tgnargs);
	RP_RETURN();
}

rk_object rd_gettgtrigarg_proc;
static rk_object
gettgtrigarg(void)
{
	int k;
	rk_object sobj;

	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	k = RK_GETINUM(rk_eval_register[0]);
	if (k < 0 || k >= tdat_trigger->tgnargs)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	if (!make_string_obj(tdat_trigger->tgargs[k], &sobj))
		RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
	rk_eval_register[0] = sobj;
	RP_RETURN();
}

rk_object rd_settgaction_proc;
static rk_object
settgaction(void)
{
	RP_ASSERTARG(1);
	if (!RK_ISINUM(rk_eval_register[0]))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	trig_action = RK_GETINUM(rk_eval_register[0]);
	if (trig_action == TRGACT_MODIFY) {
		trig_rettuple_isnull = (int *)SPI_palloc(sizeof(int) * tdat_tuple_natts);
		trig_rettuple_attrs = (uvalrep *)SPI_palloc(sizeof(uvalrep) * tdat_tuple_natts);
	}
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

static int
store_uval(valtype typ, rk_object obj, uvalrep *uval, void *(*allocator)(Size))
{
	switch (typ) {
	case vt_bool:
		if (obj == RK_SOBJ_TRUE)
			uval->v_bool = 1;
		else if (obj == RK_SOBJ_FALSE)
			uval->v_bool = 0;
		else
			return	0;
		break;
	case vt_char:
		if (!RK_ISICHAR(obj))
			return	0;
		uval->v_char = RK_GETICHAR(obj);
		break;
	case vt_int2:
		if (!RK_ISINUM(obj))
			return	0;
		uval->v_int2 = RK_GETINUM(obj);
		if (uval->v_int2 < -0x8000 || 0x8000 <= uval->v_int2)
			return	0;
		break;
	case vt_int4:
		if (!get_integer_val(obj, &uval->v_int4))
			return	0;
		break;
	case vt_float4:
		if (!obj_is_flonum(obj))
			return	0;
		uval->v_float4 = RkLoadFloat(obj);
		break;
	case vt_float8:
		if (!obj_is_flonum(obj))
			return	0;
		uval->v_float8 = RkLoadFloat(obj);
		break;
	default:
		if (!ship_string(obj, &uval->v_generic, allocator))
			return	0;
		break;
	}
	return	1;
}

rk_object rd_settgmodattr_proc;
static rk_object
settgmodattr(void)
{
	int k;

	RP_ASSERTARG(2);
	if (!RK_ISINUM(RP_CAR(rk_eval_register[1])))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	k = RK_GETINUM(RP_CAR(rk_eval_register[1]));
	if (k < 0 || k >= tdat_tuple_natts)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	if (rk_eval_register[0] == RK_SOBJ_UNSPEC) {
		trig_rettuple_isnull[k] = 1;
		RP_RETURN();
	}
	trig_rettuple_isnull[k] = 0;
	if (!store_uval(tdat_tuple_attrtypes[k], rk_eval_register[0], &trig_rettuple_attrs[k], SPI_palloc))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_setplanargs_proc;
static rk_object
setplanargs(void)
{
	rk_object obj;
	int i;

	RP_ASSERTARG(1);
	for (obj = rk_eval_register[0], plan_nargs = 0; RP_ISCONS(obj); obj = RP_CDR(obj), ++plan_nargs) ;
	if (obj != RK_SOBJ_NIL)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	plan_argtypes = (char **)palloc(sizeof(char *) * plan_nargs);
	for (i = 0; i < plan_nargs; ++i) {
		obj = RP_CAR(rk_eval_register[0]);
		rk_eval_register[0] = RP_CDR(rk_eval_register[0]);
		if (!ship_string(obj, &plan_argtypes[i], f_palloc))
			RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	}
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_makeplanobj_proc;
static rk_object
makeplanobj(void)
{
	rk_object *cp;

	RP_ASSERTARG(0);
	cp = RkAllocCells(4);
	cp[0] = RK_VECTOR_TAG(4, RD_TCODE_PLAN);
	cp[1] = ((unsigned)plan_dat&0xffff0000) | RK_MAKEINUM(0);
	cp[2] = ((unsigned)plan_dat<<16) | RK_MAKEINUM(0);
	cp[3] = RK_DUMMY_OBJ;
	rk_eval_register[0] = (rk_object)cp;
	RP_RETURN();
}

rk_object rd_setplanobj_proc;
static rk_object
setplanobj(void)
{
	rk_object *cp;

	RP_ASSERTARG(1);
	cp = (rk_object *)rk_eval_register[0];
	if ((unsigned)cp&7 || cp[0] != RK_VECTOR_TAG(4, RD_TCODE_PLAN))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	plan_dat = (struct SAVED_PLAN *)(((unsigned)cp[1]&0xffff0000) | ((unsigned)cp[2]>>16));
	exec_param_nulls = (char *)palloc(plan_dat->nparams);
	exec_params = (uvalrep *)palloc(sizeof(uvalrep) * plan_dat->nparams);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_setplanparam_proc;
static rk_object
setplanparam(void)
{
	int k;

	RP_ASSERTARG(2);
	if (!RK_ISINUM(RP_CAR(rk_eval_register[1])))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	k = RK_GETINUM(RP_CAR(rk_eval_register[1]));
	if (k < 0 || k >= plan_dat->nparams)
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	if (rk_eval_register[0] == RK_SOBJ_UNSPEC) {
		exec_param_nulls[k] = 'n';
		RP_RETURN();
	}
	exec_param_nulls[k] = ' ';
	if (!store_uval(plan_dat->params[k].param_type, rk_eval_register[0], &exec_params[k], f_palloc))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_freeplanobj_proc;
static rk_object
freeplanobj(void)
{
	rk_object *cp;
	struct SAVED_PLAN *pdat;

	RP_ASSERTARG(1);
	cp = (rk_object *)rk_eval_register[0];
	if ((unsigned)cp&7 || cp[0] != RK_VECTOR_TAG(4, RD_TCODE_PLAN))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	pdat = (struct SAVED_PLAN *)(((unsigned)cp[1]&0xffff0000) | ((unsigned)cp[2]>>16));
	SPI_freeplan(pdat->plan);
	free(pdat);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_setcursname_proc;
static rk_object
setcursname(void)
{
	RP_ASSERTARG(1);
	if (rk_eval_register[0] == RK_SOBJ_UNSPEC)
		cursor_name = NULL;
	else if (!ship_string(rk_eval_register[0], &cursor_name, f_palloc))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_makecursobj_proc;
static rk_object
makecursobj(void)
{
	rk_object *cp;

	RP_ASSERTARG(0);
	cp = RkAllocCells(4);
	cp[0] = RK_VECTOR_TAG(4, RD_TCODE_CURSOR);
	cp[1] = ((unsigned)opened_cursor&0xffff0000) | RK_MAKEINUM(0);
	cp[2] = ((unsigned)opened_cursor<<16) | RK_MAKEINUM(0);
	cp[3] = RK_DUMMY_OBJ;
	rk_eval_register[0] = (rk_object)cp;
	RP_RETURN();
}

rk_object rd_setcursobj_proc;
static rk_object
setcursobj(void)
{
	rk_object *cp;

	RP_ASSERTARG(1);
	cp = (rk_object *)rk_eval_register[0];
	if ((unsigned)cp&7 || cp[0] != RK_VECTOR_TAG(4, RD_TCODE_CURSOR))
		RK_SIGNAL_ERROR1(RP_ERROR_ILLEGALARG);
	opened_cursor = (Portal)(((unsigned)cp[1]&0xffff0000) | ((unsigned)cp[2]>>16));
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_setforflag_proc;
static rk_object
setforflag(void)
{
	RP_ASSERTARG(1);
	if (rk_eval_register[0] == RK_SOBJ_FALSE)
		corsorop_forward = false;
	else
		corsorop_forward = true;
	rk_eval_register[0] = RK_SOBJ_UNSPEC;
	RP_RETURN();
}

rk_object rd_confmodpath_proc;
static rk_object
confmodpath(void)
{
	rk_object sobj;

	RP_ASSERTARG(0);
	if (!module_search_path)
		rk_eval_register[0] = RK_SOBJ_FALSE;
	else {
		if (!make_string_obj(module_search_path, &sobj))
			RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
		rk_eval_register[0] = sobj;
	}
	RP_RETURN();
}

rk_object rd_conftrtag_proc;
static rk_object
conftrtag(void)
{
	rk_object sobj;

	RP_ASSERTARG(0);
	if (!trace_tag_list)
		rk_eval_register[0] = RK_SOBJ_FALSE;
	else {
		if (!make_string_obj(trace_tag_list, &sobj))
			RK_SIGNAL_ERROR1(RK_ERROR_OUTOFSTORAGE);
		rk_eval_register[0] = sobj;
	}
	RP_RETURN();
}

static void
start_interpreter(void RK_VOLATILE (*execute)(rk_object), rk_object proc)
{
	struct EXEC_DATA exdata;
	pthread_t dmy;
	pthread_attr_t attr;
	int err;

	sem_init(&run_interpreter, 0, 0);
	sem_init(&run_dbserver, 0, 0);
	exdata.execute = execute, exdata.proc = proc;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	err = pthread_create(&dmy, &attr, interpreter_thread_func, (void *)&exdata);
	pthread_attr_destroy(&attr);
	if (err)
		elog(ERROR, "could not start scheme interpreter thread");
	dbserver_service();
}

static int
init_main(int index)
{
	extern struct RP_PROGRAM_DESC const *RpProgramDesc(void);

	if (index == -1) {
		prog_d = RpProgramDesc();
		return	RpCallInitProcs(-1, prog_d->rp_nmodules, prog_d->rp_initprocs) + 61;
	}
	interrupts_handler = (rk_object *)RK_DUMMY_OBJ;
	if ((plrhz_procrec = (struct PROCREC *)malloc(NFUNCTIONS_PER_CHUNK * sizeof(struct PROCREC))) == NULL)
		elog(ERROR, "could not allocate functions record");
	plrhz_procalloc = NFUNCTIONS_PER_CHUNK;
	plrhz_nprocs = 0;
	p_traverse = rk_traverse_root;
	rk_traverse_root = traverse;
	topcont_proc = RkRegisterProcedure(index + 0, topcont);
	inierror_proc = RkRegisterProcedure(index + 1, inierror);
	interrupts_conti1_proc = RkRegisterProcedure(index + 2, interrupts_conti1);
	RP_DEFINESUBR("rd:set-interrupts-handler", rd_interruptshandler_proc, index + 3, interruptshandler);
	RP_DEFINESUBR("rd:suspend-interrupt", rd_suspendinterrupt_proc, index + 4, suspendinterrupt);
	RP_DEFINESUBR("rd:do-or-schedule-elog", rd_dosch_elog_proc, index + 5, dosch_elog);
	RP_DEFINESUBR("rd:get-current-task", rd_gettask_proc, index + 6, gettask);
	RP_DEFINESUBR("rd:store-eval-result", rd_evresult_proc, index + 7, evresult);
	RP_DEFINESUBR("rd:get-called-procedure", rd_getproc_proc, index + 8, getproc);
	RP_DEFINESUBR("rd:get-procedure-arguments", rd_getparg_proc, index + 9, getparg);
	RP_DEFINESUBR("rd:set-srf-continuation", rd_setsrfcont_proc, index + 10, setsrfcont);
	RP_DEFINESUBR("rd:get-srf-continuation", rd_getsrfcont_proc, index + 11, getsrfcont);
	RP_DEFINESUBR("rd:set-srf-done", rd_setsrfdone_proc, index + 12, setsrfdone);
	RP_DEFINESUBR("rd:store-preocedure-return-value", rd_putpretv_proc, index + 13, putpretv);
	RP_DEFINESUBR("rd:wait-next-call", rd_waitcall_proc, index + 14, waitcall);
	source_getchar_proc = RkRegisterProcedure(index + 15, source_getchar);
	source_ungetchar_proc = RkRegisterProcedure(index + 16, source_ungetchar);
	source_getlinecount_proc = RkRegisterProcedure(index + 17, source_getlinecount);
	source_putchar_proc = RkRegisterProcedure(index + 18, source_putchar);
	RP_DEFINESUBR("rd:open-procedure-source", rd_open_source_proc, index + 19, open_source);
	RP_DEFINESUBR("rd:set-spicall-context", rd_setspictx_proc, index + 20, setspictx);
	RP_DEFINESUBR("rd:get-spicall-context", rd_getspictx_proc, index + 21, getspictx);
	RP_DEFINESUBR("rd:set-spicall-task", rd_setspitask_proc, index + 22, setspitask);
	RP_DEFINESUBR("rd:set-sql-command", rd_setsqlcmd_proc, index + 23, setsqlcmd);
	RP_DEFINESUBR("rd:check-volatility", rd_checkvolatility_proc, index + 24, checkvolatility);
	RP_DEFINESUBR("rd:set-max-rows", rd_setmaxcnt_proc, index + 25, setmaxcnt);
	RP_DEFINESUBR("rd:get-spi-result-code", rd_getspiresult_proc, index + 26, getspiresult);
	RP_DEFINESUBR("rd:get-spi-processed-rows", rd_getspiprocessed_proc, index + 27, getspiprocessed);
	RP_DEFINESUBR("rd:get-number-of-attributes", rd_getttnatts_proc, index + 28, getttnatts);
	RP_DEFINESUBR("rd:get-attribute-name", rd_getttattname_proc, index + 29, getttattname);
	RP_DEFINESUBR("rd:get-attribute-type", rd_getttatttype_proc, index + 30, getttatttype);
	RP_DEFINESUBR("rd:get-attribute-value-bool", rd_getttvbool_proc, index + 31, getttvbool);
	RP_DEFINESUBR("rd:get-attribute-value-char", rd_getttvchar_proc, index + 32, getttvchar);
	RP_DEFINESUBR("rd:get-attribute-value-int2", rd_getttvint2_proc, index + 33, getttvint2);
	RP_DEFINESUBR("rd:get-attribute-value-int4", rd_getttvint4_proc, index + 34, getttvint4);
	RP_DEFINESUBR("rd:get-attribute-value-float4", rd_getttvfloat4_proc, index + 35, getttvfloat4);
	RP_DEFINESUBR("rd:get-attribute-value-float8", rd_getttvfloat8_proc, index + 36, getttvfloat8);
	RP_DEFINESUBR("rd:set-attribute-row-column-number", rd_setttvrcno_proc, index + 37, setttvrcno);
	RP_DEFINESUBR("rd:get-attribute-value-string", rd_getttvstr_proc, index + 38, getttvstr);
	RP_DEFINESUBR("rd:free-spi-tuple-table", rd_freett_proc, index + 39, freett);
	RP_DEFINESUBR("rd:get-trigger-event", rd_gettgevent_proc, index + 40, gettgevent);
	RP_DEFINESUBR("rd:get-trigger-relation-oid", rd_gettgrelid_proc, index + 41, gettgrelid);
	RP_DEFINESUBR("rd:get-trigger-relation-name", rd_gettgrelname_proc, index + 42, gettgrelname);
	RP_DEFINESUBR("rd:get-trigger-relation-attribute-number", rd_gettgrelattn_proc, index + 43, gettgrelattn);
	RP_DEFINESUBR("rd:get-trigger-tuple-attribute", rd_gettgtupattr_proc, index + 44, gettgtupattr);
	RP_DEFINESUBR("rd:get-trigger-trigger-name", rd_gettgtrigname_proc, index + 45, gettgtrigname);
	RP_DEFINESUBR("rd:get-trigger-trigger-argc", rd_gettgtrigargc_proc, index + 46, gettgtrigargc);
	RP_DEFINESUBR("rd:get-trigger-trigger-arg", rd_gettgtrigarg_proc, index + 47, gettgtrigarg);
	RP_DEFINESUBR("rd:set-trigger-action", rd_settgaction_proc, index + 48, settgaction);
	RP_DEFINESUBR("rd:set-trigger-modified-attribute", rd_settgmodattr_proc, index + 49, settgmodattr);
	RP_DEFINESUBR("rd:set-plan-argument-types", rd_setplanargs_proc, index + 50, setplanargs);
	RP_DEFINESUBR("rd:make-plan-object", rd_makeplanobj_proc, index + 51, makeplanobj);
	RP_DEFINESUBR("rd:set-plan-object", rd_setplanobj_proc, index + 52, setplanobj);
	RP_DEFINESUBR("rd:set-plan-parameter", rd_setplanparam_proc, index + 53, setplanparam);
	RP_DEFINESUBR("rd:spi-freeplan", rd_freeplanobj_proc, index + 54, freeplanobj);
	RP_DEFINESUBR("rd:set-cursor-name", rd_setcursname_proc, index + 55, setcursname);
	RP_DEFINESUBR("rd:make-cursor-object", rd_makecursobj_proc, index + 56, makecursobj);
	RP_DEFINESUBR("rd:set-cursor-object", rd_setcursobj_proc, index + 57, setcursobj);
	RP_DEFINESUBR("rd:set-forward-flag", rd_setforflag_proc, index + 58, setforflag);
	RP_DEFINESUBR("rd:conf-module-search-path", rd_confmodpath_proc, index + 59, confmodpath);
	RP_DEFINESUBR("rd:conf-trace-tag-list", rd_conftrtag_proc, index + 60, conftrtag);
	return	RpCallInitProcs(index + 61, prog_d->rp_nmodules, prog_d->rp_initprocs) + 61;
}

static void
plrhz_start(void)
{
	static int plrhz_ready = 0;
	static int (* const initializor[])(int) = {
		RkInitializeRead, RkInitializeWrite, RkInitializeLdSo,
		RpInitializeEval, RpInitializePrimitives, RpInitializeAbbreviation, RpInitializeSubr,
		RpInitializePort, RpInitializeNumeric, RpInitializeCharacters, RpInitializeReflection,
		RpInitializeHelper, RpInitializeDynload, init_main};
	rk_object *cp;

	if (plrhz_ready)
		return;

	DefineCustomStringVariable("plrhz.module_search_path"
		, "search path of scheme module", NULL
		, &module_search_path, PGC_SUSET, NULL, NULL);
	DefineCustomStringVariable("plrhz.trace_tag_list"
		, "list of tags for which trace is activeted", NULL
		, &trace_tag_list, PGC_USERSET, NULL, NULL);
	EmitWarningsOnPlaceholders("plrhz");

	RkInitializeHeap();
	RkInitializeSymbol();
	RkInitializeRunEngine(sizeof initializor / sizeof initializor[0], initializor);
	rk_valid_register = 0;
	cp = RkAllocCells(6);
	cp[0] = RK_VECTOR_TAG(2, 0);
	cp[1] = inierror_proc;
	rk_error_catcher = cp;
	cp[2] = RK_VECTOR_TAG(4, 0);
	cp[3] = topcont_proc;
	cp[4] = RK_MAKEINUM(0);
	cp[5] = RK_DUMMY_OBJ;
	rk_continuation = &cp[2];
	start_interpreter(interp_loop, topcont_proc);

	plrhz_ready = 1;
}

PG_FUNCTION_INFO_V1(plrhz_call_handler);

static Datum plrhz_func_handler(PG_FUNCTION_ARGS);
static HeapTuple plrhz_trigger_handler(PG_FUNCTION_ARGS);

Datum
plrhz_call_handler(PG_FUNCTION_ARGS)
{
	Datum retval;
	int save_procnr, save_tdnatts;
	valtype *save_tdattrtypes;

	plrhz_start();

	save_procnr = proc_objnr;
	save_tdnatts = tdat_tuple_natts;
	save_tdattrtypes = tdat_tuple_attrtypes;
	PG_TRY();
	{
		if (CALLED_AS_TRIGGER(fcinfo))
			retval = PointerGetDatum(plrhz_trigger_handler(fcinfo));
		else
			retval = plrhz_func_handler(fcinfo);
	}
	PG_CATCH();
	{
		proc_objnr = save_procnr;
		tdat_tuple_natts = save_tdnatts;
		tdat_tuple_attrtypes = save_tdattrtypes;
		PG_RE_THROW();
	}
	PG_END_TRY();

	proc_objnr = save_procnr;
	tdat_tuple_natts = save_tdnatts;
	tdat_tuple_attrtypes = save_tdattrtypes;
	return	retval;
}

static int
next_proc_record(void)
{
	void *newrec;

	if (plrhz_nprocs == plrhz_procalloc) {
		if ((newrec = realloc(plrhz_procrec, (plrhz_procalloc+NFUNCTIONS_PER_CHUNK) * sizeof(struct PROCREC)))
				== NULL)
			elog(ERROR, "could not extend functions record");
		plrhz_procrec = (struct PROCREC *)newrec;
		plrhz_procalloc += NFUNCTIONS_PER_CHUNK;
	}
	plrhz_procrec[plrhz_nprocs].procobj = (rk_object *)RK_DUMMY_OBJ;
	return	plrhz_nprocs++;
}

static int
evaluate_function_def(Oid fn_oid, bool trigp)
{
	HeapTuple procTup, typeTup;
	Form_pg_proc procStruct;
	Form_pg_type typeStruct;
	char procind_vname[64];
	rk_object procind_vsym, procind_obj;
	int i, procind_num = -1;
	struct PROCREC *prec;
	Datum source_dat;
	bool source_isnull;

	procTup = SearchSysCache(PROCOID, ObjectIdGetDatum(fn_oid), 0, 0, 0);
	if (!HeapTupleIsValid(procTup))
		elog(ERROR, "cache lookup failed for function %u", fn_oid);
	procStruct = (Form_pg_proc)GETSTRUCT(procTup);

	if (trigp)
		sprintf(procind_vname, "rd:plrhz-trig-%u", fn_oid);
	else
		sprintf(procind_vname, "rd:plrhz-proc-%u", fn_oid);
	if (!(procind_vsym = RkInternSymbol(procind_vname, strlen(procind_vname))))
		elog(ERROR, "could not intern procedure memoize record symbol");
	procind_obj = ((rk_object *)procind_vsym)[1];
	if (RK_ISINUM(procind_obj)) {
		procind_num = RK_GETINUM(procind_obj);
		if (procind_num < 0 || procind_num >= plrhz_nprocs
		 || (prec = &plrhz_procrec[procind_num]
		   , (prec->p_xmin != HeapTupleHeaderGetXmin(procTup->t_data)
		   || prec->p_cmin != HeapTupleHeaderGetCmin(procTup->t_data))))
			procind_num = -1;
	}

	if (procind_num == -1) {
		procind_num = next_proc_record();
		((rk_object *)procind_vsym)[1] = RK_MAKEINUM(procind_num);
		prec = &plrhz_procrec[procind_num];
		prec->p_xmin = HeapTupleHeaderGetXmin(procTup->t_data);
		prec->p_cmin = HeapTupleHeaderGetCmin(procTup->t_data);

		prec->volatility = procStruct->provolatile;
		if (!trigp) {
			prec->retset = procStruct->proretset;
			switch (procStruct->prorettype) {
			case VOIDOID:	prec->rettype = vt_void;	break;
			case BOOLOID:	prec->rettype = vt_bool;	break;
			case CHAROID:	prec->rettype = vt_char;	break;
			case INT2OID:	prec->rettype = vt_int2;	break;
			case INT4OID:	prec->rettype = vt_int4;	break;
			case FLOAT4OID:	prec->rettype = vt_float4;	break;
			case FLOAT8OID:	prec->rettype = vt_float8;	break;
			case RECORDOID: prec->rettype = vt_record;	break;
			default:
				prec->rettype = vt_generic;
				typeTup = SearchSysCache(TYPEOID, ObjectIdGetDatum(procStruct->prorettype), 0, 0, 0);
				if (!HeapTupleIsValid(typeTup))
					elog(ERROR, "cache lookup failed for type %u", procStruct->prorettype);
				typeStruct = (Form_pg_type)GETSTRUCT(typeTup);
				if (typeStruct->typtype == 'p')
					ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED)
							, errmsg("plrhz functions cannot return type %s"
								, format_type_be(procStruct->prorettype))));
				fmgr_info_cxt(typeStruct->typinput, &prec->retconv, TopMemoryContext);
				prec->rettypioparam = getTypeIOParam(typeTup);
				ReleaseSysCache(typeTup);
				break;
			}
			prec->nargs = procStruct->pronargs;
			for (i = 0; i < prec->nargs; ++i)
				switch (procStruct->proargtypes[i]) {
				case BOOLOID:	prec->argtype[i] = vt_bool;	break;
				case CHAROID:	prec->argtype[i] = vt_char;	break;
				case INT2OID:	prec->argtype[i] = vt_int2;	break;
				case INT4OID:	prec->argtype[i] = vt_int4;	break;
				case FLOAT4OID:	prec->argtype[i] = vt_float4;	break;
				case FLOAT8OID:	prec->argtype[i] = vt_float8;	break;
				default:
					prec->argtype[i] = vt_generic;
					typeTup = SearchSysCache(TYPEOID, ObjectIdGetDatum(procStruct->proargtypes[i])
								, 0, 0, 0);
					if (!HeapTupleIsValid(typeTup))
						elog(ERROR, "cache lookup failed for type %u"
							, procStruct->proargtypes[i]);
					typeStruct = (Form_pg_type)GETSTRUCT(typeTup);
					if (typeStruct->typtype == 'p')
						ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED)
							, errmsg("plrhz functions cannot take type %s"
								, format_type_be(procStruct->proargtypes[i]))));
					fmgr_info_cxt(typeStruct->typoutput, &prec->argconv[i], TopMemoryContext);
					prec->argtypioparam[i] = getTypeIOParam(typeTup);
					ReleaseSysCache(typeTup);
					break;
				}
		}

		source_dat = SysCacheGetAttr(PROCOID, procTup, Anum_pg_proc_prosrc, &source_isnull);
		if (source_isnull)
			elog(ERROR, "procedure source is null");
		source_text = DatumGetCString(DirectFunctionCall1(textout, source_dat));
		source_ptr = 0;
		source_lno = 1;
		read_eval_procedure_source(procind_num);
		pfree(source_text);
		source_text = "";
		source_ptr = 0;
		source_lno = 0;
	}

	ReleaseSysCache(procTup);
	return	procind_num;
}

static void
set_proc_args(int prono, FunctionCallInfo fcinfo)
{
	struct PROCREC *prec = &plrhz_procrec[prono];
	int i;

	proc_argcnt = prec->nargs;
	for (i = 0; i < proc_argcnt; ++i) {
		proc_arg_isnull[i] = PG_ARGISNULL(i);
		if (!proc_arg_isnull[i])
			switch (prec->argtype[i]) {
			case vt_bool:
				proc_arg[i].v_bool = PG_GETARG_BOOL(i);
				break;
			case vt_char:
				proc_arg[i].v_char = PG_GETARG_CHAR(i);
				break;
			case vt_int2:
				proc_arg[i].v_int2 = PG_GETARG_INT16(i);
				break;
			case vt_int4:
				proc_arg[i].v_int4 = PG_GETARG_INT32(i);
				break;
			case vt_float4:
				proc_arg[i].v_float4 = PG_GETARG_FLOAT4(i);
				break;
			case vt_float8:
				proc_arg[i].v_float8 = PG_GETARG_FLOAT8(i);
				break;
			case vt_generic:
				proc_arg[i].v_generic
					= DatumGetCString(FunctionCall3(&prec->argconv[i]
									, PG_GETARG_DATUM(i)
									, ObjectIdGetDatum(prec->argtypioparam[i])
									, Int32GetDatum(-1)));
				break;
			default:	Assert(0); break;
			}
	}
}

static TupleDesc
context_tupdesc(FunctionCallInfo fcinfo)
{
	ReturnSetInfo *rsinfo;

	rsinfo = (ReturnSetInfo *)fcinfo->resultinfo;
	if (!rsinfo || !IsA(rsinfo, ReturnSetInfo) || rsinfo->expectedDesc == NULL)
		ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED)
			, errmsg("function returning record called in context that cannot accept type record")));
	return	rsinfo->expectedDesc;
}

static Datum
retv_to_datum(int prono, FuncCallContext *funcctx, FunctionCallInfo fcinfo)
{
	struct PROCREC *prec = &plrhz_procrec[prono];
	AttInMetadata *attinmeta;
	HeapTuple tup;

	if (proc_retv_isnull) {
		fcinfo->isnull = true;
		return	(Datum)0;
	}
	switch (prec->rettype) {
	case vt_bool:	return	BoolGetDatum(proc_retv.v_bool);
	case vt_char:	return	CharGetDatum(proc_retv.v_char);
	case vt_int2:	return	Int16GetDatum(proc_retv.v_int2);
	case vt_int4:	return	Int32GetDatum(proc_retv.v_int4);
	case vt_float4:	return	Float4GetDatum(proc_retv.v_float4);
	case vt_float8:	return	Float8GetDatum(proc_retv.v_float8);
	case vt_generic:
		return	FunctionCall3(&prec->retconv
					, CStringGetDatum(proc_retv.v_generic)
					, ObjectIdGetDatum(prec->rettypioparam)
					, Int32GetDatum(-1));
	case vt_record:
		if (prec->retset)
			attinmeta = funcctx->attinmeta;
		else
			attinmeta = TupleDescGetAttInMetadata(context_tupdesc(fcinfo));
		tup = BuildTupleFromCStrings(attinmeta, proc_retv.v_record);
		return	HeapTupleGetDatum(tup);
	default:	return	(Datum)0;
	}
}

static Datum
plrhz_func_handler(PG_FUNCTION_ARGS)
{
	int prono;
	FuncCallContext *funcctx = NULL;
	MemoryContext oldcontext;
	TupleDesc tupdesc;

	if (SPI_connect() != SPI_OK_CONNECT)
		elog(ERROR, "could not connect to SPI manager");
	proc_objnr = prono = evaluate_function_def(fcinfo->flinfo->fn_oid, false);
	if (plrhz_procrec[prono].retset && !SRF_IS_FIRSTCALL()) {
		proc_fctx = funcctx = SRF_PERCALL_SETUP();
		run_procedure(TASK_SRF_NEXT);
	} else {
		set_proc_args(prono, fcinfo);
		if (!plrhz_procrec[prono].retset)
			run_procedure(TASK_APPLY);
		else {
			funcctx = SRF_FIRSTCALL_INIT();
			if (plrhz_procrec[prono].rettype == vt_record) {
				oldcontext = MemoryContextSwitchTo(funcctx->multi_call_memory_ctx);
				tupdesc = CreateTupleDescCopy(context_tupdesc(fcinfo));
				funcctx->attinmeta = TupleDescGetAttInMetadata(tupdesc);
				MemoryContextSwitchTo(oldcontext);
			}
			proc_fctx = funcctx = SRF_PERCALL_SETUP();
			run_procedure(TASK_SRF_FIRST);
		}
	}
	if (SPI_finish() != SPI_OK_FINISH)
		elog(ERROR, "SPI_finish() failed");
	if (!plrhz_procrec[prono].retset)
		PG_RETURN_DATUM(retv_to_datum(prono, funcctx, fcinfo));
	else {
		if (proc_done)
			SRF_RETURN_DONE(funcctx);
		else
			SRF_RETURN_NEXT(funcctx, retv_to_datum(prono, funcctx, fcinfo));
	}
}

static void
make_tuple_attvals(HeapTuple tpl, TupleDesc tupdesc, bool **isnulls, uvalrep **vals)
{
	int i;
	Datum attr;
	Oid typoutput, typioparam;
	bool typisvarlena;

	*isnulls = (bool *)palloc(sizeof(bool) * tdat_tuple_natts);
	*vals = (uvalrep *)palloc(sizeof(uvalrep) * tdat_tuple_natts);
	for (i = 0; i < tdat_tuple_natts; ++i) {
		attr = heap_getattr(tpl, i+1, tupdesc, &(*isnulls)[i]);
		if (!(*isnulls)[i])
			switch (tdat_tuple_attrtypes[i]) {
			case vt_bool:	(*vals)[i].v_bool = (int)DatumGetBool(attr);	break;
			case vt_char:	(*vals)[i].v_char = (int)DatumGetChar(attr);	break;
			case vt_int2:	(*vals)[i].v_int2 = DatumGetInt16(attr);	break;
			case vt_int4:	(*vals)[i].v_int4 = DatumGetInt32(attr);	break;
			case vt_float4:	(*vals)[i].v_float4 = DatumGetFloat4(attr);	break;
			case vt_float8:	(*vals)[i].v_float8 = DatumGetFloat8(attr);	break;
			default:
				getTypeOutputInfo(tupdesc->attrs[i]->atttypid, &typoutput, &typioparam, &typisvarlena);
				(*vals)[i].v_generic
					= DatumGetCString(OidFunctionCall3(typoutput, attr
								, ObjectIdGetDatum(typioparam)
								, Int32GetDatum(tupdesc->attrs[i]->atttypmod)));
				break;
			}
	}
}

static void
set_trigger_params(TriggerData *tdat)
{
	TupleDesc tupdesc;
	int i;

	tdat_event = tdat->tg_event;
	tdat_relation = tdat->tg_relation;
	tupdesc = tdat_relation->rd_att;
	tdat_tuple_natts = tupdesc->natts;
	tdat_tuple_attrtypes = (valtype *)SPI_palloc(sizeof(valtype) * tdat_tuple_natts);
	for (i = 0; i < tdat_tuple_natts; ++i)
		switch (tupdesc->attrs[i]->atttypid) {
		case BOOLOID:	tdat_tuple_attrtypes[i] = vt_bool;	break;
		case CHAROID:	tdat_tuple_attrtypes[i] = vt_char;	break;
		case INT2OID:	tdat_tuple_attrtypes[i] = vt_int2;	break;
		case INT4OID:	tdat_tuple_attrtypes[i] = vt_int4;	break;
		case FLOAT4OID:	tdat_tuple_attrtypes[i] = vt_float4;	break;
		case FLOAT8OID:	tdat_tuple_attrtypes[i] = vt_float8;	break;
		default:	tdat_tuple_attrtypes[i] = vt_generic;	break;
		}
	if (TRIGGER_FIRED_FOR_ROW(tdat->tg_event)) {
		make_tuple_attvals(tdat->tg_trigtuple, tupdesc, &tdat_trigtuple_isnull, &tdat_trigtuple_attrs);
		if (TRIGGER_FIRED_BY_UPDATE(tdat->tg_event))
			make_tuple_attvals(tdat->tg_newtuple, tupdesc, &tdat_newtuple_isnull, &tdat_newtuple_attrs);
	}
	tdat_trigger = tdat->tg_trigger;
}

#define BUFSIZE_INT2	(sizeof("-32768"))
#define BUFSIZE_INT4	(sizeof("-2147483648"))
#define BUFSIZE_FLOAT4	(sizeof("-3.40282e+38"))
#define BUFSIZE_FLOAT8	(sizeof("-1.79769313486231e+308"))

static HeapTuple
make_modified_tuple(valtype *vts, TupleDesc tupdesc)
{
	int i;
	char **vals;

	vals = (char **)palloc(sizeof(char *) * tupdesc->natts);
	for (i = 0; i < tupdesc->natts; ++i) {
		if (trig_rettuple_isnull[i]) {
			vals[i] = NULL;
			continue;
		}
		switch (vts[i]) {
		case vt_bool:
			vals[i] = trig_rettuple_attrs[i].v_bool ? "t" : "f";
			break;
		case vt_char:
			vals[i] = (char *)palloc(2);
			vals[i][0] = trig_rettuple_attrs[i].v_char;
			vals[i][1] = '\0';
			break;
		case vt_int2:
			vals[i] = (char *)palloc(BUFSIZE_INT2);
			snprintf(vals[i], BUFSIZE_INT2, "%d", trig_rettuple_attrs[i].v_int2);
			break;
		case vt_int4:
			vals[i] = (char *)palloc(BUFSIZE_INT4);
			snprintf(vals[i], BUFSIZE_INT4, "%d", trig_rettuple_attrs[i].v_int4);
			break;
		case vt_float4:
			vals[i] = (char *)palloc(BUFSIZE_FLOAT4);
			snprintf(vals[i], BUFSIZE_FLOAT4, "%.5e", trig_rettuple_attrs[i].v_float4);
			break;
		case vt_float8:
			vals[i] = (char *)palloc(BUFSIZE_FLOAT8);
			snprintf(vals[i], BUFSIZE_FLOAT8, "%.14e", trig_rettuple_attrs[i].v_float8);
			break;
		default:
			vals[i] = trig_rettuple_attrs[i].v_generic;
			break;
		}
	}
	return	BuildTupleFromCStrings(TupleDescGetAttInMetadata(tupdesc), vals);
}

static HeapTuple
plrhz_trigger_handler(PG_FUNCTION_ARGS)
{
	TriggerData *tdat;
	HeapTuple rettpl;
	TupleDesc tupdesc;
	valtype *vts;

	if (SPI_connect() != SPI_OK_CONNECT)
		elog(ERROR, "could not connect to SPI manager");
	proc_objnr = evaluate_function_def(fcinfo->flinfo->fn_oid, true);
	tdat = (TriggerData *)fcinfo->context;
	set_trigger_params(tdat);
	vts = tdat_tuple_attrtypes;
	tupdesc = tdat->tg_relation->rd_att;
	if (!TRIGGER_FIRED_BEFORE(tdat->tg_event) || !TRIGGER_FIRED_FOR_ROW(tdat->tg_event))
		rettpl = NULL;
	else if (!TRIGGER_FIRED_BY_UPDATE(tdat->tg_event))
		rettpl = tdat->tg_trigtuple;
	else
		rettpl = tdat->tg_newtuple;
	run_procedure(TASK_TRIGGER);
	if (SPI_finish() != SPI_OK_FINISH)
		elog(ERROR, "SPI_finish() failed");
	if (rettpl)
		switch (trig_action) {
		default:
			break;
		case TRGACT_SKIP:
			rettpl = NULL;
			break;
		case TRGACT_MODIFY:
			rettpl = make_modified_tuple(vts, tupdesc);
			break;
		}
	return	rettpl;
}
