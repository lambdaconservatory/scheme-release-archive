/*
Copyright (C) 1993,96 Inujima, Masaru
This file is a part of rhizhome/kappa, an opus of Qfwfq

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

/* @(#)$Id: rhiz_cnf.h,v 1.2 1996/10/10 08:26:37 qfwfq Exp $ */
/*
 * $Log: rhiz_cnf.h,v $
 * Revision 1.2  1996/10/10 08:26:37  qfwfq
 * Ported to Win32 environment.
 *
 * Revision 1.1  1996/09/06 06:08:13  qfwfq
 * Version 0.20 unix revision is up.
 * Renamed config.h to rhiz_cnf.h for compiler support.
 *
 * Revision 1.2  1996/06/05 05:20:12  qfwfq
 * Add switches concerning IEEE floating point functions.
 *
 * Revision 1.1  93/11/08  13:55:18  qfwfq
 * Initial revision
 * 
 */

/* Constants used by heap management routines. */
#define RK_HEAP_CHUNK_SIZE	0x4000
#define RK_BULK_ALLOC_THRESHOLD	0x400

/* Size of array rk_eval_register */
#define RK_EVAL_REGISTER_SIZE	16

/* Uncomment following if your system's signal handling is broken. */
/* #define RK_OLD_SYSV_SIGNAL */

/* Uncomment following if your libm.a does not provide IEEE 754 support functions */
/* #define RK_NO_IEEE754_SUPPORT */
/* And uncomment following if finite() is available */
/* #define RK_HAS_FINITE */

/* 2 * (this ammount) must fit in process' address space */
#if defined(GO32) || defined(WIN32) || defined(__CYGWIN32__)
#	define RK_PERSISTENT_ALLOC_SIZE	0x10000000
#	define RK_MALLOC_NO_PAGE_ALIGN
#endif

/* Uncomment following to use mblen() to test double byte character */
/* #define RK_USE_LOCALE */

/* And somewhat trivial issue :-) */
#if 0
#	define index strchr
#endif
