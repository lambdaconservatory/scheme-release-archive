/*
Copyright (C) 1997 Inujima, Masaru
This file is a part of rhizhome/kappa, an opus of Qfwfq

Permission to use, copy, modify, and/or distribute this
program for any purpose is hereby granted, provided that
this copyright notice appears in all copies made of this
program.
Fees for distribution or use of this program or derived
materials may only be charged with prior written consent
of the author.
This program is provided "as is" without any express or
implied warranty.
*/

#ifndef lint
static char rcsid[] = "@(#)$Id: ldso.c,v 1.3 1999/02/15 08:04:06 qfwfq Exp $";
#endif
/*
 * $Log: ldso.c,v $
 * Revision 1.3  1999/02/15 08:04:06  qfwfq
 * port to Microsoft C compiler
 *
 * Revision 1.2  1998/07/31 10:38:21  qfwfq
 * In Win32, make method of calling API somewhat more 'legal'
 * Hoping that it makes program more robust.
 *
 * Revision 1.1  1997/10/16 06:24:37  qfwfq
 * Release version 0.40
 *
 */

/*
 * Support for loading shared objects.
 */
#include "rhizome.h"

#include <string.h>

#define ALT_STACK_SIZE		1024	/* this should be sufficient for any architecture */
#define CALLBACK_OBJ_CHUNK	1024	/* somewhat arbitrary parameter */

#if defined(WIN32) || defined(__CYGWIN32__)
#	undef RK_LDSO_DLFCN
#	undef RK_JB_I386BSD
#endif

#if !defined(RK_LDSO_DLFCN) && !(defined(WIN32) || defined(__CYGWIN32__))
#	define NO_LDSO_METHOD
#endif

#if !defined(RK_JB_I386BSD) && !(defined(WIN32) || defined(__CYGWIN32__))
#	define JB_UNKNOWN
#endif

rk_object rk_call_external_proc;

static void
prep_errobj(char *msg)
{
	int len;
	char *s;

	if (!msg || (len = strlen(msg)) == 0 || !(s = malloc(len))) {
		rk_error_obj = RK_SOBJ_UNSPEC;
		return;
	}
	memcpy(s, msg, len);
	if (!(rk_error_obj = RkMakeMallocObject(RK_MALLOC_TAG(len, RK_TCODE_STRING), free, s))) {
		free(s);
		rk_error_obj = RK_SOBJ_UNSPEC;
	}
}

#if defined(NO_LDSO_METHOD) || defined(JB_UNKNOWN)
static char *notimpl_msg = "Feature is not implemented";
#endif

#ifdef NO_LDSO_METHOD
void *
RkLoadSharedObj(char *mname)
{
	prep_errobj(notimpl_msg);
	return	NULL;
}

void
RkUnloadSharedObj(void *handle)
{
	/* Nothing to do */
}

void *
(*RkGetObjEntry(void *handle, char *sym))(void)
{
	prep_errobj(NULL);
	return	NULL;
}
#endif

#ifdef RK_LDSO_DLFCN
#include <dlfcn.h>

void *
RkLoadSharedObj(char *mname)
{
	void *handle;

	if (handle = dlopen(mname, DL_LAZY))
		return	handle;
	prep_errobj(dlerror());
	return	NULL;
}

void
RkUnloadSharedObj(void *handle)
{
	dlclose(handle);
}

void *
(*RkGetObjEntry(void *handle, char *sym))(void)
{
	void *entry;

	if (entry = dlsym(handle, sym))
		return	(void *(*)(void))entry;
	prep_errobj(dlerror());
	return	NULL;
}
#endif

#if defined(WIN32) || defined(__CYGWIN32__)
#include <stdarg.h>
#include <windows.h>

static void
win_err(void)
{
	char buf[11];

	sprintf(buf, "#x%08lX", GetLastError());
	prep_errobj(buf);
}

void *
RkLoadSharedObj(char *mname)
{
	void *handle;

	if (handle = LoadLibraryA(mname))
		return	handle;
	win_err();
	return	NULL;
}

void
RkUnloadSharedObj(void *handle)
{
	FreeLibrary(handle);
}

void *
(*RkGetObjEntry(void *handle, char *sym))(void)
{
	FARPROC entry;

	if (entry = GetProcAddress(handle, sym))
		return	(void *(*)(void))entry;
	win_err();
	return	NULL;
}
#endif

static int (*cfa_func)();
static int cfa_argc;
static long cfa_argv[RK_BULK_ALLOC_THRESHOLD/2];
static int cfa_val;

static rk_object *callback_objects = NULL;
static int callback_obj_alloc = 0, callback_obj_max = 0;
static int callback_obj_free = -1;

static void (*p_traverse)(int, void (*)(rk_object *, void *), void *);

static void
traverse(int persistent_too, void (*scan_fun)(rk_object *, void *), void *cookie)
{
	int i;

	if (persistent_too)
		for (i = 0; i < callback_obj_max; ++i)
			(*scan_fun)(&callback_objects[i], cookie);
	(*p_traverse)(persistent_too, scan_fun, cookie);
}

static int
register_callback_object(void)
{
	rk_object *tmp_array;
	int i;

	if (callback_obj_free == -1) {
		if (!callback_obj_alloc) {
			tmp_array = malloc(CALLBACK_OBJ_CHUNK * sizeof(rk_object));
			p_traverse = rk_traverse_root;
			rk_traverse_root = traverse;
		} else
			tmp_array = realloc(callback_objects
						, (callback_obj_alloc + CALLBACK_OBJ_CHUNK) * sizeof(rk_object));
		if (!tmp_array)
			return	-1;
		tmp_array = &(callback_objects = tmp_array)[callback_obj_alloc];
		for (i = CALLBACK_OBJ_CHUNK; i--; ) {
			tmp_array[i] = RK_MAKEINUM(callback_obj_free);
			callback_obj_free = callback_obj_alloc + i;
		}
		callback_obj_alloc += CALLBACK_OBJ_CHUNK;
	}
	i = callback_obj_free;
	callback_obj_free = RK_GETINUM(callback_objects[i]);
	if (i >= callback_obj_max)
		callback_obj_max = i+1;
	RkWriteCell(&callback_objects[i], rk_eval_register[0]);
	return	i;
}

void
RkDestroyCallbackEntry(void *(*p)(void), int index)
{
	free((void *)p);
	callback_objects[index] = RK_MAKEINUM(callback_obj_free);
	callback_obj_free = index;
}

#ifdef JB_UNKNOWN
void RK_VOLATILE
RkStartExecution((void RK_VOLATILE (*execute)(rk_object)), rk_object proc)
{
	execute(proc);
	abort();
}

static rk_object
call_ext(void)
{
	prep_errobj(notimpl_msg);
	RK_SIGNAL_ERROR(RK_ERROR_DYNLOAD, rk_error_obj);
}

#define INIT_ENTRY_TEMPLATE	((void)0)

void *(*RkMakeCallbackEntry(rk_object proc, int narg, int *index))(void)
{
	return	NULL;
}
#endif

#if defined(RK_JB_I386BSD) || defined(WIN32) || defined(__CYGWIN32__)
# ifndef WIN32
#  include <setjmp.h>
typedef jmp_buf cr_buffer;
#  ifdef RK_JB_I386BSD
#   define CR_CHKPT(jb)		_setjmp(jb)
#   define CR_SWTCH(jb, s)	_longjmp(jb, s)
#  else
#   define CR_CHKPT(jb)		setjmp(jb)
#   define CR_SWTCH(jb, s)	longjmp(jb, s)
#  endif
# else
typedef long cr_buffer[6];
extern int rk_cr_chkpt(cr_buffer);
extern void rk_cr_switch(cr_buffer, int);
#  define CR_CHKPT(jb)		rk_cr_chkpt(jb)
#  define CR_SWTCH(jb, s)	rk_cr_switch(jb, s)
# endif

# if defined(WIN32) || defined(__CYGWIN32__)
#  ifndef __CYGWIN32__
#   define STDCALL	__stdcall
#  endif
#  ifdef __CYGWIN32__
static LPVOID STDCALL (*pConvertThreadToFiber)(LPVOID);
static LPVOID STDCALL (*pCreateFiber)(DWORD, VOID CALLBACK(*)(PVOID), LPVOID);
static VOID STDCALL (*pSwitchToFiber)(LPVOID);
#  else
static LPVOID (STDCALL *pConvertThreadToFiber)(LPVOID);
static LPVOID (STDCALL *pCreateFiber)(DWORD, VOID (CALLBACK *)(PVOID), LPVOID);
static VOID (STDCALL *pSwitchToFiber)(LPVOID);
#  endif
static int fiber_ok = 0;
static int main_fiber_status;
static LPVOID main_fiber, api_fiber;
# endif

#ifdef _MSC_VER
int __declspec(naked)
rk_cr_chkpt(cr_buffer cb)
{
	__asm {
		mov eax,4[esp]
		mov edx,0[esp]
		mov 0[eax],edx
		mov 4[eax],ebx
		mov 8[eax],esp
		mov 12[eax],ebp
		mov 16[eax],esi
		mov 20[eax],edi
		xor eax,eax
		ret
	}
}

void __declspec(naked)
rk_cr_switch(cr_buffer cb, int v)
{
	__asm {
		mov edx,4[esp]
		mov eax,8[esp]
		mov ecx,0[edx]
		mov ebx,4[edx]
		mov esp,8[edx]
		mov ebp,12[edx]
		mov esi,16[edx]
		mov edi,20[edx]
		mov [esp],ecx
		ret
	}
}
#endif

static cr_buffer runmain, *callout;

#ifdef __BORLANDC__
# pragma option -k
#endif

static void RK_VOLATILE
do_call(void)
{
	int i;

# if defined(RK_JB_I386BSD) || defined(__CYGWIN32__)
	for (i = cfa_argc; i-- > 0; )
		asm("pushl %0": : "r"(cfa_argv[i]): "%esp");
	asm("call *%1; movl %%eax, %0": "=r"(cfa_val): "r"(cfa_func): "%eax", "%ecx", "%edx", "cc");
# endif
# if defined(WIN32)
	register long tmp;

	for (i = cfa_argc; i-- > 0; ) {
		tmp = cfa_argv[i];
		__asm { push tmp }
	}
	tmp = (long)cfa_func;
	__asm {
		call tmp
		mov tmp,eax
	}
	cfa_val = tmp;
# endif
# if defined(WIN32) || defined(__CYGWIN32__)
	if (fiber_ok) {
		main_fiber_status = 1;
		pSwitchToFiber(main_fiber);
		CR_SWTCH(*callout, 1);
	} else
		CR_SWTCH(runmain, 1);
# else
	CR_SWTCH(runmain, 1);
# endif
}

#ifdef __BORLANDC__
# pragma option -k.
#endif

# if defined(RK_JB_I386BSD) || defined(WIN32)
#  define JBELT_IP(jb)	((jb)[0])
#  define JBELT_SP(jb)	((jb)[2])
#  define JB_SP_OFFSET	(-3)
# endif
# ifdef __CYGWIN32__
#  define JBELT_IP(jb)	((jb)[8])
#  define JBELT_SP(jb)	((jb)[7])
#  define JB_SP_OFFSET	(-2)
# endif

# if defined(WIN32) || defined(__CYGWIN32__)
static void RK_VOLATILE
start_exec_no_fiber(void RK_VOLATILE (*execute)(rk_object), rk_object proc)
# else
void RK_VOLATILE
RkStartExecution(void RK_VOLATILE (*execute)(rk_object), rk_object proc)
# endif
{
	long alt_stack[ALT_STACK_SIZE];
	cr_buffer inicall;

	CR_CHKPT(runmain);
	alt_stack[ALT_STACK_SIZE-1] = (long)proc;
	alt_stack[ALT_STACK_SIZE-2] = (long)abort;
	JBELT_IP(runmain) = (long)execute;
	JBELT_SP(runmain) = (long)&alt_stack[ALT_STACK_SIZE+JB_SP_OFFSET];
	callout = &inicall;
	if (!CR_CHKPT(inicall))
		CR_SWTCH(runmain, 1);
	do_call();
}

# if defined(WIN32) || defined(__CYGWIN32__)
struct EXEC_DATA { void RK_VOLATILE (*execute)(rk_object); rk_object proc; };

static VOID CALLBACK
main_fiber_proc(PVOID param)
{
	(((struct EXEC_DATA *)param)->execute)(((struct EXEC_DATA *)param)->proc);
	abort();
}

static void RK_VOLATILE
start_exec_fiber(void RK_VOLATILE (*execute)(rk_object), rk_object proc)
{
	struct EXEC_DATA exdata;
	cr_buffer inicall;

	exdata.execute = execute, exdata.proc = proc;
	api_fiber = pConvertThreadToFiber(NULL);
	main_fiber = pCreateFiber(ALT_STACK_SIZE*4, main_fiber_proc, (LPVOID)&exdata);
	pSwitchToFiber(main_fiber);
	callout = &inicall;
	CR_CHKPT(inicall);
	do_call();
}

void RK_VOLATILE
RkStartExecution(void RK_VOLATILE (*execute)(rk_object), rk_object proc)
{
	if (fiber_ok)
		start_exec_fiber(execute, proc);
	else
		start_exec_no_fiber(execute, proc);
}
# endif

static rk_object cb_ret_proc;

static rk_object
run_external(void)
{
	rk_object *cp, proc;
# if defined(WIN32) || defined(__CYGWIN32__)
	register int status;
# endif

# if defined(WIN32) || defined(__CYGWIN32__)
	if (fiber_ok) {
		pSwitchToFiber(api_fiber);
		status = main_fiber_status;
	} else {
		if (!(status = CR_CHKPT(runmain)))
			CR_SWTCH(*callout, 1);
	}
	switch (status) {
# else
	switch (CR_CHKPT(runmain)) {
	case 0:
		CR_SWTCH(*callout, 1);
# endif
	case 1:
		cp = RkAllocCells(4);
		cp[0] = RK_VECTOR_TAG(3, RK_TCODE_EXTARGV);
		cp[1] = (cfa_val&0xffff0000) | RK_MAKEINUM(0);
		cp[2] = RK_MAKEINUM(cfa_val&0xffff);
		cp[3] = RK_DUMMY_OBJ;
		rk_eval_register[0] = (rk_object)cp;
		rk_valid_register = 1;
		RK_PROCEED();
	case 2:
		proc = rk_eval_register[0];
		cp = RkAllocCells(4);
		cp[0] = RK_VECTOR_TAG(3, RK_TCODE_EXTARGV);
		cp[1] = rk_eval_register[2];
		cp[2] = rk_eval_register[3];
		cp[3] = RK_DUMMY_OBJ;
		rk_eval_register[0] = (rk_object)cp;
		rk_valid_register = 2;
		cp = RkAllocCells(6);
		cp[0] = RK_VECTOR_TAG(6, 0);
		cp[1] = cb_ret_proc;
		cp[2] = ((unsigned long)callout&0xffff0000) | RK_MAKEINUM(0);
		cp[3] = RK_MAKEINUM((unsigned long)callout&0xffff);
		cp[4] = (rk_object)rk_continuation;
		cp[5] = RK_DUMMY_OBJ;
		rk_continuation = cp;
		return	proc;
	}
}

static rk_object
call_ext(void)
{
	rk_object *cp;
	int i;

	cp = (rk_object *)rk_eval_register[1];
	cfa_func = (int (*)())((cp[1]&0xffff0000) | (cp[2]>>2));
	cp = &((rk_object *)rk_eval_register[0])[1];
	cfa_argc = cp[-1] >> 13;
	for (i = 0; i < cfa_argc; ++i)
		cfa_argv[i] = (cp[i*2]&0xffff0000) | (cp[i*2+1]>>2);
	return	run_external();
}

static rk_object
cb_ret(void)
{
	if ((rk_eval_register[0] & 7) || ((rk_object *)rk_eval_register[0])[0] != RK_VECTOR_TAG(3, RK_TCODE_EXTARGV))
		RK_SIGNAL_ERROR1(RK_ERROR_DYNLOAD);
	*(unsigned long *)&callout = (rk_continuation[2]&0xffff0000) | (rk_continuation[3]>>2);
	rk_continuation = (rk_object *)rk_continuation[4];
	cfa_func = NULL;
	return	run_external();
}

static char entry_template[] = {
/* 0000 */	0x89, 0xe0,		/* movl %esp,%eax    */
/* 0002 */	0x83, 0xc0, 0x04,	/* addl $4,%eax      */
/* 0005 */	0x50,			/* pushl %eax        */
/* 0006 */	0x68, 0, 0, 0, 0,	/* pushl $<proc>     */	/* proc    = 0x07 */
/* 000b */	0x68, 0, 0, 0, 0,	/* pushl $<index>    */	/* index   = 0x0c */
/* 0010 */	0xb8, 0, 0, 0, 0,	/* movl _run_cb,%eax */	/* _run_cb = 0x11 */
/* 0015 */	0xff, 0xd0,		/* call %eax         */
/* 0017 */	0x83, 0xc4, 0x0c,	/* addl $12,%esp     */
/* 001a */	0xc3,			/* ret               */
/* 001a */   /* 0xc2, */ 0, 0,		/* ret $<n>	     */ /* n       = 0x1b */
/* 001d */	};

#define INIT_ENTRY_TEMPLATE	(*(long *)&entry_template[0x11] = (long)run_cb)

static void *
run_cb(int index, rk_object proc, void *argp)
{
	cr_buffer *parent, callrec;
	rk_object *cp;

	parent = callout;
	callout = &callrec;
	rk_eval_register[0] = proc;
	rk_eval_register[1] = callback_objects[index];
	rk_eval_register[2] = ((unsigned long)argp&0xffff0000) | RK_MAKEINUM(0);
	rk_eval_register[3] = RK_MAKEINUM((unsigned long)argp&0xffff);
	rk_valid_register = 4;
# if defined(WIN32) || defined(__CYGWIN32__)
	if (fiber_ok) {
		main_fiber_status = 2;
		pSwitchToFiber(main_fiber);
		CR_CHKPT(callrec);
	} else {
		if (!CR_CHKPT(callrec))
			CR_SWTCH(runmain, 2);
	}
# else
	if (!CR_CHKPT(callrec))
		CR_SWTCH(runmain, 2);
# endif
	if (cfa_func)
		do_call();
	callout = parent;
	cp = (rk_object *)rk_eval_register[0];
	return	(void *)((cp[1]&0xffff0000) | (cp[2]>>2));
}

void *(*RkMakeCallbackEntry(rk_object proc, int narg, int *index))(void)
{
	char *entry;

	if (!(entry = malloc(32)))
		return	NULL;
	if ((*index = register_callback_object()) == -1) {
		free(entry);
		return	NULL;
	}
	memcpy(entry, entry_template, sizeof entry_template);
	*(long *)&entry[0x07] = (long)proc;
	*(long *)&entry[0x0c] = (long)*index;
# if defined(WIN32) || defined(__CYGWIN32__)
	if (narg >= 0) {
		*(unsigned char *)&entry[0x1a] = 0xc2;
		*(short *)&entry[0x1b] = narg*4;
	}
# endif
	return	(void *(*)(void))entry;
}
#endif

int
RkInitializeLdSo(int index)
{
#if defined(WIN32) || defined(__CYGWIN32__)
	HMODULE hlib_kernel;
#endif

	if (index != -1) {
		INIT_ENTRY_TEMPLATE;
#if defined(WIN32) || defined(__CYGWIN32__)
		if (hlib_kernel = LoadLibrary("kernel32.dll")) {
			*(FARPROC *)&pConvertThreadToFiber = GetProcAddress(hlib_kernel, "ConvertThreadToFiber");
			*(FARPROC *)&pCreateFiber = GetProcAddress(hlib_kernel, "CreateFiber");
			*(FARPROC *)&pSwitchToFiber = GetProcAddress(hlib_kernel, "SwitchToFiber");
			if (pConvertThreadToFiber && pCreateFiber && pSwitchToFiber)
				fiber_ok = 1;
		}
#endif
		rk_call_external_proc = RkRegisterProcedure(index + 0, call_ext);
		cb_ret_proc = RkRegisterProcedure(index + 1, cb_ret);
	}
	return	2;
}
