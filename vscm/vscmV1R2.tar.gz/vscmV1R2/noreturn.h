/*
 * noreturn.h -- Declaration of never-returning functions...
 *
 * (C) m.b (Matthias Blume); HUB; Nov 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: noreturn.h,v 2.3 1994/09/01 20:11:43 blume Exp $
 */

# ifndef NORETURN_H_
# define NORETURN_H_

# if defined (__GNUC__) && defined (__GNUC_MINOR__)

# if __GNUC__ >= 2 && __GNUC_MINOR__ >= 5

# define NORETURN
# define NRUTERON __attribute__ ((noreturn))

# else

# define NORETURN volatile
# define NRUTERON

# endif

# else

# define NORETURN
# define NRUTERON

# endif

# endif
