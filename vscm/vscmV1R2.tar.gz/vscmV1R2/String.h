/*
 * String.h -- Declarations for Scheme Strings
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: String.h,v 2.3 1994/09/01 20:12:36 blume Exp $
 */

# ifndef STRING_H_
# define STRING_H_

# include "storage.h"

typedef
struct ScmString {
  MEM_descriptor _;
  unsigned short length;
  char array[1];
} ScmString;

DCL_MEM_TYPE (String);

# endif
