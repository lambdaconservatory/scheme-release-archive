/*
 * Procedure.h -- Declarations for Scheme Procedures
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: Procedure.h,v 2.3 1994/09/01 20:12:45 blume Exp $
 */

# ifndef PROCEDURE_H_
# define PROCEDURE_H_

# include "storage.h"

typedef
struct ScmProcedure {
  MEM_descriptor _;
  void *env;
  void *code;
} ScmProcedure;

DCL_MEM_TYPE (Procedure);

# endif
