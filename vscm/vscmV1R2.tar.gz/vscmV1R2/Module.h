/*
 * Module.h -- Declarations for Scheme Modules
 *
 * (C) m.b (Matthias Blume); Sep 1994, PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: Module.h,v 1.1 1994/09/14 01:28:55 blume Exp $
 */

# ifndef MODULE_H_
# define MODULE_H_

# include "storage.h"

typedef
struct ScmModule {
  MEM_descriptor _;
  void *signature;
  void *exports;
  unsigned long length;
  void *array[1];
} ScmModule;

DCL_MEM_TYPE (Module);

# define SCM_NEW_MODULE(m,l) \
  (SCM_VNEW (m, Module, l, void *), (m)->length = (l))

# endif
