/*
 * reader.h -- Declarations for Scheme reader
 *
 * (C) m.b (Matthias Blume); Apr 1992, HUB; Mar 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: reader.h,v 2.2 1994/09/01 20:11:33 blume Exp $
 */

# ifndef READER_H_
# define READER_H_

/* returns EOF (like in stdio.h) */
typedef
int (* getc_proc) (void *stream);

/* Must work at least one time (:-) */
typedef
void (* ungetc_proc) (int c, void *stream);

/* returns NULL at end of file */
extern
void *ScmRead (getc_proc, ungetc_proc, void *);

# endif
