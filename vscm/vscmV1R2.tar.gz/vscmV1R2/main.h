#ifndef	MAIN_H__
#define	MAIN_H__

/*
 *	main.h -- 3.1 Jun  6 17:05:31 1990
 *	Copyright (c) 1986-1990 Axel T. Schreiner
 *
 *	argument standards for C++
 *
 * $Id: main.h,v 2.2 1994/09/01 20:11:55 blume Exp $
 */

#define	MAIN	int main (int argc, char * argv[])

#define	OPT	while (--argc > 0)					\
		{   switch (**++argv) {					\
		    _KEY('-')

#define	_KEY(ch)    case (ch):						\
			switch (*++*argv) {				\
			case 0:     --*argv;				\
				    break;				\
			case '-':   if (! (*argv)[1])			\
				    {	++argv, --argc;			\
					break;				\
				    }					\
			default:    do					\
				    {	switch (**argv) {		\
					case 0:

#define	ARG					continue;		\
					case

#define	PARM					if (*++*argv)		\
						    ;			\
						else if (--argc > 0)	\
						    ++argv;		\
						else			\
						{   --*argv, ++argc;	\
							break;		\
						}

#define	NEXTOPT					*argv += strlen(*argv) - 1;

#define	OTHER					continue;		\
					}

#define	KEY(ch)			    _ENDOPT _KEY(ch)

#define	_ENDOPT			    } while (*++*argv);			\
				    continue;				\
			}						\
			break;

#define	ENDOPT			    _ENDOPT				\
		    }							\
		    break;						\
		}

#define	IFANY	if (argc > 1) while (-- argc > 0)			\
		{	static char _any;				\
			if (**++argv == '-'				\
			    && ! _any) switch (*++*argv) {		\
			case 0:		--*argv;			\
					break;				\
			case '-':	if (! (*argv)[1])		\
					{	_any = 1;		\
						continue;		\
					}				\
			default:	do {				\
						switch (**argv)

#define	ANY				} while (*++*argv);		\
					continue;			\
				}

#endif
