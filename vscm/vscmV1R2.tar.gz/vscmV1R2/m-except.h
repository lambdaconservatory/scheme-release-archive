/*
 * m-except.h -- Declarations for Scheme's exception handling
 *
 * (C) m.b (Matthias Blume); Jun 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: m-except.h,v 2.4 1994/09/21 00:02:36 blume Exp $
 */

# ifndef M_EXCEPT_H_
# define M_EXCEPT_H_

# include "noreturn.h"

extern void
  NORETURN ScmRaiseError (void *handler, void *data) NRUTERON;
extern void
  NORETURN ScmReRaiseError (void *handler, void *data, void *cont) NRUTERON;
extern void
  NORETURN ScmRaiseReset (void) NRUTERON;

# endif
