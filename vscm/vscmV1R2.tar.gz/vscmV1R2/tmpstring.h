/*
 * tmpstring.h -- Declarations for temporary string save function
 *
 * (C) m.b (Matthias Blume); Jun 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: tmpstring.h,v 2.3 1994/09/01 20:10:54 blume Exp $
 */

# ifndef TMPSTRING_H_
# define TMPSTRING_H_

# include <stdlib.h>

/* result is only valid until the next call to tmpstring */
extern char *tmpstring (const char *s, unsigned len);

extern void tmpbuf_putc (int c, void *ignore);
extern const char *tmpbuf_get (size_t *len_ptr);
extern void tmpbuf_reset (void);

# endif
