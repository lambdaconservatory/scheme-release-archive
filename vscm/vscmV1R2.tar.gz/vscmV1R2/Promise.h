/*
 * Promise.h -- Declarations for Scheme Promises
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: Promise.h,v 2.3 1994/09/01 20:12:40 blume Exp $
 */

# ifndef PROMISE_H_
# define PROMISE_H_

# include "storage.h"

typedef
struct ScmPromise {
  MEM_descriptor _;
  void *env;		/* NULL, if value available */
  void *code_or_value;
} ScmPromise;

DCL_MEM_TYPE (Promise);

# endif
