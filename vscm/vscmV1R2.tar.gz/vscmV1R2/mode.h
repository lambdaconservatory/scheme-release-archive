/*
 * mode.h -- Declarations for Scheme modes
 *
 * (C) m.b (Matthias Blume); May 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: mode.h,v 2.2 1994/09/01 20:11:48 blume Exp $
 */

# ifndef MODE_H_
# define MODE_H_

enum {
  SCM_INPUT_PORT_MODE,
  SCM_OUTPUT_PORT_MODE,
  SCM_ERROR_HANDLER_MODE,
  SCM_GC_STRATEGY_MODE,
  SCM_INTERRUPT_MODE,
  SCM_TIMER_EXPIRATION_MODE,

  SCM_MODE_CACHE_SIZE
};

# endif
