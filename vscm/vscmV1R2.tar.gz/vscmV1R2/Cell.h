/*
 * Cell.h -- Declarations for Scheme Value Cells
 *
 * (C) m.b (Matthias Blume); Jan 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: Cell.h,v 2.3 1994/09/01 19:35:52 blume Exp $
 */

# ifndef CELL_H_
# define CELL_H_

# include "storage.h"

typedef
struct ScmCell {
  MEM_descriptor _;
  void *item;
} ScmCell;

DCL_MEM_TYPE (Cell);

# endif
