/*
 * realloc.h -- Header file for REALLOC
 *
 * (C) m.b (Matthias Blume); HUB; Nov 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: realloc.h,v 2.2 1994/09/01 20:11:29 blume Exp $
 */

# ifndef REALLOC_H_
# define REALLOC_H_

# ifndef REALLOC

# include <stdlib.h>
extern void *ansi_realloc (void *, size_t);
# define REALLOC ansi_realloc

# endif

# endif
