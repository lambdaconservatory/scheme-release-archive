/*
 * stack-t.h -- Tunable parameters for stacks
 *
 * (C) m.b (Matthias Blume); Apr 1992, HUB; Nov 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: stack-t.h,v 2.4 1994/09/01 20:11:18 blume Exp $
 */

# ifndef STACK_T_H_
# define STACK_T_H_

/* Size increment for stacks maintained by continuations */
# define STACK_SIZE_INCR 16	/* must be a power of two */

/* number of separate ScmCont ``free lists'' (one for each size) */
# define N_FRAME_CACHES   32

# endif
