/*
 * fileno.c -- Implementation of a ``default'' fileno
 *
 * (C) m.b (Matthias Blume); Jan 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: fileno.c,v 2.4 1994/11/12 22:20:34 blume Exp $
 */

# include "rcs.h"
RCSID ("$Id: fileno.c,v 2.4 1994/11/12 22:20:34 blume Exp $")

extern int fileno (void *file);

int fileno (void *file)
{
  return 9999;			/* Cannot figure out more */
}
