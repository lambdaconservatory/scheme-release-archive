/*
 * identifier.h -- Definition of identifying characters for Scheme types
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: identifier.h,v 2.2 1994/09/01 20:12:19 blume Exp $
 */

# ifndef IDENTIFIER_H_
# define IDENTIFIER_H_

# define IDENTIFIER(x) x ## _IDENTIFIER,
enum {
# include "ident.tab"
  IDENTIFIER_MAP_LENGTH
};
# undef IDENTIFIER

# endif
