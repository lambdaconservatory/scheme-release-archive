/*
 * mainloop.h -- Definition of ScmSystemMainLoop
 *
 * (C) m.b (Matthias Blume); Oct 1994, PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: mainloop.h,v 1.1 1994/10/05 00:27:00 blume Exp $
 */

# ifndef MAINLOOP_H_
# define MAINLOOP_H_

extern void *ScmSystemMainLoop;

# endif
