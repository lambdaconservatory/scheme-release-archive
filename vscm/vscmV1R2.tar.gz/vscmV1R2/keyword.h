/*
 * keyword.h -- Declarations for variables, which hold the Scheme keywords
 *
 * (C) m.b (Matthias Blume); Apr 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * $Id: keyword.h,v 2.3 1994/11/09 02:24:39 blume Exp $
 */

# ifndef KEYWORD_H_
# define KEYWORD_H_

typedef
struct ScmKeyword {
  void *ptr;
  const char *name;
} ScmKeyword;

extern ScmKeyword ScmKeyword_array [4];

# define ScmQuasiquotePtr	(ScmKeyword_array[0].ptr)
# define ScmQuotePtr		(ScmKeyword_array[1].ptr)
# define ScmUnquotePtr		(ScmKeyword_array[2].ptr)
# define ScmUnquoteSplicingPtr	(ScmKeyword_array[3].ptr)

extern void ScmInitializeKeywords (void);

# endif
