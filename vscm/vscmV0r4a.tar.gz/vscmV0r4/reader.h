/*
 * reader.h -- Declarations for Scheme reader
 *
 * (C) m.b (Matthias Blume); Apr 1992, HUB; Mar 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) reader.h (C) M.Blume, Princeton University, 2.1"
 */

# ifndef READER_H_
# define READER_H_

/* returns EOF (like in stdio.h) */
typedef
int (* getc_proc) (void *stream);

/* Must work at least one time (:-) */
typedef
void (* ungetc_proc) (int c, void *stream);

/* returns NULL at end of file */
extern
void *ScmRead (getc_proc, ungetc_proc, void *);

# endif
