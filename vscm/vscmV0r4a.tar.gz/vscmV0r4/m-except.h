/*
 * m-except.h -- Declarations for Scheme's exception handling
 *
 * (C) m.b (Matthias Blume); Jun 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) m-except.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef M_EXCEPT_H_
# define M_EXCEPT_H_

# include "noreturn.h"

extern void
  NORETURN ScmRaiseError (void *error_handler, void *error_data) NRUTERON;
extern void NORETURN ScmRaiseReset (void) NRUTERON;

# endif
