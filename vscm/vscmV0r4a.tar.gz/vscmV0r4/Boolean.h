/*
 * Boolean.h -- Declarations for Scheme Booleans (and () + <EOF>)
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) Boolean.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef BOOLEAN_H_
# define BOOLEAN_H_

# include "storage.h"

typedef
struct ScmBoolean {
  MEM_descriptor _;
} ScmBoolean;

DCL_MEM_TYPE (Boolean);

extern ScmBoolean ScmTrue, ScmFalse, ScmNil, ScmEof;

# endif
