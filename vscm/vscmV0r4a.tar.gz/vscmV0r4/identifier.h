/*
 * identifier.h -- Definition of identifying characters for Scheme types
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) identifier.h (C) M.Blume, Princeton University, 2.1"
 */

# ifndef IDENTIFIER_H_
# define IDENTIFIER_H_

# define IDENTIFIER(x) x ## _IDENTIFIER,
enum {
# include "ident.tab"
  IDENTIFIER_MAP_LENGTH
};
# undef IDENTIFIER

# endif
