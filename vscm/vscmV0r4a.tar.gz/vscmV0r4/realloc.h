/*
 * realloc.h -- Header file for REALLOC
 *
 * (C) m.b (Matthias Blume); HUB; Nov 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) realloc.h (C) M.Blume, Princeton University, 2.1"
 */

# ifndef REALLOC_H_
# define REALLOC_H_

# ifndef REALLOC

# include <stdlib.h>
extern void *ansi_realloc (void *, size_t);
# define REALLOC ansi_realloc

# endif

# endif
