/*
 * storage-t.h -- Tunable parameters for storage-module
 *
 * (C) m.b (Matthias Blume); Feb 1992, HUB; Jan 1993, PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) storage-t.h (C) M.Blume, Princeton University, 2.4"
 */

# ifndef STORAGE_T_H_
# define STORAGE_T_H_

# define SIZE_MINIMUM 3
# define HEAP_BLOCK_SIZE 32768	/* (2048) measured in sizeof(align_t) */
# define HEAP_SIZE_INCR 32
# define MIN_HEAP_SIZE	(10*HEAP_BLOCK_SIZE)
# define DUMP_HASHTAB_SIZE 211

# endif
